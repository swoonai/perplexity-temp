#!/usr/bin/env python3
"""
content_generator.py — W6.3 AI Content Generation Pipeline
Takes a keyword cluster + SERP analysis (from W6.1) and generates a
full, ready-to-publish article with FAQ schema and snippet targets.

Usage:
    python3 content_generator.py "best crypto IRA 2026"
    python3 content_generator.py --serp-file serp_results.json --keyword "best crypto IRA 2026"
    python3 content_generator.py --keyword "best gold IRA 2026" --output article.md

Output:
    - Markdown article with proper headings, FAQ section, and snippet targets
    - JSON file with article metadata + JSON-LD schema blocks

Requires:
    OPENAI_API_KEY environment variable
    pip install openai
"""
import os
import sys
import json
import argparse
import datetime
import re
from typing import Optional

try:
    from openai import OpenAI
except ImportError:
    print("ERROR: openai package not installed. Run: pip install openai")
    sys.exit(1)

# ─── Configuration ────────────────────────────────────────────────────────────
OPENAI_API_KEY = os.environ.get("OPENAI_API_KEY")
MODEL = "gpt-4.1-mini"  # Use gpt-4.1-mini for cost efficiency; swap to gpt-4.1 for quality
SITE_NAME = "IRA Research Hub"
SITE_URL = "https://iraresearchhub.com"
SITE_DESCRIPTION = "Independent, unbiased research on Self-Directed IRA providers"
AUTHOR_NAME = "James Mitchell"
AUTHOR_URL = f"{SITE_URL}/author/james-mitchell"

# Affiliate disclosure required on all content
AFFILIATE_DISCLOSURE = (
    "**Affiliate Disclosure:** IRA Research Hub may earn a commission when you "
    "click links to providers on this page. This does not affect our editorial "
    "independence or ratings. [Learn more about how we rate providers](/methodology)."
)

# ─── SERP Data Loading ────────────────────────────────────────────────────────

def load_serp_data(serp_file: str, keyword: str) -> Optional[dict]:
    """Load SERP analysis data for a specific keyword from a JSON file."""
    try:
        with open(serp_file) as f:
            data = json.load(f)
        for result in data.get("results", []):
            if result.get("keyword", "").lower() == keyword.lower():
                return result
    except Exception as e:
        print(f"  [warn] Could not load SERP file: {e}")
    return None


def build_serp_context(serp_data: Optional[dict]) -> str:
    """Convert SERP analysis data into a concise context string for the LLM."""
    if not serp_data:
        return ""

    agg = serp_data.get("aggregate", {})
    lines = [
        f"SERP Analysis for: {serp_data['keyword']}",
        f"Average competitor word count: {agg.get('avg_word_count', 'unknown')}",
        f"FAQ prevalence: {agg.get('faq_prevalence', 'unknown')} competitors use FAQPage schema",
        f"Table prevalence: {agg.get('table_prevalence', 'unknown')} competitors use comparison tables",
        "",
        "Top recurring H2 themes from competitors:",
    ]
    for item in agg.get("top_h2_themes", [])[:10]:
        lines.append(f"  - {item['heading']} (seen in {item['count']} results)")

    lines.append("\nTop entities mentioned by competitors:")
    for item in agg.get("top_entities", [])[:10]:
        lines.append(f"  - {item['entity']} ({item['count']} mentions)")

    lines.append("\nTop competitor pages:")
    for page in serp_data.get("pages", [])[:5]:
        if page.get("fetched"):
            lines.append(
                f"  [{page['serp_position']}] {page['domain']} — "
                f"{page['word_count']} words, "
                f"schemas: {', '.join(page['schema_types']) or 'none'}"
            )
    return "\n".join(lines)


# ─── Content Generation ───────────────────────────────────────────────────────

def generate_outline(client: OpenAI, keyword: str, serp_context: str) -> str:
    """Step 1: Generate a structured content outline."""
    print(f"  [step 1] Generating outline...")

    system_prompt = f"""You are an expert SEO content strategist for {SITE_NAME}, 
an independent research site covering Self-Directed IRA providers (Crypto IRAs and Gold/Precious Metals IRAs).

Your content must:
- Be genuinely helpful, accurate, and unbiased
- Follow Google's E-E-A-T guidelines (Experience, Expertise, Authoritativeness, Trustworthiness)
- Include comparison tables, FAQ sections, and snippet-optimized answers
- Target financial investors researching retirement account options
- Include affiliate CTAs naturally without being salesy
- Comply with financial content best practices (include disclaimers, not financial advice)

Site: {SITE_URL}
Author: {AUTHOR_NAME}"""

    user_prompt = f"""Create a detailed content outline for an article targeting the keyword: "{keyword}"

{serp_context if serp_context else "No SERP data available — use your knowledge of this topic."}

The outline should:
1. Include a compelling H1 title with the target keyword
2. Have 6-10 H2 sections covering: overview, top picks, comparison table, fees, how to choose, FAQ
3. Note which sections should include: comparison tables, callout boxes, schema markup types
4. Specify target word count per section
5. List 5-8 FAQ questions to answer
6. Suggest 3 internal links to related pages on iraresearchhub.com
7. Suggest the primary CTA (which provider to recommend)

Return the outline as structured markdown."""

    response = client.chat.completions.create(
        model=MODEL,
        messages=[
            {"role": "system", "content": system_prompt},
            {"role": "user", "content": user_prompt},
        ],
        temperature=0.3,
        max_tokens=2000,
    )
    return response.choices[0].message.content


def generate_article(client: OpenAI, keyword: str, outline: str, serp_context: str) -> str:
    """Step 2: Generate the full article from the outline."""
    print(f"  [step 2] Generating full article...")

    system_prompt = f"""You are an expert financial content writer for {SITE_NAME}.

Writing guidelines:
- Write in a clear, authoritative, but accessible tone for retail investors aged 45-65
- Use "we" to refer to IRA Research Hub's research team
- Always include the affiliate disclosure at the top
- Never give specific financial advice — always say "consult a financial advisor"
- Use comparison tables with markdown pipe syntax
- Bold key terms on first use
- Include a "Bottom Line" callout box at the end of major sections
- Write FAQ answers as direct, snippet-optimized responses (2-4 sentences each)
- Target keyword density: mention the primary keyword naturally 3-5 times
- Include the current year (2026) in time-sensitive claims"""

    user_prompt = f"""Write a complete, publication-ready article for the keyword: "{keyword}"

Use this outline as your guide:
{outline}

SERP context (what competitors cover):
{serp_context if serp_context else "N/A"}

Requirements:
- Start with the affiliate disclosure
- Include a TL;DR / quick summary box near the top
- Include at least one comparison table
- End with a proper FAQ section (use H2 "Frequently Asked Questions")
- Include a "Not Financial Advice" disclaimer at the bottom
- Target 1,800-2,500 words total
- Use markdown formatting throughout

Write the complete article now:"""

    response = client.chat.completions.create(
        model=MODEL,
        messages=[
            {"role": "system", "content": system_prompt},
            {"role": "user", "content": user_prompt},
        ],
        temperature=0.4,
        max_tokens=4000,
    )
    return response.choices[0].message.content


def generate_schema(client: OpenAI, keyword: str, article: str) -> dict:
    """Step 3: Generate JSON-LD schema markup for the article."""
    print(f"  [step 3] Generating JSON-LD schema...")

    # Extract FAQ questions from the article
    faq_pattern = re.compile(r"#{1,3}\s*(.+\?)\s*\n+([\s\S]+?)(?=\n#{1,3}|\Z)", re.MULTILINE)
    faq_matches = faq_pattern.findall(article)
    faq_items = []
    for question, answer in faq_matches[:8]:
        answer_clean = re.sub(r"[#*`]", "", answer).strip()[:500]
        if len(answer_clean) > 20:
            faq_items.append({
                "@type": "Question",
                "name": question.strip(),
                "acceptedAnswer": {
                    "@type": "Answer",
                    "text": answer_clean,
                },
            })

    # Extract title from article
    title_match = re.search(r"^#\s+(.+)$", article, re.MULTILINE)
    title = title_match.group(1) if title_match else keyword

    now = datetime.datetime.utcnow()
    schema_blocks = []

    # Article schema
    schema_blocks.append({
        "@context": "https://schema.org",
        "@type": "Article",
        "headline": title,
        "description": f"Independent research and comparison of {keyword} — unbiased ratings, fees, and expert analysis.",
        "author": {
            "@type": "Person",
            "name": AUTHOR_NAME,
            "url": AUTHOR_URL,
        },
        "publisher": {
            "@type": "Organization",
            "name": SITE_NAME,
            "url": SITE_URL,
            "logo": {
                "@type": "ImageObject",
                "url": f"{SITE_URL}/assets/logos/logo-dark.png",
            },
        },
        "datePublished": now.strftime("%Y-%m-%d"),
        "dateModified": now.strftime("%Y-%m-%d"),
        "mainEntityOfPage": {
            "@type": "WebPage",
            "@id": f"{SITE_URL}/",
        },
    })

    # FAQPage schema
    if faq_items:
        schema_blocks.append({
            "@context": "https://schema.org",
            "@type": "FAQPage",
            "mainEntity": faq_items,
        })

    return {"schema_blocks": schema_blocks, "faq_count": len(faq_items)}


def generate_metadata(client: OpenAI, keyword: str, article: str) -> dict:
    """Step 4: Generate SEO metadata (title tag, meta description, slug)."""
    print(f"  [step 4] Generating SEO metadata...")

    response = client.chat.completions.create(
        model=MODEL,
        messages=[
            {
                "role": "system",
                "content": "You are an SEO specialist. Return ONLY valid JSON, no markdown.",
            },
            {
                "role": "user",
                "content": f"""Generate SEO metadata for this article about "{keyword}".

Return JSON with these fields:
- title_tag: SEO title (50-60 chars, include keyword + year 2026)
- meta_description: Meta description (150-160 chars, compelling, include keyword)
- slug: URL slug (lowercase, hyphens, no year unless needed for disambiguation)
- og_title: Open Graph title (can be slightly longer/more compelling than title_tag)
- og_description: OG description (same as meta_description is fine)
- primary_keyword: The exact primary keyword
- secondary_keywords: Array of 3-5 related keywords to target

Article excerpt:
{article[:500]}""",
            },
        ],
        temperature=0.2,
        max_tokens=500,
    )

    try:
        raw = response.choices[0].message.content.strip()
        # Strip markdown code fences if present
        raw = re.sub(r"^```json\s*|^```\s*|\s*```$", "", raw, flags=re.MULTILINE).strip()
        return json.loads(raw)
    except Exception:
        return {
            "title_tag": f"{keyword.title()} — IRA Research Hub",
            "meta_description": f"Independent research on {keyword}. Compare fees, features, and ratings.",
            "slug": re.sub(r"[^a-z0-9]+", "-", keyword.lower()).strip("-"),
            "primary_keyword": keyword,
        }


# ─── Main ─────────────────────────────────────────────────────────────────────

def main():
    parser = argparse.ArgumentParser(
        description="AI Content Generation Pipeline — W6.3 (iraresearchhub.com)"
    )
    parser.add_argument("keyword", nargs="?", help="Target keyword for content generation")
    parser.add_argument("--serp-file", help="Path to SERP analysis JSON from serp_scraper.py")
    parser.add_argument("--output", help="Output markdown file path (default: <slug>.md)")
    parser.add_argument("--output-dir", default=".", help="Output directory for generated files")
    parser.add_argument("--model", default=MODEL, help=f"OpenAI model to use (default: {MODEL})")
    args = parser.parse_args()

    if not args.keyword:
        parser.print_help()
        sys.exit(1)

    if not OPENAI_API_KEY:
        print("ERROR: OPENAI_API_KEY environment variable not set")
        sys.exit(1)

    global MODEL
    MODEL = args.model

    client = OpenAI(api_key=OPENAI_API_KEY)
    keyword = args.keyword

    print(f"\nAI Content Generation Pipeline — W6.3")
    print(f"Date: {datetime.datetime.utcnow().strftime('%Y-%m-%d %H:%M UTC')}")
    print(f"Keyword: {keyword!r}")
    print(f"Model: {MODEL}")

    # Load SERP context if available
    serp_data = None
    if args.serp_file:
        serp_data = load_serp_data(args.serp_file, keyword)
        if serp_data:
            print(f"  Loaded SERP data: {serp_data['pages_fetched']} pages analyzed")
        else:
            print(f"  No SERP data found for this keyword — generating without context")
    serp_context = build_serp_context(serp_data)

    # Step 1: Outline
    outline = generate_outline(client, keyword, serp_context)

    # Step 2: Full article
    article = generate_article(client, keyword, outline, serp_context)

    # Step 3: Schema
    schema_result = generate_schema(client, keyword, article)

    # Step 4: Metadata
    metadata = generate_metadata(client, keyword, article)

    # Determine output paths
    slug = metadata.get("slug", re.sub(r"[^a-z0-9]+", "-", keyword.lower()).strip("-"))
    os.makedirs(args.output_dir, exist_ok=True)
    md_path = args.output or os.path.join(args.output_dir, f"{slug}.md")
    json_path = os.path.join(args.output_dir, f"{slug}.json")

    # Build final markdown with frontmatter
    schema_json = json.dumps(schema_result["schema_blocks"], indent=2)
    frontmatter = f"""---
title: "{metadata.get('title_tag', keyword)}"
description: "{metadata.get('meta_description', '')}"
slug: "{slug}"
keyword: "{keyword}"
author: "{AUTHOR_NAME}"
date: "{datetime.datetime.utcnow().strftime('%Y-%m-%d')}"
schema: |
{chr(10).join('  ' + line for line in schema_json.splitlines())}
---

"""
    final_markdown = frontmatter + article

    # Save markdown
    with open(md_path, "w") as f:
        f.write(final_markdown)

    # Save full JSON output (for content evaluation pipeline)
    full_output = {
        "pipeline": "content_generator",
        "version": "W6.3",
        "generated_at": datetime.datetime.utcnow().isoformat(),
        "keyword": keyword,
        "model": MODEL,
        "metadata": metadata,
        "outline": outline,
        "article": article,
        "schema": schema_result,
        "word_count": len(re.findall(r"\b\w+\b", article)),
        "serp_context_used": bool(serp_data),
    }
    with open(json_path, "w") as f:
        json.dump(full_output, f, indent=2)

    print(f"\n{'='*60}")
    print(f"✅ Content generation complete")
    print(f"   Keyword: {keyword}")
    print(f"   Word count: {full_output['word_count']}")
    print(f"   FAQ items: {schema_result['faq_count']}")
    print(f"   Markdown: {md_path}")
    print(f"   JSON: {json_path}")
    print(f"{'='*60}")


if __name__ == "__main__":
    main()
