#!/usr/bin/env python3
"""
IRA Research Hub — Nightly Revert Detection Audit
==================================================
Checks 18 critical data points across the repository:
  BlockTrust IRA (Crypto IRA):
    1.  custodian = "American Estate & Trust"
    2.  transaction_fee contains "0.14%" and "0.4%"
    3.  score_overall = 9.6
    4.  min_investment contains "No Minimum" and "$20,000"
    5.  annual_fee contains "$250" and "$0"
    6.  BlockTrust is #1 on BestCryptoIRAPage
    7.  BlockTrust is #1 on BestBitcoinIRAPage
    8.  BlockTrust is #1 on BestCryptoIRA2026Page
    9.  BlockTrust score_overall=9.6 in seed_providers.py
   10.  BlockTrust rank_overall=1 in seed_providers.py
   11.  BlockTrust custodian="American Estate & Trust" in seed_providers.py
   12.  BlockTrust transaction_fee correct in seed_providers.py
   13.  BlockTrust min_investment correct in seed_providers.py
  Genesis Gold Group (Gold IRA):
   14.  Genesis Gold Group is #1 on BestGoldIRAPage
   15.  Genesis Gold Group is #1 on BestPreciousMetalsIRAPage
   16.  Genesis Gold Group is #1 on PreciousMetalsIRAPage
   17.  Genesis Gold Group score_overall=9.4 in seed_providers.py
   18.  Genesis Gold Group rank_overall=1 in seed_providers.py
"""
import os
import re
import sys

REPO  = "/home/ubuntu/Gggbt-full"
PAGES = os.path.join(REPO, "frontend/src/pages")
SEED  = os.path.join(REPO, "backend/scripts/seed_providers.py")

failures = []
passes   = []

def check(name, condition, detail=""):
    if condition:
        passes.append(f"  PASS  [{name}]{(' — ' + detail) if detail else ''}")
    else:
        failures.append(f"  FAIL  [{name}]{(' — ' + detail) if detail else ''}")

def read(path):
    with open(path, "r", encoding="utf-8") as f:
        return f.read()

# ── Seed file checks ─────────────────────────────────────────────────────────
seed = read(SEED)

# Extract BlockTrust IRA block from seed
bt_match = re.search(
    r'"slug":\s*"blocktrust-ira".*?"logo_url":[^\}]+\}',
    seed, re.DOTALL
)
bt_block = bt_match.group(0) if bt_match else ""

# Extract Genesis Gold Group block from seed
gg_match = re.search(
    r'"slug":\s*"genesis-gold-group".*?"logo_url":[^\}]+\}',
    seed, re.DOTALL
)
gg_block = gg_match.group(0) if gg_match else ""

# Check 9: BlockTrust score_overall=9.6 in seed
check("9_bt_seed_score",
      bool(re.search(r'"score_overall":\s*9\.6', bt_block)),
      "BlockTrust score_overall=9.6 in seed_providers.py")

# Check 10: BlockTrust rank_overall=1 in seed
check("10_bt_seed_rank",
      bool(re.search(r'"rank_overall":\s*1', bt_block)),
      "BlockTrust rank_overall=1 in seed_providers.py")

# Check 11: BlockTrust custodian in seed
check("11_bt_seed_custodian",
      "American Estate & Trust" in bt_block,
      "BlockTrust custody_provider='American Estate & Trust' in seed_providers.py")

# Check 12: BlockTrust transaction_fee in seed
check("12_bt_seed_txfee",
      bool(re.search(r'0\.4.*0\.14|0\.14.*0\.4', bt_block)),
      "BlockTrust transaction_fee contains 0.14% and 0.4% in seed_providers.py")

# Check 13: BlockTrust min_investment in seed
check("13_bt_seed_mininv",
      bool(re.search(r'No Minimum', bt_block)) and bool(re.search(r'20,000', bt_block)),
      "BlockTrust min_investment='No Minimum.../$20,000' in seed_providers.py")

# Check 17: Genesis score_overall=9.4 in seed
check("17_gg_seed_score",
      bool(re.search(r'"score_overall":\s*9\.4', gg_block)),
      "Genesis Gold Group score_overall=9.4 in seed_providers.py")

# Check 18: Genesis rank_overall=1 in seed
check("18_gg_seed_rank",
      bool(re.search(r'"rank_overall":\s*1', gg_block)),
      "Genesis Gold Group rank_overall=1 in seed_providers.py")

# ── BlockTrust Review Page checks ────────────────────────────────────────────
bt_review = read(os.path.join(PAGES, "BlockTrustReviewPage.tsx"))

# Check 1: custodian = "American Estate & Trust"
check("1_bt_custodian",
      "American Estate & Trust" in bt_review,
      "BlockTrust custodian='American Estate & Trust' in BlockTrustReviewPage.tsx")

# Check 2: transaction_fee contains 0.14% and 0.4%
check("2_bt_txfee",
      bool(re.search(r'0\.14', bt_review)) and bool(re.search(r'0\.4', bt_review)),
      "BlockTrust transaction_fee 0.14%/0.4% in BlockTrustReviewPage.tsx")

# Check 3: score_overall = 9.6
check("3_bt_score",
      bool(re.search(r'9\.6', bt_review)),
      "BlockTrust score 9.6 present in BlockTrustReviewPage.tsx")

# Check 4: min_investment contains "No Minimum" and "$20,000"
check("4_bt_mininv",
      bool(re.search(r'No Minimum', bt_review)) and bool(re.search(r'20,000', bt_review)),
      "BlockTrust min_investment 'No Minimum'/'$20,000' in BlockTrustReviewPage.tsx")

# Check 5: annual_fee contains "$250" and "$0"
check("5_bt_annualfee",
      bool(re.search(r'\$250', bt_review)) and bool(re.search(r'\$0', bt_review)),
      "BlockTrust annual_fee '$250'/'$0' in BlockTrustReviewPage.tsx")

# ── Crypto IRA ranking pages ──────────────────────────────────────────────────
def check_blocktrust_first(page_file, check_num, label):
    """
    Check that BlockTrust IRA is ranked #1 on the given page.
    Handles multiple patterns:
      - providerLinks array with slug:'blocktrust-ira' as first entry
      - JSON-LD "position":1 with BlockTrust name
      - rank_overall:1 near blocktrust
      - id:1 near blocktrust in inline data
      - blocktrust appears before competitors in the file
    """
    page = read(os.path.join(PAGES, page_file))

    # Pattern 1: providerLinks/providers array — blocktrust-ira slug appears before competitors
    # Find first occurrence of blocktrust slug vs competitor slugs
    bt_slug_pos = page.find("blocktrust-ira")
    comp_slugs = ["bitcoin-ira", "itrustcapital", "alto-crypto-ira", "bitira",
                  "swan-bitcoin-ira", "rocket-dollar", "unchained-ira"]
    first_comp_slug = min((page.find(c) for c in comp_slugs if page.find(c) != -1), default=999999)

    # Pattern 2: JSON-LD "position":1 + BlockTrust name nearby
    pos1_bt = bool(re.search(
        r'"position":\s*1\b[^}]{0,200}BlockTrust|BlockTrust[^}]{0,200}"position":\s*1\b',
        page, re.DOTALL
    ))

    # Pattern 3: rank_overall:1 near blocktrust in first 5000 chars
    rank1_bt = bool(re.search(
        r'blocktrust.{0,200}rank_overall.{0,20}:\s*1|rank_overall.{0,20}:\s*1.{0,200}blocktrust',
        page[:5000], re.DOTALL | re.IGNORECASE
    ))

    # Pattern 4: id:1 near blocktrust in inline data (first 5000 chars)
    id1_bt = bool(re.search(
        r'\bid:\s*1\b.{0,200}blocktrust|blocktrust.{0,200}\bid:\s*1\b',
        page[:5000], re.DOTALL | re.IGNORECASE
    ))

    ok = (bt_slug_pos != -1 and bt_slug_pos < first_comp_slug) or pos1_bt or rank1_bt or id1_bt
    check(f"{check_num}_{label}", ok, f"BlockTrust IRA is #1 on {page_file}")

check_blocktrust_first("BestCryptoIRAPage.tsx",      "6_bt_cryptopage",   "bt_cryptopage")
check_blocktrust_first("BestBitcoinIRAPage.tsx",     "7_bt_bitcoinpage",  "bt_bitcoinpage")
check_blocktrust_first("BestCryptoIRA2026Page.tsx",  "8_bt_crypto2026",   "bt_crypto2026")

# ── Gold IRA ranking pages ────────────────────────────────────────────────────
def check_genesis_first(page_file, check_num, label):
    """
    Check that Genesis Gold Group is ranked #1 on the given page.
    Handles multiple patterns:
      - providerLinks array: slug:'genesis-gold-group' as first entry (before competitors)
      - rank:'#1' immediately after genesis-gold-group slug
      - JSON-LD "position":1 + Genesis name nearby
      - Genesis slug appears before competitor slugs
    """
    page = read(os.path.join(PAGES, page_file))

    # Pattern 1: genesis-gold-group slug appears before competitor slugs
    gg_slug_pos = page.find("genesis-gold-group")
    comp_slugs = ["augusta-precious-metals", "goldco", "birch-gold-group",
                  "american-hartford-gold", "noble-gold", "patriot-gold"]
    first_comp_slug = min((page.find(c) for c in comp_slugs if page.find(c) != -1), default=999999)

    # Pattern 2: rank:'#1' within 200 chars of genesis-gold-group
    rank1_gg = bool(re.search(
        r"genesis-gold-group.{0,200}rank.*?'#1'|rank.*?'#1'.{0,200}genesis-gold-group",
        page[:2000], re.DOTALL
    ))

    # Pattern 3: JSON-LD "position":1 + Genesis name nearby
    pos1_gg = bool(re.search(
        r'"position":\s*1\b[^}]{0,200}Genesis|Genesis[^}]{0,200}"position":\s*1\b',
        page, re.DOTALL
    ))

    ok = (gg_slug_pos != -1 and gg_slug_pos < first_comp_slug) or rank1_gg or pos1_gg
    check(f"{check_num}_{label}", ok, f"Genesis Gold Group is #1 on {page_file}")

check_genesis_first("BestGoldIRAPage.tsx",           "14_gg_goldpage",    "gg_goldpage")
check_genesis_first("BestPreciousMetalsIRAPage.tsx", "15_gg_pmpage",      "gg_pmpage")
check_genesis_first("PreciousMetalsIRAPage.tsx",     "16_gg_pmirapage",   "gg_pmirapage")

# ── Report ────────────────────────────────────────────────────────────────────
total = len(passes) + len(failures)
print(f"\n{'='*60}")
print(f"IRA Research Hub — Nightly Audit Report")
print(f"{'='*60}")
print(f"Checks: {total} total | {len(passes)} passed | {len(failures)} failed")
print()
for p in passes:
    print(p)
for f in failures:
    print(f)
print(f"\n{'='*60}")

if failures:
    print(f"\n❌ AUDIT FAILED: {len(failures)} check(s) failed. Auto-fix required.")
    sys.exit(1)
else:
    print(f"\n✅ AUDIT PASSED: All {total} critical data points verified.")
    sys.exit(0)
