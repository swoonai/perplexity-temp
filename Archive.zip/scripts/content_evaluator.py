#!/usr/bin/env python3
"""
content_evaluator.py — W6.4 Content Evaluation Loop
Scores generated content against top-5 competitors and iterates until
the quality threshold is met. Acts as the quality gate before publication.

Usage:
    python3 content_evaluator.py --content article.json --serp serp_results.json
    python3 content_evaluator.py --content article.json --keyword "best crypto IRA 2026"
    python3 content_evaluator.py --content article.md --auto-improve --max-iterations 3

Output:
    - Quality score report (JSON)
    - Improved article (if --auto-improve is set)
    - PASS/FAIL gate result (exit code 0 = pass, 1 = fail)

Requires:
    OPENAI_API_KEY environment variable
"""
import os
import sys
import json
import re
import argparse
import datetime
from typing import Optional

try:
    from openai import OpenAI
except ImportError:
    print("ERROR: openai package not installed. Run: pip install openai")
    sys.exit(1)

# ─── Configuration ────────────────────────────────────────────────────────────
OPENAI_API_KEY = os.environ.get("OPENAI_API_KEY")
MODEL = "gpt-4.1-mini"

# Quality gate thresholds
QUALITY_THRESHOLD = 75          # Minimum score to pass (out of 100)
MAX_ITERATIONS = 3              # Max improvement iterations before giving up

# Scoring weights (must sum to 100)
SCORING_WEIGHTS = {
    "topical_coverage":    20,   # Does it cover the key topics competitors cover?
    "content_depth":       20,   # Word count, detail level, unique insights
    "eeat_signals":        20,   # E-E-A-T: author, citations, disclaimers, expertise
    "structure_ux":        15,   # Headings, tables, FAQ, readability
    "keyword_optimization": 10,  # Keyword usage, LSI terms, snippet targeting
    "schema_markup":       10,   # JSON-LD schema types present
    "affiliate_compliance":  5,  # Disclosure, not-financial-advice disclaimer
}

# ─── Scoring Functions ────────────────────────────────────────────────────────

def score_structure(article_text: str) -> tuple[int, list[str]]:
    """Score article structure heuristically (no LLM needed)."""
    issues = []
    score = 100

    # Word count
    words = re.findall(r"\b\w+\b", article_text)
    wc = len(words)
    if wc < 1000:
        score -= 30
        issues.append(f"Word count too low: {wc} (target: 1800+)")
    elif wc < 1500:
        score -= 15
        issues.append(f"Word count below target: {wc} (target: 1800+)")
    elif wc > 4000:
        score -= 5
        issues.append(f"Word count very high: {wc} — consider splitting")

    # Headings
    h2_count = len(re.findall(r"^##\s", article_text, re.MULTILINE))
    h3_count = len(re.findall(r"^###\s", article_text, re.MULTILINE))
    if h2_count < 4:
        score -= 15
        issues.append(f"Too few H2 headings: {h2_count} (target: 6+)")
    if h3_count < 2:
        score -= 5
        issues.append(f"Too few H3 subheadings: {h3_count}")

    # Table
    if "|" not in article_text or article_text.count("|") < 10:
        score -= 15
        issues.append("Missing comparison table (markdown pipe table required)")

    # FAQ section
    if "frequently asked questions" not in article_text.lower() and "## faq" not in article_text.lower():
        score -= 10
        issues.append("Missing FAQ section")
    else:
        faq_questions = len(re.findall(r"\?", article_text[article_text.lower().find("faq"):]))
        if faq_questions < 3:
            score -= 5
            issues.append(f"FAQ section has too few questions: {faq_questions}")

    # Affiliate disclosure
    if "affiliate" not in article_text.lower():
        score -= 10
        issues.append("Missing affiliate disclosure")

    # Not financial advice disclaimer
    if "not financial advice" not in article_text.lower() and "financial advisor" not in article_text.lower():
        score -= 10
        issues.append("Missing financial advice disclaimer")

    return max(0, score), issues


def score_with_llm(client: OpenAI, article_text: str, serp_context: str, keyword: str) -> dict:
    """Use LLM to score topical coverage, depth, E-E-A-T, and keyword optimization."""
    print(f"  [eval] Running LLM quality evaluation...")

    prompt = f"""You are a senior SEO content auditor evaluating an article for the keyword: "{keyword}"

SERP CONTEXT (what top competitors cover):
{serp_context if serp_context else "Not available — evaluate based on your knowledge of this topic."}

ARTICLE TO EVALUATE:
---
{article_text[:6000]}
---

Score the article on each dimension (0-100) and provide specific, actionable feedback.
Return ONLY valid JSON (no markdown fences) with this exact structure:
{{
  "topical_coverage": {{
    "score": <0-100>,
    "feedback": "<what topics are missing or well-covered>",
    "missing_topics": ["<topic1>", "<topic2>"]
  }},
  "content_depth": {{
    "score": <0-100>,
    "feedback": "<assessment of depth, uniqueness, data points>",
    "suggestions": ["<improvement1>", "<improvement2>"]
  }},
  "eeat_signals": {{
    "score": <0-100>,
    "feedback": "<E-E-A-T assessment>",
    "missing_signals": ["<signal1>", "<signal2>"]
  }},
  "keyword_optimization": {{
    "score": <0-100>,
    "feedback": "<keyword usage assessment>",
    "lsi_terms_missing": ["<term1>", "<term2>"]
  }},
  "overall_assessment": "<2-3 sentence overall quality assessment>",
  "top_3_improvements": ["<improvement1>", "<improvement2>", "<improvement3>"]
}}"""

    response = client.chat.completions.create(
        model=MODEL,
        messages=[
            {"role": "system", "content": "You are an expert SEO content auditor. Return only valid JSON."},
            {"role": "user", "content": prompt},
        ],
        temperature=0.1,
        max_tokens=1500,
    )

    raw = response.choices[0].message.content.strip()
    raw = re.sub(r"^```json\s*|^```\s*|\s*```$", "", raw, flags=re.MULTILINE).strip()
    try:
        return json.loads(raw)
    except Exception as e:
        print(f"  [warn] Could not parse LLM evaluation JSON: {e}")
        return {}


def compute_final_score(structure_score: int, llm_scores: dict) -> tuple[int, dict]:
    """Compute weighted final score from structure + LLM evaluations."""
    weights = SCORING_WEIGHTS
    scores = {}

    # Structure & UX (heuristic)
    scores["structure_ux"] = structure_score

    # LLM-evaluated dimensions
    scores["topical_coverage"] = llm_scores.get("topical_coverage", {}).get("score", 50)
    scores["content_depth"] = llm_scores.get("content_depth", {}).get("score", 50)
    scores["eeat_signals"] = llm_scores.get("eeat_signals", {}).get("score", 50)
    scores["keyword_optimization"] = llm_scores.get("keyword_optimization", {}).get("score", 50)

    # Schema markup (heuristic)
    scores["schema_markup"] = 80  # Will be overridden if we have schema data

    # Affiliate compliance (heuristic — already in structure check)
    scores["affiliate_compliance"] = 100

    # Weighted average
    total = sum(scores.get(dim, 50) * weight for dim, weight in weights.items()) // 100
    return total, scores


def improve_article(client: OpenAI, article_text: str, issues: list[str],
                    llm_feedback: dict, keyword: str) -> str:
    """Use LLM to improve the article based on evaluation feedback."""
    print(f"  [improve] Generating improved version...")

    top_improvements = llm_feedback.get("top_3_improvements", [])
    all_issues = issues + top_improvements

    prompt = f"""Improve this article about "{keyword}" based on the following quality issues:

ISSUES TO FIX:
{chr(10).join(f'- {issue}' for issue in all_issues[:10])}

ORIGINAL ARTICLE:
---
{article_text}
---

Rewrite the full article addressing all the issues above. Keep the same overall structure
but improve depth, add missing topics, strengthen E-E-A-T signals, and ensure all
compliance requirements are met. Return only the improved article in markdown format."""

    response = client.chat.completions.create(
        model=MODEL,
        messages=[
            {"role": "system", "content": "You are an expert financial content writer. Return only the improved article in markdown."},
            {"role": "user", "content": prompt},
        ],
        temperature=0.4,
        max_tokens=5000,
    )
    return response.choices[0].message.content


# ─── Main Evaluation Loop ─────────────────────────────────────────────────────

def evaluate_and_gate(
    article_text: str,
    keyword: str,
    serp_context: str = "",
    auto_improve: bool = False,
    max_iterations: int = MAX_ITERATIONS,
    threshold: int = QUALITY_THRESHOLD,
) -> dict:
    """Run the full evaluation loop. Returns evaluation report."""

    if not OPENAI_API_KEY:
        print("ERROR: OPENAI_API_KEY not set")
        sys.exit(1)

    client = OpenAI(api_key=OPENAI_API_KEY)

    iteration = 0
    current_article = article_text
    history = []

    while iteration < max_iterations:
        iteration += 1
        print(f"\n  [iter {iteration}/{max_iterations}] Evaluating content quality...")

        # Heuristic structure scoring
        structure_score, structure_issues = score_structure(current_article)
        print(f"    Structure score: {structure_score}/100 ({len(structure_issues)} issues)")

        # LLM evaluation
        llm_scores = score_with_llm(client, current_article, serp_context, keyword)

        # Compute final score
        final_score, dimension_scores = compute_final_score(structure_score, llm_scores)

        print(f"    Final score: {final_score}/100 (threshold: {threshold})")

        iteration_result = {
            "iteration": iteration,
            "final_score": final_score,
            "dimension_scores": dimension_scores,
            "structure_issues": structure_issues,
            "llm_evaluation": llm_scores,
            "passed": final_score >= threshold,
        }
        history.append(iteration_result)

        if final_score >= threshold:
            print(f"    ✅ PASSED quality gate (score: {final_score} >= {threshold})")
            break
        else:
            print(f"    ❌ FAILED quality gate (score: {final_score} < {threshold})")
            if auto_improve and iteration < max_iterations:
                all_issues = structure_issues + llm_scores.get("top_3_improvements", [])
                current_article = improve_article(client, current_article, all_issues, llm_scores, keyword)
                print(f"    → Improved article generated, re-evaluating...")
            else:
                break

    final_result = history[-1]
    return {
        "pipeline": "content_evaluator",
        "version": "W6.4",
        "evaluated_at": datetime.datetime.utcnow().isoformat(),
        "keyword": keyword,
        "threshold": threshold,
        "passed": final_result["passed"],
        "final_score": final_result["final_score"],
        "iterations": len(history),
        "history": history,
        "final_article": current_article if auto_improve else None,
        "recommendation": (
            "PUBLISH" if final_result["passed"]
            else f"HOLD — score {final_result['final_score']}/{threshold} after {len(history)} iteration(s)"
        ),
    }


# ─── Main ─────────────────────────────────────────────────────────────────────

def main():
    parser = argparse.ArgumentParser(
        description="Content Evaluation Loop — W6.4 (iraresearchhub.com)"
    )
    parser.add_argument("--content", required=True, help="Path to article (.md or .json from content_generator.py)")
    parser.add_argument("--serp", help="Path to SERP analysis JSON from serp_scraper.py")
    parser.add_argument("--keyword", help="Target keyword (auto-detected from JSON if not provided)")
    parser.add_argument("--threshold", type=int, default=QUALITY_THRESHOLD,
                        help=f"Minimum score to pass (default: {QUALITY_THRESHOLD})")
    parser.add_argument("--auto-improve", action="store_true",
                        help="Automatically improve article if it fails the quality gate")
    parser.add_argument("--max-iterations", type=int, default=MAX_ITERATIONS,
                        help=f"Max improvement iterations (default: {MAX_ITERATIONS})")
    parser.add_argument("--output", help="Output JSON report path (default: <slug>_eval.json)")
    args = parser.parse_args()

    # Load article
    article_text = ""
    keyword = args.keyword or ""

    if args.content.endswith(".json"):
        with open(args.content) as f:
            content_data = json.load(f)
        article_text = content_data.get("article", "")
        keyword = keyword or content_data.get("keyword", "")
    else:
        with open(args.content) as f:
            article_text = f.read()
        # Try to extract keyword from frontmatter
        if not keyword:
            kw_match = re.search(r'^keyword:\s*"?(.+?)"?\s*$', article_text, re.MULTILINE)
            keyword = kw_match.group(1) if kw_match else "unknown"

    if not keyword:
        print("ERROR: Could not determine keyword. Use --keyword flag.")
        sys.exit(1)

    # Load SERP context
    serp_context = ""
    if args.serp:
        try:
            with open(args.serp) as f:
                serp_data = json.load(f)
            for result in serp_data.get("results", []):
                if result.get("keyword", "").lower() == keyword.lower():
                    agg = result.get("aggregate", {})
                    lines = [f"Avg competitor word count: {agg.get('avg_word_count', 'N/A')}"]
                    for item in agg.get("top_h2_themes", [])[:8]:
                        lines.append(f"- {item['heading']}")
                    serp_context = "\n".join(lines)
                    break
        except Exception as e:
            print(f"  [warn] Could not load SERP file: {e}")

    print(f"\nContent Evaluation Loop — W6.4")
    print(f"Date: {datetime.datetime.utcnow().strftime('%Y-%m-%d %H:%M UTC')}")
    print(f"Keyword: {keyword!r}")
    print(f"Threshold: {args.threshold}/100")
    print(f"Auto-improve: {args.auto_improve}")

    # Run evaluation
    report = evaluate_and_gate(
        article_text=article_text,
        keyword=keyword,
        serp_context=serp_context,
        auto_improve=args.auto_improve,
        max_iterations=args.max_iterations,
        threshold=args.threshold,
    )

    # Save report
    slug = re.sub(r"[^a-z0-9]+", "-", keyword.lower()).strip("-")
    output_path = args.output or f"{slug}_eval.json"
    with open(output_path, "w") as f:
        json.dump(report, f, indent=2)

    # Save improved article if generated
    if args.auto_improve and report.get("final_article"):
        improved_path = args.content.replace(".md", "_improved.md").replace(".json", "_improved.md")
        with open(improved_path, "w") as f:
            f.write(report["final_article"])
        print(f"   Improved article: {improved_path}")

    # Print summary
    print(f"\n{'='*60}")
    status = "✅ PASSED" if report["passed"] else "❌ FAILED"
    print(f"{status} — Score: {report['final_score']}/100 (threshold: {report['threshold']})")
    print(f"Recommendation: {report['recommendation']}")
    print(f"Iterations: {report['iterations']}")
    print(f"Report: {output_path}")
    print(f"{'='*60}")

    # Exit with error code if failed (for CI/CD integration)
    sys.exit(0 if report["passed"] else 1)


if __name__ == "__main__":
    main()
