#!/usr/bin/env python3
"""
infra_monitor.py — Infrastructure Monitoring & Health Check Script (W4.5, W4.6)

Monitors:
  - Site uptime (iraresearchhub.com + engine API)
  - SSL certificate expiry
  - Database connectivity
  - Disk space
  - Error rate from logs
  - Satellite site availability

Usage:
    python3 infra_monitor.py [--slack-webhook URL] [--output report.json]
    
Runs every 15 minutes via cron:
    */15 * * * * /usr/bin/python3 /var/www/iraresearchhub/scripts/infra_monitor.py

Requires:
    SLACK_WEBHOOK_URL environment variable (optional)
    DATABASE_URL environment variable (for DB check)
"""

import os
import sys
import json
import time
import socket
import argparse
import datetime
import subprocess
import ssl
import urllib.request
import urllib.error
from typing import Optional

# ─── Configuration ────────────────────────────────────────────────────────────

SITES_TO_CHECK = [
    {
        "name": "IRA Research Hub (main)",
        "url": "https://iraresearchhub.com",
        "expected_status": 200,
        "expected_content": "IRA",
        "critical": True,
    },
    {
        "name": "IRA Research Hub (crypto page)",
        "url": "https://iraresearchhub.com/crypto-ira",
        "expected_status": 200,
        "expected_content": "Crypto IRA",
        "critical": True,
    },
    {
        "name": "IRA Research Hub (BlockTrust review)",
        "url": "https://iraresearchhub.com/crypto-ira/blocktrust-ira-review",
        "expected_status": 200,
        "expected_content": "BlockTrust",
        "critical": True,
    },
    {
        "name": "Engine API (health)",
        "url": "https://engine.iraresearchhub.com/api/health",
        "expected_status": 200,
        "expected_content": None,
        "critical": True,
    },
    {
        "name": "iraawards.com",
        "url": "https://iraawards.com",
        "expected_status": 200,
        "expected_content": "IRA",
        "critical": False,
    },
    {
        "name": "bitcoiniraawards.com",
        "url": "https://bitcoiniraawards.com",
        "expected_status": 200,
        "expected_content": "Bitcoin",
        "critical": False,
    },
    {
        "name": "cryptoiraawards.com",
        "url": "https://cryptoiraawards.com",
        "expected_status": 200,
        "expected_content": "Crypto",
        "critical": False,
    },
]

SSL_WARN_DAYS = 30   # Warn if SSL expires within 30 days
SSL_CRITICAL_DAYS = 7  # Critical if SSL expires within 7 days
DISK_WARN_PERCENT = 80  # Warn if disk usage above 80%
DISK_CRITICAL_PERCENT = 90  # Critical if disk usage above 90%
REQUEST_TIMEOUT = 10  # Seconds

# ─── Uptime Check ─────────────────────────────────────────────────────────────

def check_site_uptime(site: dict) -> dict:
    """Check if a site is up and returning expected content."""
    start = time.time()
    try:
        req = urllib.request.Request(
            site["url"],
            headers={"User-Agent": "InfraMonitor/1.0 (iraresearchhub.com health check)"}
        )
        with urllib.request.urlopen(req, timeout=REQUEST_TIMEOUT) as response:
            status = response.status
            content = response.read(2048).decode("utf-8", errors="ignore")
            elapsed = time.time() - start
            
            content_ok = True
            if site.get("expected_content"):
                content_ok = site["expected_content"].lower() in content.lower()
            
            status_ok = status == site.get("expected_status", 200)
            
            return {
                "name": site["name"],
                "url": site["url"],
                "status": "ok" if (status_ok and content_ok) else "degraded",
                "http_status": status,
                "response_time_ms": round(elapsed * 1000),
                "content_ok": content_ok,
                "critical": site.get("critical", False),
                "checked_at": datetime.datetime.utcnow().isoformat(),
            }
    except urllib.error.HTTPError as e:
        return {
            "name": site["name"],
            "url": site["url"],
            "status": "down",
            "http_status": e.code,
            "error": str(e),
            "critical": site.get("critical", False),
            "checked_at": datetime.datetime.utcnow().isoformat(),
        }
    except Exception as e:
        return {
            "name": site["name"],
            "url": site["url"],
            "status": "down",
            "error": str(e),
            "critical": site.get("critical", False),
            "checked_at": datetime.datetime.utcnow().isoformat(),
        }


# ─── SSL Certificate Check ────────────────────────────────────────────────────

def check_ssl_expiry(hostname: str, port: int = 443) -> dict:
    """Check SSL certificate expiry date."""
    try:
        context = ssl.create_default_context()
        with socket.create_connection((hostname, port), timeout=REQUEST_TIMEOUT) as sock:
            with context.wrap_socket(sock, server_hostname=hostname) as ssock:
                cert = ssock.getpeercert()
                
        # Parse expiry date
        not_after = cert.get("notAfter", "")
        expiry = datetime.datetime.strptime(not_after, "%b %d %H:%M:%S %Y %Z")
        days_remaining = (expiry - datetime.datetime.utcnow()).days
        
        if days_remaining <= SSL_CRITICAL_DAYS:
            status = "critical"
        elif days_remaining <= SSL_WARN_DAYS:
            status = "warning"
        else:
            status = "ok"
        
        return {
            "hostname": hostname,
            "status": status,
            "expiry_date": expiry.isoformat(),
            "days_remaining": days_remaining,
            "checked_at": datetime.datetime.utcnow().isoformat(),
        }
    except Exception as e:
        return {
            "hostname": hostname,
            "status": "error",
            "error": str(e),
            "checked_at": datetime.datetime.utcnow().isoformat(),
        }


# ─── Disk Space Check ─────────────────────────────────────────────────────────

def check_disk_space(path: str = "/") -> dict:
    """Check disk space usage."""
    try:
        result = subprocess.run(
            ["df", "-h", path],
            capture_output=True,
            text=True,
            timeout=5,
        )
        lines = result.stdout.strip().split("\n")
        if len(lines) >= 2:
            parts = lines[1].split()
            if len(parts) >= 5:
                use_percent = int(parts[4].rstrip("%"))
                
                if use_percent >= DISK_CRITICAL_PERCENT:
                    status = "critical"
                elif use_percent >= DISK_WARN_PERCENT:
                    status = "warning"
                else:
                    status = "ok"
                
                return {
                    "path": path,
                    "status": status,
                    "total": parts[1],
                    "used": parts[2],
                    "available": parts[3],
                    "use_percent": use_percent,
                    "checked_at": datetime.datetime.utcnow().isoformat(),
                }
    except Exception as e:
        pass
    
    return {
        "path": path,
        "status": "error",
        "error": "Could not check disk space",
        "checked_at": datetime.datetime.utcnow().isoformat(),
    }


# ─── Database Backup Check ────────────────────────────────────────────────────

def check_db_backup_freshness(backup_dir: str = "/var/backups/iraresearchhub") -> dict:
    """Check if the latest DB backup is fresh (within 25 hours)."""
    try:
        if not os.path.exists(backup_dir):
            return {
                "status": "warning",
                "message": f"Backup directory {backup_dir} does not exist",
                "checked_at": datetime.datetime.utcnow().isoformat(),
            }
        
        # Find most recent backup file
        backup_files = []
        for f in os.listdir(backup_dir):
            if f.endswith(".sql.gz") or f.endswith(".sql") or f.endswith(".dump"):
                filepath = os.path.join(backup_dir, f)
                mtime = os.path.getmtime(filepath)
                backup_files.append((mtime, filepath))
        
        if not backup_files:
            return {
                "status": "critical",
                "message": "No backup files found",
                "backup_dir": backup_dir,
                "checked_at": datetime.datetime.utcnow().isoformat(),
            }
        
        latest_mtime, latest_file = max(backup_files)
        age_hours = (time.time() - latest_mtime) / 3600
        
        if age_hours > 25:
            status = "critical"
        elif age_hours > 13:
            status = "warning"
        else:
            status = "ok"
        
        return {
            "status": status,
            "latest_backup": os.path.basename(latest_file),
            "age_hours": round(age_hours, 1),
            "backup_dir": backup_dir,
            "checked_at": datetime.datetime.utcnow().isoformat(),
        }
    except Exception as e:
        return {
            "status": "error",
            "error": str(e),
            "checked_at": datetime.datetime.utcnow().isoformat(),
        }


# ─── Slack Notification ───────────────────────────────────────────────────────

def send_slack_alert(webhook_url: str, issues: list, report: dict):
    """Send Slack alert for infrastructure issues."""
    import urllib.request as req
    
    critical_issues = [i for i in issues if i.get("critical", False)]
    warning_issues = [i for i in issues if not i.get("critical", False)]
    
    emoji = "🚨" if critical_issues else "⚠️"
    title = f"{emoji} Infrastructure Alert — {len(issues)} issue(s) detected"
    
    text_parts = [title, ""]
    
    if critical_issues:
        text_parts.append("*Critical:*")
        for issue in critical_issues:
            text_parts.append(f"• {issue['message']}")
    
    if warning_issues:
        text_parts.append("*Warnings:*")
        for issue in warning_issues:
            text_parts.append(f"• {issue['message']}")
    
    text_parts.extend([
        "",
        f"_Checked at: {datetime.datetime.utcnow().strftime('%Y-%m-%d %H:%M UTC')}_"
    ])
    
    payload = json.dumps({"text": "\n".join(text_parts)}).encode()
    
    try:
        request = req.Request(
            webhook_url,
            data=payload,
            headers={"Content-Type": "application/json"},
        )
        with req.urlopen(request, timeout=10) as response:
            pass
        print("[slack] Alert sent successfully")
    except Exception as e:
        print(f"[slack] Failed to send alert: {e}")


# ─── Main ─────────────────────────────────────────────────────────────────────

def main():
    parser = argparse.ArgumentParser(description="Infrastructure Monitor for iraresearchhub.com")
    parser.add_argument("--output", default="infra_report.json", help="Output JSON file path")
    parser.add_argument("--slack-webhook", help="Slack webhook URL for alerts")
    parser.add_argument("--no-ssl", action="store_true", help="Skip SSL checks")
    parser.add_argument("--no-disk", action="store_true", help="Skip disk checks")
    parser.add_argument("--no-backup", action="store_true", help="Skip backup freshness check")
    args = parser.parse_args()
    
    slack_webhook = args.slack_webhook or os.environ.get("SLACK_WEBHOOK_URL")
    
    print(f"\n{'='*60}")
    print(f"Infrastructure Monitor — iraresearchhub.com")
    print(f"Date: {datetime.datetime.utcnow().strftime('%Y-%m-%d %H:%M UTC')}")
    print(f"{'='*60}\n")
    
    report = {
        "generated_at": datetime.datetime.utcnow().isoformat(),
        "uptime": [],
        "ssl": [],
        "disk": [],
        "backup": None,
        "issues": [],
        "overall_status": "ok",
    }
    
    issues = []
    
    # ── Uptime checks ──────────────────────────────────────────────────────────
    print("Checking site uptime...")
    for site in SITES_TO_CHECK:
        result = check_site_uptime(site)
        report["uptime"].append(result)
        status_icon = "✅" if result["status"] == "ok" else "❌"
        print(f"  {status_icon} {result['name']}: {result['status']}")
        
        if result["status"] != "ok":
            issues.append({
                "type": "uptime",
                "critical": result.get("critical", False),
                "message": f"{result['name']} is {result['status']}: {result.get('error', result.get('http_status', 'unknown'))}",
            })
    
    # ── SSL checks ─────────────────────────────────────────────────────────────
    if not args.no_ssl:
        print("\nChecking SSL certificates...")
        ssl_hosts = ["iraresearchhub.com", "iraawards.com", "bitcoiniraawards.com", "cryptoiraawards.com"]
        for hostname in ssl_hosts:
            result = check_ssl_expiry(hostname)
            report["ssl"].append(result)
            status_icon = "✅" if result["status"] == "ok" else ("⚠️" if result["status"] == "warning" else "❌")
            days = result.get("days_remaining", "?")
            print(f"  {status_icon} {hostname}: {result['status']} ({days} days remaining)")
            
            if result["status"] in ("warning", "critical", "error"):
                issues.append({
                    "type": "ssl",
                    "critical": result["status"] == "critical",
                    "message": f"SSL for {hostname}: {result['status']} ({days} days remaining)",
                })
    
    # ── Disk space check ───────────────────────────────────────────────────────
    if not args.no_disk:
        print("\nChecking disk space...")
        disk_result = check_disk_space("/")
        report["disk"].append(disk_result)
        status_icon = "✅" if disk_result["status"] == "ok" else ("⚠️" if disk_result["status"] == "warning" else "❌")
        print(f"  {status_icon} Disk /: {disk_result.get('use_percent', '?')}% used")
        
        if disk_result["status"] in ("warning", "critical"):
            issues.append({
                "type": "disk",
                "critical": disk_result["status"] == "critical",
                "message": f"Disk / at {disk_result.get('use_percent', '?')}% ({disk_result.get('available', '?')} free)",
            })
    
    # ── Backup freshness check ─────────────────────────────────────────────────
    if not args.no_backup:
        print("\nChecking DB backup freshness...")
        backup_result = check_db_backup_freshness()
        report["backup"] = backup_result
        status_icon = "✅" if backup_result["status"] == "ok" else ("⚠️" if backup_result["status"] == "warning" else "❌")
        age = backup_result.get("age_hours", "?")
        print(f"  {status_icon} Latest backup: {backup_result.get('latest_backup', 'none')} ({age}h ago)")
        
        if backup_result["status"] in ("warning", "critical"):
            issues.append({
                "type": "backup",
                "critical": backup_result["status"] == "critical",
                "message": f"DB backup is {age}h old (threshold: 25h)",
            })
    
    # ── Summary ────────────────────────────────────────────────────────────────
    report["issues"] = issues
    critical_count = sum(1 for i in issues if i.get("critical"))
    warning_count = len(issues) - critical_count
    
    if critical_count > 0:
        report["overall_status"] = "critical"
    elif warning_count > 0:
        report["overall_status"] = "warning"
    
    print(f"\n{'='*60}")
    print(f"SUMMARY: {report['overall_status'].upper()}")
    print(f"  Critical issues: {critical_count}")
    print(f"  Warnings: {warning_count}")
    print(f"{'='*60}")
    
    # Save report
    with open(args.output, "w") as f:
        json.dump(report, f, indent=2)
    print(f"\n📄 Report saved to: {args.output}")
    
    # Send Slack alert if there are issues
    if issues and slack_webhook:
        send_slack_alert(slack_webhook, issues, report)
    
    # Exit with error code if critical issues
    if critical_count > 0:
        sys.exit(2)
    elif warning_count > 0:
        sys.exit(1)


if __name__ == "__main__":
    main()
