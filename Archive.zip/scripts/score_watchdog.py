#!/usr/bin/env python3
"""
IRA Research Hub — Score Watchdog (Backup Check)
=================================================
Runs every 6 hours via cron, offset from the hourly monitor.
Independently checks the 3 most critical scores (BlockTrust, Genesis,
Goldco) and also verifies the primary monitor has run recently.

If scores are wrong OR the monitor log is stale (>2 hours old),
it auto-corrects and sends an email alert.

This is the safety net for the safety net.

Cron entry (every 6 hours, offset by 30 min):
  30 */6 * * * /var/www/iraresearchhub/venv/bin/python \
    /var/www/iraresearchhub/repo/scripts/score_watchdog.py \
    >> /var/www/iraresearchhub/logs/score_watchdog.log 2>&1
"""

import json
import sys
import os
import urllib.request
import urllib.error
from datetime import datetime, timezone, timedelta

# Critical scores — top 3 that must never be wrong
CRITICAL_SCORES = {
    "blocktrust-ira":    9.6,
    "genesis-gold-group": 9.4,
    "goldco":            9.2,
}

# Full score list for complete correction if needed
ALL_SCORES = {
    "blocktrust-ira":           9.6,
    "genesis-gold-group":       9.4,
    "goldco":                   9.2,
    "augusta-precious-metals":  9.1,
    "birch-gold-group":         9.1,
    "bitcoin-ira":              9.0,
    "advantage-gold":           9.0,
    "goldencrest-metals":       9.0,
    "noble-gold-investments":   8.9,
    "patriot-gold-group":       8.9,
    "itrustcapital":            8.8,
    "american-hartford-gold":   8.8,
    "oxford-gold-group":        8.8,
    "preserve-gold":            8.8,
    "allegiance-gold":          8.7,
    "alto-crypto-ira":          8.6,
    "bitira":                   8.5,
    "lear-capital":             8.5,
    "rosland-capital":          8.4,
    "swan-bitcoin-ira":         8.3,
    "rocket-dollar":            8.1,
    "unchained-ira":            8.0,
}

BASE_URL     = "https://iraresearchhub.com"
ADMIN_KEY    = "ira-admin-2026-secret"
ALERT_EMAIL  = "natacha@swoon.ai"
LOG_DIR      = "/var/www/iraresearchhub/logs"
MONITOR_LOG  = os.path.join(LOG_DIR, "score_monitor.log")
WATCHDOG_LOG = os.path.join(LOG_DIR, "score_watchdog.log")
MONITOR_MAX_STALENESS_HOURS = 2


def ts():
    return datetime.now(timezone.utc).strftime("%Y-%m-%d %H:%M:%S UTC")


def ensure_log_dir():
    global LOG_DIR, MONITOR_LOG, WATCHDOG_LOG
    for candidate in [LOG_DIR, "/tmp/iraresearchhub_monitor"]:
        try:
            os.makedirs(candidate, exist_ok=True)
            LOG_DIR      = candidate
            MONITOR_LOG  = os.path.join(candidate, "score_monitor.log")
            WATCHDOG_LOG = os.path.join(candidate, "score_watchdog.log")
            return
        except PermissionError:
            continue


def fetch_score(slug: str):
    url = f"{BASE_URL}/api/v1/providers/{slug}"
    try:
        with urllib.request.urlopen(url, timeout=10) as r:
            return json.loads(r.read()).get("score_overall")
    except Exception as e:
        print(f"  [WARN] Could not fetch {slug}: {e}")
        return None


def auto_correct_all() -> bool:
    url     = f"{BASE_URL}/api/v1/providers/admin/scores"
    payload = json.dumps(ALL_SCORES).encode()
    req = urllib.request.Request(
        url, data=payload,
        headers={"Content-Type": "application/json", "X-Admin-Key": ADMIN_KEY},
        method="PATCH",
    )
    try:
        with urllib.request.urlopen(req, timeout=15) as r:
            result = json.loads(r.read())
            print(f"  [AUTO-CORRECT] Updated: {result.get('updated', [])}")
            return True
    except Exception as e:
        print(f"  [ERROR] Auto-correct failed: {e}")
        return False


def send_email_alert(subject: str, body: str):
    api_key = os.environ.get("SENDGRID_API_KEY", "").strip()
    if not api_key:
        print(f"  [EMAIL] SENDGRID_API_KEY not set — email skipped.")
        return False
    payload = json.dumps({
        "personalizations": [{"to": [{"email": ALERT_EMAIL}]}],
        "from": {"email": "monitor@iraresearchhub.com", "name": "IRA Hub Watchdog"},
        "subject": subject,
        "content": [{"type": "text/plain", "value": body}],
    }).encode()
    req = urllib.request.Request(
        "https://api.sendgrid.com/v3/mail/send",
        data=payload,
        headers={"Authorization": f"Bearer {api_key}", "Content-Type": "application/json"},
        method="POST",
    )
    try:
        with urllib.request.urlopen(req, timeout=15) as r:
            print(f"  [EMAIL] Alert sent to {ALERT_EMAIL} (status {r.status})")
            return True
    except Exception as e:
        print(f"  [EMAIL] Failed: {e}")
        return False


def check_monitor_health() -> tuple[bool, str]:
    """Returns (is_healthy, reason)."""
    if not os.path.exists(MONITOR_LOG):
        return False, f"Monitor log not found at {MONITOR_LOG}"
    mtime = datetime.fromtimestamp(os.path.getmtime(MONITOR_LOG), tz=timezone.utc)
    age   = datetime.now(timezone.utc) - mtime
    if age > timedelta(hours=MONITOR_MAX_STALENESS_HOURS):
        return False, f"Monitor log is {age.seconds // 3600}h {(age.seconds % 3600) // 60}m old (max {MONITOR_MAX_STALENESS_HOURS}h)"
    return True, f"Monitor last ran {int(age.total_seconds() // 60)}m ago"


def main():
    ensure_log_dir()
    print(f"\n[{ts()}] Score watchdog starting")

    issues = []

    # 1. Check monitor health
    monitor_ok, monitor_reason = check_monitor_health()
    if not monitor_ok:
        print(f"  [WARN] Primary monitor issue: {monitor_reason}")
        issues.append(f"Primary monitor issue: {monitor_reason}")
    else:
        print(f"  [OK] Primary monitor: {monitor_reason}")

    # 2. Check critical scores
    drifted = {}
    for slug, expected in CRITICAL_SCORES.items():
        actual = fetch_score(slug)
        if actual is None:
            issues.append(f"Could not fetch score for {slug}")
            continue
        if actual != expected:
            print(f"  [DRIFT] {slug}: got {actual}, expected {expected}")
            drifted[slug] = (actual, expected)
            issues.append(f"{slug}: was {actual}, expected {expected}")
        else:
            print(f"  [OK]    {slug}: {actual}")

    if not issues:
        print(f"[{ts()}] Watchdog: all clear.")
        return 0

    # Issues found — auto-correct everything and alert
    print(f"\n[{ts()}] Watchdog detected {len(issues)} issue(s). Auto-correcting all scores...")
    corrected = auto_correct_all()

    body = (
        f"IRA Research Hub — Watchdog Alert\n"
        f"{'='*50}\n"
        f"Time: {ts()}\n\n"
        f"Issues detected ({len(issues)}):\n"
        + "\n".join(f"  - {i}" for i in issues)
        + f"\n\nAuto-correct all scores: {'SUCCESS' if corrected else 'FAILED'}\n\n"
        f"Primary monitor log: {MONITOR_LOG}\n"
        f"Site: https://iraresearchhub.com\n"
    )
    subject = (
        f"[IRA Hub WATCHDOG] {len(issues)} issue(s) detected"
        + (" — auto-corrected" if corrected else " — MANUAL ACTION NEEDED")
    )
    send_email_alert(subject, body)
    print(f"[{ts()}] Watchdog complete. Issues: {issues}")
    return 1 if not corrected else 0


if __name__ == "__main__":
    sys.exit(main())
