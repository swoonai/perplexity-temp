#!/usr/bin/env python3
"""
IndexNow Ping Script — iraresearchhub.com
Notifies Bing, Yandex, and other IndexNow-compatible search engines
about new or updated pages on iraresearchhub.com.

Usage:
    python3 scripts/indexnow_ping.py              # ping all URLs
    python3 scripts/indexnow_ping.py /about       # ping specific URL
    python3 scripts/indexnow_ping.py --sitemap    # ping all sitemap URLs

IndexNow API: https://www.indexnow.org/documentation
"""

import sys
import json
import time
import urllib.request
import urllib.parse
import xml.etree.ElementTree as ET
from datetime import datetime

# ── Config ────────────────────────────────────────────────────────────────────
SITE_HOST = "iraresearchhub.com"
SITE_URL = f"https://{SITE_HOST}"
# IndexNow key — must match the key file at https://iraresearchhub.com/{key}.txt
# Generate at https://www.bing.com/indexnow
INDEXNOW_KEY = "iraresearchhub-indexnow-2026"
SITEMAP_PATH = "frontend/public/sitemap.xml"

# IndexNow endpoints
ENDPOINTS = [
    "https://api.indexnow.org/indexnow",
    "https://www.bing.com/indexnow",
    "https://yandex.com/indexnow",
]

# ── All indexable URLs ─────────────────────────────────────────────────────────
ALL_URLS = [
    f"{SITE_URL}/",
    f"{SITE_URL}/about",
    f"{SITE_URL}/methodology",
    f"{SITE_URL}/editorial-policy",
    f"{SITE_URL}/privacy",
    f"{SITE_URL}/terms",
    f"{SITE_URL}/author/james-mitchell",
    # Crypto IRA hub
    f"{SITE_URL}/crypto-ira",
    f"{SITE_URL}/crypto-ira/best-companies",
    f"{SITE_URL}/crypto-ira/best-bitcoin-ira",
    f"{SITE_URL}/crypto-ira/401k-to-crypto-ira-rollover",
    # Crypto IRA reviews
    f"{SITE_URL}/crypto-ira/blocktrust-ira-review",
    f"{SITE_URL}/crypto-ira/bitcoin-ira-review",
    f"{SITE_URL}/crypto-ira/itrustcapital-review",
    f"{SITE_URL}/crypto-ira/alto-crypto-ira-review",
    f"{SITE_URL}/crypto-ira/bitira-review",
    f"{SITE_URL}/crypto-ira/swan-bitcoin-ira-review",
    f"{SITE_URL}/crypto-ira/rocket-dollar-review",
    f"{SITE_URL}/crypto-ira/unchained-ira-review",
    f"{SITE_URL}/crypto-ira/fidelity-crypto-ira-review",
    # Crypto IRA comparisons
    f"{SITE_URL}/crypto-ira/blocktrust-ira-vs-bitcoin-ira",
    f"{SITE_URL}/crypto-ira/blocktrust-ira-vs-itrustcapital",
    f"{SITE_URL}/crypto-ira/bitcoin-ira-vs-itrustcapital",
    f"{SITE_URL}/crypto-ira/swan-bitcoin-ira-vs-blocktrust-ira",
    f"{SITE_URL}/crypto-ira/alto-crypto-ira-vs-itrustcapital",
    f"{SITE_URL}/crypto-ira/bitira-vs-bitcoin-ira",
    # Crypto IRA guides & education
    f"{SITE_URL}/crypto-ira/what-is-a-crypto-ira",
    f"{SITE_URL}/crypto-ira/how-to-open-a-crypto-ira",
    f"{SITE_URL}/crypto-ira-vs-stock-ira",
    # Coin-specific IRA pages
    f"{SITE_URL}/crypto-ira/ethereum-ira",
    f"{SITE_URL}/crypto-ira/solana-ira",
    f"{SITE_URL}/crypto-ira/dogecoin-ira",
    f"{SITE_URL}/crypto-ira/litecoin-ira",
    f"{SITE_URL}/crypto-ira/xrp-ripple-ira",
    # Precious Metals IRA hub
    f"{SITE_URL}/precious-metals-ira",
    f"{SITE_URL}/precious-metals-ira/best-companies",
    f"{SITE_URL}/precious-metals-ira/best-gold-ira",
    f"{SITE_URL}/precious-metals-ira/401k-to-gold-ira-rollover",
    # Precious Metals IRA reviews
    f"{SITE_URL}/precious-metals-ira/genesis-gold-group-review",
    f"{SITE_URL}/precious-metals-ira/augusta-precious-metals-review",
    f"{SITE_URL}/precious-metals-ira/birch-gold-group-review",
    f"{SITE_URL}/precious-metals-ira/goldco-review",
    f"{SITE_URL}/precious-metals-ira/american-hartford-gold-review",
    f"{SITE_URL}/precious-metals-ira/lear-capital-review",
    f"{SITE_URL}/precious-metals-ira/noble-gold-investments-review",
    f"{SITE_URL}/precious-metals-ira/advantage-gold-review",
    f"{SITE_URL}/precious-metals-ira/goldencrest-metals-review",
    f"{SITE_URL}/precious-metals-ira/patriot-gold-group-review",
    f"{SITE_URL}/precious-metals-ira/oxford-gold-group-review",
    f"{SITE_URL}/precious-metals-ira/preserve-gold-review",
    f"{SITE_URL}/precious-metals-ira/rosland-capital-review",
    f"{SITE_URL}/precious-metals-ira/allegiance-gold-review",
    # Precious Metals IRA comparisons
    f"{SITE_URL}/gold-ira-vs-crypto-ira",
    f"{SITE_URL}/precious-metals-ira/augusta-vs-goldco",
    f"{SITE_URL}/precious-metals-ira/birch-gold-vs-augusta",
    f"{SITE_URL}/precious-metals-ira/gold-ira-vs-silver-ira",
    # Precious Metals IRA guides
    f"{SITE_URL}/precious-metals-ira/what-is-a-gold-ira",
    f"{SITE_URL}/precious-metals-ira/how-to-open-gold-ira",
    f"{SITE_URL}/precious-metals-ira/how-to-buy-gold-in-ira",
    # Guides hub
    f"{SITE_URL}/guides",
    f"{SITE_URL}/guides/what-is-self-directed-ira",
    f"{SITE_URL}/guides/ira-rollover-rules",
    f"{SITE_URL}/guides/ira-contribution-limits-2026",
    f"{SITE_URL}/guides/required-minimum-distributions-2026",
    f"{SITE_URL}/guides/ira-tax-strategies-high-income",
    f"{SITE_URL}/guides/crypto-in-retirement",
    f"{SITE_URL}/guides/crypto-ira-vs-buying-directly",
    f"{SITE_URL}/guides/gold-ira-vs-gold-etf",
    f"{SITE_URL}/guides/precious-metals-in-ira",
    f"{SITE_URL}/guides/how-to-research-sdira-providers",
    # Education pages
    f"{SITE_URL}/education/crypto-ira-guide",
    f"{SITE_URL}/education/gold-ira-guide",
    f"{SITE_URL}/education/digital-asset-retirement-planning",
    f"{SITE_URL}/education/irs-rules-digital-asset-iras",
    # Research pages
    f"{SITE_URL}/research/crypto-ira-fees-2026",
    f"{SITE_URL}/research/gold-ira-fees-2026",
]


def ping_indexnow(urls: list[str]) -> dict:
    """Submit URLs to IndexNow API (batch submission)."""
    payload = {
        "host": SITE_HOST,
        "key": INDEXNOW_KEY,
        "keyLocation": f"{SITE_URL}/{INDEXNOW_KEY}.txt",
        "urlList": urls,
    }
    data = json.dumps(payload).encode("utf-8")
    results = {}

    for endpoint in ENDPOINTS:
        try:
            req = urllib.request.Request(
                endpoint,
                data=data,
                headers={
                    "Content-Type": "application/json; charset=utf-8",
                    "User-Agent": "IRAResearchHub-IndexNow/1.0",
                },
                method="POST",
            )
            with urllib.request.urlopen(req, timeout=10) as resp:
                results[endpoint] = f"HTTP {resp.status}"
        except Exception as e:
            results[endpoint] = f"ERROR: {e}"
        time.sleep(0.5)

    return results


def load_sitemap_urls(sitemap_path: str) -> list[str]:
    """Parse sitemap.xml and return all <loc> URLs."""
    tree = ET.parse(sitemap_path)
    root = tree.getroot()
    ns = {"sm": "http://www.sitemaps.org/schemas/sitemap/0.9"}
    return [loc.text.strip() for loc in root.findall(".//sm:loc", ns)]


def main():
    args = sys.argv[1:]

    if "--sitemap" in args:
        urls = load_sitemap_urls(SITEMAP_PATH)
        print(f"Loaded {len(urls)} URLs from sitemap")
    elif args and args[0].startswith("/"):
        urls = [f"{SITE_URL}{args[0]}"]
        print(f"Pinging single URL: {urls[0]}")
    else:
        urls = ALL_URLS
        print(f"Pinging all {len(urls)} URLs")

    print(f"\nTimestamp: {datetime.utcnow().isoformat()}Z")
    print(f"Key: {INDEXNOW_KEY}")
    print(f"URLs to submit: {len(urls)}")
    print()

    # IndexNow recommends batches of up to 10,000 URLs
    # We submit all at once since we have < 100
    results = ping_indexnow(urls)

    print("Results:")
    for endpoint, status in results.items():
        print(f"  {endpoint}: {status}")

    print("\nDone.")


if __name__ == "__main__":
    main()
