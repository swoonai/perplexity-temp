#!/usr/bin/env python3
"""
ai_citation_monitor.py — W2.R AI Citation Monitoring Script

Checks whether iraresearchhub.com and its key brands (BlockTrust IRA, Genesis Gold Group)
are cited by major AI assistants (Perplexity, ChatGPT, Gemini) for target queries.

Usage:
    python3 ai_citation_monitor.py [--output results.json] [--slack-webhook URL]

Requires:
    OPENAI_API_KEY environment variable (for GPT-4 citation checks)
    PERPLEXITY_API_KEY environment variable (optional, for Perplexity checks)

Output:
    - Console summary table
    - JSON report with per-query citation status
    - Optional Slack notification if citation rate drops below threshold
"""

import os
import sys
import json
import time
import argparse
import datetime
import requests
from typing import Optional

# ─── Configuration ────────────────────────────────────────────────────────────

TARGET_DOMAINS = [
    "iraresearchhub.com",
    "blocktrust",
    "BlockTrust IRA",
    "Genesis Gold Group",
    "genesisGoldGroup",
]

# Queries where we expect to be cited
TARGET_QUERIES = [
    # Crypto IRA queries
    "best crypto IRA 2026",
    "best Bitcoin IRA companies",
    "BlockTrust IRA review",
    "BlockTrust IRA fees",
    "crypto IRA comparison",
    "iTrustCapital vs BlockTrust IRA",
    "crypto IRA rollover guide",
    # Gold IRA queries
    "best gold IRA companies 2026",
    "Genesis Gold Group review",
    "gold IRA rollover guide",
    "Augusta Precious Metals vs Goldco",
    # General IRA queries
    "best IRA companies for cryptocurrency",
    "how to open a crypto IRA",
    "crypto IRA fees comparison 2026",
]

CITATION_THRESHOLD = 0.30  # Alert if citation rate drops below 30%

# ─── OpenAI Citation Check ────────────────────────────────────────────────────

def check_openai_citation(query: str, api_key: str) -> dict:
    """Ask GPT-4 the query and check if it cites iraresearchhub.com."""
    try:
        import openai
        client = openai.OpenAI(api_key=api_key)
        
        response = client.chat.completions.create(
            model="gpt-4.1-mini",
            messages=[
                {
                    "role": "system",
                    "content": "You are a helpful financial research assistant. Answer questions about IRA investing with specific company recommendations and cite your sources where possible."
                },
                {
                    "role": "user",
                    "content": query
                }
            ],
            max_tokens=500,
            temperature=0.1,
        )
        
        answer = response.choices[0].message.content or ""
        
        # Check for citations
        cited = any(
            domain.lower() in answer.lower()
            for domain in TARGET_DOMAINS
        )
        
        return {
            "query": query,
            "model": "gpt-4.1-mini",
            "cited": cited,
            "answer_excerpt": answer[:300] + "..." if len(answer) > 300 else answer,
            "checked_at": datetime.datetime.utcnow().isoformat(),
        }
        
    except Exception as e:
        return {
            "query": query,
            "model": "gpt-4.1-mini",
            "cited": False,
            "error": str(e),
            "checked_at": datetime.datetime.utcnow().isoformat(),
        }


def check_perplexity_citation(query: str, api_key: str) -> dict:
    """Ask Perplexity the query and check if it cites iraresearchhub.com."""
    try:
        headers = {
            "Authorization": f"Bearer {api_key}",
            "Content-Type": "application/json",
        }
        
        payload = {
            "model": "sonar",
            "messages": [
                {
                    "role": "user",
                    "content": query
                }
            ],
            "max_tokens": 500,
        }
        
        response = requests.post(
            "https://api.perplexity.ai/chat/completions",
            headers=headers,
            json=payload,
            timeout=30,
        )
        response.raise_for_status()
        data = response.json()
        
        answer = data["choices"][0]["message"]["content"]
        citations = data.get("citations", [])
        
        # Check if our domain appears in the answer or citations
        cited_in_answer = any(
            domain.lower() in answer.lower()
            for domain in TARGET_DOMAINS
        )
        cited_in_sources = any(
            "iraresearchhub.com" in str(citation)
            for citation in citations
        )
        cited = cited_in_answer or cited_in_sources
        
        return {
            "query": query,
            "model": "perplexity-sonar",
            "cited": cited,
            "cited_in_sources": cited_in_sources,
            "sources": citations[:5],
            "answer_excerpt": answer[:300] + "..." if len(answer) > 300 else answer,
            "checked_at": datetime.datetime.utcnow().isoformat(),
        }
        
    except Exception as e:
        return {
            "query": query,
            "model": "perplexity-sonar",
            "cited": False,
            "error": str(e),
            "checked_at": datetime.datetime.utcnow().isoformat(),
        }


# ─── Slack Notification ───────────────────────────────────────────────────────

def send_slack_notification(webhook_url: str, results: list, citation_rate: float):
    """Send Slack notification with citation monitoring results."""
    cited_count = sum(1 for r in results if r.get("cited"))
    total = len(results)
    
    status_emoji = "✅" if citation_rate >= CITATION_THRESHOLD else "🚨"
    status_text = "Citation rate healthy" if citation_rate >= CITATION_THRESHOLD else "ALERT: Citation rate below threshold"
    
    blocks = [
        {
            "type": "header",
            "text": {
                "type": "plain_text",
                "text": f"{status_emoji} AI Citation Monitor Report"
            }
        },
        {
            "type": "section",
            "fields": [
                {
                    "type": "mrkdwn",
                    "text": f"*Status:*\n{status_text}"
                },
                {
                    "type": "mrkdwn",
                    "text": f"*Citation Rate:*\n{citation_rate:.1%} ({cited_count}/{total} queries)"
                },
                {
                    "type": "mrkdwn",
                    "text": f"*Date:*\n{datetime.datetime.utcnow().strftime('%Y-%m-%d %H:%M UTC')}"
                },
                {
                    "type": "mrkdwn",
                    "text": f"*Threshold:*\n{CITATION_THRESHOLD:.0%}"
                }
            ]
        }
    ]
    
    # Add top cited queries
    cited_queries = [r["query"] for r in results if r.get("cited")][:5]
    if cited_queries:
        blocks.append({
            "type": "section",
            "text": {
                "type": "mrkdwn",
                "text": "*Cited in:*\n" + "\n".join(f"• {q}" for q in cited_queries)
            }
        })
    
    # Add missed queries
    missed_queries = [r["query"] for r in results if not r.get("cited")][:5]
    if missed_queries:
        blocks.append({
            "type": "section",
            "text": {
                "type": "mrkdwn",
                "text": "*Not cited in:*\n" + "\n".join(f"• {q}" for q in missed_queries)
            }
        })
    
    try:
        response = requests.post(
            webhook_url,
            json={"blocks": blocks},
            timeout=10,
        )
        response.raise_for_status()
        print("[slack] Notification sent successfully")
    except Exception as e:
        print(f"[slack] Failed to send notification: {e}")


# ─── Main ─────────────────────────────────────────────────────────────────────

def main():
    parser = argparse.ArgumentParser(description="AI Citation Monitor for iraresearchhub.com")
    parser.add_argument("--output", default="citation_report.json", help="Output JSON file path")
    parser.add_argument("--slack-webhook", help="Slack webhook URL for notifications")
    parser.add_argument("--model", choices=["openai", "perplexity", "both"], default="openai",
                        help="Which AI model to check")
    parser.add_argument("--queries", nargs="+", help="Specific queries to check (default: all)")
    args = parser.parse_args()
    
    openai_key = os.environ.get("OPENAI_API_KEY")
    perplexity_key = os.environ.get("PERPLEXITY_API_KEY")
    
    if args.model in ("openai", "both") and not openai_key:
        print("ERROR: OPENAI_API_KEY not set")
        sys.exit(1)
    
    if args.model in ("perplexity", "both") and not perplexity_key:
        print("WARNING: PERPLEXITY_API_KEY not set, skipping Perplexity checks")
    
    queries = args.queries or TARGET_QUERIES
    results = []
    
    print(f"\n{'='*60}")
    print(f"AI Citation Monitor — iraresearchhub.com")
    print(f"Date: {datetime.datetime.utcnow().strftime('%Y-%m-%d %H:%M UTC')}")
    print(f"Checking {len(queries)} queries...")
    print(f"{'='*60}\n")
    
    for i, query in enumerate(queries, 1):
        print(f"[{i}/{len(queries)}] Checking: {query}")
        
        if args.model in ("openai", "both") and openai_key:
            result = check_openai_citation(query, openai_key)
            results.append(result)
            status = "✅ CITED" if result["cited"] else "❌ NOT CITED"
            print(f"  OpenAI: {status}")
            time.sleep(1)  # Rate limiting
        
        if args.model in ("perplexity", "both") and perplexity_key:
            result = check_perplexity_citation(query, perplexity_key)
            results.append(result)
            status = "✅ CITED" if result["cited"] else "❌ NOT CITED"
            print(f"  Perplexity: {status}")
            time.sleep(1)  # Rate limiting
    
    # Calculate citation rate
    cited_count = sum(1 for r in results if r.get("cited"))
    total = len(results)
    citation_rate = cited_count / total if total > 0 else 0.0
    
    # Summary
    print(f"\n{'='*60}")
    print(f"SUMMARY")
    print(f"{'='*60}")
    print(f"Total queries checked: {total}")
    print(f"Cited: {cited_count} ({citation_rate:.1%})")
    print(f"Not cited: {total - cited_count} ({1 - citation_rate:.1%})")
    print(f"Threshold: {CITATION_THRESHOLD:.0%}")
    
    if citation_rate >= CITATION_THRESHOLD:
        print(f"\n✅ Citation rate is HEALTHY (above {CITATION_THRESHOLD:.0%} threshold)")
    else:
        print(f"\n🚨 ALERT: Citation rate is BELOW threshold ({CITATION_THRESHOLD:.0%})")
        print("   Action required: Review content strategy and schema markup")
    
    # Save report
    report = {
        "generated_at": datetime.datetime.utcnow().isoformat(),
        "summary": {
            "total_queries": total,
            "cited_count": cited_count,
            "citation_rate": citation_rate,
            "threshold": CITATION_THRESHOLD,
            "status": "healthy" if citation_rate >= CITATION_THRESHOLD else "alert",
        },
        "results": results,
    }
    
    with open(args.output, "w") as f:
        json.dump(report, f, indent=2)
    print(f"\n📄 Report saved to: {args.output}")
    
    # Send Slack notification if webhook provided
    if args.slack_webhook:
        send_slack_notification(args.slack_webhook, results, citation_rate)
    
    # Exit with error code if below threshold (for CI/CD integration)
    if citation_rate < CITATION_THRESHOLD:
        sys.exit(1)


if __name__ == "__main__":
    main()
