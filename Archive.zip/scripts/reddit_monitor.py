#!/usr/bin/env python3
"""
reddit_monitor.py — IRA Research Hub Reddit Brand Mention Monitor
=================================================================
Monitors Reddit for mentions of iraresearchhub.com and competitor brands.
Outputs a JSON report and optionally sends a Slack/email alert.

Usage:
  python3 reddit_monitor.py [--output /path/to/report.json] [--days 7]

Crontab (run weekly, Monday 9 AM UTC):
  0 9 * * 1 /var/www/iraresearchhub/venv/bin/python3 /var/www/iraresearchhub/scripts/reddit_monitor.py --output /var/log/iraresearchhub/reddit_report.json >> /var/log/iraresearchhub/reddit_monitor.log 2>&1
"""

import argparse
import json
import time
import urllib.request
import urllib.parse
from datetime import datetime, timezone, timedelta

# ─── Configuration ────────────────────────────────────────────────────────────

# Search terms to monitor
BRAND_TERMS = [
    "iraresearchhub",
    "ira research hub",
    "iraresearchhub.com",
]

COMPETITOR_TERMS = [
    "best gold IRA",
    "best crypto IRA",
    "gold IRA review",
    "bitcoin IRA review",
    "blocktrust IRA review",
    "genesis gold group review",
    "augusta precious metals review",
    "birch gold group review",
]

# Subreddits to monitor (in addition to all-reddit search)
TARGET_SUBREDDITS = [
    "personalfinance",
    "investing",
    "financialindependence",
    "retirement",
    "Bitcoin",
    "CryptoCurrency",
    "Gold",
    "preciousmetals",
    "IRAs",
    "financialplanning",
    "Bogleheads",
    "SilverAndGold",
]

# Reddit API base URL (public JSON API, no auth required for read-only)
REDDIT_BASE = "https://www.reddit.com"
HEADERS = {
    "User-Agent": "IRAResearchHub-Monitor/1.0 (contact: admin@iraresearchhub.com)"
}

# ─── Helpers ──────────────────────────────────────────────────────────────────

def reddit_search(query: str, subreddit: str = None, limit: int = 25, days: int = 7) -> list:
    """Search Reddit for a query, optionally within a specific subreddit."""
    if subreddit:
        url = f"{REDDIT_BASE}/r/{subreddit}/search.json"
    else:
        url = f"{REDDIT_BASE}/search.json"

    params = {
        "q": query,
        "sort": "new",
        "limit": limit,
        "t": "week" if days <= 7 else "month",
        "restrict_sr": "true" if subreddit else "false",
        "type": "link,comment",
    }

    full_url = url + "?" + urllib.parse.urlencode(params)

    try:
        req = urllib.request.Request(full_url, headers=HEADERS)
        with urllib.request.urlopen(req, timeout=10) as resp:
            data = json.loads(resp.read().decode("utf-8"))
        time.sleep(1)  # Respect Reddit rate limits
        return data.get("data", {}).get("children", [])
    except Exception as e:
        print(f"  [WARN] Search failed for '{query}' in r/{subreddit or 'all'}: {e}")
        return []


def parse_post(child: dict, search_term: str) -> dict:
    """Parse a Reddit post/comment into a structured dict."""
    d = child.get("data", {})
    kind = child.get("kind", "t3")

    if kind == "t1":  # Comment
        return {
            "type": "comment",
            "id": d.get("id"),
            "subreddit": d.get("subreddit"),
            "author": d.get("author"),
            "body": d.get("body", "")[:500],
            "score": d.get("score", 0),
            "url": f"https://reddit.com{d.get('permalink', '')}",
            "created_utc": d.get("created_utc"),
            "search_term": search_term,
        }
    else:  # Post (t3)
        return {
            "type": "post",
            "id": d.get("id"),
            "subreddit": d.get("subreddit"),
            "author": d.get("author"),
            "title": d.get("title", ""),
            "selftext": d.get("selftext", "")[:300],
            "score": d.get("score", 0),
            "num_comments": d.get("num_comments", 0),
            "url": d.get("url"),
            "permalink": f"https://reddit.com{d.get('permalink', '')}",
            "created_utc": d.get("created_utc"),
            "search_term": search_term,
        }


def is_recent(created_utc: float, days: int) -> bool:
    """Check if a post/comment is within the specified number of days."""
    if not created_utc:
        return True
    cutoff = datetime.now(timezone.utc) - timedelta(days=days)
    post_time = datetime.fromtimestamp(created_utc, tz=timezone.utc)
    return post_time >= cutoff


# ─── Main ─────────────────────────────────────────────────────────────────────

def run_monitor(days: int = 7) -> dict:
    report = {
        "generated_at": datetime.now(timezone.utc).isoformat(),
        "period_days": days,
        "brand_mentions": [],
        "competitor_opportunities": [],
        "summary": {},
    }

    # 1. Brand mentions — search all of Reddit for our brand
    print(f"\n[1/2] Scanning for brand mentions of iraresearchhub.com...")
    seen_ids = set()
    for term in BRAND_TERMS:
        print(f"  Searching: '{term}'")
        results = reddit_search(term, limit=50, days=days)
        for child in results:
            post = parse_post(child, term)
            if post["id"] not in seen_ids and is_recent(post.get("created_utc"), days):
                seen_ids.add(post["id"])
                report["brand_mentions"].append(post)

    # 2. Competitor opportunity scan — find threads where we could add value
    print(f"\n[2/2] Scanning for competitor/opportunity threads...")
    seen_ids_comp = set()
    for term in COMPETITOR_TERMS:
        # Search in the most relevant subreddits only (to avoid rate limits)
        for sub in TARGET_SUBREDDITS[:5]:
            print(f"  Searching r/{sub}: '{term}'")
            results = reddit_search(term, subreddit=sub, limit=10, days=days)
            for child in results:
                post = parse_post(child, term)
                if post["id"] not in seen_ids_comp and is_recent(post.get("created_utc"), days):
                    seen_ids_comp.add(post["id"])
                    report["competitor_opportunities"].append(post)

    # 3. Summary
    brand_count = len(report["brand_mentions"])
    opp_count = len(report["competitor_opportunities"])
    high_score_opps = [p for p in report["competitor_opportunities"] if p.get("score", 0) >= 10]

    report["summary"] = {
        "brand_mentions_total": brand_count,
        "competitor_opportunities_total": opp_count,
        "high_engagement_opportunities": len(high_score_opps),
        "top_subreddits_for_brand": _top_subreddits(report["brand_mentions"]),
        "top_subreddits_for_opportunities": _top_subreddits(report["competitor_opportunities"]),
        "action_required": brand_count > 0 or len(high_score_opps) > 0,
    }

    return report


def _top_subreddits(posts: list) -> list:
    counts = {}
    for p in posts:
        sub = p.get("subreddit", "unknown")
        counts[sub] = counts.get(sub, 0) + 1
    return sorted(counts.items(), key=lambda x: x[1], reverse=True)[:5]


def print_report(report: dict):
    s = report["summary"]
    print("\n" + "="*60)
    print("IRA RESEARCH HUB — REDDIT MONITOR REPORT")
    print(f"Generated: {report['generated_at']}")
    print(f"Period: Last {report['period_days']} days")
    print("="*60)
    print(f"\n📊 SUMMARY")
    print(f"  Brand mentions found:          {s['brand_mentions_total']}")
    print(f"  Competitor opportunities:       {s['competitor_opportunities_total']}")
    print(f"  High-engagement opportunities: {s['high_engagement_opportunities']}")
    print(f"  Action required:               {'YES ⚠️' if s['action_required'] else 'No'}")

    if report["brand_mentions"]:
        print(f"\n🔍 BRAND MENTIONS ({len(report['brand_mentions'])})")
        for m in report["brand_mentions"][:10]:
            print(f"  [{m['type']}] r/{m['subreddit']} | Score: {m.get('score', 0)}")
            if m["type"] == "post":
                print(f"    Title: {m.get('title', '')[:80]}")
            else:
                print(f"    Body: {m.get('body', '')[:80]}...")
            print(f"    URL: {m.get('permalink') or m.get('url')}")

    high_opps = [p for p in report["competitor_opportunities"] if p.get("score", 0) >= 10]
    if high_opps:
        print(f"\n🎯 HIGH-VALUE OPPORTUNITIES ({len(high_opps)})")
        for p in high_opps[:10]:
            print(f"  [{p['type']}] r/{p['subreddit']} | Score: {p.get('score', 0)} | Comments: {p.get('num_comments', 'N/A')}")
            if p["type"] == "post":
                print(f"    Title: {p.get('title', '')[:80]}")
            print(f"    URL: {p.get('permalink') or p.get('url')}")

    print("\n" + "="*60)


# ─── Entry Point ──────────────────────────────────────────────────────────────

if __name__ == "__main__":
    parser = argparse.ArgumentParser(description="IRA Research Hub Reddit Monitor")
    parser.add_argument("--output", default=None, help="Path to save JSON report")
    parser.add_argument("--days", type=int, default=7, help="Number of days to look back")
    args = parser.parse_args()

    print(f"Starting Reddit monitor (last {args.days} days)...")
    report = run_monitor(days=args.days)
    print_report(report)

    if args.output:
        with open(args.output, "w") as f:
            json.dump(report, f, indent=2)
        print(f"\nReport saved to: {args.output}")
