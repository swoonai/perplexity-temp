#!/bin/bash
# db_backup.sh — Automated daily database backup (W4.5)
#
# Creates a compressed SQL dump of the MySQL database and uploads to S3/local storage.
# Retains last 30 daily backups and last 4 weekly backups.
#
# Usage:
#   ./db_backup.sh [--s3-bucket BUCKET] [--local-dir DIR]
#
# Cron (daily at 2:00 AM UTC):
#   0 2 * * * /var/www/iraresearchhub/scripts/db_backup.sh >> /var/log/db_backup.log 2>&1
#
# Environment variables:
#   DB_HOST, DB_PORT, DB_NAME, DB_USER, DB_PASS — MySQL connection details
#   S3_BUCKET — S3 bucket name for remote backup (optional)
#   SLACK_WEBHOOK_URL — Slack webhook for notifications (optional)

set -euo pipefail

# ─── Configuration ─────────────────────────────────────────────────────────────
BACKUP_DIR="${BACKUP_DIR:-/var/backups/iraresearchhub}"
RETENTION_DAYS=30
RETENTION_WEEKS=4
TIMESTAMP=$(date +"%Y%m%d_%H%M%S")
WEEKDAY=$(date +"%u")  # 1=Monday, 7=Sunday
DATE_TAG=$(date +"%Y-%m-%d")

DB_HOST="${DB_HOST:-localhost}"
DB_PORT="${DB_PORT:-3306}"
DB_NAME="${DB_NAME:-iraresearchhub}"
DB_USER="${DB_USER:-}"
DB_PASS="${DB_PASS:-}"

S3_BUCKET="${S3_BUCKET:-}"
SLACK_WEBHOOK="${SLACK_WEBHOOK_URL:-}"

# ─── Setup ─────────────────────────────────────────────────────────────────────
mkdir -p "$BACKUP_DIR/daily"
mkdir -p "$BACKUP_DIR/weekly"

BACKUP_FILE="$BACKUP_DIR/daily/db_${DB_NAME}_${TIMESTAMP}.sql.gz"

echo "=== DB Backup Started: $(date) ==="
echo "Database: $DB_NAME @ $DB_HOST:$DB_PORT"
echo "Output: $BACKUP_FILE"

# ─── Create backup ─────────────────────────────────────────────────────────────
if [ -n "$DB_PASS" ]; then
    MYSQL_PWD="$DB_PASS" mysqldump \
        --host="$DB_HOST" \
        --port="$DB_PORT" \
        --user="$DB_USER" \
        --single-transaction \
        --quick \
        --lock-tables=false \
        --routines \
        --triggers \
        "$DB_NAME" | gzip -9 > "$BACKUP_FILE"
else
    mysqldump \
        --host="$DB_HOST" \
        --port="$DB_PORT" \
        --user="$DB_USER" \
        --single-transaction \
        --quick \
        --lock-tables=false \
        --routines \
        --triggers \
        "$DB_NAME" | gzip -9 > "$BACKUP_FILE"
fi

BACKUP_SIZE=$(du -sh "$BACKUP_FILE" | cut -f1)
echo "Backup created: $BACKUP_FILE ($BACKUP_SIZE)"

# ─── Weekly backup copy ────────────────────────────────────────────────────────
if [ "$WEEKDAY" = "1" ]; then
    WEEKLY_FILE="$BACKUP_DIR/weekly/db_${DB_NAME}_weekly_${DATE_TAG}.sql.gz"
    cp "$BACKUP_FILE" "$WEEKLY_FILE"
    echo "Weekly backup saved: $WEEKLY_FILE"
fi

# ─── Upload to S3 ─────────────────────────────────────────────────────────────
if [ -n "$S3_BUCKET" ] && command -v aws &>/dev/null; then
    aws s3 cp "$BACKUP_FILE" "s3://${S3_BUCKET}/daily/$(basename $BACKUP_FILE)" \
        --storage-class STANDARD_IA
    echo "Uploaded to S3: s3://${S3_BUCKET}/daily/$(basename $BACKUP_FILE)"
    
    if [ "$WEEKDAY" = "1" ] && [ -n "$WEEKLY_FILE" ]; then
        aws s3 cp "$WEEKLY_FILE" "s3://${S3_BUCKET}/weekly/$(basename $WEEKLY_FILE)" \
            --storage-class STANDARD_IA
        echo "Weekly backup uploaded to S3"
    fi
fi

# ─── Cleanup old backups ───────────────────────────────────────────────────────
echo "Cleaning up old backups..."
find "$BACKUP_DIR/daily" -name "*.sql.gz" -mtime +${RETENTION_DAYS} -delete
find "$BACKUP_DIR/weekly" -name "*.sql.gz" -mtime +$((RETENTION_WEEKS * 7)) -delete

DAILY_COUNT=$(ls "$BACKUP_DIR/daily"/*.sql.gz 2>/dev/null | wc -l)
WEEKLY_COUNT=$(ls "$BACKUP_DIR/weekly"/*.sql.gz 2>/dev/null | wc -l)
echo "Retained: $DAILY_COUNT daily, $WEEKLY_COUNT weekly backups"

# ─── Slack notification ────────────────────────────────────────────────────────
if [ -n "$SLACK_WEBHOOK" ]; then
    STATUS="✅ DB Backup Complete"
    MESSAGE="*${STATUS}*\n• Database: ${DB_NAME}\n• Size: ${BACKUP_SIZE}\n• File: $(basename $BACKUP_FILE)\n• Daily backups retained: ${DAILY_COUNT}\n• Time: $(date)"
    
    curl -s -X POST "$SLACK_WEBHOOK" \
        -H "Content-Type: application/json" \
        -d "{\"text\": \"${MESSAGE}\"}" \
        --max-time 10 || true
fi

echo "=== DB Backup Complete: $(date) ==="
