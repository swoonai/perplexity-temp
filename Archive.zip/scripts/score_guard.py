#!/usr/bin/env python3
"""
IRA Research Hub — Score Guard
================================
Scans all TSX pages and verifies every hardcoded provider score matches
the seed script (source of truth). Exits with code 1 if any issues are found.

Usage:
  python3 scripts/score_guard.py              # audit only
  python3 scripts/score_guard.py --fix        # audit + auto-fix
  python3 scripts/score_guard.py --ci         # CI mode: fail on any issue

Run as pre-commit hook or nightly cron.
"""

import re, os, sys, argparse
from datetime import datetime

# ── Source of truth (mirrors seed_providers.py) ──────────────────────────────
CORRECT_SCORES = {
    "BlockTrust IRA":          9.6,
    "Genesis Gold Group":      9.4,
    "Goldco":                  9.2,
    "Augusta Precious Metals": 9.1,
    "Birch Gold Group":        9.1,
    "Bitcoin IRA":             9.0,
    "Advantage Gold":          9.0,
    "GoldenCrest Metals":      9.0,
    "Noble Gold Investments":  8.9,
    "Patriot Gold Group":      8.9,
    "iTrustCapital":           8.8,
    "American Hartford Gold":  8.8,
    "Oxford Gold Group":       8.8,
    "Preserve Gold":           8.8,
    "Allegiance Gold":         8.7,
    "Alto CryptoIRA":          8.6,
    "BitIRA":                  8.5,
    "Lear Capital":            8.5,
    "Rosland Capital":         8.4,
    "Swan Bitcoin IRA":        8.3,
    "Rocket Dollar":           8.1,
    "Unchained IRA":           8.0,
}

PAGES_DIR = os.path.join(os.path.dirname(os.path.abspath(__file__)), "..", "frontend", "src", "pages")

def find_issues(fpath):
    """Return list of (line_num, provider, found_score, correct_score, issue_type) tuples."""
    content = open(fpath).read()
    lines = content.split("\n")
    issues = []
    seen = set()

    for i, line in enumerate(lines):
        if line.strip().startswith("//") or line.strip().startswith("*"):
            continue

        # ── Check A: Same-line — name AND score_overall on the same line ─────
        nm = re.search(r"""name\s*[:=]\s*["']([^"']+)["']""", line)
        sm = re.search(r'score_overall\s*[:=]\s*([0-9]+\.[0-9]+)', line)
        if nm and sm:
            provider = nm.group(1)
            score_val = float(sm.group(1))
            if provider in CORRECT_SCORES:
                correct = CORRECT_SCORES[provider]
                key = (i+1, provider)
                if abs(score_val - correct) > 0.05 and key not in seen:
                    issues.append((i+1, provider, score_val, correct, "score_overall"))
                    seen.add(key)
            continue  # Don't also run Check B on this line

        # ── Check B: Multi-line — score_overall line, look back for name ─────
        # Only runs on lines that do NOT have a name field (avoids false positives)
        sm2 = re.search(r'score[_O]?[Oo]verall\s*[:=]\s*([0-9]+\.[0-9]+)', line)
        if sm2 and not nm:
            score_val = float(sm2.group(1))
            for j in range(i-1, max(0, i-15), -1):
                nm2 = re.search(r"""name\s*[:=]\s*["']([^"']+)["']""", lines[j])
                if nm2:
                    provider = nm2.group(1)
                    if provider in CORRECT_SCORES:
                        correct = CORRECT_SCORES[provider]
                        key = (i+1, provider)
                        if abs(score_val - correct) > 0.05 and key not in seen:
                            issues.append((i+1, provider, score_val, correct, "score_overall"))
                            seen.add(key)
                    break

        # ── Check C: Inline text "ProviderName (X.X/10)" ─────────────────────
        for provider, correct in CORRECT_SCORES.items():
            pat = re.escape(provider) + r'\s*\(([0-9]+\.[0-9]+)/10\)'
            for m in re.finditer(pat, line):
                score_val = float(m.group(1))
                key = (i+1, provider)
                if abs(score_val - correct) > 0.05 and key not in seen:
                    issues.append((i+1, provider, score_val, correct, "inline text"))
                    seen.add(key)

        # ── Check D: Fallback ?? values ───────────────────────────────────────
        for m in re.finditer(r'(\?\?\s*)([0-9]+\.[0-9]+)', line):
            score_val = float(m.group(2))
            ctx = "\n".join(lines[max(0, i-10):i+2])
            for provider, correct in CORRECT_SCORES.items():
                if provider in ctx:
                    key = (i+1, provider)
                    if abs(score_val - correct) > 0.05 and key not in seen:
                        issues.append((i+1, provider, score_val, correct, "fallback ??"))
                        seen.add(key)
                    break

    return issues

def fix_issues(fpath, issues):
    """Auto-fix all identified issues in a file."""
    lines = open(fpath).read().split("\n")
    fixed = 0
    for line_num, provider, found, correct, issue_type in sorted(issues, key=lambda x: x[0]):
        i = line_num - 1
        old_s = f"{found:.1f}"
        new_s = f"{correct:.1f}"
        if old_s in lines[i]:
            lines[i] = lines[i].replace(old_s, new_s, 1)
            fixed += 1
    if fixed:
        open(fpath, 'w').write("\n".join(lines))
    return fixed

def run_audit(fix_mode=False, ci_mode=False):
    tsx_files = sorted([f for f in os.listdir(PAGES_DIR) if f.endswith(".tsx")])
    total_issues = 0
    files_with_issues = []

    for fname in tsx_files:
        fpath = os.path.join(PAGES_DIR, fname)
        issues = find_issues(fpath)
        if issues:
            files_with_issues.append((fname, issues))
            total_issues += len(issues)

    timestamp = datetime.now().strftime("%Y-%m-%d %H:%M:%S")

    if total_issues == 0:
        print(f"[{timestamp}] SCORE GUARD: ✓ All {len(tsx_files)} pages clean — no score inconsistencies found.")
        return 0

    print(f"[{timestamp}] SCORE GUARD: Found {total_issues} score issues across {len(files_with_issues)} files:")
    for fname, issues in files_with_issues:
        print(f"\n  {fname}:")
        for line_num, provider, found, correct, issue_type in issues:
            print(f"    L{line_num}: [{issue_type}] {provider}: {found} → should be {correct}")

    if fix_mode:
        print("\nAuto-fixing...")
        total_fixed = 0
        for fname, issues in files_with_issues:
            fpath = os.path.join(PAGES_DIR, fname)
            n = fix_issues(fpath, issues)
            total_fixed += n
            print(f"  Fixed {n} issues in {fname}")
        print(f"\n✓ Total fixed: {total_fixed}")
        return 0

    if ci_mode:
        print(f"\n❌ CI FAILED: {total_issues} score inconsistencies. Run: python3 scripts/score_guard.py --fix")
        return 1

    return 1

if __name__ == "__main__":
    parser = argparse.ArgumentParser(description="IRA Research Hub Score Guard")
    parser.add_argument("--fix", action="store_true", help="Auto-fix all issues found")
    parser.add_argument("--ci", action="store_true", help="CI mode: exit 1 on any issue")
    args = parser.parse_args()
    sys.exit(run_audit(fix_mode=args.fix, ci_mode=args.ci))
