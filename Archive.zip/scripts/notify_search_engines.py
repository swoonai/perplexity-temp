#!/usr/bin/env python3
"""
IRA Research Hub — Multi-Site Search Engine Notification Script
===============================================================
Notifies Bing, Yandex, and Google (via IndexNow) whenever content is
refreshed on any managed site. IndexNow is supported by Bing, Yandex,
and Google — a single submission notifies all three engines.

Managed sites:
  1. iraresearchhub.com      (main site — 52 URLs)
  2. bestbitcoinira.net      (satellite — 1 URL)
  3. bitcoiniraawards.com    (satellite — 1 URL)
  4. cryptoiraawards.com     (satellite — 1 URL)
  5. cryptoiracomparison.com (satellite — 1 URL)
  6. iraawards.com           (satellite — 1 URL)

Usage:
  # Notify all URLs across all sites:
  python3 scripts/notify_search_engines.py --all

  # Notify only provider review pages on iraresearchhub.com:
  python3 scripts/notify_search_engines.py --providers

  # Notify a specific site only:
  python3 scripts/notify_search_engines.py --site iraresearchhub

  # Notify specific URLs:
  python3 scripts/notify_search_engines.py --urls /crypto-ira/blocktrust-ira-review

Cron entry (every 4 hours):
  0 */4 * * * /var/www/iraresearchhub/venv/bin/python3 \\
    /var/www/iraresearchhub/repo/scripts/notify_search_engines.py --providers \\
    >> /var/log/iraresearchhub/search_notify.log 2>&1
"""

import json
import sys
import time
import urllib.request
import urllib.error
from datetime import datetime, timezone

# ── Engine API config ─────────────────────────────────────────────────────────
ENGINE_API_URL    = "https://engine.iraresearchhub.com/api/trpc/seo.logSubmissionPublic"
ENGINE_LOG_SECRET = "ira-seo-log-2026"

# ── IndexNow endpoints ────────────────────────────────────────────────────────
INDEXNOW_ENDPOINTS = [
    "https://api.indexnow.org/indexnow",   # Routes to Google + Yandex + others
    "https://www.bing.com/indexnow",        # Bing directly
]

# ── Site definitions ──────────────────────────────────────────────────────────
# Each site has: id, host, indexnow_key, and its full URL list
SITES = {
    "iraresearchhub": {
        "id":           "iraresearchhub",
        "host":         "iraresearchhub.com",
        "base_url":     "https://iraresearchhub.com",
        "indexnow_key": "iraresearchhub-indexnow-2026",
        "urls": [
            # Core pages
            "https://iraresearchhub.com/",
            "https://iraresearchhub.com/about",
            "https://iraresearchhub.com/author/james-mitchell",
            "https://iraresearchhub.com/editorial-policy",
            "https://iraresearchhub.com/methodology",
            "https://iraresearchhub.com/privacy",
            "https://iraresearchhub.com/terms",
            "https://iraresearchhub.com/gold-ira-vs-crypto-ira",
            "https://iraresearchhub.com/crypto-ira-vs-stock-ira",
            # Crypto IRA hub & reviews
            "https://iraresearchhub.com/crypto-ira",
            "https://iraresearchhub.com/crypto-ira/best-companies",
            "https://iraresearchhub.com/crypto-ira/best-bitcoin-ira",
            "https://iraresearchhub.com/crypto-ira/best-crypto-ira-2026",
            "https://iraresearchhub.com/crypto-ira/what-is-a-crypto-ira",
            "https://iraresearchhub.com/crypto-ira/how-to-open-a-crypto-ira",
            "https://iraresearchhub.com/crypto-ira/blocktrust-ira-review",
            "https://iraresearchhub.com/crypto-ira/bitcoin-ira-review",
            "https://iraresearchhub.com/crypto-ira/itrustcapital-review",
            "https://iraresearchhub.com/crypto-ira/alto-crypto-ira-review",
            "https://iraresearchhub.com/crypto-ira/bitira-review",
            "https://iraresearchhub.com/crypto-ira/swan-bitcoin-ira-review",
            "https://iraresearchhub.com/crypto-ira/rocket-dollar-review",
            "https://iraresearchhub.com/crypto-ira/unchained-ira-review",
            "https://iraresearchhub.com/crypto-ira/fidelity-crypto-ira-review",
            # Crypto IRA comparisons
            "https://iraresearchhub.com/crypto-ira/blocktrust-ira-vs-bitcoin-ira",
            "https://iraresearchhub.com/crypto-ira/blocktrust-ira-vs-itrustcapital",
            "https://iraresearchhub.com/crypto-ira/bitcoin-ira-vs-itrustcapital",
            "https://iraresearchhub.com/crypto-ira/alto-crypto-ira-vs-itrustcapital",
            "https://iraresearchhub.com/crypto-ira/bitira-vs-bitcoin-ira",
            "https://iraresearchhub.com/crypto-ira/blocktrust-ira-vs-swan-bitcoin-ira",
            "https://iraresearchhub.com/crypto-ira/swan-bitcoin-ira-vs-blocktrust-ira",
            # Crypto IRA coin guides
            "https://iraresearchhub.com/crypto-ira/401k-to-crypto-ira-rollover",
            "https://iraresearchhub.com/crypto-ira/dogecoin-ira",
            "https://iraresearchhub.com/crypto-ira/ethereum-ira",
            "https://iraresearchhub.com/crypto-ira/litecoin-ira",
            "https://iraresearchhub.com/crypto-ira/solana-ira",
            "https://iraresearchhub.com/crypto-ira/xrp-ripple-ira",
            # Precious metals IRA hub & reviews
            "https://iraresearchhub.com/precious-metals-ira",
            "https://iraresearchhub.com/precious-metals-ira/best-companies",
            "https://iraresearchhub.com/precious-metals-ira/best-gold-ira",
            "https://iraresearchhub.com/precious-metals-ira/what-is-a-gold-ira",
            "https://iraresearchhub.com/precious-metals/best-companies",
            "https://iraresearchhub.com/precious-metals/best-gold-ira",
            "https://iraresearchhub.com/precious-metals/what-is-a-gold-ira",
            "https://iraresearchhub.com/precious-metals-ira/genesis-gold-group-review",
            "https://iraresearchhub.com/precious-metals-ira/augusta-precious-metals-review",
            "https://iraresearchhub.com/precious-metals-ira/birch-gold-group-review",
            "https://iraresearchhub.com/precious-metals-ira/goldco-review",
            "https://iraresearchhub.com/precious-metals-ira/american-hartford-gold-review",
            "https://iraresearchhub.com/precious-metals-ira/lear-capital-review",
            "https://iraresearchhub.com/precious-metals-ira/noble-gold-investments-review",
            "https://iraresearchhub.com/precious-metals-ira/advantage-gold-review",
            "https://iraresearchhub.com/precious-metals-ira/goldencrest-metals-review",
            "https://iraresearchhub.com/precious-metals-ira/patriot-gold-group-review",
            "https://iraresearchhub.com/precious-metals-ira/oxford-gold-group-review",
            "https://iraresearchhub.com/precious-metals-ira/preserve-gold-review",
            "https://iraresearchhub.com/precious-metals-ira/rosland-capital-review",
            "https://iraresearchhub.com/precious-metals-ira/allegiance-gold-review",
            # Precious metals comparisons
            "https://iraresearchhub.com/precious-metals-ira/augusta-vs-goldco",
            "https://iraresearchhub.com/precious-metals-ira/birch-gold-vs-augusta",
            "https://iraresearchhub.com/precious-metals-ira/gold-ira-vs-silver-ira",
            "https://iraresearchhub.com/precious-metals-ira/401k-to-gold-ira-rollover",
            "https://iraresearchhub.com/precious-metals-ira/how-to-buy-gold-in-ira",
            "https://iraresearchhub.com/precious-metals-ira/how-to-open-gold-ira",
            # Research reports
            "https://iraresearchhub.com/research/crypto-ira-fees-2026",
            "https://iraresearchhub.com/research/gold-ira-fees-2026",
            "https://iraresearchhub.com/research/precious-metals-ira-fees-2026",
            "https://iraresearchhub.com/research/crypto-ira-industry-report-2026",
            "https://iraresearchhub.com/research/gold-ira-vs-crypto-ira-2026",
            # Guides
            "https://iraresearchhub.com/guides",
            "https://iraresearchhub.com/guides/what-is-self-directed-ira",
            "https://iraresearchhub.com/guides/crypto-in-retirement",
            "https://iraresearchhub.com/guides/precious-metals-in-ira",
            "https://iraresearchhub.com/guides/ira-rollover-rules",
            "https://iraresearchhub.com/guides/how-to-research-sdira-providers",
            "https://iraresearchhub.com/guides/ira-contribution-limits-2026",
            "https://iraresearchhub.com/guides/required-minimum-distributions-2026",
            "https://iraresearchhub.com/guides/crypto-ira-vs-buying-directly",
            "https://iraresearchhub.com/guides/gold-ira-vs-gold-etf",
            "https://iraresearchhub.com/guides/ira-tax-strategies-high-income",
            # Education
            "https://iraresearchhub.com/education/what-is-a-self-directed-ira",
            "https://iraresearchhub.com/education/crypto-ira-guide",
            "https://iraresearchhub.com/education/gold-ira-guide",
            "https://iraresearchhub.com/education/crypto-ira-tax-guide-2026",
            "https://iraresearchhub.com/education/ira-tax-strategies-high-income",
            "https://iraresearchhub.com/education/irs-rules-digital-asset-iras",
            "https://iraresearchhub.com/education/digital-asset-retirement-planning",
            "https://iraresearchhub.com/education/required-minimum-distributions",
            "https://iraresearchhub.com/education/how-to-research-sdira-providers",
            # Tools
            "https://iraresearchhub.com/tools/crypto-ira-fee-calculator",
            "https://iraresearchhub.com/tools/crypto-ira-rollover-eligibility",
            # Investor type pages
            "https://iraresearchhub.com/investor/best-crypto-ira-beginners",
            "https://iraresearchhub.com/investor/best-crypto-ira-active-traders",
            "https://iraresearchhub.com/investor/best-crypto-ira-high-net-worth",
            "https://iraresearchhub.com/investor/best-crypto-ira-retirees",
            "https://iraresearchhub.com/investor/best-crypto-ira-self-employed",
            "https://iraresearchhub.com/investor/best-crypto-ira-bitcoin-only",
            "https://iraresearchhub.com/investor/best-crypto-ira-altcoins",
            "https://iraresearchhub.com/investor/best-crypto-ira-rollover",
            # Local / geo pages (50 states)
            "https://iraresearchhub.com/local/best-crypto-ira-alabama",
            "https://iraresearchhub.com/local/best-crypto-ira-alaska",
            "https://iraresearchhub.com/local/best-crypto-ira-arizona",
            "https://iraresearchhub.com/local/best-crypto-ira-arkansas",
            "https://iraresearchhub.com/local/best-crypto-ira-california",
            "https://iraresearchhub.com/local/best-crypto-ira-colorado",
            "https://iraresearchhub.com/local/best-crypto-ira-connecticut",
            "https://iraresearchhub.com/local/best-crypto-ira-delaware",
            "https://iraresearchhub.com/local/best-crypto-ira-florida",
            "https://iraresearchhub.com/local/best-crypto-ira-georgia",
            "https://iraresearchhub.com/local/best-crypto-ira-hawaii",
            "https://iraresearchhub.com/local/best-crypto-ira-idaho",
            "https://iraresearchhub.com/local/best-crypto-ira-illinois",
            "https://iraresearchhub.com/local/best-crypto-ira-indiana",
            "https://iraresearchhub.com/local/best-crypto-ira-iowa",
            "https://iraresearchhub.com/local/best-crypto-ira-kansas",
            "https://iraresearchhub.com/local/best-crypto-ira-kentucky",
            "https://iraresearchhub.com/local/best-crypto-ira-louisiana",
            "https://iraresearchhub.com/local/best-crypto-ira-maine",
            "https://iraresearchhub.com/local/best-crypto-ira-maryland",
            "https://iraresearchhub.com/local/best-crypto-ira-massachusetts",
            "https://iraresearchhub.com/local/best-crypto-ira-michigan",
            "https://iraresearchhub.com/local/best-crypto-ira-minnesota",
            "https://iraresearchhub.com/local/best-crypto-ira-mississippi",
            "https://iraresearchhub.com/local/best-crypto-ira-missouri",
            "https://iraresearchhub.com/local/best-crypto-ira-montana",
            "https://iraresearchhub.com/local/best-crypto-ira-nebraska",
            "https://iraresearchhub.com/local/best-crypto-ira-nevada",
            "https://iraresearchhub.com/local/best-crypto-ira-new-hampshire",
            "https://iraresearchhub.com/local/best-crypto-ira-new-jersey",
            "https://iraresearchhub.com/local/best-crypto-ira-new-mexico",
            "https://iraresearchhub.com/local/best-crypto-ira-new-york",
            "https://iraresearchhub.com/local/best-crypto-ira-north-carolina",
            "https://iraresearchhub.com/local/best-crypto-ira-north-dakota",
            "https://iraresearchhub.com/local/best-crypto-ira-ohio",
            "https://iraresearchhub.com/local/best-crypto-ira-oklahoma",
            "https://iraresearchhub.com/local/best-crypto-ira-oregon",
            "https://iraresearchhub.com/local/best-crypto-ira-pennsylvania",
            "https://iraresearchhub.com/local/best-crypto-ira-rhode-island",
            "https://iraresearchhub.com/local/best-crypto-ira-south-carolina",
            "https://iraresearchhub.com/local/best-crypto-ira-south-dakota",
            "https://iraresearchhub.com/local/best-crypto-ira-tennessee",
            "https://iraresearchhub.com/local/best-crypto-ira-texas",
            "https://iraresearchhub.com/local/best-crypto-ira-utah",
            "https://iraresearchhub.com/local/best-crypto-ira-vermont",
            "https://iraresearchhub.com/local/best-crypto-ira-virginia",
            "https://iraresearchhub.com/local/best-crypto-ira-washington",
            "https://iraresearchhub.com/local/best-crypto-ira-west-virginia",
            "https://iraresearchhub.com/local/best-crypto-ira-wisconsin",
            "https://iraresearchhub.com/local/best-crypto-ira-wyoming",
        ],
        # Subset: provider review pages only (for targeted post-score-refresh submissions)
        "provider_urls": [
            "https://iraresearchhub.com/crypto-ira/best-companies",
            "https://iraresearchhub.com/crypto-ira/best-bitcoin-ira",
            "https://iraresearchhub.com/crypto-ira/best-crypto-ira-2026",
            "https://iraresearchhub.com/crypto-ira/blocktrust-ira-review",
            "https://iraresearchhub.com/crypto-ira/bitcoin-ira-review",
            "https://iraresearchhub.com/crypto-ira/itrustcapital-review",
            "https://iraresearchhub.com/crypto-ira/alto-crypto-ira-review",
            "https://iraresearchhub.com/crypto-ira/bitira-review",
            "https://iraresearchhub.com/crypto-ira/swan-bitcoin-ira-review",
            "https://iraresearchhub.com/crypto-ira/rocket-dollar-review",
            "https://iraresearchhub.com/crypto-ira/unchained-ira-review",
            "https://iraresearchhub.com/crypto-ira/fidelity-crypto-ira-review",
            "https://iraresearchhub.com/precious-metals-ira/best-companies",
            "https://iraresearchhub.com/precious-metals-ira/best-gold-ira",
            "https://iraresearchhub.com/precious-metals-ira/genesis-gold-group-review",
            "https://iraresearchhub.com/precious-metals-ira/augusta-precious-metals-review",
            "https://iraresearchhub.com/precious-metals-ira/birch-gold-group-review",
            "https://iraresearchhub.com/precious-metals-ira/goldco-review",
            "https://iraresearchhub.com/precious-metals-ira/american-hartford-gold-review",
            "https://iraresearchhub.com/precious-metals-ira/lear-capital-review",
            "https://iraresearchhub.com/precious-metals-ira/noble-gold-investments-review",
            "https://iraresearchhub.com/precious-metals-ira/advantage-gold-review",
            "https://iraresearchhub.com/precious-metals-ira/goldencrest-metals-review",
            "https://iraresearchhub.com/precious-metals-ira/patriot-gold-group-review",
            "https://iraresearchhub.com/precious-metals-ira/oxford-gold-group-review",
            "https://iraresearchhub.com/precious-metals-ira/preserve-gold-review",
            "https://iraresearchhub.com/precious-metals-ira/rosland-capital-review",
            "https://iraresearchhub.com/precious-metals-ira/allegiance-gold-review",
        ],
    },
        "bestbitcoinira": {
        "id":           "bestbitcoinira",
        "host":         "bestbitcoinira.net",
        "base_url":     "https://bestbitcoinira.net",
        "indexnow_key": "iraresearchhub-indexnow-2026",
        "urls": [
            "https://bestbitcoinira.net/",
        ],
        "provider_urls": [
            "https://bestbitcoinira.net/",
        ],
    },
    "bitcoiniraawards": {
        "id":           "bitcoiniraawards",
        "host":         "bitcoiniraawards.com",
        "base_url":     "https://bitcoiniraawards.com",
        "indexnow_key": "iraresearchhub-indexnow-2026",
        "urls": [
            "https://bitcoiniraawards.com/",
        ],
        "provider_urls": [
            "https://bitcoiniraawards.com/",
        ],
    },
    "cryptoiraawards": {
        "id":           "cryptoiraawards",
        "host":         "cryptoiraawards.com",
        "base_url":     "https://cryptoiraawards.com",
        "indexnow_key": "iraresearchhub-indexnow-2026",
        "urls": [
            "https://cryptoiraawards.com/",
        ],
        "provider_urls": [
            "https://cryptoiraawards.com/",
        ],
    },
    "cryptoiracomparison": {
        "id":           "cryptoiracomparison",
        "host":         "cryptoiracomparison.com",
        "base_url":     "https://cryptoiracomparison.com",
        "indexnow_key": "iraresearchhub-indexnow-2026",
        "urls": [
            "https://cryptoiracomparison.com/",
        ],
        "provider_urls": [
            "https://cryptoiracomparison.com/",
        ],
    },
    "iraawards": {
        "id":           "iraawards",
        "host":         "iraawards.com",
        "base_url":     "https://iraawards.com",
        "indexnow_key": "iraresearchhub-indexnow-2026",
        "urls": [
            "https://iraawards.com/",
        ],
        "provider_urls": [
            "https://iraawards.com/",
        ],
    },
}


# ── IndexNow Submission ────────────────────────────────────────────────────────
def ping_indexnow(site: dict, urls: list) -> dict:
    """Submit URLs for a given site to IndexNow endpoints."""
    payload = json.dumps({
        "host": site["host"],
        "key": site["indexnow_key"],
        "keyLocation": f"{site['base_url']}/{site['indexnow_key']}.txt",
        "urlList": urls,
    }).encode("utf-8")

    results = {}
    for endpoint in INDEXNOW_ENDPOINTS:
        try:
            req = urllib.request.Request(
                endpoint,
                data=payload,
                headers={"Content-Type": "application/json; charset=utf-8"},
                method="POST",
            )
            with urllib.request.urlopen(req, timeout=10) as resp:
                results[endpoint] = f"HTTP {resp.status}"
        except urllib.error.HTTPError as e:
            results[endpoint] = f"HTTP {e.code}: {e.read().decode('utf-8', errors='replace')[:80]}"
        except Exception as e:
            results[endpoint] = f"ERROR: {e}"
        time.sleep(0.3)
    return results


# ── Engine API Logging ────────────────────────────────────────────────────────
def log_to_engine(site_id: str, urls: list, trigger: str, bing_status: str, indexnow_status: str) -> None:
    """Log the submission batch to the engine SEO Monitor dashboard."""
    try:
        payload = json.dumps({
            "json": {
                "secret": ENGINE_LOG_SECRET,
                "site": site_id,
                "urls": urls,
                "trigger": trigger,
                "bingStatus": bing_status,
                "indexnowStatus": indexnow_status,
            }
        }).encode("utf-8")
        req = urllib.request.Request(
            ENGINE_API_URL,
            data=payload,
            headers={"Content-Type": "application/json"},
            method="POST",
        )
        with urllib.request.urlopen(req, timeout=8) as resp:
            print(f"  [Engine log] HTTP {resp.status} — {len(urls)} URLs logged to SEO Monitor")
    except Exception as e:
        print(f"  [Engine log] Skipped — {e}")


# ── Process one site ──────────────────────────────────────────────────────────
def process_site(site: dict, urls: list, trigger: str) -> bool:
    print(f"\n── {site['host']} ({len(urls)} URLs) ──")
    results = ping_indexnow(site, urls)
    all_ok = True
    bing_status = "unknown"
    indexnow_status = "unknown"
    for endpoint, status in results.items():
        print(f"  {endpoint}: {status}")
        code = status.split()[1] if " " in status else "0"
        if "bing.com" in endpoint:
            bing_status = code
        else:
            indexnow_status = code
        if "200" not in status and "202" not in status:
            all_ok = False
    log_to_engine(site["id"], urls, trigger, bing_status, indexnow_status)
    return all_ok


# ── Main ──────────────────────────────────────────────────────────────────────
def main():
    args = sys.argv[1:]
    timestamp = datetime.now(timezone.utc).isoformat()
    print(f"\n{'='*60}")
    print(f"Multi-Site Search Engine Notification — {timestamp}")
    print(f"{'='*60}")

    # Determine trigger type
    trigger = "cron"
    if "--trigger" in args:
        idx = args.index("--trigger")
        if idx + 1 < len(args):
            trigger = args[idx + 1]

    # Determine which sites to process
    if "--site" in args:
        idx = args.index("--site")
        site_key = args[idx + 1] if idx + 1 < len(args) else ""
        sites_to_process = {k: v for k, v in SITES.items() if k == site_key}
        if not sites_to_process:
            print(f"[ERROR] Unknown site: {site_key}. Valid sites: {', '.join(SITES.keys())}")
            sys.exit(1)
    else:
        sites_to_process = SITES

    # Determine URL mode
    providers_only = "--providers" in args
    specific_urls = None
    if "--urls" in args:
        idx = args.index("--urls")
        specific_urls = [a for a in args[idx+1:] if not a.startswith("--")]

    mode = "provider pages" if providers_only else ("specific URLs" if specific_urls else "all URLs")
    print(f"Mode: {mode} | Sites: {', '.join(sites_to_process.keys())} | Trigger: {trigger}")

    # ── Submit each site ──────────────────────────────────────────────────────
    print(f"\n[IndexNow] Submitting to Bing/Google/Yandex...")
    all_ok = True
    total_urls = 0

    for site_key, site in sites_to_process.items():
        if specific_urls:
            # Specific URLs mode — only applies to iraresearchhub
            base = site["base_url"]
            urls = [f"{base}{u}" if u.startswith("/") else u for u in specific_urls]
        elif providers_only:
            urls = site["provider_urls"]
        else:
            urls = site["urls"]

        ok = process_site(site, urls, trigger)
        if not ok:
            all_ok = False
        total_urls += len(urls)

    # ── Summary ───────────────────────────────────────────────────────────────
    print(f"\n{'='*60}")
    if all_ok:
        print(f"[OK] All {total_urls} URLs across {len(sites_to_process)} site(s) submitted successfully.")
    else:
        print(f"[WARN] Some submissions failed — check output above.")
    print(f"Done. {timestamp}")


if __name__ == "__main__":
    main()
