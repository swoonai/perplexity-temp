#!/usr/bin/env python3
"""
serp_scraper.py — W6.1 SERP Scraping Pipeline
Fetches top-10 Google results for a keyword cluster and extracts structured
data for the AI content generation pipeline (W6.3).

Usage:
    python3 serp_scraper.py "best crypto IRA 2026"
    python3 serp_scraper.py --cluster crypto-ira --output serp_results.json
    python3 serp_scraper.py --file engine-seeds/crypto-ira-seeds-plain.txt --limit 5

Output:
    JSON file with per-URL: headings, entities, word count, schema types,
    internal links, meta description, and a competitor summary.

Requires:
    pip install requests beautifulsoup4 lxml
    SERP_API_KEY (optional — uses SerpAPI if set, else falls back to DuckDuckGo HTML scraping)
"""
import os
import sys
import json
import time
import re
import argparse
import datetime
import hashlib
from typing import Optional
from urllib.parse import urlparse, urljoin

import requests
from bs4 import BeautifulSoup

# ─── Configuration ────────────────────────────────────────────────────────────
SERP_API_KEY = os.environ.get("SERP_API_KEY")          # SerpAPI key (optional)
USER_AGENT = (
    "Mozilla/5.0 (Macintosh; Intel Mac OS X 10_15_7) "
    "AppleWebKit/537.36 (KHTML, like Gecko) "
    "Chrome/122.0.0.0 Safari/537.36"
)
REQUEST_TIMEOUT = 15
CRAWL_DELAY = 2  # seconds between page fetches

# Domains to exclude from competitor analysis (our own sites)
OWN_DOMAINS = {"iraresearchhub.com", "iraawards.com", "bitcoiniraawards.com"}

# Schema types we care about for SEO analysis
SCHEMA_TYPES_OF_INTEREST = {
    "Article", "NewsArticle", "BlogPosting", "FAQPage", "HowTo",
    "Review", "AggregateRating", "BreadcrumbList", "WebPage",
    "Organization", "LocalBusiness", "Product", "ItemList",
}

# ─── SERP Fetching ────────────────────────────────────────────────────────────

def fetch_serp_serpapi(query: str, num: int = 10) -> list[dict]:
    """Fetch SERP results via SerpAPI (paid, reliable)."""
    url = "https://serpapi.com/search"
    params = {
        "q": query,
        "num": num,
        "hl": "en",
        "gl": "us",
        "api_key": SERP_API_KEY,
    }
    resp = requests.get(url, params=params, timeout=REQUEST_TIMEOUT)
    resp.raise_for_status()
    data = resp.json()
    results = []
    for item in data.get("organic_results", [])[:num]:
        results.append({
            "position": item.get("position"),
            "title": item.get("title"),
            "url": item.get("link"),
            "snippet": item.get("snippet"),
            "domain": urlparse(item.get("link", "")).netloc.replace("www.", ""),
        })
    return results


def fetch_serp_duckduckgo(query: str, num: int = 10) -> list[dict]:
    """Fallback: fetch SERP results by scraping DuckDuckGo HTML."""
    headers = {"User-Agent": USER_AGENT}
    url = "https://html.duckduckgo.com/html/"
    params = {"q": query, "kl": "us-en"}
    resp = requests.post(url, data=params, headers=headers, timeout=REQUEST_TIMEOUT)
    resp.raise_for_status()
    soup = BeautifulSoup(resp.text, "lxml")
    results = []
    for i, result in enumerate(soup.select(".result__body")[:num], 1):
        title_el = result.select_one(".result__title a")
        snippet_el = result.select_one(".result__snippet")
        if not title_el:
            continue
        href = title_el.get("href", "")
        # DuckDuckGo wraps URLs — extract the actual URL
        if "uddg=" in href:
            import urllib.parse
            parsed = urllib.parse.parse_qs(urllib.parse.urlparse(href).query)
            href = parsed.get("uddg", [href])[0]
        results.append({
            "position": i,
            "title": title_el.get_text(strip=True),
            "url": href,
            "snippet": snippet_el.get_text(strip=True) if snippet_el else "",
            "domain": urlparse(href).netloc.replace("www.", ""),
        })
    return results


def fetch_serp(query: str, num: int = 10) -> list[dict]:
    """Fetch SERP results using SerpAPI if available, else DuckDuckGo."""
    if SERP_API_KEY:
        print(f"  [serp] Using SerpAPI for: {query!r}")
        return fetch_serp_serpapi(query, num)
    else:
        print(f"  [serp] Using DuckDuckGo (no SERP_API_KEY set) for: {query!r}")
        return fetch_serp_duckduckgo(query, num)


# ─── Page Analysis ────────────────────────────────────────────────────────────

def extract_page_data(url: str) -> dict:
    """Fetch a URL and extract SEO-relevant data."""
    result = {
        "url": url,
        "domain": urlparse(url).netloc.replace("www.", ""),
        "fetched": False,
        "error": None,
        "title": None,
        "meta_description": None,
        "h1": [],
        "h2": [],
        "h3": [],
        "word_count": 0,
        "schema_types": [],
        "internal_links": [],
        "external_links": [],
        "entities": [],
        "has_faq": False,
        "has_howto": False,
        "has_table": False,
        "has_aggregate_rating": False,
        "image_count": 0,
        "content_preview": "",
    }

    try:
        headers = {
            "User-Agent": USER_AGENT,
            "Accept": "text/html,application/xhtml+xml,application/xml;q=0.9,*/*;q=0.8",
            "Accept-Language": "en-US,en;q=0.5",
        }
        resp = requests.get(url, headers=headers, timeout=REQUEST_TIMEOUT, allow_redirects=True)
        resp.raise_for_status()
        soup = BeautifulSoup(resp.text, "lxml")

        # Remove scripts, styles, nav, footer noise
        for tag in soup(["script", "style", "nav", "footer", "header", "aside"]):
            tag.decompose()

        # Title
        title_tag = soup.find("title")
        result["title"] = title_tag.get_text(strip=True) if title_tag else None

        # Meta description
        meta_desc = soup.find("meta", attrs={"name": "description"})
        if meta_desc:
            result["meta_description"] = meta_desc.get("content", "")

        # Headings
        result["h1"] = [h.get_text(strip=True) for h in soup.find_all("h1")][:5]
        result["h2"] = [h.get_text(strip=True) for h in soup.find_all("h2")][:15]
        result["h3"] = [h.get_text(strip=True) for h in soup.find_all("h3")][:20]

        # Word count (body text only)
        body = soup.find("body")
        body_text = body.get_text(separator=" ", strip=True) if body else ""
        words = re.findall(r"\b\w+\b", body_text)
        result["word_count"] = len(words)
        result["content_preview"] = " ".join(words[:100])

        # Tables
        result["has_table"] = bool(soup.find("table"))

        # Images
        result["image_count"] = len(soup.find_all("img"))

        # Internal / external links
        base_domain = urlparse(url).netloc.replace("www.", "")
        for a in soup.find_all("a", href=True):
            href = a["href"]
            if href.startswith("#") or href.startswith("mailto:") or href.startswith("tel:"):
                continue
            abs_href = urljoin(url, href)
            link_domain = urlparse(abs_href).netloc.replace("www.", "")
            link_text = a.get_text(strip=True)[:80]
            if link_domain == base_domain or not link_domain:
                result["internal_links"].append({"url": abs_href, "text": link_text})
            else:
                result["external_links"].append({"url": abs_href, "text": link_text, "domain": link_domain})
        result["internal_links"] = result["internal_links"][:30]
        result["external_links"] = result["external_links"][:20]

        # JSON-LD schema extraction
        schema_types = set()
        for script in soup.find_all("script", type="application/ld+json"):
            try:
                data = json.loads(script.string or "")
                if isinstance(data, list):
                    items = data
                elif isinstance(data, dict) and data.get("@graph"):
                    items = data["@graph"]
                else:
                    items = [data]
                for item in items:
                    t = item.get("@type", "")
                    if isinstance(t, list):
                        schema_types.update(t)
                    elif t:
                        schema_types.add(t)
            except Exception:
                pass
        result["schema_types"] = sorted(schema_types & SCHEMA_TYPES_OF_INTEREST)
        result["has_faq"] = "FAQPage" in schema_types
        result["has_howto"] = "HowTo" in schema_types
        result["has_aggregate_rating"] = "AggregateRating" in schema_types

        # Simple entity extraction: capitalized phrases (NER-lite)
        entity_pattern = re.compile(r"\b([A-Z][a-z]+ (?:[A-Z][a-z]+ )*(?:IRA|Gold|Crypto|Bitcoin|Silver|Capital|Group|Investments|Financial|Metals))\b")
        entities = list(set(entity_pattern.findall(body_text)))[:20]
        result["entities"] = entities

        result["fetched"] = True

    except requests.exceptions.Timeout:
        result["error"] = "timeout"
    except requests.exceptions.HTTPError as e:
        result["error"] = f"http_{e.response.status_code}"
    except Exception as e:
        result["error"] = str(e)[:100]

    return result


# ─── Cluster Analysis ─────────────────────────────────────────────────────────

def analyze_cluster(keyword: str, num_results: int = 10) -> dict:
    """Full SERP analysis for a single keyword."""
    print(f"\n{'='*60}")
    print(f"Analyzing: {keyword!r}")
    print(f"{'='*60}")

    serp_results = fetch_serp(keyword, num=num_results)
    print(f"  Found {len(serp_results)} SERP results")

    analyzed_pages = []
    for result in serp_results:
        url = result.get("url", "")
        domain = result.get("domain", "")
        if not url or not url.startswith("http"):
            continue
        print(f"  [{result['position']:2d}] Crawling {domain} ...")
        page_data = extract_page_data(url)
        page_data.update({
            "serp_position": result["position"],
            "serp_title": result["title"],
            "serp_snippet": result["snippet"],
        })
        analyzed_pages.append(page_data)
        time.sleep(CRAWL_DELAY)

    # Aggregate insights across top results
    all_h2s = []
    all_entities = []
    schema_type_counts: dict[str, int] = {}
    avg_word_count = 0
    faq_count = 0
    howto_count = 0
    table_count = 0

    for page in analyzed_pages:
        if page.get("fetched"):
            all_h2s.extend(page.get("h2", []))
            all_entities.extend(page.get("entities", []))
            avg_word_count += page.get("word_count", 0)
            if page.get("has_faq"):
                faq_count += 1
            if page.get("has_howto"):
                howto_count += 1
            if page.get("has_table"):
                table_count += 1
            for st in page.get("schema_types", []):
                schema_type_counts[st] = schema_type_counts.get(st, 0) + 1

    fetched_count = sum(1 for p in analyzed_pages if p.get("fetched"))
    if fetched_count > 0:
        avg_word_count = avg_word_count // fetched_count

    # Top recurring H2 themes
    h2_freq: dict[str, int] = {}
    for h2 in all_h2s:
        h2_lower = h2.lower()
        h2_freq[h2_lower] = h2_freq.get(h2_lower, 0) + 1
    top_h2_themes = sorted(h2_freq.items(), key=lambda x: -x[1])[:15]

    # Top entities
    entity_freq: dict[str, int] = {}
    for e in all_entities:
        entity_freq[e] = entity_freq.get(e, 0) + 1
    top_entities = sorted(entity_freq.items(), key=lambda x: -x[1])[:15]

    return {
        "keyword": keyword,
        "analyzed_at": datetime.datetime.utcnow().isoformat(),
        "serp_count": len(serp_results),
        "pages_fetched": fetched_count,
        "aggregate": {
            "avg_word_count": avg_word_count,
            "faq_prevalence": f"{faq_count}/{fetched_count}",
            "howto_prevalence": f"{howto_count}/{fetched_count}",
            "table_prevalence": f"{table_count}/{fetched_count}",
            "schema_type_counts": dict(sorted(schema_type_counts.items(), key=lambda x: -x[1])),
            "top_h2_themes": [{"heading": h, "count": c} for h, c in top_h2_themes],
            "top_entities": [{"entity": e, "count": c} for e, c in top_entities],
        },
        "pages": analyzed_pages,
    }


# ─── Main ─────────────────────────────────────────────────────────────────────

def main():
    parser = argparse.ArgumentParser(
        description="SERP Scraping Pipeline — W6.1 (iraresearchhub.com)"
    )
    parser.add_argument("keyword", nargs="?", help="Single keyword to analyze")
    parser.add_argument("--cluster", choices=["crypto-ira", "precious-metals"], help="Analyze a predefined keyword cluster")
    parser.add_argument("--file", help="Path to a plain-text file with one keyword per line")
    parser.add_argument("--limit", type=int, default=5, help="Max keywords to process (default: 5)")
    parser.add_argument("--num-results", type=int, default=10, help="Number of SERP results to fetch per keyword (default: 10)")
    parser.add_argument("--output", default="serp_results.json", help="Output JSON file path")
    args = parser.parse_args()

    keywords = []

    if args.keyword:
        keywords = [args.keyword]
    elif args.cluster == "crypto-ira":
        keywords = [
            "best crypto IRA 2026",
            "best Bitcoin IRA companies",
            "crypto IRA comparison",
            "iTrustCapital review 2026",
            "BlockTrust IRA review",
            "crypto IRA fees comparison",
            "Bitcoin IRA rollover",
            "crypto IRA vs direct crypto",
            "best altcoin IRA",
            "Ethereum IRA companies",
        ]
    elif args.cluster == "precious-metals":
        keywords = [
            "best gold IRA companies 2026",
            "best precious metals IRA",
            "Augusta Precious Metals review 2026",
            "Goldco review 2026",
            "Birch Gold Group review 2026",
            "gold IRA fees comparison",
            "gold IRA rollover guide",
            "gold IRA vs ETF",
            "best silver IRA companies",
            "Genesis Gold Group review",
        ]
    elif args.file:
        with open(args.file) as f:
            keywords = [line.strip() for line in f if line.strip()]
    else:
        parser.print_help()
        sys.exit(1)

    keywords = keywords[:args.limit]
    print(f"\nSERP Scraping Pipeline — W6.1")
    print(f"Date: {datetime.datetime.utcnow().strftime('%Y-%m-%d %H:%M UTC')}")
    print(f"Keywords to analyze: {len(keywords)}")
    print(f"Results per keyword: {args.num_results}")
    if not SERP_API_KEY:
        print("⚠️  SERP_API_KEY not set — using DuckDuckGo fallback (less reliable)")

    all_results = []
    for kw in keywords:
        result = analyze_cluster(kw, num_results=args.num_results)
        all_results.append(result)

    # Save output
    output = {
        "pipeline": "serp_scraper",
        "version": "W6.1",
        "generated_at": datetime.datetime.utcnow().isoformat(),
        "keyword_count": len(all_results),
        "results": all_results,
    }
    with open(args.output, "w") as f:
        json.dump(output, f, indent=2)

    print(f"\n{'='*60}")
    print(f"✅ SERP analysis complete")
    print(f"   Keywords analyzed: {len(all_results)}")
    print(f"   Output: {args.output}")
    print(f"{'='*60}")

    # Print summary table
    print(f"\n{'Keyword':<40} {'Pages':>6} {'Avg WC':>8} {'FAQ':>5} {'Schema':>8}")
    print("-" * 75)
    for r in all_results:
        agg = r["aggregate"]
        schema_count = len(agg["schema_type_counts"])
        print(
            f"{r['keyword'][:39]:<40} "
            f"{r['pages_fetched']:>6} "
            f"{agg['avg_word_count']:>8} "
            f"{agg['faq_prevalence']:>5} "
            f"{schema_count:>8}"
        )


if __name__ == "__main__":
    main()
