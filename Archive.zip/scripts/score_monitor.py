#!/usr/bin/env python3
"""
IRA Research Hub — Score Monitor & Auto-Corrector
==================================================
Runs every hour via cron. Checks all 22 provider scores against canonical
values. If any score has drifted, immediately calls the admin endpoint to
restore the correct value, logs the incident, and sends an email alert.

Email alert: Sends automatically when SENDGRID_API_KEY env var is set.
             Until then, all incidents are logged to the incident log file.

Log files:
  /var/www/iraresearchhub/logs/score_monitor.log    (stdout from cron)
  /var/www/iraresearchhub/logs/score_incidents.log  (incident records)

Cron entry (hourly):
  0 * * * * /var/www/iraresearchhub/venv/bin/python \
    /var/www/iraresearchhub/repo/scripts/score_monitor.py \
    >> /var/www/iraresearchhub/logs/score_monitor.log 2>&1
"""

import json
import sys
import os
import urllib.request
import urllib.error
from datetime import datetime, timezone

# ---------------------------------------------------------------------------
# Canonical scores — single source of truth
# ---------------------------------------------------------------------------
CORRECT_SCORES = {
    "blocktrust-ira":           9.6,
    "genesis-gold-group":       9.4,
    "goldco":                   9.2,
    "augusta-precious-metals":  9.1,
    "birch-gold-group":         9.1,
    "bitcoin-ira":              9.0,
    "advantage-gold":           9.0,
    "goldencrest-metals":       9.0,
    "noble-gold-investments":   8.9,
    "patriot-gold-group":       8.9,
    "itrustcapital":            8.8,
    "american-hartford-gold":   8.8,
    "oxford-gold-group":        8.8,
    "preserve-gold":            8.8,
    "allegiance-gold":          8.7,
    "alto-crypto-ira":          8.6,
    "bitira":                   8.5,
    "lear-capital":             8.5,
    "rosland-capital":          8.4,
    "swan-bitcoin-ira":         8.3,
    "rocket-dollar":            8.1,
    "unchained-ira":            8.0,
}

BASE_URL     = "https://iraresearchhub.com"
ADMIN_KEY    = "ira-admin-2026-secret"
ALERT_EMAIL  = "natacha@swoon.ai"
LOG_DIR      = "/var/www/iraresearchhub/logs"
INCIDENT_LOG = os.path.join(LOG_DIR, "score_incidents.log")
MONITOR_LOG  = os.path.join(LOG_DIR, "score_monitor.log")


# ---------------------------------------------------------------------------
# Helpers
# ---------------------------------------------------------------------------
def ts():
    return datetime.now(timezone.utc).strftime("%Y-%m-%d %H:%M:%S UTC")


def ensure_log_dir():
    global LOG_DIR, INCIDENT_LOG, MONITOR_LOG
    for candidate in [LOG_DIR, "/tmp/iraresearchhub_monitor"]:
        try:
            os.makedirs(candidate, exist_ok=True)
            LOG_DIR      = candidate
            INCIDENT_LOG = os.path.join(candidate, "score_incidents.log")
            MONITOR_LOG  = os.path.join(candidate, "score_monitor.log")
            return
        except PermissionError:
            continue


def fetch_score(slug: str):
    url = f"{BASE_URL}/api/v1/providers/{slug}"
    try:
        with urllib.request.urlopen(url, timeout=10) as r:
            return json.loads(r.read()).get("score_overall")
    except Exception as e:
        print(f"  [WARN] Could not fetch {slug}: {e}")
        return None


def auto_correct(correction_payload: dict) -> bool:
    url     = f"{BASE_URL}/api/v1/providers/admin/scores"
    payload = json.dumps(correction_payload).encode()
    req = urllib.request.Request(
        url, data=payload,
        headers={"Content-Type": "application/json", "X-Admin-Key": ADMIN_KEY},
        method="PATCH",
    )
    try:
        with urllib.request.urlopen(req, timeout=15) as r:
            result  = json.loads(r.read())
            updated = result.get("updated", [])
            print(f"  [AUTO-CORRECT] Updated: {updated}")
            return len(updated) == len(correction_payload)
    except Exception as e:
        print(f"  [ERROR] Auto-correct failed: {e}")
        return False


def send_email_alert(subject: str, body: str):
    """
    Send email via SendGrid HTTP API.
    Activates automatically when SENDGRID_API_KEY env var is set.
    No-op (logs a warning) if the key is not present.
    """
    api_key = os.environ.get("SENDGRID_API_KEY", "").strip()
    if not api_key:
        print(f"  [EMAIL] SENDGRID_API_KEY not set — email skipped. "
              f"Set it on the server to enable alerts to {ALERT_EMAIL}.")
        return False

    payload = json.dumps({
        "personalizations": [{"to": [{"email": ALERT_EMAIL}]}],
        "from": {"email": f"monitor@iraresearchhub.com", "name": "IRA Research Hub Monitor"},
        "subject": subject,
        "content": [{"type": "text/plain", "value": body}],
    }).encode()

    req = urllib.request.Request(
        "https://api.sendgrid.com/v3/mail/send",
        data=payload,
        headers={
            "Authorization": f"Bearer {api_key}",
            "Content-Type": "application/json",
        },
        method="POST",
    )
    try:
        with urllib.request.urlopen(req, timeout=15) as r:
            print(f"  [EMAIL] Alert sent to {ALERT_EMAIL} (status {r.status})")
            return True
    except urllib.error.HTTPError as e:
        print(f"  [EMAIL] SendGrid error {e.code}: {e.read().decode()[:200]}")
        return False
    except Exception as e:
        print(f"  [EMAIL] Failed to send alert: {e}")
        return False


def log_incident(drifted: dict, corrected: bool, verify_failed: list):
    os.makedirs(LOG_DIR, exist_ok=True)
    lines = [
        f"\n{'='*60}",
        f"INCIDENT: {ts()}",
        f"Drifted providers ({len(drifted)}):",
    ]
    for slug, (actual, expected) in drifted.items():
        lines.append(f"  {slug}: was {actual}, expected {expected}")
    lines.append(f"Auto-correct: {'SUCCESS' if corrected else 'FAILED'}")
    if verify_failed:
        lines.append(f"Still wrong after correction: {verify_failed}")
    lines.append(f"{'='*60}")
    with open(INCIDENT_LOG, "a") as f:
        f.write("\n".join(lines) + "\n")


# ---------------------------------------------------------------------------
# Main
# ---------------------------------------------------------------------------
def main():
    ensure_log_dir()
    print(f"\n[{ts()}] Score monitor — checking {len(CORRECT_SCORES)} providers")

    drifted = {}
    errors  = []

    for slug, expected in CORRECT_SCORES.items():
        actual = fetch_score(slug)
        if actual is None:
            errors.append(slug)
            continue
        if actual != expected:
            print(f"  [DRIFT] {slug}: got {actual}, expected {expected}")
            drifted[slug] = (actual, expected)
        else:
            print(f"  [OK]    {slug}: {actual}")

    if errors:
        print(f"\n  [WARN] Could not fetch: {errors}")

    if not drifted:
        print(f"[{ts()}] All 22 scores correct. No action needed.")
        return 0

    # ── Drift detected ──────────────────────────────────────────────────────
    print(f"\n[{ts()}] DRIFT in {len(drifted)} providers — auto-correcting...")
    correction_payload = {s: exp for s, (_, exp) in drifted.items()}
    corrected = auto_correct(correction_payload)

    # Verify corrections took effect
    verify_failed = []
    if corrected:
        for slug, expected in correction_payload.items():
            actual = fetch_score(slug)
            if actual != expected:
                verify_failed.append(f"{slug}: still {actual}")
        if verify_failed:
            print(f"  [WARN] Still wrong after correction: {verify_failed}")
        else:
            print(f"  [OK] All corrections verified.")

    # Log the incident
    log_incident(drifted, corrected, verify_failed)

    # Build email body
    drift_lines = "\n".join(
        f"  {slug}: was {actual}, expected {expected}"
        for slug, (actual, expected) in drifted.items()
    )
    status_line = "Auto-correct: SUCCESS" if (corrected and not verify_failed) else "Auto-correct: FAILED — manual check required"
    email_body = (
        f"IRA Research Hub Score Monitor — Incident Report\n"
        f"{'='*50}\n"
        f"Time: {ts()}\n\n"
        f"Drifted providers ({len(drifted)}):\n{drift_lines}\n\n"
        f"{status_line}\n\n"
        f"Incident log: {INCIDENT_LOG}\n"
        f"Site: https://iraresearchhub.com\n"
    )
    subject = f"[IRA Hub] Score drift detected — {len(drifted)} provider(s) auto-corrected"
    if verify_failed:
        subject = f"[IRA Hub] URGENT: Score drift NOT corrected — manual action needed"

    send_email_alert(subject, email_body)

    print(f"[{ts()}] Incident logged to {INCIDENT_LOG}")
    return 0 if (corrected and not verify_failed) else 1


if __name__ == "__main__":
    sys.exit(main())
