/**
 * Google Ads Script: Educational Pillar Test - 2026
 *
 * Builds the complete campaign structure:
 *   - 1 Campaign: "Educational Pillar Test - 2026"  ($50/day, Manual CPC, PAUSED)
 *   - 10 Ad Groups (one per educational pillar)
 *   - 3 Exact-Match Keywords per Ad Group
 *   - 1 Responsive Search Ad per Ad Group
 *
 * HOW TO RUN:
 *   1. Google Ads → Tools & Settings → Bulk Actions → Scripts → +
 *   2. Paste this file in full
 *   3. Click Preview to verify the build log shows no errors
 *   4. Click Run — the campaign is created PAUSED for your review
 */

function main() {

  // ─── 1. SHARED BUDGET ─────────────────────────────────────────────────────
  var budget = AdsApp.budgets()
    .newBudgetBuilder()
    .withName("Educational Pillar Test - 2026 Budget")
    .withAmount(50.0)
    .withDeliveryMethod("STANDARD")
    .build()
    .getResult();

  Logger.log("Budget created: $50/day");

  // ─── 2. CAMPAIGN ──────────────────────────────────────────────────────────
  var campaign = AdsApp.newCampaignBuilder()
    .withName("Educational Pillar Test - 2026")
    .withBudget(budget)
    .withBiddingStrategy("MANUAL_CPC")
    .withStatus("PAUSED")
    .build()
    .getResult();

  Logger.log("Campaign created: Educational Pillar Test - 2026 (PAUSED)");

  // ─── 3. PILLAR DEFINITIONS ────────────────────────────────────────────────
  var pillars = [
    {
      name: "P1 - What Is a Self-Directed IRA",
      url:  "https://iraresearchhub.com/guides/what-is-self-directed-ira",
      keywords: [
        "[what is a self directed ira]",
        "[self directed ira rules]",
        "[how does an sdira work]"
      ],
      headlines: [
        "What Is A Self-Directed IRA?",
        "SDIRA IRS Rules Explained",
        "Independent SDIRA Research"
      ],
      descriptions: [
        "Learn the IRS rules for Self-Directed IRAs. Compare custodians, fees, and eligible assets.",
        "Read our independent 2026 guide to Self-Directed IRAs before you open an account."
      ]
    },
    {
      name: "P2 - Crypto in Retirement Accounts",
      url:  "https://iraresearchhub.com/guides/crypto-in-retirement-accounts",
      keywords: [
        "[crypto in retirement accounts]",
        "[can i buy crypto in my ira]",
        "[crypto ira rules]"
      ],
      headlines: [
        "Crypto In Retirement Accounts",
        "Crypto IRA Rules Explained",
        "Risks Of Crypto In An IRA"
      ],
      descriptions: [
        "Understand the tax implications and IRS rules of holding digital assets in your IRA.",
        "Independent research on custody, security, and prohibited transactions for Crypto IRAs."
      ]
    },
    {
      name: "P3 - Precious Metals in IRAs",
      url:  "https://iraresearchhub.com/guides/precious-metals-in-ira",
      keywords: [
        "[precious metals in ira]",
        "[gold ira irs rules]",
        "[approved metals for ira]"
      ],
      headlines: [
        "Precious Metals In IRAs",
        "IRS Approved Gold For IRAs",
        "Gold IRA Storage Rules"
      ],
      descriptions: [
        "Learn which precious metals meet IRS purity requirements for retirement accounts.",
        "Understand depository requirements, fees, and prohibited home storage for Gold IRAs."
      ]
    },
    {
      name: "P4 - IRA Rollover Rules",
      url:  "https://iraresearchhub.com/guides/ira-rollover-rules-2026",
      keywords: [
        "[ira rollover rules]",
        "[401k to ira rollover]",
        "[irs 60 day rollover rule]"
      ],
      headlines: [
        "IRA Rollover Rules 2026",
        "Direct vs Indirect Rollovers",
        "Avoid The 60-Day IRS Penalty"
      ],
      descriptions: [
        "Learn the difference between direct and indirect rollovers to avoid tax penalties.",
        "Step-by-step guide to rolling over a 401(k) to a Self-Directed IRA safely."
      ]
    },
    {
      name: "P5 - How to Research SDIRA Providers",
      url:  "https://iraresearchhub.com/guides/how-to-research-sdira-providers",
      keywords: [
        "[how to choose an ira custodian]",
        "[sdira provider reviews]",
        "[sdira custodian comparison]"
      ],
      headlines: [
        "How To Research SDIRAs",
        "Compare SDIRA Custodians",
        "SDIRA Red Flags To Avoid"
      ],
      descriptions: [
        "Learn the 7 key questions to ask before choosing a Self-Directed IRA provider.",
        "Independent methodology for comparing custodian fees, security, and IRS compliance."
      ]
    },
    {
      name: "P6 - IRA Contribution Limits 2026",
      url:  "https://iraresearchhub.com/guides/ira-contribution-limits-2026",
      keywords: [
        "[ira contribution limits 2026]",
        "[roth ira income limits]",
        "[how much can i contribute to ira]"
      ],
      headlines: [
        "IRA Contribution Limits 2026",
        "Traditional vs Roth Limits",
        "2026 IRA Income Phase-Outs"
      ],
      descriptions: [
        "See the updated 2026 IRS contribution limits for Traditional, Roth, and SEP IRAs.",
        "Learn the rules for catch-up contributions and income limits for the current tax year."
      ]
    },
    {
      name: "P7 - Required Minimum Distributions",
      url:  "https://iraresearchhub.com/guides/required-minimum-distributions-2026",
      keywords: [
        "[required minimum distributions]",
        "[rmd rules 2026]",
        "[when do rmds start]"
      ],
      headlines: [
        "Required Minimum Distributions",
        "2026 RMD Rules And Deadlines",
        "Avoid The 25% RMD Penalty"
      ],
      descriptions: [
        "Learn how to calculate your Required Minimum Distribution using IRS Table III.",
        "Understand the SECURE 2.0 Act changes to RMD ages and how to avoid excise taxes."
      ]
    },
    {
      name: "P8 - Crypto IRA vs Buying Directly",
      url:  "https://iraresearchhub.com/guides/crypto-ira-vs-buying-directly",
      keywords: [
        "[crypto ira vs buying directly]",
        "[crypto taxes in ira]",
        "[tax free crypto trading]"
      ],
      headlines: [
        "Crypto IRA vs Direct Buying",
        "Crypto Tax Comparison 2026",
        "Trade Crypto Tax-Deferred"
      ],
      descriptions: [
        "Compare the tax implications of trading crypto inside an SDIRA versus a standard exchange.",
        "Learn how capital gains taxes apply to digital assets in Traditional and Roth IRAs."
      ]
    },
    {
      name: "P9 - Gold IRA vs Gold ETF",
      url:  "https://iraresearchhub.com/guides/gold-ira-vs-gold-etf",
      keywords: [
        "[gold ira vs gold etf]",
        "[physical gold vs paper gold]",
        "[gold etf taxes]"
      ],
      headlines: [
        "Gold IRA vs Gold ETF",
        "Physical vs Paper Gold",
        "The Gold ETF Tax Trap"
      ],
      descriptions: [
        "Compare physical Gold IRAs with Gold ETFs. Understand custody, fees, and counterparty risk.",
        "Learn why the IRS taxes Gold ETFs as collectibles at a higher maximum capital gains rate."
      ]
    },
    {
      name: "P10 - IRA Tax Strategies High Income",
      url:  "https://iraresearchhub.com/guides/ira-tax-strategies-high-income",
      keywords: [
        "[backdoor roth ira]",
        "[mega backdoor roth]",
        "[tax strategies for high income earners]"
      ],
      headlines: [
        "High-Income IRA Tax Strategies",
        "The Backdoor Roth IRA",
        "Mega Backdoor Roth Rules"
      ],
      descriptions: [
        "Learn how high earners use the Backdoor Roth strategy to legally bypass income limits.",
        "Advanced IRA strategies including tax-loss harvesting and alternative asset placement."
      ]
    }
  ];

  // ─── 4. BUILD AD GROUPS, KEYWORDS, AND ADS ────────────────────────────────
  for (var i = 0; i < pillars.length; i++) {
    var p = pillars[i];

    // Ad Group
    var agResult = campaign.newAdGroupBuilder()
      .withName(p.name)
      .withCpc(2.50)
      .withStatus("ENABLED")
      .build();

    if (!agResult.isSuccessful()) {
      Logger.log("FAILED Ad Group: " + p.name + " — " + agResult.getErrors().join(", "));
      continue;
    }
    var adGroup = agResult.getResult();
    Logger.log("  Ad Group: " + p.name);

    // Keywords
    for (var k = 0; k < p.keywords.length; k++) {
      var kwResult = adGroup.newKeywordBuilder()
        .withText(p.keywords[k])
        .withCpc(2.50)
        .build();
      if (!kwResult.isSuccessful()) {
        Logger.log("    FAILED keyword: " + p.keywords[k] + " — " + kwResult.getErrors().join(", "));
      }
    }

    // Responsive Search Ad
    var adResult = adGroup.newAd()
      .responsiveSearchAdBuilder()
      .withFinalUrl(p.url)
      .addHeadline(p.headlines[0])
      .addHeadline(p.headlines[1])
      .addHeadline(p.headlines[2])
      .addDescription(p.descriptions[0])
      .addDescription(p.descriptions[1])
      .build();

    if (!adResult.isSuccessful()) {
      Logger.log("    FAILED RSA: " + p.name + " — " + adResult.getErrors().join(", "));
    } else {
      Logger.log("    RSA created OK");
    }
  }

  Logger.log("==============================================");
  Logger.log("Build complete. Campaign is PAUSED — review in the UI before enabling.");
}
