# IRA Research Hub

An independent, high-authority research platform for IRA investors covering Crypto IRAs and Precious Metals IRAs.

**Live URL:** https://iraresearchhub.com  
**Stack:** React + Vite + TailwindCSS (frontend) | FastAPI + PostgreSQL (backend) | Python DataForSEO engine

## Project Structure

```
/
├── frontend/          # React + Vite + TailwindCSS
├── backend/           # FastAPI + PostgreSQL
├── engine/            # DataForSEO review engine (Python)
└── .github/workflows/ # CI/CD pipelines
```

## Development

See individual README files in each subdirectory.

---

*Managed by Swoon Media Inc.*
