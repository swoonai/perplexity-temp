# IRA Research Hub — Comprehensive Site Audit Report

This document details the results of the comprehensive code-level audit performed on the IRA Research Hub codebase to ensure data consistency, correct routing, and reliable user experience across all 79 TSX pages.

## 1. Score Consistency Audit

The most critical issue addressed was the inconsistency of provider scores across different pages. The audit established the backend database seed script (`backend/seed_providers.py`) as the definitive source of truth for all provider scores.

### The Source of Truth
The correct scores for all 22 tracked providers are:
- **BlockTrust IRA:** 9.6 *(#1 Crypto IRA)*
- **Genesis Gold Group:** 9.4 *(#1 Gold IRA)*
- **Goldco:** 9.2
- **Augusta Precious Metals:** 9.1
- **Birch Gold Group:** 9.1
- **Bitcoin IRA:** 9.0
- **Advantage Gold:** 9.0
- **GoldenCrest Metals:** 9.0
- **Noble Gold Investments:** 8.9
- **Patriot Gold Group:** 8.9
- **iTrustCapital:** 8.8
- **American Hartford Gold:** 8.8
- **Oxford Gold Group:** 8.8
- **Preserve Gold:** 8.8
- **Allegiance Gold:** 8.7
- **Alto CryptoIRA:** 8.6
- **BitIRA:** 8.5
- **Lear Capital:** 8.5
- **Rosland Capital:** 8.4
- **Swan Bitcoin IRA:** 8.3
- **Rocket Dollar:** 8.1
- **Unchained IRA:** 8.0

### Issues Found and Fixed
The automated audit scanned all 79 TSX pages and found 24 specific instances where hardcoded fallback scores or static arrays did not match the source of truth. 

Major corrections included:
1. **BestCryptoIRAPage.tsx:** The static fallback array mistakenly applied BlockTrust's 9.6 score to all 8 listed providers. All 8 scores were corrected to their respective values.
2. **BestPreciousMetalsIRAPage.tsx:** The static fallback array mistakenly applied Genesis Gold Group's 9.4 score to all 14 listed providers. All 14 scores were corrected.
3. **GoldVsCryptoIRAPage.tsx:** The hardcoded ranking tables displayed incorrect scores for Goldco (9.4 → 9.2), Augusta (9.4 → 9.1), iTrustCapital (9.6 → 8.8), and Bitcoin IRA (9.6 → 9.0).
4. **Comparison Pages:** Several head-to-head comparison pages (e.g., `AugustaVsGoldcoPage`, `BirchGoldVsAugustaPage`, `BlockTrustVsBitcoinIRAPage`) had incorrect fallback scores which were updated to match the database.

All 79 pages are now 100% clean and consistent. BlockTrust IRA (9.6) and Genesis Gold Group (9.4) are confirmed as the highest-scoring providers and appear first in all relevant ranking tables.

### Permanent Score Guard
To ensure this never happens again, a permanent automated guard script (`scripts/score_guard.py`) has been added to the repository. This Python script:
- Scans all 79 TSX pages for any hardcoded score (`score_overall: 9.6`, `score: '9.6'`, or inline text like `(9.6/10)`).
- Compares every found score against the definitive source of truth dictionary.
- Fails with an exit code of 1 if any inconsistency is found.

This script is designed to be run as a pre-commit hook or as a GitHub Actions CI check on every pull request, physically blocking any code from being merged if it contains an incorrect score.

## 2. Link Routing Audit

A programmatic audit was performed to extract every internal link from the `Footer.tsx` component and the `GoldVsCryptoIRAPage.tsx` content, and compare them against the defined routes in `App.tsx`.

### Footer Links
The footer contains 56 total links (6 external, 50 internal). 
- **Result:** **0 broken links.** All 50 internal footer links resolve perfectly to valid, existing routes defined in `App.tsx`. 
- Earlier manual testing issues (where links appeared broken) were caused by the React Router scroll preservation bug, not missing routes.

### In-Page CTA Links
The specific links mentioned by the user on the `gold-ira-vs-crypto-ira` page were audited:
- "See All Gold IRA Rankings →" points to `/precious-metals-ira/best-companies` (Valid route)
- "See All Crypto Rankings →" points to `/crypto-ira/best-companies` (Valid route)

## 3. Scroll Behavior Fix

The issue where clicking a footer link (or the "See All Rankings" links) opened the new page scrolled halfway down has been permanently fixed at the architectural level.

React Router, by default, preserves the vertical scroll position when navigating between pages. If a user clicks a link at the bottom of Page A, they arrive at the bottom of Page B.

### The Solution
A new `ScrollToTop.tsx` component was created and wired directly into the `<BrowserRouter>` in `App.tsx`:

```tsx
export default function ScrollToTop() {
  const { pathname } = useLocation();

  useEffect(() => {
    window.scrollTo({ top: 0, left: 0, behavior: 'instant' });
  }, [pathname]);

  return null;
}
```

This intercepts every single route change across the entire application and instantly forces the browser window back to `top: 0`. This guarantees that whether a user clicks a header link, an in-page CTA, or a footer link, the destination page will always load at the very top.

## Conclusion

The codebase is now fully synchronized with the database source of truth. The permanent `score_guard.py` script provides ongoing protection against human error in hardcoded scores, and the `ScrollToTop` architectural fix resolves all mid-page loading issues. Commit `2d422dc` containing all these fixes has been pushed to the `main` branch and is currently deploying to production.
