from typing import Optional, List, Any
from datetime import datetime
from pydantic import BaseModel, model_validator

# Weights used on the review pages (must match BlockTrustReviewPage.tsx scoreLabels)
_SCORE_WEIGHTS = {
    "score_fees": 0.20,
    "score_assets": 0.20,
    "score_security": 0.20,
    "score_compliance": 0.15,
    "score_support": 0.15,
    "score_reputation": 0.10,
}


def _compute_weighted_score(data: dict) -> Optional[float]:
    """Compute the weighted overall score from sub-scores."""
    total_weight = 0.0
    weighted_sum = 0.0
    for field, weight in _SCORE_WEIGHTS.items():
        value = data.get(field)
        if value is not None:
            weighted_sum += value * weight
            total_weight += weight
    if total_weight == 0:
        return None
    return round(weighted_sum / total_weight, 1)


class ProviderBase(BaseModel):
    slug: str
    name: str
    category: str
    tagline: Optional[str] = None
    website: Optional[str] = None
    affiliate_url: Optional[str] = None

    setup_fee: Optional[str] = None
    annual_fee: Optional[str] = None
    transaction_fee: Optional[str] = None
    min_investment: Optional[str] = None

    supported_assets: Optional[List[str]] = None
    asset_count: Optional[int] = None
    custody_provider: Optional[str] = None
    storage_type: Optional[str] = None
    insurance_coverage: Optional[str] = None
    bbb_rating: Optional[str] = None
    founded_year: Optional[int] = None
    headquarters: Optional[str] = None

    score_fees: Optional[float] = None
    score_assets: Optional[float] = None
    score_security: Optional[float] = None
    score_compliance: Optional[float] = None
    score_support: Optional[float] = None
    score_reputation: Optional[float] = None
    score_overall: Optional[float] = None

    rank_overall: Optional[int] = None
    is_featured: bool = False
    logo_url: Optional[str] = None
    review_slug: Optional[str] = None
    meta_description: Optional[str] = None
    review_count: Optional[int] = 1


class ProviderCreate(ProviderBase):
    pass


class ProviderResponse(ProviderBase):
    id: int
    is_active: bool
    created_at: datetime
    updated_at: datetime

    @model_validator(mode="before")
    @classmethod
    def compute_overall_score(cls, values):
        """
        Use the stored score_overall from the database if it exists.
        Only fall back to computing from sub-scores if score_overall is None.
        This respects manually curated scores set by the editorial team.
        """
        if hasattr(values, "__dict__"):
            stored = getattr(values, "score_overall", None)
        else:
            stored = values.get("score_overall")

        # If a curated score is already stored, use it as-is
        if stored is not None:
            return values

        # Only compute from sub-scores when no stored value exists
        if hasattr(values, "__dict__"):
            data = {k: getattr(values, k, None) for k in _SCORE_WEIGHTS}
        else:
            data = {k: values.get(k) for k in _SCORE_WEIGHTS}
        computed = _compute_weighted_score(data)
        if computed is not None:
            if hasattr(values, "__dict__"):
                object.__setattr__(values, "score_overall", computed)
            else:
                values["score_overall"] = computed
        return values

    class Config:
        from_attributes = True


class ProviderListResponse(BaseModel):
    providers: List[ProviderResponse]
    total: int
    category: Optional[str] = None
