"""
award.py — Pydantic schemas for the awards API.

These schemas are used by the FastAPI endpoints to serialize/deserialize
award data for the satellite sites (iraawards.com, bitcoiniraawards.com,
cryptoiraawards.com).
"""

from typing import Optional, List, Literal
from datetime import datetime
from pydantic import BaseModel


# ─── Enums ────────────────────────────────────────────────────────────────────

AwardStatus = Literal["winner", "runner_up", "nominee"]
AwardSiteKey = Literal["ira", "bitcoin", "crypto"]


# ─── Base Schema ──────────────────────────────────────────────────────────────

class AwardBase(BaseModel):
    provider_id: int
    award_year: int
    award_category: str
    award_label: str
    award_status: AwardStatus = "nominee"
    site_key: AwardSiteKey = "ira"
    score_at_award: Optional[float] = None
    citation: Optional[str] = None
    is_active: bool = True


# ─── Create Schema ────────────────────────────────────────────────────────────

class AwardCreate(AwardBase):
    pass


# ─── Response Schema ──────────────────────────────────────────────────────────

class AwardResponse(AwardBase):
    id: int
    awarded_at: datetime
    created_at: datetime
    updated_at: datetime

    # Denormalized provider fields (joined from providers table)
    provider_name: Optional[str] = None
    provider_slug: Optional[str] = None
    provider_logo_url: Optional[str] = None
    provider_affiliate_url: Optional[str] = None
    provider_website: Optional[str] = None

    class Config:
        from_attributes = True


# ─── List Response Schema ─────────────────────────────────────────────────────

class AwardListResponse(BaseModel):
    awards: List[AwardResponse]
    total: int
    year: Optional[int] = None
    category: Optional[str] = None
    site_key: Optional[str] = None


# ─── Category Summary Schema ──────────────────────────────────────────────────

class AwardCategoryWinner(BaseModel):
    """Compact summary of the winner for a given category — used by satellite site hero sections."""
    category: str
    award_label: str
    award_year: int
    site_key: str
    winner_name: str
    winner_slug: str
    winner_logo_url: Optional[str] = None
    winner_affiliate_url: Optional[str] = None
    winner_score: Optional[float] = None
    citation: Optional[str] = None


class AwardCategoryWinnersResponse(BaseModel):
    """All category winners for a given site and year."""
    site_key: str
    year: int
    winners: List[AwardCategoryWinner]
    total: int
