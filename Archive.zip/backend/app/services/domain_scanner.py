"""
Domain Typosquatting Monitor
Generates brand variant domains and checks registration/threat status via WHOIS + DNS + HTTP.
"""
import socket
import subprocess
import requests
import logging
from datetime import datetime
from typing import Optional
from sqlalchemy.orm import Session

from app.models.domain_monitor import MonitoredDomain, DomainStatus, DomainThreatLevel

logger = logging.getLogger(__name__)

# ─────────────────────────────────────────────
# Master domain watchlist
# ─────────────────────────────────────────────

BRAND_DOMAINS = {
    "blocktrustira": {
        "canonical": "blocktrustira.com",
        "brand_owned": {"blocktrustira.com", "blocktrust.com"},
        "variants": [
            # Tier 1 — Alt TLDs
            ("blocktrustira.net", "alt_tld", 1),
            ("blocktrustira.org", "alt_tld", 1),
            ("blocktrustira.io", "alt_tld", 1),
            ("blocktrustira.co", "alt_tld", 1),
            ("blocktrustira.us", "alt_tld", 1),
            ("blocktrustira.biz", "alt_tld", 2),
            ("blocktrustira.info", "alt_tld", 2),
            # Tier 1 — Hyphenated
            ("block-trust-ira.com", "hyphenated", 1),
            ("block-trust-ira.net", "hyphenated", 1),
            ("block-trustira.com", "hyphenated", 1),
            ("blocktrust-ira.com", "hyphenated", 1),
            # Tier 1 — Plural/suffix
            ("blocktrustsira.com", "suffix", 1),
            ("blocktrustsira.net", "suffix", 1),
            # Tier 2 — Keyword appended (phishing patterns)
            ("blocktrustira-login.com", "keyword_append", 1),
            ("blocktrustira-account.com", "keyword_append", 1),
            ("blocktrustira-secure.com", "keyword_append", 1),
            ("blocktrustira-official.com", "keyword_append", 1),
            ("blocktrustira-invest.com", "keyword_append", 2),
            ("blocktrustira-crypto.com", "keyword_append", 2),
            ("blocktrustira-wallet.com", "keyword_append", 1),
            ("blocktrustira-app.com", "keyword_append", 2),
            ("blocktrustira-support.com", "keyword_append", 1),
            ("blocktrustirareviews.com", "keyword_append", 2),
            ("blocktrustiracomplaints.com", "keyword_append", 2),
            ("blocktrustiralegit.com", "keyword_append", 2),
            ("blocktrustirascam.com", "keyword_append", 2),
            ("blocktrustira2026.com", "keyword_append", 2),
            # Tier 3 — Typosquats (missing letters)
            ("blocktrustir.com", "typosquat", 2),
            ("blocktrusira.com", "typosquat", 2),
            ("blocktrustia.com", "typosquat", 2),
            ("bloktrustira.com", "typosquat", 2),
            ("bocktrustira.com", "typosquat", 2),
            ("blockrustira.com", "typosquat", 2),
            ("blocktustira.com", "typosquat", 2),
            # Tier 3 — Transposition
            ("blocktrsuira.com", "typosquat", 3),
            ("blocktrusitra.com", "typosquat", 3),
            ("blocktrustiar.com", "typosquat", 3),
            ("blocktrsutira.com", "typosquat", 3),
            ("blocktrutsira.com", "typosquat", 3),
            # Tier 3 — Double letters
            ("blocktrustirra.com", "typosquat", 3),
            ("blocktrustiira.com", "typosquat", 3),
            ("blocktrustiraa.com", "typosquat", 3),
            ("blockktrustira.com", "typosquat", 3),
            # Tier 3 — Homoglyphs
            ("b1ocktrustira.com", "homoglyph", 2),
            ("bl0cktrustira.com", "homoglyph", 2),
            ("blocktrustlra.com", "homoglyph", 2),
            # Misc
            ("blockfinanceira.com", "other", 2),
            ("blockescrowira.com", "other", 2),
        ]
    },
    "blocktrust": {
        "canonical": "blocktrust.com",
        "brand_owned": {"blocktrust.com", "blocktrustira.com"},
        "variants": [
            # Rebrand alt TLDs — CRITICAL
            ("blocktrust.net", "alt_tld", 1),
            ("blocktrust.org", "alt_tld", 1),
            ("blocktrust.io", "alt_tld", 1),
            ("blocktrust.co", "alt_tld", 1),
            ("blocktrust.us", "alt_tld", 1),
            ("blocktrust.biz", "alt_tld", 2),
            # Hyphenated
            ("block-trust.com", "hyphenated", 1),
            ("block-trust.net", "hyphenated", 1),
            ("block-trust.org", "hyphenated", 1),
            # Keyword appended
            ("blocktrustcrypto.com", "keyword_append", 2),
            ("blocktrustcrypto.net", "keyword_append", 2),
            ("blocktrust-crypto.com", "keyword_append", 2),
            ("blocktrust-ira.com", "keyword_append", 1),
            ("blocktrust-login.com", "keyword_append", 1),
            ("blocktrust-wallet.com", "keyword_append", 1),
            ("blocktrust-official.com", "keyword_append", 2),
            ("blocktrustreviews.com", "keyword_append", 2),
        ]
    },
    "genesisgoldgroup": {
        "canonical": "genesisgoldgroup.com",
        "brand_owned": {"genesisgoldgroup.com"},
        "variants": [
            # Alt TLDs
            ("genesisgoldgroup.net", "alt_tld", 1),
            ("genesisgoldgroup.org", "alt_tld", 1),
            ("genesisgoldgroup.io", "alt_tld", 1),
            ("genesisgoldgroup.co", "alt_tld", 1),
            ("genesisgoldgroup.us", "alt_tld", 2),
            # Hyphenated
            ("genesis-gold-group.com", "hyphenated", 1),
            ("genesis-gold-group.net", "hyphenated", 1),
            ("genesis-gold-ira.com", "hyphenated", 1),
            # Typosquats
            ("genesisggoldgroup.com", "typosquat", 2),
            ("genesisgoldgrup.com", "typosquat", 2),
            ("genesisgoldgroupe.com", "typosquat", 2),
            ("genesissgoldgroup.com", "typosquat", 2),
            # Keyword appended
            ("genesisgoldira.com", "keyword_append", 1),
            ("genesisgoldira.net", "keyword_append", 1),
            ("genesisgoldira.org", "keyword_append", 1),
            ("genesisira.com", "keyword_append", 2),
            ("genesisgoldgroup-login.com", "keyword_append", 1),
            ("genesisgoldgroup-account.com", "keyword_append", 1),
            ("genesisgoldgroup-support.com", "keyword_append", 1),
            ("genesisgoldgroup-official.com", "keyword_append", 2),
            ("genesisgoldgroupscam.com", "keyword_append", 2),
            ("genesisgoldgroupreviews.com", "keyword_append", 2),
        ]
    }
}


# ─────────────────────────────────────────────
# Registration checking
# ─────────────────────────────────────────────

def check_dns_resolves(domain: str) -> Optional[str]:
    """Returns IP if domain resolves, None otherwise."""
    try:
        return socket.gethostbyname(domain)
    except socket.gaierror:
        return None


def check_whois(domain: str) -> dict:
    """Run system whois and parse basic registration info."""
    try:
        result = subprocess.run(
            ['whois', domain],
            capture_output=True, text=True, timeout=15
        )
        output = result.stdout.lower()
        raw = result.stdout

        if any(x in output for x in ['no match', 'not found', 'no entries found', 'domain not found', 'no data found']):
            return {'registered': False}

        if any(x in output for x in ['domain name:', 'registrant', 'creation date', 'registered on', 'registry expiry']):
            # Extract registrar
            registrar = None
            for line in raw.splitlines():
                if 'registrar:' in line.lower() and not registrar:
                    registrar = line.split(':', 1)[-1].strip()[:100]

            # Extract dates
            reg_date = None
            exp_date = None
            for line in raw.splitlines():
                ll = line.lower()
                if ('creation date:' in ll or 'registered on:' in ll) and not reg_date:
                    reg_date = line.split(':', 1)[-1].strip()[:30]
                if ('registry expiry date:' in ll or 'expiry date:' in ll or 'expiration date:' in ll) and not exp_date:
                    exp_date = line.split(':', 1)[-1].strip()[:30]

            return {
                'registered': True,
                'registrar': registrar,
                'registered_date': reg_date,
                'expiry_date': exp_date,
            }

        return {'registered': None, 'raw_snippet': output[:200]}
    except subprocess.TimeoutExpired:
        return {'registered': None, 'error': 'timeout'}
    except Exception as e:
        return {'registered': None, 'error': str(e)[:80]}


def check_http_content(domain: str) -> dict:
    """Fetch the site and extract title + snippet for threat analysis."""
    result = {'title': None, 'snippet': None, 'redirects_to': None, 'is_phishing': False}
    try:
        r = requests.get(
            f"https://{domain}",
            timeout=8,
            allow_redirects=True,
            headers={'User-Agent': 'Mozilla/5.0 (compatible; DomainMonitor/1.0)'}
        )
        # Detect redirects
        if r.history:
            final_url = r.url
            if domain not in final_url:
                result['redirects_to'] = final_url[:200]

        content = r.text[:3000]

        # Extract title
        import re
        title_m = re.search(r'<title[^>]*>([^<]+)</title>', content, re.IGNORECASE)
        if title_m:
            result['title'] = title_m.group(1).strip()[:200]

        # Phishing indicators
        phishing_keywords = [
            'login', 'sign in', 'password', 'wallet', 'seed phrase', 'private key',
            'verify your account', 'connect wallet', 'claim your', 'airdrop',
            'enter your', 'recovery phrase'
        ]
        content_lower = content.lower()
        phishing_hits = [kw for kw in phishing_keywords if kw in content_lower]
        if len(phishing_hits) >= 2:
            result['is_phishing'] = True

        result['snippet'] = content[:300].replace('\n', ' ').strip()

    except requests.exceptions.SSLError:
        # Try HTTP
        try:
            r = requests.get(f"http://{domain}", timeout=5, allow_redirects=True)
            result['snippet'] = r.text[:200]
        except Exception:
            pass
    except Exception:
        pass

    return result


def determine_threat_level(
    domain: str,
    brand: str,
    is_registered: bool,
    resolves: bool,
    is_phishing: bool,
    brand_owned: set,
    tier: int
) -> tuple[str, str, str]:
    """Returns (status, threat_level, action_required)."""

    if domain in brand_owned:
        return DomainStatus.registered_friendly, DomainThreatLevel.safe, "none"

    if not is_registered:
        if tier == 1:
            return DomainStatus.unregistered, DomainThreatLevel.low, "purchase"
        return DomainStatus.unregistered, DomainThreatLevel.low, "monitor"

    if is_phishing:
        return DomainStatus.registered_threat, DomainThreatLevel.critical, "file_complaint"

    if resolves:
        return DomainStatus.registered_unknown, DomainThreatLevel.high, "investigate"

    return DomainStatus.registered_parked, DomainThreatLevel.medium, "monitor"


# ─────────────────────────────────────────────
# Main scan function
# ─────────────────────────────────────────────

def scan_domain(domain: str, brand: str, variant_type: str, tier: int, db: Session) -> MonitoredDomain:
    """Scan a single domain and upsert into the DB."""
    brand_config = BRAND_DOMAINS.get(brand, {})
    brand_owned = brand_config.get("brand_owned", set())

    # Get or create record
    record = db.query(MonitoredDomain).filter(MonitoredDomain.domain == domain).first()
    if not record:
        record = MonitoredDomain(
            domain=domain,
            brand=brand,
            variant_type=variant_type,
            tier=tier,
        )
        db.add(record)

    was_unregistered = record.is_registered is False

    # 1. DNS check
    ip = check_dns_resolves(domain)
    resolves = ip is not None
    record.resolves_to_ip = ip

    # 2. WHOIS check
    whois_data = check_whois(domain)
    is_registered = whois_data.get('registered')
    if is_registered is True:
        record.is_registered = True
        record.registrar = whois_data.get('registrar')
        record.registered_date = whois_data.get('registered_date')
        record.expiry_date = whois_data.get('expiry_date')
        # Flag first-time detection
        if was_unregistered and not record.first_seen_registered:
            record.first_seen_registered = datetime.utcnow()
            record.alert_sent = False  # trigger alert
    elif is_registered is False:
        record.is_registered = False
    # None = unknown, leave existing value

    # 3. HTTP content check (only if resolves)
    is_phishing = False
    if resolves and record.is_registered:
        http_data = check_http_content(domain)
        record.site_title = http_data.get('title')
        record.site_content_snippet = http_data.get('snippet')
        record.redirects_to = http_data.get('redirects_to')
        is_phishing = http_data.get('is_phishing', False)
        record.is_phishing = is_phishing

    # 4. Brand ownership check
    record.is_brand_owned = domain in brand_owned

    # 5. Determine threat level
    status, threat_level, action = determine_threat_level(
        domain, brand,
        bool(record.is_registered),
        resolves, is_phishing,
        brand_owned, tier
    )
    record.status = status
    record.threat_level = threat_level
    record.action_required = action

    # Update scan metadata
    record.last_scanned_at = datetime.utcnow()
    record.scan_count = (record.scan_count or 0) + 1
    record.updated_at = datetime.utcnow()

    db.commit()
    db.refresh(record)
    return record


def seed_watchlist(db: Session):
    """Seed all brand variants into the DB if not already present."""
    added = 0
    for brand, config in BRAND_DOMAINS.items():
        for domain, variant_type, tier in config["variants"]:
            existing = db.query(MonitoredDomain).filter(MonitoredDomain.domain == domain).first()
            if not existing:
                record = MonitoredDomain(
                    domain=domain,
                    brand=brand,
                    variant_type=variant_type,
                    tier=tier,
                    status=DomainStatus.unregistered,
                    threat_level=DomainThreatLevel.low,
                )
                db.add(record)
                added += 1
    db.commit()
    logger.info(f"Seeded {added} new domains into watchlist")
    return added


def run_full_scan(db: Session, brand: Optional[str] = None) -> dict:
    """Run a full scan of all monitored domains (or just one brand)."""
    query = db.query(MonitoredDomain)
    if brand:
        query = query.filter(MonitoredDomain.brand == brand)

    domains = query.all()
    results = {"scanned": 0, "threats_found": 0, "new_registrations": 0, "errors": 0}

    for record in domains:
        brand_config = BRAND_DOMAINS.get(record.brand, {})
        try:
            updated = scan_domain(
                record.domain, record.brand,
                record.variant_type or "unknown",
                record.tier or 2, db
            )
            results["scanned"] += 1
            if updated.threat_level in (DomainThreatLevel.critical, DomainThreatLevel.high):
                results["threats_found"] += 1
            if updated.first_seen_registered and not updated.alert_sent:
                results["new_registrations"] += 1
        except Exception as e:
            logger.error(f"Error scanning {record.domain}: {e}")
            results["errors"] += 1

    return results
