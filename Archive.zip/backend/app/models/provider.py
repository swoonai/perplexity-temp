from datetime import datetime
from sqlalchemy import Column, Integer, String, Float, Boolean, DateTime, Text, JSON
from app.models import Base


class Provider(Base):
    __tablename__ = "providers"

    id = Column(Integer, primary_key=True, index=True)
    slug = Column(String(100), unique=True, nullable=False, index=True)
    name = Column(String(200), nullable=False)
    category = Column(String(50), nullable=False)  # 'crypto' or 'precious_metals'
    tagline = Column(String(300))
    website = Column(String(500))
    affiliate_url = Column(String(500))
    logo_url = Column(String(500))

    # Fees
    setup_fee = Column(String(100))
    annual_fee = Column(String(100))
    transaction_fee = Column(String(100))
    min_investment = Column(String(100))

    # Details
    supported_assets = Column(JSON)  # list of asset names
    asset_count = Column(Integer)
    custody_provider = Column(String(200))
    storage_type = Column(String(200))
    insurance_coverage = Column(String(200))
    bbb_rating = Column(String(10))
    founded_year = Column(Integer)
    headquarters = Column(String(200))

    # Scores (0-10)
    score_fees = Column(Float)
    score_assets = Column(Float)
    score_security = Column(Float)
    score_compliance = Column(Float)
    score_support = Column(Float)
    score_reputation = Column(Float)
    score_overall = Column(Float)

    # Rankings
    rank_overall = Column(Integer)
    is_featured = Column(Boolean, default=False)
    is_active = Column(Boolean, default=True)

    # SEO
    review_slug = Column(String(200))
    meta_description = Column(Text)

    # Review data
    review_count = Column(Integer, default=1)  # Used in AggregateRating JSON-LD schema

    # Timestamps
    created_at = Column(DateTime, default=datetime.utcnow)
    updated_at = Column(DateTime, default=datetime.utcnow, onupdate=datetime.utcnow)
