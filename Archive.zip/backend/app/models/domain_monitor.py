from datetime import datetime
from sqlalchemy import Column, Integer, String, Boolean, DateTime, Text, Enum
from app.models import Base
import enum


class DomainStatus(str, enum.Enum):
    unregistered = "unregistered"
    registered_friendly = "registered_friendly"   # owned by the brand
    registered_threat = "registered_threat"        # active phishing/impersonation
    registered_parked = "registered_parked"        # registered but inactive/parked
    registered_unknown = "registered_unknown"      # registered, status unclear
    error = "error"


class DomainThreatLevel(str, enum.Enum):
    critical = "critical"    # active phishing site
    high = "high"            # registered by unknown party, resolving
    medium = "medium"        # registered but parked / no content
    low = "low"              # unregistered but high-risk variant
    safe = "safe"            # owned by brand or confirmed safe


class MonitoredDomain(Base):
    __tablename__ = "monitored_domains"

    id = Column(Integer, primary_key=True, index=True)

    # Domain info
    domain = Column(String(300), unique=True, nullable=False, index=True)
    brand = Column(String(100), nullable=False, index=True)  # 'blocktrustira', 'blocktrust', 'genesisgoldgroup'
    variant_type = Column(String(100))  # 'typosquat', 'alt_tld', 'hyphenated', 'keyword_append', 'homoglyph', 'rebrand'
    tier = Column(Integer, default=2)   # 1=critical, 2=high, 3=secondary

    # Current status
    status = Column(String(50), default=DomainStatus.unregistered)
    threat_level = Column(String(20), default=DomainThreatLevel.low)
    is_registered = Column(Boolean, nullable=True)  # None = unknown
    resolves_to_ip = Column(String(100))
    registrar = Column(String(200))
    registered_date = Column(String(50))
    expiry_date = Column(String(50))

    # Content analysis
    site_title = Column(String(500))
    site_content_snippet = Column(Text)
    redirects_to = Column(String(500))
    is_phishing = Column(Boolean, default=False)
    is_brand_owned = Column(Boolean, default=False)

    # Action tracking
    action_required = Column(String(200))  # 'purchase', 'file_complaint', 'monitor', 'none'
    action_taken = Column(Text)
    notes = Column(Text)

    # Scan metadata
    last_scanned_at = Column(DateTime)
    scan_count = Column(Integer, default=0)
    first_seen_registered = Column(DateTime)  # when we first detected it as registered
    alert_sent = Column(Boolean, default=False)

    # Timestamps
    created_at = Column(DateTime, default=datetime.utcnow)
    updated_at = Column(DateTime, default=datetime.utcnow, onupdate=datetime.utcnow)
