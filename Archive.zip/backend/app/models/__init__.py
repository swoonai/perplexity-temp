from sqlalchemy.orm import DeclarativeBase

class Base(DeclarativeBase):
    pass

from app.models.provider import Provider  # noqa: F401, E402
from app.models.review import ReviewMention  # noqa: F401, E402
from app.models.domain_monitor import MonitoredDomain  # noqa: F401, E402
from app.models.award import Award  # noqa: F401, E402
