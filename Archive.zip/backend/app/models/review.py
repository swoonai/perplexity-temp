from datetime import datetime
from sqlalchemy import Column, Integer, String, Float, Boolean, DateTime, Text, ForeignKey
from app.models import Base


class ReviewMention(Base):
    __tablename__ = "review_mentions"

    id = Column(Integer, primary_key=True, index=True)
    provider_id = Column(Integer, ForeignKey("providers.id"), nullable=False, index=True)
    source_url = Column(String(1000), nullable=False)
    source_domain = Column(String(200))
    source_title = Column(String(500))
    query_keyword = Column(String(300))
    serp_position = Column(Integer)
    sentiment = Column(String(20))  # 'positive', 'negative', 'neutral'
    rating_mentioned = Column(Float)
    snippet = Column(Text)
    crawled_at = Column(DateTime, default=datetime.utcnow)
    is_verified = Column(Boolean, default=False)
