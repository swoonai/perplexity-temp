"""
award.py — SQLAlchemy model for the awards table.

This model is shared between:
  - iraresearchhub.com (internal admin)
  - iraawards.com (satellite site)
  - bitcoiniraawards.com (satellite site)
  - cryptoiraawards.com (satellite site)

The awards table stores award definitions and their winners/runners-up for each
award category and year. The `site_key` field determines which satellite site
the award belongs to.
"""

from datetime import datetime
from sqlalchemy import Column, Integer, String, Float, Boolean, DateTime, Text, Enum
from app.models import Base


class Award(Base):
    __tablename__ = "awards"

    id = Column(Integer, primary_key=True, index=True)

    # Foreign key to providers table (provider_id)
    provider_id = Column(Integer, nullable=False, index=True)

    # Award metadata
    award_year = Column(Integer, nullable=False, index=True)
    award_category = Column(String(128), nullable=False, index=True)
    award_label = Column(String(255), nullable=False)

    # Status: winner, runner_up, nominee
    award_status = Column(
        Enum("winner", "runner_up", "nominee", name="award_status_enum"),
        nullable=False,
        default="nominee",
        index=True,
    )

    # Which satellite site this award belongs to
    # 'ira' = iraawards.com, 'bitcoin' = bitcoiniraawards.com, 'crypto' = cryptoiraawards.com
    site_key = Column(
        Enum("ira", "bitcoin", "crypto", name="award_site_key_enum"),
        nullable=False,
        default="ira",
        index=True,
    )

    # Score at time of award (0.0–10.0)
    score_at_award = Column(Float)

    # Citation text (e.g., "Awarded for best crypto IRA fees in 2026")
    citation = Column(Text)

    # Whether this award is currently active/displayed
    is_active = Column(Boolean, default=True, nullable=False)

    # Timestamps
    awarded_at = Column(DateTime, default=datetime.utcnow, nullable=False)
    created_at = Column(DateTime, default=datetime.utcnow, nullable=False)
    updated_at = Column(DateTime, default=datetime.utcnow, onupdate=datetime.utcnow, nullable=False)
