from fastapi import FastAPI
from fastapi.middleware.cors import CORSMiddleware
from app.api.v1.router import api_router

app = FastAPI(
    title="IRA Research Hub API",
    description="Provider data and review engine for iraresearchhub.com",
    version="1.0.0",
    docs_url="/api/docs",
    redoc_url="/api/redoc",
)

# CORS — allow the frontend origin
app.add_middleware(
    CORSMiddleware,
    allow_origins=[
        "https://iraresearchhub.com",
        "https://www.iraresearchhub.com",
        "http://localhost:5173",  # Vite dev server
        "http://104.131.110.45",
    ],
    allow_credentials=True,
    allow_methods=["GET", "POST"],
    allow_headers=["*"],
)

app.include_router(api_router, prefix="/api/v1")


@app.on_event("startup")
def startup_event():
    from app.db.session import engine
    from app.models import Base
    Base.metadata.create_all(bind=engine)


@app.get("/api/health")
def health_check():
    return {"status": "ok", "service": "ira-research-hub-api"}

@app.get("/api/v1/version")
def get_version():
    import subprocess
    try:
        commit = subprocess.check_output(
            ["git", "rev-parse", "--short", "HEAD"],
            cwd="/var/www/iraresearchhub/repo",
            stderr=subprocess.DEVNULL
        ).decode().strip()
    except:
        commit = "unknown"
    return {"commit": commit, "repo": "/var/www/iraresearchhub/repo"}
