from fastapi import APIRouter
from app.api.v1.endpoints import providers, tracker, domain_monitor, awards

api_router = APIRouter()
api_router.include_router(providers.router, prefix="/providers", tags=["providers"])
api_router.include_router(tracker.router, prefix="/tracker", tags=["tracker"])
api_router.include_router(domain_monitor.router, prefix="/domains", tags=["domain-monitor"])
api_router.include_router(awards.router, prefix="/awards", tags=["awards"])
