"""
awards.py — FastAPI endpoints for the awards satellite sites.

These endpoints serve:
  - iraawards.com (site_key='ira')
  - bitcoiniraawards.com (site_key='bitcoin')
  - cryptoiraawards.com (site_key='crypto')

All endpoints are read-only (GET). Award data is managed via the
gggbt-engine admin UI (awardsRouter in routers.ts).

Endpoints:
  GET /awards/                        — List all awards (filterable)
  GET /awards/winners/{site_key}      — Get all category winners for a site+year
  GET /awards/{id}                    — Get a single award by ID
  GET /awards/category/{category}     — Get all awards for a category
  GET /awards/provider/{provider_id}  — Get all awards for a provider
"""

from typing import Optional, List, Literal
from fastapi import APIRouter, Depends, HTTPException, Query
from sqlalchemy.orm import Session
from sqlalchemy import and_
from app.db.session import get_db
from app.models.award import Award
from app.models.provider import Provider
from app.schemas.award import (
    AwardResponse,
    AwardListResponse,
    AwardCategoryWinner,
    AwardCategoryWinnersResponse,
)

router = APIRouter()


def _build_award_response(award: Award, provider: Optional[Provider]) -> AwardResponse:
    """Build an AwardResponse with denormalized provider fields."""
    return AwardResponse(
        id=award.id,
        provider_id=award.provider_id,
        award_year=award.award_year,
        award_category=award.award_category,
        award_label=award.award_label,
        award_status=award.award_status,
        site_key=award.site_key,
        score_at_award=award.score_at_award,
        citation=award.citation,
        is_active=award.is_active,
        awarded_at=award.awarded_at,
        created_at=award.created_at,
        updated_at=award.updated_at,
        provider_name=provider.name if provider else None,
        provider_slug=provider.slug if provider else None,
        provider_logo_url=provider.logo_url if provider else None,
        provider_affiliate_url=provider.affiliate_url if provider else None,
        provider_website=provider.website if provider else None,
    )


@router.get("/", response_model=AwardListResponse)
def list_awards(
    site_key: Optional[str] = Query(None, description="Filter by site: ira, bitcoin, crypto"),
    year: Optional[int] = Query(None, description="Filter by award year"),
    category: Optional[str] = Query(None, description="Filter by award category"),
    status: Optional[str] = Query(None, description="Filter by status: winner, runner_up, nominee"),
    active_only: bool = Query(True, description="Return only active awards"),
    db: Session = Depends(get_db),
):
    """
    List all awards with optional filters.
    Used by satellite site listing pages and comparison tables.
    """
    query = db.query(Award)

    if active_only:
        query = query.filter(Award.is_active == True)
    if site_key:
        query = query.filter(Award.site_key == site_key)
    if year:
        query = query.filter(Award.award_year == year)
    if category:
        query = query.filter(Award.award_category == category)
    if status:
        query = query.filter(Award.award_status == status)

    query = query.order_by(Award.award_year.desc(), Award.award_category.asc())
    award_rows = query.all()

    # Batch-load providers
    provider_ids = list({a.provider_id for a in award_rows})
    providers_map = {}
    if provider_ids:
        providers = db.query(Provider).filter(Provider.id.in_(provider_ids)).all()
        providers_map = {p.id: p for p in providers}

    responses = [
        _build_award_response(a, providers_map.get(a.provider_id))
        for a in award_rows
    ]

    return AwardListResponse(
        awards=responses,
        total=len(responses),
        year=year,
        category=category,
        site_key=site_key,
    )


@router.get("/winners/{site_key}", response_model=AwardCategoryWinnersResponse)
def get_category_winners(
    site_key: str,
    year: int = Query(2026, description="Award year"),
    db: Session = Depends(get_db),
):
    """
    Get all category winners for a given satellite site and year.
    Used by the satellite site hero/category sections.

    site_key: 'ira', 'bitcoin', or 'crypto'
    """
    if site_key not in ("ira", "bitcoin", "crypto"):
        raise HTTPException(
            status_code=400,
            detail=f"Invalid site_key '{site_key}'. Must be one of: ira, bitcoin, crypto",
        )

    award_rows = (
        db.query(Award)
        .filter(
            and_(
                Award.site_key == site_key,
                Award.award_year == year,
                Award.award_status == "winner",
                Award.is_active == True,
            )
        )
        .order_by(Award.award_category.asc())
        .all()
    )

    # Batch-load providers
    provider_ids = list({a.provider_id for a in award_rows})
    providers_map = {}
    if provider_ids:
        providers = db.query(Provider).filter(Provider.id.in_(provider_ids)).all()
        providers_map = {p.id: p for p in providers}

    winners = []
    for award in award_rows:
        provider = providers_map.get(award.provider_id)
        winners.append(
            AwardCategoryWinner(
                category=award.award_category,
                award_label=award.award_label,
                award_year=award.award_year,
                site_key=award.site_key,
                winner_name=provider.name if provider else f"Provider #{award.provider_id}",
                winner_slug=provider.slug if provider else str(award.provider_id),
                winner_logo_url=provider.logo_url if provider else None,
                winner_affiliate_url=provider.affiliate_url if provider else None,
                winner_score=award.score_at_award,
                citation=award.citation,
            )
        )

    return AwardCategoryWinnersResponse(
        site_key=site_key,
        year=year,
        winners=winners,
        total=len(winners),
    )


@router.get("/category/{category}", response_model=AwardListResponse)
def get_awards_by_category(
    category: str,
    site_key: Optional[str] = Query(None),
    year: Optional[int] = Query(None),
    db: Session = Depends(get_db),
):
    """
    Get all awards for a specific category.
    Used by category detail pages on the satellite sites.
    """
    query = db.query(Award).filter(
        and_(Award.award_category == category, Award.is_active == True)
    )
    if site_key:
        query = query.filter(Award.site_key == site_key)
    if year:
        query = query.filter(Award.award_year == year)

    query = query.order_by(Award.award_year.desc(), Award.award_status.asc())
    award_rows = query.all()

    provider_ids = list({a.provider_id for a in award_rows})
    providers_map = {}
    if provider_ids:
        providers = db.query(Provider).filter(Provider.id.in_(provider_ids)).all()
        providers_map = {p.id: p for p in providers}

    responses = [
        _build_award_response(a, providers_map.get(a.provider_id))
        for a in award_rows
    ]

    return AwardListResponse(
        awards=responses,
        total=len(responses),
        year=year,
        category=category,
        site_key=site_key,
    )


@router.get("/provider/{provider_id}", response_model=AwardListResponse)
def get_awards_by_provider(
    provider_id: int,
    site_key: Optional[str] = Query(None),
    db: Session = Depends(get_db),
):
    """
    Get all awards for a specific provider.
    Used by provider award badges on review pages.
    """
    provider = db.query(Provider).filter(Provider.id == provider_id).first()
    if not provider:
        raise HTTPException(status_code=404, detail=f"Provider #{provider_id} not found")

    query = db.query(Award).filter(
        and_(Award.provider_id == provider_id, Award.is_active == True)
    )
    if site_key:
        query = query.filter(Award.site_key == site_key)

    query = query.order_by(Award.award_year.desc(), Award.award_category.asc())
    award_rows = query.all()

    responses = [_build_award_response(a, provider) for a in award_rows]

    return AwardListResponse(
        awards=responses,
        total=len(responses),
        site_key=site_key,
    )


@router.get("/{award_id}", response_model=AwardResponse)
def get_award(award_id: int, db: Session = Depends(get_db)):
    """
    Get a single award by ID.
    """
    award = db.query(Award).filter(Award.id == award_id).first()
    if not award:
        raise HTTPException(status_code=404, detail=f"Award #{award_id} not found")

    provider = db.query(Provider).filter(Provider.id == award.provider_id).first()
    return _build_award_response(award, provider)
