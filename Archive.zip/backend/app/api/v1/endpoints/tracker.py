"""
Shared task tracker API.
Persists checkbox state to a JSON file on the server so all team members
see the same live board.

GET  /api/v1/tracker/state            → returns full state
POST /api/v1/tracker/state            → update checked status for a task
POST /api/v1/tracker/queue            → update queued-for-Manus status for a task
GET  /api/v1/tracker/queue            → returns just the queued task IDs
GET  /api/v1/tracker/state/reset      → resets all checkboxes and queue (admin use)
"""

import json
import os
from datetime import datetime, timezone
from fastapi import APIRouter
from pydantic import BaseModel

router = APIRouter()

STATE_FILE = os.path.join(os.path.dirname(__file__), "..", "..", "..", "..", "tracker_state.json")


def _load() -> dict:
    if os.path.exists(STATE_FILE):
        try:
            with open(STATE_FILE, "r") as f:
                return json.load(f)
        except Exception:
            pass
    return {
        "checked": {},
        "queued": {},
        "updated_at": None,
        "updated_by": None,
        "queue_updated_at": None,
        "queue_updated_by": None,
    }


def _save(state: dict):
    os.makedirs(os.path.dirname(STATE_FILE), exist_ok=True)
    with open(STATE_FILE, "w") as f:
        json.dump(state, f, indent=2)


def _migrate(state: dict) -> dict:
    """Ensure older state files have the queued field."""
    if "queued" not in state:
        state["queued"] = {}
    if "queue_updated_at" not in state:
        state["queue_updated_at"] = None
    if "queue_updated_by" not in state:
        state["queue_updated_by"] = None
    return state


class TaskUpdate(BaseModel):
    id: str
    checked: bool
    updated_by: str = "team"


class QueueUpdate(BaseModel):
    id: str
    queued: bool
    updated_by: str = "team"


@router.get("/state")
def get_state():
    return _migrate(_load())


@router.post("/state")
def update_state(update: TaskUpdate):
    state = _migrate(_load())
    state["checked"][update.id] = update.checked
    state["updated_at"] = datetime.now(timezone.utc).isoformat()
    state["updated_by"] = update.updated_by
    _save(state)
    return state


@router.get("/queue")
def get_queue():
    state = _migrate(_load())
    queued_ids = [k for k, v in state.get("queued", {}).items() if v]
    return {
        "queued": queued_ids,
        "queue_updated_at": state.get("queue_updated_at"),
        "queue_updated_by": state.get("queue_updated_by"),
    }


@router.post("/queue")
def update_queue(update: QueueUpdate):
    state = _migrate(_load())
    state["queued"][update.id] = update.queued
    state["queue_updated_at"] = datetime.now(timezone.utc).isoformat()
    state["queue_updated_by"] = update.updated_by
    _save(state)
    return state


@router.get("/state/reset")
def reset_state():
    state = {
        "checked": {},
        "queued": {},
        "updated_at": datetime.now(timezone.utc).isoformat(),
        "updated_by": "reset",
        "queue_updated_at": None,
        "queue_updated_by": None,
    }
    _save(state)
    return state
