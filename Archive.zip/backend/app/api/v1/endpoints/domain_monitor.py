"""
Domain Monitor API endpoints
GET  /api/v1/domains/                  — list all monitored domains (filterable)
GET  /api/v1/domains/summary           — threat summary by brand
GET  /api/v1/domains/{domain}          — single domain detail
POST /api/v1/domains/scan              — trigger a scan (full or single brand)
POST /api/v1/domains/seed              — seed the watchlist from the master list
POST /api/v1/domains/{domain}/action   — record an action taken on a domain
"""
from typing import Optional, List
from fastapi import APIRouter, Depends, HTTPException, BackgroundTasks
from sqlalchemy.orm import Session
from sqlalchemy import func
from pydantic import BaseModel
from datetime import datetime

from app.db.session import get_db
from app.models.domain_monitor import MonitoredDomain, DomainThreatLevel
from app.services.domain_scanner import seed_watchlist, run_full_scan, scan_domain, BRAND_DOMAINS

router = APIRouter()


# ─────────────────────────────────────────────
# Schemas
# ─────────────────────────────────────────────

class DomainOut(BaseModel):
    id: int
    domain: str
    brand: str
    variant_type: Optional[str]
    tier: Optional[int]
    status: Optional[str]
    threat_level: Optional[str]
    is_registered: Optional[bool]
    resolves_to_ip: Optional[str]
    registrar: Optional[str]
    registered_date: Optional[str]
    expiry_date: Optional[str]
    site_title: Optional[str]
    redirects_to: Optional[str]
    is_phishing: Optional[bool]
    is_brand_owned: Optional[bool]
    action_required: Optional[str]
    action_taken: Optional[str]
    notes: Optional[str]
    last_scanned_at: Optional[datetime]
    scan_count: Optional[int]
    first_seen_registered: Optional[datetime]
    alert_sent: Optional[bool]
    created_at: Optional[datetime]
    updated_at: Optional[datetime]

    class Config:
        from_attributes = True


class ThreatSummary(BaseModel):
    brand: str
    total: int
    critical: int
    high: int
    medium: int
    low: int
    safe: int
    unscanned: int
    last_scan: Optional[datetime]


class ActionUpdate(BaseModel):
    action_taken: str
    notes: Optional[str] = None
    alert_sent: Optional[bool] = None


class ScanRequest(BaseModel):
    brand: Optional[str] = None  # None = scan all brands
    domain: Optional[str] = None  # scan a single domain


# ─────────────────────────────────────────────
# Endpoints
# ─────────────────────────────────────────────

@router.get("/", response_model=List[DomainOut])
def list_domains(
    brand: Optional[str] = None,
    threat_level: Optional[str] = None,
    status: Optional[str] = None,
    action_required: Optional[str] = None,
    tier: Optional[int] = None,
    limit: int = 200,
    db: Session = Depends(get_db)
):
    """List all monitored domains with optional filters."""
    q = db.query(MonitoredDomain)
    if brand:
        q = q.filter(MonitoredDomain.brand == brand)
    if threat_level:
        q = q.filter(MonitoredDomain.threat_level == threat_level)
    if status:
        q = q.filter(MonitoredDomain.status == status)
    if action_required:
        q = q.filter(MonitoredDomain.action_required == action_required)
    if tier:
        q = q.filter(MonitoredDomain.tier == tier)
    return q.order_by(MonitoredDomain.tier, MonitoredDomain.threat_level).limit(limit).all()


@router.get("/summary")
def get_summary(db: Session = Depends(get_db)):
    """Get threat summary grouped by brand."""
    summaries = []
    for brand in BRAND_DOMAINS.keys():
        domains = db.query(MonitoredDomain).filter(MonitoredDomain.brand == brand).all()
        if not domains:
            continue
        last_scan = max((d.last_scanned_at for d in domains if d.last_scanned_at), default=None)
        summaries.append({
            "brand": brand,
            "total": len(domains),
            "critical": sum(1 for d in domains if d.threat_level == DomainThreatLevel.critical),
            "high": sum(1 for d in domains if d.threat_level == DomainThreatLevel.high),
            "medium": sum(1 for d in domains if d.threat_level == DomainThreatLevel.medium),
            "low": sum(1 for d in domains if d.threat_level == DomainThreatLevel.low),
            "safe": sum(1 for d in domains if d.threat_level == DomainThreatLevel.safe),
            "unscanned": sum(1 for d in domains if not d.last_scanned_at),
            "last_scan": last_scan,
        })
    return summaries


@router.get("/alerts")
def get_alerts(db: Session = Depends(get_db)):
    """Get all domains that need attention (new registrations, threats, unacknowledged alerts)."""
    alerts = db.query(MonitoredDomain).filter(
        (MonitoredDomain.alert_sent == False) &
        (MonitoredDomain.is_registered == True) &
        (MonitoredDomain.is_brand_owned != True)
    ).order_by(MonitoredDomain.threat_level).all()
    return alerts


@router.get("/{domain_name:path}", response_model=DomainOut)
def get_domain(domain_name: str, db: Session = Depends(get_db)):
    """Get details for a specific domain."""
    record = db.query(MonitoredDomain).filter(MonitoredDomain.domain == domain_name).first()
    if not record:
        raise HTTPException(status_code=404, detail=f"Domain {domain_name} not found in watchlist")
    return record


@router.post("/seed")
def seed_domains(db: Session = Depends(get_db)):
    """Seed the watchlist with all brand variant domains."""
    added = seed_watchlist(db)
    total = db.query(func.count(MonitoredDomain.id)).scalar()
    return {"seeded": added, "total_in_watchlist": total}


@router.post("/scan")
def trigger_scan(request: ScanRequest, background_tasks: BackgroundTasks, db: Session = Depends(get_db)):
    """Trigger a domain scan. Runs in background for full scans."""
    if request.domain:
        # Single domain scan — run synchronously
        record = db.query(MonitoredDomain).filter(MonitoredDomain.domain == request.domain).first()
        if not record:
            raise HTTPException(status_code=404, detail=f"Domain {request.domain} not in watchlist")
        updated = scan_domain(record.domain, record.brand, record.variant_type or "unknown", record.tier or 2, db)
        return {"scanned": 1, "domain": updated.domain, "status": updated.status, "threat_level": updated.threat_level}

    # Full scan — run in background
    def _run():
        from app.db.session import SessionLocal
        bg_db = SessionLocal()
        try:
            run_full_scan(bg_db, brand=request.brand)
        finally:
            bg_db.close()

    background_tasks.add_task(_run)
    brand_label = request.brand or "all brands"
    return {"message": f"Full scan started for {brand_label} in background"}


@router.post("/{domain_name:path}/action")
def update_action(domain_name: str, update: ActionUpdate, db: Session = Depends(get_db)):
    """Record an action taken on a domain (e.g. 'Filed Dynadot abuse report')."""
    record = db.query(MonitoredDomain).filter(MonitoredDomain.domain == domain_name).first()
    if not record:
        raise HTTPException(status_code=404, detail=f"Domain {domain_name} not found")

    record.action_taken = update.action_taken
    if update.notes:
        record.notes = update.notes
    if update.alert_sent is not None:
        record.alert_sent = update.alert_sent
    record.updated_at = datetime.utcnow()
    db.commit()
    db.refresh(record)
    return record
