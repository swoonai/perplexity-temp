import os
from typing import Optional, Dict
from fastapi import APIRouter, Depends, HTTPException, Header
from sqlalchemy.orm import Session
from app.db.session import get_db
from app.models.provider import Provider
from app.schemas.provider import ProviderResponse, ProviderListResponse

router = APIRouter()


@router.get("/", response_model=ProviderListResponse)
def list_providers(
    category: Optional[str] = None,
    featured_only: bool = False,
    db: Session = Depends(get_db),
):
    """
    List all active providers, optionally filtered by category.
    - category: 'crypto' or 'precious_metals'
    - featured_only: return only featured/top-ranked providers
    """
    query = db.query(Provider).filter(Provider.is_active == True)

    if category:
        query = query.filter(Provider.category == category)

    if featured_only:
        query = query.filter(Provider.is_featured == True)

    query = query.order_by(Provider.rank_overall.asc().nullslast())
    providers = query.all()

    return ProviderListResponse(
        providers=providers,
        total=len(providers),
        category=category,
    )


@router.get("/ranked", response_model=ProviderListResponse)
def get_ranked_providers(
    category: str,
    limit: int = 10,
    db: Session = Depends(get_db),
):
    """
    Get ranked providers for a specific category (used by comparison pages).
    """
    providers = (
        db.query(Provider)
        .filter(Provider.is_active == True, Provider.category == category)
        .order_by(Provider.rank_overall.asc().nullslast())
        .limit(limit)
        .all()
    )
    return ProviderListResponse(providers=providers, total=len(providers), category=category)


# IMPORTANT: This route must be defined BEFORE /{slug} to avoid being caught by the slug pattern
@router.patch("/admin/scores", status_code=200)
def bulk_update_scores(
    scores: Dict[str, float],
    x_admin_key: Optional[str] = Header(None),
    db: Session = Depends(get_db),
):
    """
    Admin endpoint: bulk update provider score_overall values.
    Protected by X-Admin-Key header.
    Body: { "genesis-gold-group": 9.4, "goldco": 9.2, ... }
    """
    admin_key = os.environ.get("ADMIN_SECRET_KEY", "ira-admin-2026-secret")
    if x_admin_key != admin_key:
        raise HTTPException(status_code=403, detail="Invalid admin key")

    from sqlalchemy import text as _text
    updated = []
    not_found = []
    for slug, new_score in scores.items():
        # Use raw SQL to bypass ORM caching and any trigger issues
        result = db.execute(
            _text("UPDATE providers SET score_overall = :score, updated_at = NOW() WHERE slug = :slug"),
            {"score": float(new_score), "slug": slug}
        )
        if result.rowcount == 0:
            not_found.append(slug)
        else:
            updated.append(slug)

    db.commit()
    return {"updated": updated, "not_found": not_found, "total": len(updated)}


@router.get("/{slug}", response_model=ProviderResponse)
def get_provider(slug: str, db: Session = Depends(get_db)):
    """
    Get a single provider by slug (used by review pages).
    """
    provider = db.query(Provider).filter(
        Provider.slug == slug,
        Provider.is_active == True,
    ).first()

    if not provider:
        raise HTTPException(status_code=404, detail=f"Provider '{slug}' not found")

    return provider
