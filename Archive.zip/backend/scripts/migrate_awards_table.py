#!/usr/bin/env python3
"""
migrate_awards_table.py — Create the awards table in the PostgreSQL database.

This script creates the awards table if it does not already exist.
It is designed to be idempotent (safe to run multiple times).

Usage:
    python3 migrate_awards_table.py [--dry-run]

Environment variables:
    DATABASE_URL   postgresql://iraresearchhub:...@localhost/iraresearchhub
"""

import argparse
import os
import sys
import logging
from sqlalchemy import create_engine, text

logging.basicConfig(level=logging.INFO, format="%(levelname)s: %(message)s")
logger = logging.getLogger(__name__)

# ─── SQL ──────────────────────────────────────────────────────────────────────

CREATE_AWARD_STATUS_ENUM = """
DO $$
BEGIN
    IF NOT EXISTS (SELECT 1 FROM pg_type WHERE typname = 'award_status_enum') THEN
        CREATE TYPE award_status_enum AS ENUM ('winner', 'runner_up', 'nominee');
    END IF;
END$$;
"""

CREATE_AWARD_SITE_KEY_ENUM = """
DO $$
BEGIN
    IF NOT EXISTS (SELECT 1 FROM pg_type WHERE typname = 'award_site_key_enum') THEN
        CREATE TYPE award_site_key_enum AS ENUM ('ira', 'bitcoin', 'crypto');
    END IF;
END$$;
"""

CREATE_AWARDS_TABLE = """
CREATE TABLE IF NOT EXISTS awards (
    id              SERIAL PRIMARY KEY,
    provider_id     INTEGER NOT NULL,
    award_year      INTEGER NOT NULL,
    award_category  VARCHAR(128) NOT NULL,
    award_label     VARCHAR(255) NOT NULL,
    award_status    award_status_enum NOT NULL DEFAULT 'nominee',
    site_key        award_site_key_enum NOT NULL DEFAULT 'ira',
    score_at_award  FLOAT,
    citation        TEXT,
    is_active       BOOLEAN NOT NULL DEFAULT TRUE,
    awarded_at      TIMESTAMP NOT NULL DEFAULT NOW(),
    created_at      TIMESTAMP NOT NULL DEFAULT NOW(),
    updated_at      TIMESTAMP NOT NULL DEFAULT NOW()
);
"""

CREATE_AWARDS_INDEXES = """
CREATE INDEX IF NOT EXISTS idx_awards_provider_id ON awards (provider_id);
CREATE INDEX IF NOT EXISTS idx_awards_award_year ON awards (award_year);
CREATE INDEX IF NOT EXISTS idx_awards_award_category ON awards (award_category);
CREATE INDEX IF NOT EXISTS idx_awards_award_status ON awards (award_status);
CREATE INDEX IF NOT EXISTS idx_awards_site_key ON awards (site_key);
"""

# ─── Seed data ────────────────────────────────────────────────────────────────

SEED_AWARDS = """
-- Seed 2026 awards for iraawards.com (site_key='ira')
-- These are placeholder awards; real data will be synced from the engine via bridge_sync.py
INSERT INTO awards (provider_id, award_year, award_category, award_label, award_status, site_key, score_at_award, citation, is_active)
SELECT p.id, 2026, 'Best Overall IRA Provider', 'Best Overall IRA Provider 2026', 'winner', 'ira', 9.6,
       'Awarded for exceptional overall performance across fees, security, compliance, and customer support.',
       TRUE
FROM providers p WHERE p.slug = 'blocktrust-ira' AND NOT EXISTS (
    SELECT 1 FROM awards a WHERE a.provider_id = p.id AND a.award_year = 2026 AND a.award_category = 'Best Overall IRA Provider' AND a.site_key = 'ira'
)
LIMIT 1;

-- Seed 2026 awards for bitcoiniraawards.com (site_key='bitcoin')
INSERT INTO awards (provider_id, award_year, award_category, award_label, award_status, site_key, score_at_award, citation, is_active)
SELECT p.id, 2026, 'Best Bitcoin IRA Provider', 'Best Bitcoin IRA Provider 2026', 'winner', 'bitcoin', 9.6,
       'Awarded for best-in-class Bitcoin IRA custody, security, and fee structure.',
       TRUE
FROM providers p WHERE p.slug = 'blocktrust-ira' AND NOT EXISTS (
    SELECT 1 FROM awards a WHERE a.provider_id = p.id AND a.award_year = 2026 AND a.award_category = 'Best Bitcoin IRA Provider' AND a.site_key = 'bitcoin'
)
LIMIT 1;

-- Seed 2026 awards for cryptoiraawards.com (site_key='crypto')
INSERT INTO awards (provider_id, award_year, award_category, award_label, award_status, site_key, score_at_award, citation, is_active)
SELECT p.id, 2026, 'Best Crypto IRA Provider', 'Best Crypto IRA Provider 2026', 'winner', 'crypto', 9.6,
       'Awarded for supporting 60+ cryptocurrencies with institutional-grade custody.',
       TRUE
FROM providers p WHERE p.slug = 'blocktrust-ira' AND NOT EXISTS (
    SELECT 1 FROM awards a WHERE a.provider_id = p.id AND a.award_year = 2026 AND a.award_category = 'Best Crypto IRA Provider' AND a.site_key = 'crypto'
)
LIMIT 1;
"""


# ─── Main ─────────────────────────────────────────────────────────────────────

def main():
    parser = argparse.ArgumentParser(description="Create the awards table in the PostgreSQL database")
    parser.add_argument("--dry-run", action="store_true", help="Print SQL without executing")
    args = parser.parse_args()

    db_url = os.getenv(
        "DATABASE_URL",
        "postgresql://iraresearchhub:iraresearchhub2026@localhost/iraresearchhub"
    )

    if args.dry_run:
        logger.info("DRY RUN — SQL that would be executed:")
        for sql in [CREATE_AWARD_STATUS_ENUM, CREATE_AWARD_SITE_KEY_ENUM, CREATE_AWARDS_TABLE, CREATE_AWARDS_INDEXES, SEED_AWARDS]:
            print(sql)
        return

    engine = create_engine(db_url, pool_pre_ping=True)

    try:
        with engine.begin() as conn:
            logger.info("Creating award_status_enum type...")
            conn.execute(text(CREATE_AWARD_STATUS_ENUM))

            logger.info("Creating award_site_key_enum type...")
            conn.execute(text(CREATE_AWARD_SITE_KEY_ENUM))

            logger.info("Creating awards table...")
            conn.execute(text(CREATE_AWARDS_TABLE))

            logger.info("Creating awards indexes...")
            conn.execute(text(CREATE_AWARDS_INDEXES))

            logger.info("Seeding initial award data...")
            conn.execute(text(SEED_AWARDS))

        logger.info("Migration complete. awards table is ready.")
    except Exception as e:
        logger.error(f"Migration failed: {e}")
        sys.exit(1)


if __name__ == "__main__":
    main()
