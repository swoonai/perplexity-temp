#!/usr/bin/env python3
"""
Migration: Add score_lock column and set to TRUE for all providers.
This protects curated scores from being overwritten by bridge_sync.
Run once on the production database.
"""
import os
import sys

sys.path.insert(0, os.path.dirname(os.path.dirname(os.path.abspath(__file__))))

from sqlalchemy import text
from app.db.session import SessionLocal

def migrate():
    db = SessionLocal()
    try:
        # Add score_lock column if it doesn't exist
        db.execute(text("""
            ALTER TABLE providers 
            ADD COLUMN IF NOT EXISTS score_lock BOOLEAN NOT NULL DEFAULT FALSE
        """))
        db.commit()
        print("Column score_lock added (or already exists)")
        
        # Set score_lock=TRUE for all providers to protect curated scores
        result = db.execute(text("""
            UPDATE providers SET score_lock = TRUE
        """))
        db.commit()
        print(f"Set score_lock=TRUE for all providers")
        
        # Verify
        rows = db.execute(text("SELECT name, score_overall, score_lock FROM providers ORDER BY name")).fetchall()
        print(f"\nVerification ({len(rows)} providers):")
        for row in rows:
            print(f"  {row[0]}: score={row[1]}, score_lock={row[2]}")
            
    except Exception as e:
        db.rollback()
        print(f"Error: {e}")
        raise
    finally:
        db.close()

if __name__ == "__main__":
    migrate()
