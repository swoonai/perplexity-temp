#!/usr/bin/env python3
"""
Bridge Sync Script
==================
Reads provider intelligence data from the gggbt-engine MySQL database
and syncs it into the public iraresearchhub PostgreSQL database.

This script maps engine provider_profiles data → public providers table,
updating scores, fees, and metadata so the public site always reflects
the latest research run output.

score_lock behaviour
--------------------
If a provider row has score_lock = TRUE in the public PostgreSQL DB, bridge_sync
will NOT overwrite ANY of the following fields for that provider:

  Scores:   score_overall, score_fees, score_security, score_reputation
  Metadata: setup_fee, annual_fee, transaction_fee, min_investment,
            custody_provider

This protects all manually curated values (e.g. Jacob Diaz audit corrections)
from being overwritten by stale or incomplete engine data.

The only field always updated regardless of score_lock is updated_at, so the
row's freshness timestamp stays accurate.

Usage:
    python3 bridge_sync.py [--dry-run] [--verbose]

Environment variables (can be set or passed inline):
    ENGINE_DB_URL   mysql://gggbt:...@localhost:3306/gggbt_engine
    PUBLIC_DB_URL   postgresql://iraresearchhub:...@localhost/iraresearchhub
"""

import argparse
import os
import sys
import logging
from datetime import datetime, timezone

# ---------------------------------------------------------------------------
# Argument parsing
# ---------------------------------------------------------------------------
parser = argparse.ArgumentParser(description="Sync engine provider data to public site DB")
parser.add_argument("--dry-run", action="store_true", help="Print changes without writing to DB")
parser.add_argument("--verbose", action="store_true", help="Enable debug logging")
args = parser.parse_args()

logging.basicConfig(
    level=logging.DEBUG if args.verbose else logging.INFO,
    format="%(asctime)s [%(levelname)s] %(message)s",
)
log = logging.getLogger("bridge_sync")

# ---------------------------------------------------------------------------
# DB connection strings
# ---------------------------------------------------------------------------
ENGINE_DB_URL = os.environ.get(
    "ENGINE_DB_URL",
    "mysql://gggbt:Gggbt2026!Engine@localhost:3306/gggbt_engine",
)
PUBLIC_DB_URL = os.environ.get(
    "PUBLIC_DB_URL",
    "postgresql://iraresearchhub:iraresearchhub2026@localhost/iraresearchhub",
)

# ---------------------------------------------------------------------------
# Slug mapping: engine provider name → public site slug
# ---------------------------------------------------------------------------
SLUG_MAP = {
    # Crypto IRA providers
    "BlockTrust IRA": "blocktrust-ira",
    "Bitcoin IRA": "bitcoin-ira",
    "iTrustCapital": "itrustcapital",
    "Alto CryptoIRA": "alto-crypto-ira",
    "BitIRA": "bitira",
    "Swan Bitcoin IRA": "swan-bitcoin-ira",
    "Rocket Dollar": "rocket-dollar",
    "Unchained IRA": "unchained-ira",
    # Precious metals IRA providers
    "Augusta Precious Metals": "augusta-precious-metals",
    "Birch Gold Group": "birch-gold-group",
    "Goldco": "goldco",
    "American Hartford Gold": "american-hartford-gold",
    "Lear Capital": "lear-capital",
    "Genesis Gold Group": "genesis-gold-group",
    "Noble Gold Investments": "noble-gold-investments",
    "Advantage Gold": "advantage-gold",
    "GoldenCrest Metals": "goldencrest-metals",
    "Patriot Gold Group": "patriot-gold-group",
    "Oxford Gold Group": "oxford-gold-group",
    "Preserve Gold": "preserve-gold",
    "Rosland Capital": "rosland-capital",
    "Allegiance Gold": "allegiance-gold",
}

# ---------------------------------------------------------------------------
# Score calculation helpers
# ---------------------------------------------------------------------------

def calc_fee_transparency_score(profile: dict) -> int:
    """Score 0-100 based on how transparent and competitive the fee structure is."""
    score = 50  # baseline
    if profile.get("setup_fee") is not None:
        score += 10  # has disclosed setup fee
    if profile.get("annual_fee") is not None:
        score += 10
    if profile.get("transaction_fee_pct") is not None:
        score += 10
    if profile.get("spread_markup_pct") is not None:
        score += 10
    # Penalise high fees
    annual = profile.get("annual_fee") or 0
    if annual < 100:
        score += 10
    elif annual > 300:
        score -= 10
    return max(0, min(100, score))


def calc_security_score(profile: dict) -> int:
    """Score 0-100 based on custody and security indicators."""
    score = 50
    custody = profile.get("custody_type", "unknown")
    if custody == "qualified_custodian":
        score += 20
    elif custody == "exchange":
        score -= 10
    if profile.get("insurance_amount") and profile["insurance_amount"] > 0:
        score += 10
    if profile.get("cold_storage_pct") and profile["cold_storage_pct"] >= 90:
        score += 10
    if profile.get("has_multi_sig_security"):
        score += 10
    return max(0, min(100, score))


def calc_reputation_score(profile: dict) -> int:
    """Score 0-100 based on BBB and Trustpilot data."""
    score = 50
    bbb = profile.get("bbb_rating", "")
    bbb_scores = {"A+": 25, "A": 20, "A-": 15, "B+": 10, "B": 5, "B-": 0, "C": -10, "F": -20}
    score += bbb_scores.get(bbb, 0)
    tp = profile.get("trustpilot_score") or 0
    if tp >= 4.5:
        score += 20
    elif tp >= 4.0:
        score += 15
    elif tp >= 3.5:
        score += 10
    elif tp >= 3.0:
        score += 5
    elif tp > 0:
        score -= 5
    complaints = profile.get("bbb_complaint_count") or 0
    if complaints == 0:
        score += 5
    elif complaints > 50:
        score -= 10
    return max(0, min(100, score))


def calc_overall_score(profile: dict) -> float:
    """Weighted overall score 0-10."""
    fee = calc_fee_transparency_score(profile)
    sec = calc_security_score(profile)
    rep = calc_reputation_score(profile)
    # Weighted average: fees 30%, security 35%, reputation 35%
    raw = (fee * 0.30 + sec * 0.35 + rep * 0.35)
    return round(raw / 10, 1)  # convert to 0-10 scale


# ---------------------------------------------------------------------------
# Curated score overrides — these always win over engine-calculated scores.
# Edit this dict to change any provider's score_overall permanently.
# bridge_sync will use these values instead of the MySQL engine calculation.
# ---------------------------------------------------------------------------
SCORE_OVERRIDES = {
    "blocktrust-ira":           9.6,
    "genesis-gold-group":       9.4,
    "goldco":                   9.2,
    "augusta-precious-metals":  9.1,
    "birch-gold-group":         9.1,
    "bitcoin-ira":              9.0,
    "advantage-gold":           9.0,
    "goldencrest-metals":       9.0,
    "noble-gold-investments":   8.9,
    "patriot-gold-group":       8.9,
    "itrustcapital":            8.8,
    "american-hartford-gold":   8.8,
    "oxford-gold-group":        8.8,
    "preserve-gold":            8.8,
    "allegiance-gold":          8.7,
    "alto-crypto-ira":          8.6,
    "bitira":                   8.5,
    "lear-capital":             8.5,
    "rosland-capital":          8.4,
    "swan-bitcoin-ira":         8.3,
    "rocket-dollar":            8.1,
    "unchained-ira":            8.0,
}

# ---------------------------------------------------------------------------
# Main sync logic
# ---------------------------------------------------------------------------

def main():
    try:
        import pymysql
        import psycopg2
    except ImportError:
        log.error("Missing dependencies. Run: pip3 install pymysql psycopg2-binary")
        sys.exit(1)

    # Parse MySQL URL
    import re
    m = re.match(r"mysql://([^:]+):([^@]+)@([^:/]+):?(\d+)?/(.+)", ENGINE_DB_URL)
    if not m:
        log.error("Invalid ENGINE_DB_URL format")
        sys.exit(1)
    eng_user, eng_pass, eng_host, eng_port, eng_db = m.groups()
    eng_port = int(eng_port or 3306)

    # Parse PostgreSQL URL
    m2 = re.match(r"postgresql://([^:]+):([^@]+)@([^:/]+):?(\d+)?/(.+)", PUBLIC_DB_URL)
    if not m2:
        log.error("Invalid PUBLIC_DB_URL format")
        sys.exit(1)
    pub_user, pub_pass, pub_host, pub_port, pub_db = m2.groups()
    pub_port = int(pub_port or 5432)

    log.info("Connecting to engine MySQL DB...")
    try:
        eng_conn = pymysql.connect(
            host=eng_host, port=eng_port, user=eng_user,
            password=eng_pass, database=eng_db, cursorclass=pymysql.cursors.DictCursor
        )
    except Exception as e:
        log.error(f"Failed to connect to engine MySQL: {e}")
        sys.exit(1)

    log.info("Connecting to public PostgreSQL DB...")
    try:
        pub_conn = psycopg2.connect(
            host=pub_host, port=pub_port, user=pub_user,
            password=pub_pass, dbname=pub_db
        )
    except Exception as e:
        log.error(f"Failed to connect to public PostgreSQL: {e}")
        sys.exit(1)

    synced = 0
    skipped = 0
    errors = 0

    with eng_conn.cursor() as eng_cur, pub_conn.cursor() as pub_cur:
        # Fetch all engine providers with their profiles
        eng_cur.execute("""
            SELECT p.id, p.name, p.domain,
                   pp.setup_fee, pp.annual_fee, pp.transaction_fee_pct,
                   pp.spread_markup_pct, pp.min_investment,
                   pp.supported_assets_count, pp.supported_assets_json,
                   pp.custody_type, pp.custodian_name, pp.insurance_amount,
                   pp.cold_storage_pct, pp.has_multi_sig_security,
                   pp.bbb_rating, pp.bbb_complaint_count,
                   pp.trustpilot_score, pp.trustpilot_review_count,
                   pp.founded_year, pp.website_url, pp.last_audited_at
            FROM providers p
            LEFT JOIN provider_profiles pp ON pp.provider_id = p.id
        """)
        engine_providers = eng_cur.fetchall()
        log.info(f"Found {len(engine_providers)} providers in engine DB")

        for ep in engine_providers:
            name = ep["name"]
            slug = SLUG_MAP.get(name)
            if not slug:
                log.debug(f"No slug mapping for '{name}', skipping")
                skipped += 1
                continue

            # Calculate scores from profile data
            overall = SCORE_OVERRIDES.get(slug, calc_overall_score(ep))
            fee_score = calc_fee_transparency_score(ep)
            sec_score = calc_security_score(ep)
            rep_score = calc_reputation_score(ep)
            if slug in SCORE_OVERRIDES:
                log.info(f"  {name} → using curated SCORE_OVERRIDE: {overall}")

            # Format fee strings from engine data
            annual_fee_str = f"${ep['annual_fee']:.0f}/yr" if ep.get("annual_fee") else None
            setup_fee_str = f"${ep['setup_fee']:.0f}" if ep.get("setup_fee") else "$0"
            min_invest_str = f"${ep['min_investment']:,.0f}" if ep.get("min_investment") else None
            tx_fee_str = f"{ep['transaction_fee_pct']:.1f}%" if ep.get("transaction_fee_pct") else None

            log.info(f"  {name} → slug={slug} | overall={overall} | fee_score={fee_score} | sec={sec_score} | rep={rep_score}")

            if args.dry_run:
                log.info(f"  [DRY RUN] Would update public DB for slug={slug}")
                synced += 1
                continue

            # ----------------------------------------------------------------
            # score_lock guard
            # When score_lock = TRUE, bridge_sync must NOT overwrite any field
            # that was manually curated (scores AND metadata).  This protects
            # corrections applied by Jacob Diaz and future editorial audits from
            # being silently reverted by stale engine data on every deploy.
            #
            # Fields protected when score_lock = TRUE:
            #   Scores:   score_overall, score_fees, score_security,
            #             score_reputation
            #   Metadata: setup_fee, annual_fee, transaction_fee,
            #             min_investment, custody_provider
            #
            # The only field always written is updated_at so the row's
            # freshness timestamp remains accurate.
            # ----------------------------------------------------------------
            pub_cur.execute("SELECT score_lock FROM providers WHERE slug = %s", (slug,))
            lock_row = pub_cur.fetchone()
            score_locked = bool(lock_row and lock_row[0])
            if score_locked:
                log.info(
                    f"  {name} → score_lock=TRUE, skipping all curated fields "
                    f"(scores + metadata). Only updating updated_at."
                )

            # Update public DB
            try:
                # Always update the timestamp so freshness is accurate
                update_fields = {
                    "updated_at": datetime.now(timezone.utc),
                }

                if not score_locked:
                    # Scores — only from engine calculation
                    update_fields["score_overall"] = overall
                    update_fields["score_fees"] = round(fee_score / 10, 1)
                    update_fields["score_security"] = round(sec_score / 10, 1)
                    update_fields["score_reputation"] = round(rep_score / 10, 1)

                    # Metadata — only from engine profile data, and only when
                    # the engine actually has a value (never blank out a field
                    # with None just because the engine hasn't scraped it yet)
                    if annual_fee_str:
                        update_fields["annual_fee"] = annual_fee_str
                    if setup_fee_str:
                        update_fields["setup_fee"] = setup_fee_str
                    if min_invest_str:
                        update_fields["min_investment"] = min_invest_str
                    if tx_fee_str:
                        update_fields["transaction_fee"] = tx_fee_str
                    if ep.get("custodian_name"):
                        update_fields["custody_provider"] = ep["custodian_name"]

                set_clause = ", ".join(f"{k} = %s" for k in update_fields)
                values = list(update_fields.values()) + [slug]

                pub_cur.execute(
                    f"UPDATE providers SET {set_clause} WHERE slug = %s",
                    values
                )
                rows_updated = pub_cur.rowcount
                if rows_updated == 0:
                    log.warning(f"  No row found in public DB for slug={slug}")
                    skipped += 1
                else:
                    log.info(f"  Updated {rows_updated} row(s) for slug={slug}")
                    synced += 1
            except Exception as e:
                log.error(f"  Error updating slug={slug}: {e}")
                errors += 1

        if not args.dry_run:
            pub_conn.commit()
            log.info("Changes committed to public DB")

    eng_conn.close()
    pub_conn.close()

    log.info(f"\nSync complete: {synced} synced, {skipped} skipped, {errors} errors")
    if errors > 0:
        sys.exit(1)


if __name__ == "__main__":
    main()
