# Precious Metals IRA — Seed Keywords for gggbt-engine
**Prepared:** 2026-03-17 | **Total seeds:** 87 keywords across 8 intent clusters

---

## How to Use These in the Engine

Run each cluster as a separate research run so results stay organized by topic. Start with **Cluster 1** (highest commercial intent, most affiliate competition) and work down. The engine will pull SERP data, identify review domains, and surface outreach opportunities for each.

---

## Cluster 1: "Best Of" — Commercial Intent (Highest Priority)

These are the money keywords. Every major affiliate site ranks for these. The goal is to identify which review domains are winning and whether they mention BlockTrustIRA.com.

```
best gold IRA companies 2026
best gold IRA companies
top gold IRA companies
best precious metals IRA companies
best gold IRA
top rated gold IRA companies
best gold IRA for beginners
best gold IRA for seniors
best gold IRA for small investors
best gold IRA low minimum
gold IRA companies ranked
best silver IRA companies
best precious metals IRA
```

---

## Cluster 2: Provider Reviews — Transactional Intent

These keywords are searched by people who are close to making a decision. Ranking here = high conversion.

```
Augusta Precious Metals review
Augusta Precious Metals review 2026
Augusta Precious Metals pros and cons
Augusta Precious Metals minimum investment
Augusta Precious Metals fees
Birch Gold Group review
Birch Gold Group review 2026
Birch Gold Group fees
Birch Gold Group pros and cons
Birch Gold Group minimum investment
Goldco review
Goldco review 2026
Goldco gold IRA review
American Hartford Gold review
American Hartford Gold review 2026
Lear Capital review
Lear Capital review 2026
Advantage Gold review
Noble Gold review
iTrustCapital precious metals review
```

---

## Cluster 3: Provider Comparisons — Decision Intent

People comparing two providers are very close to converting. These are underserved by most sites.

```
Augusta Precious Metals vs Birch Gold Group
Augusta Precious Metals vs Goldco
Augusta Precious Metals vs American Hartford Gold
Birch Gold Group vs Goldco
Birch Gold Group vs American Hartford Gold
Goldco vs American Hartford Gold
Goldco vs Lear Capital
Augusta Precious Metals vs Lear Capital
best gold IRA company comparison
gold IRA company comparison 2026
```

---

## Cluster 4: Rollover & Setup — High-Intent Process Keywords

People actively in the process of opening an account. Very high intent.

```
gold IRA rollover
gold IRA rollover from 401k
401k to gold IRA rollover
how to rollover 401k to gold IRA
gold IRA rollover without penalty
IRA to gold IRA rollover
gold IRA rollover guide
silver IRA rollover
silver IRA rollover from 401k
how to open a gold IRA
how to start a gold IRA
gold IRA setup process
precious metals IRA rollover
self-directed IRA gold rollover
```

---

## Cluster 5: Fees, Costs & Minimums — Comparison Intent

Searchers who are price-sensitive and comparing costs. High affiliate value.

```
gold IRA fees
gold IRA fees comparison
gold IRA annual fees
gold IRA storage fees
gold IRA custodian fees
gold IRA minimum investment
gold IRA with no minimum
lowest fee gold IRA
cheapest gold IRA
gold IRA cost
how much does a gold IRA cost
gold IRA setup fees
gold IRA maintenance fees
```

---

## Cluster 6: Educational / Informational — Top of Funnel

These keywords attract people early in the research phase. Lower conversion but high volume and good for building topical authority.

```
what is a gold IRA
how does a gold IRA work
gold IRA explained
gold IRA pros and cons
is a gold IRA a good investment
gold IRA vs traditional IRA
gold IRA vs Roth IRA
gold IRA vs 401k
gold IRA tax benefits
gold IRA rules
gold IRA contribution limits 2026
IRS rules for gold IRA
IRA eligible gold
IRA approved gold coins
IRA approved silver coins
precious metals IRA rules
what metals can you hold in an IRA
gold IRA purity requirements
```

---

## Cluster 7: Specific Metals — Niche Intent

Lower volume but less competition. Good for long-tail content that builds authority.

```
silver IRA
silver IRA companies
best silver IRA
silver IRA vs gold IRA
platinum IRA
palladium IRA
gold and silver IRA
gold silver platinum IRA
IRA eligible silver coins
IRA eligible gold bars
American Eagle gold coin IRA
American Buffalo gold coin IRA
gold IRA coins vs bars
```

---

## Cluster 8: Trust & Safety — Protective Intent

People who are worried about scams or want to verify legitimacy. These are high-trust signals and often lead to conversions when answered well.

```
gold IRA scams
gold IRA scams to avoid
is gold IRA legitimate
gold IRA red flags
gold IRA BBB ratings
gold IRA complaints
Augusta Precious Metals BBB rating
Birch Gold Group BBB rating
Goldco BBB rating
gold IRA free silver offer scam
how to verify a gold IRA company
gold IRA CFTC warning
gold IRA safe investment
```

---

## Recommended Run Order

| Priority | Cluster | Rationale |
|---|---|---|
| 1 | Cluster 1 — Best Of | Highest competition, most affiliate sites to identify |
| 2 | Cluster 4 — Rollover & Setup | Highest buyer intent, most actionable outreach |
| 3 | Cluster 2 — Provider Reviews | Direct comparison to BlockTrustIRA.com opportunity |
| 4 | Cluster 3 — Comparisons | Underserved, high-conversion content gap |
| 5 | Cluster 5 — Fees & Costs | Price-sensitive buyers, good affiliate angle |
| 6 | Cluster 8 — Trust & Safety | Trust content builds domain authority |
| 7 | Cluster 6 — Educational | Volume play, topical authority |
| 8 | Cluster 7 — Specific Metals | Long-tail, low competition |

---

## Key Competitors to Watch in SERP Results

When the engine surfaces review domains, these are the sites most likely to appear. Flag them as high-priority outreach targets if they **do not** mention BlockTrustIRA.com:

- `money.com` — Ranks for nearly every "best gold IRA" keyword
- `investopedia.com` — Dominates educational terms
- `cbsnews.com` — Strong on news-adjacent gold IRA content
- `bankrate.com` — Ranks for fees and comparison terms
- `forbes.com/advisor` — Ranks for "best of" lists
- `cnbc.com/select` — Strong on comparison content
- `raremetalblog.com` — Niche affiliate site, high rankings
- `clutejournals.com` — Newer but ranking aggressively in 2026
- `goldirainvestorsguide.com` — Pure affiliate, ranks for review terms

---

## Notes for the Engine

- **Focus keyword for BlockTrustIRA.com positioning:** "best gold IRA for crypto-native investors" — this is the gap. All competitors focus on traditional retirees. BlockTrust's angle is crypto-savvy investors diversifying into physical metals.
- **Content gap identified:** No major review site has a "gold IRA vs crypto IRA" comparison page. This is a unique angle for `iraresearchhub.com`.
- **Affiliate commission context:** Average gold IRA account size is $50,000–$150,000. Augusta Precious Metals pays ~$200 per qualified lead. Birch Gold Group pays ~$100–$150. High-value affiliate vertical.
