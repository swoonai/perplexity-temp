# Genesis Gold Group — Seed Keywords for gggbt-engine
**Prepared:** 2026-03-25 | **Total seeds:** 68 keywords across 8 intent layers

---

## How to Use These in the Engine

These keywords are designed for the Genesis Gold Group brand config in the engine's Growth OS. They cover all 8 intent layers: brand USP, competitor terms, comparison, asset-specific, rollover/setup, fees, trust/safety, and educational. Run Layers 1–3 first (highest commercial intent), then Layers 4–8 for topical authority.

---

## Layer 1 — Brand USP (Genesis Gold Group Specific)

These are the brand-specific keywords that directly target Genesis Gold Group's reputation and positioning. Critical for monitoring brand mentions and identifying review sites.

```
Genesis Gold Group review
Genesis Gold Group fees
Genesis Gold Group minimum investment
Genesis Gold Group vs Augusta
Genesis Gold Group vs Goldco
Genesis Gold Group vs Birch Gold
Genesis Gold Group BBB rating
Genesis Gold Group complaints
Genesis Gold Group legit
Genesis Gold Group IRA
Genesis Gold Group gold IRA
Genesis Gold Group precious metals IRA
Genesis Gold Group team
Genesis Gold Group founders
Genesis Gold Group 2026
```

---

## Layer 2 — Competitor Brand Terms

These are the competitor review keywords. Sites ranking for these are the primary outreach targets — they review competitors but may not yet mention Genesis Gold Group.

```
Augusta Precious Metals review
Birch Gold Group review
Goldco review
American Hartford Gold review
Lear Capital review
Noble Gold review
Advantage Gold review
Oxford Gold Group review
Patriot Gold Group review
best gold IRA companies 2026
```

---

## Layer 3 — Comparison Intent

People comparing two providers are very close to converting. These are underserved by most sites and represent a strong content gap opportunity.

```
Augusta vs Birch Gold
Augusta vs Goldco
Birch Gold vs Goldco
best gold IRA for small investors
best gold IRA low minimum
gold IRA company comparison 2026
gold IRA vs silver IRA
gold IRA vs crypto IRA
gold IRA vs bitcoin IRA
```

---

## Layer 4 — Asset-Specific (Gold, Silver, Platinum, Palladium)

These keywords attract investors looking for specific metal types. Genesis Gold Group supports all four IRS-approved precious metals.

```
gold IRA
precious metals IRA
silver IRA
silver IRA companies
platinum IRA
palladium IRA
gold and silver IRA
IRA approved gold coins
IRA approved silver coins
American Eagle gold coin IRA
gold IRA coins vs bars
IRA eligible gold bars
American Buffalo gold coin IRA
IRA eligible silver coins
IRA approved platinum coins
```

---

## Layer 5 — Rollover & Setup

People actively in the process of opening an account. Very high intent.

```
gold retirement account
gold IRA rollover from 401k
how to rollover 401k to gold IRA
gold IRA rollover without penalty
convert 401k to gold
how to open a gold IRA
gold IRA setup process
self-directed IRA gold
IRA to gold IRA rollover
gold IRA rollover guide
precious metals IRA rollover
silver IRA rollover from 401k
```

---

## Layer 6 — Fees & Costs

Searchers who are price-sensitive and comparing costs. High affiliate value.

```
gold IRA fees
gold IRA fees comparison
gold IRA annual fees
gold IRA storage fees
gold IRA custodian fees
gold IRA minimum investment
lowest fee gold IRA
cheapest gold IRA
gold IRA cost
```

---

## Layer 7 — Trust & Safety

People who are worried about scams or want to verify legitimacy. High-trust signals and often lead to conversions when answered well.

```
gold IRA scams
gold IRA red flags
is gold IRA legitimate
gold IRA BBB ratings
gold IRA CFTC warning
how to verify a gold IRA company
gold IRA free silver offer scam
best gold IRA 2026
gold IRA safe investment
```

---

## Layer 8 — Educational / Top-of-Funnel

These keywords attract people early in the research phase. Lower conversion but high volume and good for building topical authority.

```
what is a gold IRA
how does a gold IRA work
gold IRA explained
gold IRA pros and cons
is a gold IRA a good investment
gold IRA vs traditional IRA
gold IRA vs Roth IRA
gold IRA vs 401k
gold IRA tax benefits
gold IRA rules
gold IRA contribution limits 2026
IRS rules for gold IRA
IRA eligible gold
precious metals IRA rules
```

---

## Recommended Run Order

| Priority | Layer | Rationale |
|---|---|---|
| 1 | Layer 1 — Brand USP | Monitor Genesis Gold Group's own reputation and identify review sites |
| 2 | Layer 3 — Comparison Intent | Underserved, high-conversion content gap |
| 3 | Layer 2 — Competitor Terms | Identify review sites that cover competitors but not Genesis Gold Group |
| 4 | Layer 5 — Rollover & Setup | Highest buyer intent, most actionable outreach |
| 5 | Layer 6 — Fees & Costs | Price-sensitive buyers, good affiliate angle |
| 6 | Layer 7 — Trust & Safety | Trust content builds domain authority |
| 7 | Layer 4 — Asset-Specific | Niche intent, builds topical authority |
| 8 | Layer 8 — Educational | Volume play, topical authority |

---

## Key Competitors to Watch in SERP Results

When the engine surfaces review domains, these are the sites most likely to appear. Flag them as high-priority outreach targets if they **do not** mention Genesis Gold Group:

- `money.com` — Ranks for nearly every "best gold IRA" keyword
- `investopedia.com` — Dominates educational terms
- `cbsnews.com` — Strong on news-adjacent gold IRA content
- `bankrate.com` — Ranks for fees and comparison terms
- `forbes.com/advisor` — Ranks for "best of" lists
- `cnbc.com/select` — Strong on comparison content
- `raremetalblog.com` — Niche affiliate site, high rankings
- `goldirainvestorsguide.com` — Pure affiliate, ranks for review terms

---

## Notes for the Engine

- **Genesis Gold Group's unique angle:** Unlike BlockTrust IRA (which targets crypto-native investors), Genesis Gold Group targets traditional retirees and conservative investors seeking wealth preservation. The messaging should emphasize stability, IRS compliance, and physical asset ownership.
- **Content gap:** No major review site has a "Genesis Gold Group vs. [Competitor]" comparison page. This is a unique opportunity for `iraresearchhub.com`.
- **Competitor domains added:** `advantagegold.com`, `oxfordgoldgroup.com`, `patriotgoldgroup.com` — these are the three competitors most likely to appear in SERP results for Genesis Gold Group's target keywords that were missing from the original config.
