/** @type {import('tailwindcss').Config} */
export default {
  content: [
    "./index.html",
    "./src/**/*.{js,ts,jsx,tsx}",
  ],
  theme: {
    extend: {
      colors: {
        navy: {
          DEFAULT: '#0F172A',
          50: '#F0F4FF',
          100: '#E0E9FF',
          200: '#C2D3FF',
          300: '#93AFFF',
          400: '#6B8EFF',
          500: '#4A6EFF',
          600: '#2E50F5',
          700: '#1E3AE0',
          800: '#1A2FB5',
          900: '#0F172A',
        },
        sky: {
          DEFAULT: '#0EA5E9',
          50: '#F0F9FF',
          100: '#E0F2FE',
          200: '#BAE6FD',
          300: '#7DD3FC',
          400: '#38BDF8',
          500: '#0EA5E9',
          600: '#0284C7',
          700: '#0369A1',
          800: '#075985',
          900: '#0C4A6E',
        },
        brand: {
          navy: '#0F172A',
          sky: '#0EA5E9',
          slate: '#64748B',
          white: '#FFFFFF',
          offwhite: '#F8FAFC',
        },
      },
      fontFamily: {
        heading: ['Inter', 'Montserrat', 'system-ui', 'sans-serif'],
        body: ['Open Sans', 'Roboto', 'system-ui', 'sans-serif'],
      },
      maxWidth: {
        '8xl': '88rem',
        '9xl': '96rem',
      },
      boxShadow: {
        'card': '0 1px 3px 0 rgba(15, 23, 42, 0.08), 0 1px 2px -1px rgba(15, 23, 42, 0.06)',
        'card-hover': '0 4px 6px -1px rgba(15, 23, 42, 0.10), 0 2px 4px -2px rgba(15, 23, 42, 0.06)',
        'elevated': '0 10px 15px -3px rgba(15, 23, 42, 0.10), 0 4px 6px -4px rgba(15, 23, 42, 0.06)',
      },
    },
  },
  plugins: [],
}

