import { useEffect } from 'react';

// Light form — white background, for use on light-background sections (article pages)
const BEEHIIV_LIGHT_FORM_ID = 'e783096b-041a-4345-97f5-dea787f42154';
// Dark form — transparent background, IRA blue button, for use in footer/dark backgrounds
const BEEHIIV_DARK_FORM_ID = 'bf8e8572-c92b-44e3-b015-bc7dd6afbaec';

// Track whether embed.js has been injected globally (only needed once per page)
let embedScriptInjected = false;

interface BeehiivEmbedProps {
  /** Use 'dark' for dark backgrounds (footer), 'light' for light backgrounds (article pages) */
  variant?: 'light' | 'dark';
  className?: string;
}

export default function BeehiivEmbed({ variant = 'light', className = '' }: BeehiivEmbedProps) {
  const formId = variant === 'dark' ? BEEHIIV_DARK_FORM_ID : BEEHIIV_LIGHT_FORM_ID;
  const embedUrl = `https://subscribe-forms.beehiiv.com/${formId}`;
  const height = variant === 'dark' ? 290 : 52;

  useEffect(() => {
    // Inject embed.js only once per page load.
    // embed.js resizes iframes to 401px — we counteract this by setting
    // margin: 0 auto on the iframe via CSS after the script loads.
    if (!embedScriptInjected) {
      embedScriptInjected = true;
      const script = document.createElement('script');
      script.src = 'https://subscribe-forms.beehiiv.com/embed.js';
      script.async = true;
      document.head.appendChild(script);
    }
  }, []);

  return (
    /*
     * Centering strategy — v4 (definitive):
     *
     * Problem: embed.js sets width: 401px on the FIRST iframe it finds,
     * but leaves subsequent iframes at width: 100%. This means instance 0
     * is 401px and instance 1 is 560px — both centered, but visually
     * inconsistent (401px looks narrower/shifted in a 736px card).
     *
     * Solution: Use a flex centering container. The iframe sits inside a
     * flex row with justify-content: center. The iframe itself uses
     * max-width: 100% (from Beehiiv's own embed code) so it never overflows.
     * Even if embed.js sets width: 401px, the flex container centers it.
     * The outer div is text-center as a fallback for non-flex contexts.
     *
     * The key insight: we do NOT set width: 100% on the iframe — we let
     * embed.js set whatever width it wants, and we center the result.
     */
    <div className={`w-full text-center ${className}`}>
      <div
        style={{
          display: 'flex',
          justifyContent: 'center',
          alignItems: 'center',
          width: '100%',
        }}
      >
        <iframe
          src={embedUrl}
          className="beehiiv-embed"
          data-test-id="beehiiv-embed"
          frameBorder={0}
          scrolling="no"
          style={{
            // Use the exact style from Beehiiv's official embed code.
            // We do NOT override width — embed.js will set it to 401px,
            // and the flex parent will center whatever width results.
            height: `${height}px`,
            margin: 0,
            borderRadius: '0px',
            backgroundColor: 'transparent',
            boxShadow: '0 0 #0000',
            maxWidth: '100%',
            // display:block prevents inline baseline gap
            display: 'block',
          }}
          title="IRA Research Digest Newsletter Signup"
        />
      </div>
    </div>
  );
}
