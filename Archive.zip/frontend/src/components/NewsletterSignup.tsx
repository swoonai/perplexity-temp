import BeehiivEmbed from './BeehiivEmbed';

interface NewsletterSignupProps {
  /** Visual variant: 'light' for white/light backgrounds, 'dark' for dark backgrounds */
  variant?: 'light' | 'dark';
  /** Optional override for the heading text */
  heading?: string;
  /** Optional override for the subheading text */
  subheading?: string;
  className?: string;
}

export default function NewsletterSignup({
  variant = 'light',
  heading = 'Stay ahead of IRA rule changes',
  subheading = 'Get the IRA Research Digest — free weekly insights on IRS rules, fee changes, and provider updates.',
  className = '',
}: NewsletterSignupProps) {
  const bgClass = variant === 'dark'
    ? 'bg-slate-800 border-slate-700'
    : 'bg-blue-50 border-blue-100';
  const headingClass = variant === 'dark' ? 'text-white' : 'text-slate-900';
  const labelClass = variant === 'dark' ? 'text-blue-400' : 'text-blue-600';
  const subClass = variant === 'dark' ? 'text-slate-400' : 'text-slate-600';
  const microcopyClass = variant === 'dark' ? 'text-slate-600' : 'text-slate-400';

  return (
    <div className={`rounded-xl border p-6 sm:p-8 text-center ${bgClass} ${className}`}>
      <p className={`text-xs font-semibold uppercase tracking-widest mb-2 ${labelClass}`}>Free Newsletter</p>
      <h2 className={`text-xl sm:text-2xl font-bold mb-2 ${headingClass}`}>{heading}</h2>
      <p className={`text-sm mb-5 max-w-md mx-auto ${subClass}`}>{subheading}</p>
      <div className="flex justify-center">
        <BeehiivEmbed variant={variant} />
      </div>
      <p className={`text-xs mt-3 ${microcopyClass}`}>No spam. Unsubscribe any time.</p>
    </div>
  );
}
