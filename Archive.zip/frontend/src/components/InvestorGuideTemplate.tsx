import { Link } from 'react-router-dom'
import SEO from './SEO'
import AdvertiserDisclosure from './AdvertiserDisclosure'
import NewsletterSignup from './NewsletterSignup'
import BlockTrustCTA from './BlockTrustCTA'

export type InvestorType =
  | 'beginners'
  | 'high-net-worth'
  | 'self-employed'
  | 'bitcoin-only'
  | 'retirees'
  | 'active-traders'
  | 'altcoins'
  | 'rollover'

interface InvestorGuideTemplateProps {
  investorType: InvestorType
  title: string
  headline: string
  slug: string
  /** One or two sentences describing this investor type */
  intro: string
  /** Why BlockTrust IRA is the right fit for this investor type */
  whyBlockTrust: string
  /** Why Genesis Gold Group is relevant for this investor type */
  whyGenesis: string
  /** 3–5 key considerations specific to this investor type */
  keyConsiderations: { heading: string; body: string }[]
  /** FAQ items */
  faqs: { q: string; a: string }[]
}

export default function InvestorGuideTemplate({
  investorType,
  title,
  headline,
  slug,
  intro,
  whyBlockTrust,
  whyGenesis,
  keyConsiderations,
  faqs,
}: InvestorGuideTemplateProps) {
  const pageSlug = `investor/${slug}`

  return (
    <>
      <SEO
        title={title}
        description={`${headline} — Compare Crypto IRA and Precious Metals IRA options for ${investorType.replace(/-/g, ' ')} investors in 2026.`}
        canonical={`/${pageSlug}`}
      />
      <div className="container-site section-padding">
        {/* Breadcrumb */}
        <nav className="text-sm text-slate-500 mb-6" aria-label="Breadcrumb">
          <ol className="flex flex-wrap gap-1 items-center">
            <li><Link to="/" className="hover:text-amber-600">Home</Link></li>
            <li className="text-slate-300">/</li>
            <li><Link to="/investor" className="hover:text-amber-600">Investor Guides</Link></li>
            <li className="text-slate-300">/</li>
            <li className="text-slate-700 font-medium">{headline}</li>
          </ol>
        </nav>

        <div className="grid lg:grid-cols-[1fr_320px] gap-10">
          {/* Main content */}
          <main>
            <div className="mb-2">
              <div className="flex items-center gap-3 mb-3">
                <span className="text-xs font-semibold uppercase tracking-wider text-amber-600 bg-amber-50 border border-amber-200 px-2 py-1 rounded">Investor Guide</span>
                <span className="text-xs text-slate-500">Updated April 2026</span>
              </div>
              <h1 className="text-3xl md:text-4xl font-bold text-[#0F172A] mb-4">{headline}</h1>
              <AdvertiserDisclosure />
            </div>

            <div className="prose prose-slate max-w-none mt-8 space-y-6">
              <p className="text-lg text-slate-700 leading-relaxed">{intro}</p>

              {/* #1 Recommendation — BlockTrust IRA */}
              <div className="not-prose rounded-xl border-2 border-amber-300 bg-gradient-to-br from-amber-50 to-orange-50 p-6 my-8">
                <div className="flex items-center gap-2 mb-3">
                  <span className="inline-flex items-center px-2.5 py-1 rounded-full text-xs font-bold bg-amber-500 text-white uppercase tracking-wide">
                    #1 Recommended — Crypto IRA
                  </span>
                  <span className="text-xs text-slate-500">Editor's Choice 2026</span>
                </div>
                <div className="flex flex-col sm:flex-row gap-5 items-start">
                  <div className="flex-1">
                    <h2 className="text-xl font-bold text-[#0F172A] mb-1">BlockTrust IRA</h2>
                    <div className="flex items-center gap-1 mb-3">
                      <span className="text-amber-400 text-base">★★★★★</span>
                      <span className="text-sm font-semibold text-slate-700 ml-1">4.9 / 5</span>
                    </div>
                    <p className="text-sm text-slate-700 leading-relaxed mb-3">{whyBlockTrust}</p>
                    <ul className="space-y-1.5 text-sm text-slate-700">
                      <li className="flex gap-2"><span className="text-green-500 font-bold mt-0.5">✓</span><span><strong>Fees:</strong> 0.14%–0.40% trading fee — no hidden annual charges</span></li>
                      <li className="flex gap-2"><span className="text-green-500 font-bold mt-0.5">✓</span><span><strong>Assets:</strong> 60+ cryptocurrencies including Bitcoin, Ethereum, and altcoins</span></li>
                      <li className="flex gap-2"><span className="text-green-500 font-bold mt-0.5">✓</span><span><strong>Custody:</strong> IRS-compliant cold storage with institutional-grade security</span></li>
                      <li className="flex gap-2"><span className="text-green-500 font-bold mt-0.5">✓</span><span><strong>Support:</strong> Dedicated IRA specialist — not a call center</span></li>
                      <li className="flex gap-2"><span className="text-green-500 font-bold mt-0.5">✓</span><span><strong>Rollovers:</strong> Free 401(k) and traditional IRA rollover assistance</span></li>
                    </ul>
                  </div>
                  <div className="flex-shrink-0 flex flex-col gap-2 sm:w-44">
                    <Link
                      to="/crypto-ira/blocktrust-ira-review"
                      className="block w-full text-center px-4 py-3 rounded-lg bg-amber-500 hover:bg-amber-600 text-white font-bold text-sm transition-colors"
                    >
                      Read Full Review →
                    </Link>
                    <p className="text-xs text-slate-400 text-center">Free · No obligation</p>
                  </div>
                </div>
              </div>

              {/* Key considerations */}
              <h2 className="text-2xl font-bold text-[#0F172A] mt-10 mb-4">Key Considerations for {headline.replace('Best Crypto IRA for ', '').replace('Best Crypto IRA — ', '')}</h2>
              <div className="space-y-5 not-prose">
                {keyConsiderations.map((item, i) => (
                  <div key={i} className="border-l-4 border-amber-300 pl-4">
                    <h3 className="font-semibold text-slate-900 mb-1">{item.heading}</h3>
                    <p className="text-slate-600 text-sm leading-relaxed">{item.body}</p>
                  </div>
                ))}
              </div>

              {/* Precious Metals section */}
              <h2 className="text-2xl font-bold text-[#0F172A] mt-10 mb-4">Also Considering a Precious Metals IRA?</h2>
              <p className="text-slate-700 leading-relaxed">{whyGenesis}</p>

              {/* Genesis Gold Group card */}
              <div className="not-prose rounded-xl border-2 border-slate-200 bg-gradient-to-br from-slate-50 to-gray-50 p-6 my-6">
                <div className="flex items-center gap-2 mb-3">
                  <span className="inline-flex items-center px-2.5 py-1 rounded-full text-xs font-bold bg-slate-700 text-white uppercase tracking-wide">
                    #1 Recommended — Precious Metals IRA
                  </span>
                </div>
                <div className="flex flex-col sm:flex-row gap-5 items-start">
                  <div className="flex-1">
                    <h3 className="text-xl font-bold text-[#0F172A] mb-1">Genesis Gold Group</h3>
                    <div className="flex items-center gap-1 mb-3">
                      <span className="text-amber-400 text-base">★★★★★</span>
                      <span className="text-sm font-semibold text-slate-700 ml-1">4.8 / 5</span>
                    </div>
                    <p className="text-sm text-slate-700 leading-relaxed mb-3">
                      Genesis Gold Group specializes in 401(k) and IRA rollovers into physical gold and silver. They offer white-glove service, transparent pricing, and IRS-approved storage through Brinks and Delaware Depository.
                    </p>
                    <ul className="space-y-1.5 text-sm text-slate-700">
                      <li className="flex gap-2"><span className="text-green-500 font-bold mt-0.5">✓</span><span><strong>Metals:</strong> IRS-approved gold, silver, platinum, and palladium</span></li>
                      <li className="flex gap-2"><span className="text-green-500 font-bold mt-0.5">✓</span><span><strong>Storage:</strong> Segregated storage at Brinks and Delaware Depository</span></li>
                      <li className="flex gap-2"><span className="text-green-500 font-bold mt-0.5">✓</span><span><strong>Rollovers:</strong> Full-service 401(k) to Gold IRA — zero out-of-pocket cost</span></li>
                      <li className="flex gap-2"><span className="text-green-500 font-bold mt-0.5">✓</span><span><strong>Buyback:</strong> Guaranteed buyback at competitive market rates</span></li>
                    </ul>
                  </div>
                  <div className="flex-shrink-0 flex flex-col gap-2 sm:w-44">
                    <Link
                      to="/precious-metals-ira/genesis-gold-group-review"
                      className="block w-full text-center px-4 py-3 rounded-lg bg-slate-700 hover:bg-slate-800 text-white font-bold text-sm transition-colors"
                    >
                      Read Full Review →
                    </Link>
                    <p className="text-xs text-slate-400 text-center">Free · No obligation</p>
                  </div>
                </div>
              </div>

              {/* FAQ */}
              <h2 className="text-2xl font-bold text-[#0F172A] mt-10 mb-4">Frequently Asked Questions</h2>
              <div className="space-y-4 not-prose">
                {faqs.map((faq, i) => (
                  <div key={i} className="border border-slate-200 rounded-lg p-4">
                    <h3 className="font-semibold text-slate-900 mb-2 text-sm">{faq.q}</h3>
                    <p className="text-slate-600 text-sm leading-relaxed">{faq.a}</p>
                  </div>
                ))}
              </div>

              {/* Bottom CTA */}
              <div className="not-prose mt-10">
                <BlockTrustCTA sourcePage={pageSlug} variant="banner" />
              </div>
            </div>

            <div className="mt-10">
              <NewsletterSignup />
            </div>
          </main>

          {/* Sidebar */}
          <aside className="hidden lg:block space-y-6">
            <div className="sticky top-8 space-y-6">
              <BlockTrustCTA sourcePage={pageSlug} variant="sidebar" />

              <div className="rounded-xl border border-slate-200 bg-white p-5">
                <p className="text-xs font-semibold uppercase tracking-wider text-slate-500 mb-2">Precious Metals IRA</p>
                <h3 className="font-bold text-slate-900 text-sm mb-1">Genesis Gold Group</h3>
                <div className="flex items-center gap-1 mb-3">
                  <span className="text-amber-400 text-sm">★★★★★</span>
                  <span className="text-xs text-slate-500 ml-1">4.8/5</span>
                </div>
                <ul className="space-y-1 text-xs text-slate-600 mb-4">
                  <li className="flex gap-1.5"><span className="text-green-500 font-bold">✓</span> Gold &amp; Silver IRA rollovers</li>
                  <li className="flex gap-1.5"><span className="text-green-500 font-bold">✓</span> Brinks &amp; Delaware storage</li>
                  <li className="flex gap-1.5"><span className="text-green-500 font-bold">✓</span> Guaranteed buyback program</li>
                  <li className="flex gap-1.5"><span className="text-green-500 font-bold">✓</span> Zero-cost 401k rollover</li>
                </ul>
                <Link
                  to="/precious-metals-ira/genesis-gold-group-review"
                  className="block w-full text-center px-3 py-2.5 rounded-lg bg-slate-700 hover:bg-slate-800 text-white font-semibold text-sm transition-colors"
                >
                  See Full Review →
                </Link>
              </div>

              <div className="bg-slate-50 rounded-xl p-5 border border-slate-200">
                <h3 className="font-bold text-slate-900 mb-3 text-sm">Top-Rated Providers</h3>
                <ul className="space-y-2 text-sm">
                  <li><Link to="/crypto-ira" className="text-amber-600 hover:underline">Best Crypto IRA Companies 2026</Link></li>
                  <li><Link to="/crypto-ira/blocktrust-ira-review" className="text-amber-600 hover:underline">BlockTrust IRA Review (#1 Rated)</Link></li>
                  <li><Link to="/crypto-ira/bitcoin-ira-review" className="text-amber-600 hover:underline">Bitcoin IRA Review</Link></li>
                  <li><Link to="/crypto-ira/itrustcapital-review" className="text-amber-600 hover:underline">iTrustCapital Review</Link></li>
                  <li><Link to="/crypto-ira/bitira-review" className="text-amber-600 hover:underline">BitIRA Review</Link></li>
                  <li><Link to="/crypto-ira/swan-bitcoin-ira-review" className="text-amber-600 hover:underline">Swan Bitcoin IRA Review</Link></li>
                  <li><Link to="/precious-metals-ira/best-gold-ira" className="text-amber-600 hover:underline">Best Gold IRA Companies 2026</Link></li>
                  <li><Link to="/precious-metals-ira/augusta-precious-metals-review" className="text-amber-600 hover:underline">Augusta Precious Metals Review</Link></li>
                </ul>
              </div>
              <div className="bg-slate-50 rounded-xl p-5 border border-slate-200">
                <h3 className="font-bold text-slate-900 mb-3 text-sm">Investor Guides</h3>
                <ul className="space-y-2 text-sm">
                  <li><Link to="/investor/best-crypto-ira-beginners" className="text-amber-600 hover:underline">Best Crypto IRA for Beginners</Link></li>
                  <li><Link to="/investor/best-crypto-ira-high-net-worth" className="text-amber-600 hover:underline">Best Crypto IRA for High Net Worth</Link></li>
                  <li><Link to="/investor/best-crypto-ira-bitcoin-only" className="text-amber-600 hover:underline">Best Bitcoin-Only IRA</Link></li>
                  <li><Link to="/investor/best-crypto-ira-rollover" className="text-amber-600 hover:underline">Best Crypto IRA for Rollovers</Link></li>
                  <li><Link to="/investor/best-crypto-ira-retirees" className="text-amber-600 hover:underline">Best Crypto IRA for Retirees</Link></li>
                  <li><Link to="/investor/best-crypto-ira-self-employed" className="text-amber-600 hover:underline">Best Crypto IRA for Self-Employed</Link></li>
                  <li><Link to="/research/crypto-ira-fees-2026" className="text-amber-600 hover:underline">Crypto IRA Fees 2026</Link></li>
                  <li><Link to="/tools/crypto-ira-fee-calculator" className="text-amber-600 hover:underline">Crypto IRA Fee Calculator</Link></li>
                  <li><Link to="/gold-ira-vs-crypto-ira" className="text-amber-600 hover:underline">Gold IRA vs Crypto IRA</Link></li>
                </ul>
              </div>
            </div>
          </aside>
        </div>
      </div>
    </>
  )
}
