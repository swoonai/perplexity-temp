import { Link } from 'react-router-dom'
export default function Footer() {
  return (
    <footer className="bg-[#0F172A] text-slate-400" role="contentinfo" aria-label="Site footer">

      <div className="container-site py-12">
        <div className="grid grid-cols-1 md:grid-cols-4 gap-8 mb-10">
          {/* Brand */}
          <div className="md:col-span-1">
            <Link
              to="/"
              className="inline-block mb-4 focus:outline-none focus:ring-2 focus:ring-sky-400 focus:ring-offset-2 focus:ring-offset-slate-900 rounded"
              aria-label="IRA Research Hub — Home"
            >
              <img
                src="/assets/logos/logo-footer.png"
                alt="IRA Research Hub"
                className="h-10 w-auto"
                loading="lazy"
                width="150"
                height="40"
              />
            </Link>
            <p className="text-sm text-slate-400 leading-relaxed mb-4">
              Independent research and analysis for IRA investors. We are not affiliated with any financial institution.
            </p>
            <p className="text-xs text-slate-500">
              <Link to="/editorial-policy" className="hover:text-slate-300 transition-colors focus:outline-none focus:underline">Editorial Policy</Link>
              {' · '}
              <Link to="/methodology" className="hover:text-slate-300 transition-colors focus:outline-none focus:underline">Methodology</Link>
            </p>
          </div>

          {/* Crypto IRAs */}
          <nav aria-label="Crypto IRA pages">
            <h4 className="text-white font-semibold text-sm mb-4 uppercase tracking-wider">Crypto IRAs</h4>
            <ul className="space-y-2 text-sm" role="list">
              <li><Link to="/crypto-ira" className="hover:text-white transition-colors focus:outline-none focus:underline">Overview</Link></li>
              <li><Link to="/crypto-ira/best-companies" className="hover:text-white transition-colors focus:outline-none focus:underline">Best Companies 2026</Link></li>
              <li><Link to="/crypto-ira/401k-to-crypto-ira-rollover" className="hover:text-white transition-colors focus:outline-none focus:underline">401k Rollover Guide</Link></li>
              <li><Link to="/research/crypto-ira-fees-2026" className="hover:text-white transition-colors focus:outline-none focus:underline">2026 Fee Research</Link></li>
              <li><Link to="/crypto-ira/best-bitcoin-ira" className="hover:text-white transition-colors focus:outline-none focus:underline">Best Bitcoin IRA</Link></li>
              <li><Link to="/crypto-ira/what-is-a-crypto-ira" className="hover:text-white transition-colors focus:outline-none focus:underline">What Is a Crypto IRA?</Link></li>
              <li><Link to="/crypto-ira-vs-stock-ira" className="hover:text-white transition-colors focus:outline-none focus:underline">Crypto IRA vs. Stock IRA</Link></li>
              <li className="pt-1 text-slate-600 text-xs uppercase tracking-wider font-semibold" aria-hidden="true">Comparisons</li>
              <li><Link to="/crypto-ira/swan-bitcoin-ira-vs-blocktrust-ira" className="hover:text-white transition-colors focus:outline-none focus:underline">Swan vs BlockTrust</Link></li>
              <li><Link to="/crypto-ira/bitira-vs-bitcoin-ira" className="hover:text-white transition-colors focus:outline-none focus:underline">BitIRA vs Bitcoin IRA</Link></li>
              <li className="pt-1 text-slate-600 text-xs uppercase tracking-wider font-semibold" aria-hidden="true">Reviews</li>
              <li><Link to="/crypto-ira/blocktrust-ira-review" className="hover:text-white transition-colors focus:outline-none focus:underline">BlockTrust IRA</Link></li>
              <li><Link to="/crypto-ira/bitcoin-ira-review" className="hover:text-white transition-colors focus:outline-none focus:underline">Bitcoin IRA</Link></li>
              <li><Link to="/crypto-ira/itrustcapital-review" className="hover:text-white transition-colors focus:outline-none focus:underline">iTrustCapital</Link></li>
              <li><Link to="/crypto-ira/alto-crypto-ira-review" className="hover:text-white transition-colors focus:outline-none focus:underline">Alto CryptoIRA</Link></li>
              <li><Link to="/crypto-ira/bitira-review" className="hover:text-white transition-colors focus:outline-none focus:underline">BitIRA</Link></li>
              <li><Link to="/crypto-ira/swan-bitcoin-ira-review" className="hover:text-white transition-colors focus:outline-none focus:underline">Swan Bitcoin IRA</Link></li>
              <li><Link to="/crypto-ira/rocket-dollar-review" className="hover:text-white transition-colors focus:outline-none focus:underline">Rocket Dollar</Link></li>
              <li><Link to="/crypto-ira/unchained-ira-review" className="hover:text-white transition-colors focus:outline-none focus:underline">Unchained IRA</Link></li>
            </ul>
          </nav>

          {/* Precious Metals IRAs */}
          <nav aria-label="Precious metals IRA pages">
            <h4 className="text-white font-semibold text-sm mb-4 uppercase tracking-wider">Precious Metals IRAs</h4>
            <ul className="space-y-2 text-sm" role="list">
              <li><Link to="/precious-metals-ira" className="hover:text-white transition-colors focus:outline-none focus:underline">Overview</Link></li>
              <li><Link to="/precious-metals-ira/best-companies" className="hover:text-white transition-colors focus:outline-none focus:underline">Best Companies 2026</Link></li>
              <li><Link to="/precious-metals-ira/401k-to-gold-ira-rollover" className="hover:text-white transition-colors focus:outline-none focus:underline">401k Rollover Guide</Link></li>
              <li><Link to="/research/gold-ira-fees-2026" className="hover:text-white transition-colors focus:outline-none focus:underline">2026 Gold IRA Fees</Link></li>
              <li><Link to="/precious-metals-ira/best-gold-ira" className="hover:text-white transition-colors focus:outline-none focus:underline">Best Gold IRA</Link></li>
              <li><Link to="/precious-metals-ira/what-is-a-gold-ira" className="hover:text-white transition-colors focus:outline-none focus:underline">What Is a Gold IRA?</Link></li>
              <li><Link to="/precious-metals-ira/how-to-buy-gold-in-ira" className="hover:text-white transition-colors focus:outline-none focus:underline">How to Buy Gold in IRA</Link></li>
              <li className="pt-1 text-slate-600 text-xs uppercase tracking-wider font-semibold" aria-hidden="true">Comparisons</li>
              <li><Link to="/precious-metals-ira/augusta-vs-goldco" className="hover:text-white transition-colors focus:outline-none focus:underline">Augusta vs Goldco</Link></li>
              <li><Link to="/precious-metals-ira/birch-gold-vs-augusta" className="hover:text-white transition-colors focus:outline-none focus:underline">Birch Gold vs Augusta</Link></li>
              <li className="pt-1 text-slate-600 text-xs uppercase tracking-wider font-semibold" aria-hidden="true">Reviews</li>
              <li><Link to="/precious-metals-ira/augusta-precious-metals-review" className="hover:text-white transition-colors focus:outline-none focus:underline">Augusta Precious Metals</Link></li>
              <li><Link to="/precious-metals-ira/goldco-review" className="hover:text-white transition-colors focus:outline-none focus:underline">Goldco</Link></li>
              <li><Link to="/precious-metals-ira/birch-gold-group-review" className="hover:text-white transition-colors focus:outline-none focus:underline">Birch Gold Group</Link></li>
              <li><Link to="/precious-metals-ira/american-hartford-gold-review" className="hover:text-white transition-colors focus:outline-none focus:underline">American Hartford Gold</Link></li>
              <li><Link to="/precious-metals-ira/genesis-gold-group-review" className="hover:text-white transition-colors focus:outline-none focus:underline">Genesis Gold Group</Link></li>
              <li><Link to="/precious-metals-ira/lear-capital-review" className="hover:text-white transition-colors focus:outline-none focus:underline">Lear Capital</Link></li>
              <li><Link to="/precious-metals-ira/noble-gold-investments-review" className="hover:text-white transition-colors focus:outline-none focus:underline">Noble Gold Investments</Link></li>
              <li><Link to="/precious-metals-ira/advantage-gold-review" className="hover:text-white transition-colors focus:outline-none focus:underline">Advantage Gold</Link></li>
              <li><Link to="/precious-metals-ira/goldencrest-metals-review" className="hover:text-white transition-colors focus:outline-none focus:underline">GoldenCrest Metals</Link></li>
              <li><Link to="/precious-metals-ira/patriot-gold-group-review" className="hover:text-white transition-colors focus:outline-none focus:underline">Patriot Gold Group</Link></li>
              <li><Link to="/precious-metals-ira/oxford-gold-group-review" className="hover:text-white transition-colors focus:outline-none focus:underline">Oxford Gold Group</Link></li>
              <li><Link to="/precious-metals-ira/preserve-gold-review" className="hover:text-white transition-colors focus:outline-none focus:underline">Preserve Gold</Link></li>
              <li><Link to="/precious-metals-ira/rosland-capital-review" className="hover:text-white transition-colors focus:outline-none focus:underline">Rosland Capital</Link></li>
              <li><Link to="/precious-metals-ira/allegiance-gold-review" className="hover:text-white transition-colors focus:outline-none focus:underline">Allegiance Gold</Link></li>
            </ul>
          </nav>

          {/* About */}
          <nav aria-label="About and policies">
            <h4 className="text-white font-semibold text-sm mb-4 uppercase tracking-wider">About</h4>
            <ul className="space-y-2 text-sm" role="list">
              <li><Link to="/about" className="hover:text-white transition-colors focus:outline-none focus:underline">About Us</Link></li>
              <li><Link to="/methodology" className="hover:text-white transition-colors focus:outline-none focus:underline">Our Methodology</Link></li>
              <li><Link to="/editorial-policy" className="hover:text-white transition-colors focus:outline-none focus:underline">Editorial Policy</Link></li>
              <li><Link to="/privacy" className="hover:text-white transition-colors focus:outline-none focus:underline">Privacy Policy</Link></li>
              <li><Link to="/terms" className="hover:text-white transition-colors focus:outline-none focus:underline">Terms of Use</Link></li>
              <li><Link to="/gold-ira-vs-crypto-ira" className="hover:text-white transition-colors focus:outline-none focus:underline">Gold vs Crypto IRA</Link></li>
              <li><Link to="/education/irs-rules-digital-asset-iras" className="hover:text-white transition-colors focus:outline-none focus:underline">IRS Rules: Digital Asset IRAs</Link></li>
              <li><Link to="/education/digital-asset-retirement-planning" className="hover:text-white transition-colors focus:outline-none focus:underline">Digital Asset Retirement</Link></li>
              <li><Link to="/crypto-ira/fidelity-crypto-ira-review" className="hover:text-white transition-colors focus:outline-none focus:underline">Fidelity Crypto IRA Review</Link></li>
            </ul>
          </nav>
        </div>

        {/* Disclaimer */}
        <div className="border-t border-slate-700 pt-8">
          <p className="text-xs text-slate-500 leading-relaxed mb-4">
            <strong className="text-slate-400">Disclosure:</strong> IRA Research Hub is an independent research publication. We may receive compensation when you open an account with providers featured on this site. This compensation may influence which providers we review and how they are ranked, but does not affect our editorial integrity or the objectivity of our ratings. All reviews are based on our independent research and analysis. See our{' '}
            <Link to="/editorial-policy" className="text-slate-400 hover:text-slate-200 underline focus:outline-none focus:text-slate-200">Editorial Policy</Link>{' '}
            for full details.
          </p>
          <p className="text-xs text-slate-500 leading-relaxed mb-4">
            <strong className="text-slate-400">Not Financial Advice:</strong> The content on this site is for informational purposes only and does not constitute financial, investment, or tax advice. Investing in a self-directed IRA involves significant risks including market volatility, liquidity risk, and the risk of total loss. Please consult a qualified financial advisor before making any investment decisions.
          </p>
          <div className="flex flex-col sm:flex-row justify-between items-start sm:items-center gap-2 mt-6">
            <p className="text-xs text-slate-600">
              &copy; {new Date().getFullYear()} IRA Research Hub. All rights reserved.
            </p>
            <nav aria-label="Footer legal links">
              <div className="flex gap-4 text-xs">
                <Link to="/privacy" className="text-slate-500 hover:text-slate-300 transition-colors focus:outline-none focus:underline">Privacy Policy</Link>
                <Link to="/editorial-policy" className="text-slate-500 hover:text-slate-300 transition-colors focus:outline-none focus:underline">Editorial Policy</Link>
                <Link to="/methodology" className="text-slate-500 hover:text-slate-300 transition-colors focus:outline-none focus:underline">Methodology</Link>
              </div>
            </nav>
          </div>
        </div>
      </div>
    </footer>
  )
}
