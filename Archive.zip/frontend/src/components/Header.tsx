import { useState, useRef, useEffect } from 'react'
import { Link, NavLink, useLocation } from 'react-router-dom'

type NavChild = { label: string; href: string | null }
type NavItem = { label: string; href: string; children?: NavChild[] }

const navLinks: NavItem[] = [
  {
    label: 'Educational Guides',
    href: '/guides',
    children: [
      { label: 'What Is a Self-Directed IRA? (2026 Guide)', href: '/guides/what-is-self-directed-ira' },
      { label: 'Crypto in Retirement: Rules, Risks & Tax Implications', href: '/guides/crypto-in-retirement' },
      { label: 'Precious Metals in IRAs: Gold, Silver & Diversification', href: '/guides/precious-metals-in-ira' },
      { label: 'IRA Rollover Rules: Complete 2026 Guide', href: '/guides/ira-rollover-rules' },
      { label: 'IRA Contribution Limits & Rules 2026', href: '/guides/ira-contribution-limits-2026' },
      { label: '— More Guides —', href: null },
      { label: 'Crypto IRA vs. Buying Crypto Directly', href: '/guides/crypto-ira-vs-buying-directly' },
      { label: 'Gold IRA vs. Gold ETF: Which Is Better?', href: '/guides/gold-ira-vs-gold-etf' },
      { label: 'IRA Tax Strategies for High-Income Earners', href: '/guides/ira-tax-strategies-high-income' },
      { label: 'How to Research SDIRA Providers', href: '/guides/how-to-research-sdira-providers' },
      { label: 'Required Minimum Distributions (RMDs) 2026', href: '/guides/required-minimum-distributions-2026' },
      { label: '— Education —', href: null },
      { label: 'IRS Rules for Digital Asset IRAs', href: '/education/irs-rules-digital-asset-iras' },
      { label: 'Digital Asset Retirement Planning', href: '/education/digital-asset-retirement-planning' },
    ],
  },
  {
    label: 'Crypto IRA Research',
    href: '/crypto-ira',
    children: [
      { label: '2026 Crypto IRA Provider Comparison', href: '/crypto-ira/best-companies' },
      { label: 'Best Bitcoin IRA Companies', href: '/crypto-ira/best-bitcoin-ira' },
      { label: '401k to Crypto IRA Rollover Guide', href: '/crypto-ira/401k-to-crypto-ira-rollover' },
      { label: '2026 Crypto IRA Fee Research', href: '/research/crypto-ira-fees-2026' },
      { label: 'What Is a Crypto IRA?', href: '/crypto-ira/what-is-a-crypto-ira' },
      { label: 'Crypto IRA vs. Stock IRA', href: '/crypto-ira-vs-stock-ira' },
      { label: '— Comparisons —', href: null },
      { label: 'Swan Bitcoin IRA vs BlockTrust', href: '/crypto-ira/swan-bitcoin-ira-vs-blocktrust-ira' },
      { label: 'BitIRA vs Bitcoin IRA', href: '/crypto-ira/bitira-vs-bitcoin-ira' },
      { label: '— Provider Data Profiles —', href: null },
      { label: 'BlockTrust IRA', href: '/crypto-ira/blocktrust-ira-review' },
      { label: 'Bitcoin IRA', href: '/crypto-ira/bitcoin-ira-review' },
      { label: 'iTrustCapital', href: '/crypto-ira/itrustcapital-review' },
      { label: 'Alto CryptoIRA', href: '/crypto-ira/alto-crypto-ira-review' },
      { label: 'BitIRA', href: '/crypto-ira/bitira-review' },
      { label: 'Swan Bitcoin IRA', href: '/crypto-ira/swan-bitcoin-ira-review' },
      { label: 'Rocket Dollar', href: '/crypto-ira/rocket-dollar-review' },
      { label: 'Unchained IRA', href: '/crypto-ira/unchained-ira-review' },
      { label: 'Fidelity Crypto IRA', href: '/crypto-ira/fidelity-crypto-ira-review' },
    ],
  },
  {
    label: 'Precious Metals Research',
    href: '/precious-metals-ira',
    children: [
      { label: '2026 Precious Metals IRA Provider Comparison', href: '/precious-metals-ira/best-companies' },
      { label: 'Best Gold IRA Companies', href: '/precious-metals-ira/best-gold-ira' },
      { label: '401k to Gold IRA Rollover Guide', href: '/precious-metals-ira/401k-to-gold-ira-rollover' },
      { label: '2026 Gold IRA Fee Research', href: '/research/gold-ira-fees-2026' },
      { label: 'What Is a Gold IRA?', href: '/precious-metals-ira/what-is-a-gold-ira' },
      { label: 'How to Buy Gold in an IRA', href: '/precious-metals-ira/how-to-buy-gold-in-ira' },
      { label: '— Comparisons —', href: null },
      { label: 'Augusta vs Goldco (2026)', href: '/precious-metals-ira/augusta-vs-goldco' },
      { label: 'Birch Gold vs Augusta', href: '/precious-metals-ira/birch-gold-vs-augusta' },
      { label: '— Provider Data Profiles —', href: null },
      { label: 'Augusta Precious Metals', href: '/precious-metals-ira/augusta-precious-metals-review' },
      { label: 'Goldco', href: '/precious-metals-ira/goldco-review' },
      { label: 'Birch Gold Group', href: '/precious-metals-ira/birch-gold-group-review' },
      { label: 'American Hartford Gold', href: '/precious-metals-ira/american-hartford-gold-review' },
      { label: 'Genesis Gold Group', href: '/precious-metals-ira/genesis-gold-group-review' },
      { label: 'Lear Capital', href: '/precious-metals-ira/lear-capital-review' },
      { label: 'Noble Gold Investments', href: '/precious-metals-ira/noble-gold-investments-review' },
      { label: 'Advantage Gold', href: '/precious-metals-ira/advantage-gold-review' },
      { label: 'GoldenCrest Metals', href: '/precious-metals-ira/goldencrest-metals-review' },
      { label: 'Patriot Gold Group', href: '/precious-metals-ira/patriot-gold-group-review' },
      { label: 'Oxford Gold Group', href: '/precious-metals-ira/oxford-gold-group-review' },
      { label: 'Preserve Gold', href: '/precious-metals-ira/preserve-gold-review' },
      { label: 'Rosland Capital', href: '/precious-metals-ira/rosland-capital-review' },
      { label: 'Allegiance Gold', href: '/precious-metals-ira/allegiance-gold-review' },
    ],
  },
  { label: 'Gold vs Crypto IRA', href: '/gold-ira-vs-crypto-ira' },
  { label: 'Methodology', href: '/methodology' },
  { label: 'About', href: '/about' },
]

export default function Header() {
  const [mobileOpen, setMobileOpen] = useState(false)
  const [openDropdown, setOpenDropdown] = useState<string | null>(null)
  const [mobileExpandedSections, setMobileExpandedSections] = useState<Set<string>>(new Set())
  const location = useLocation()
  const dropdownRef = useRef<HTMLDivElement>(null)

  // Close mobile menu on route change
  useEffect(() => {
    setMobileOpen(false)
    setOpenDropdown(null)
  }, [location.pathname])

  // Close dropdown when clicking outside
  useEffect(() => {
    function handleClickOutside(e: MouseEvent) {
      if (dropdownRef.current && !dropdownRef.current.contains(e.target as Node)) {
        setOpenDropdown(null)
      }
    }
    document.addEventListener('mousedown', handleClickOutside)
    return () => document.removeEventListener('mousedown', handleClickOutside)
  }, [])

  const toggleMobileSection = (href: string) => {
    setMobileExpandedSections(prev => {
      const next = new Set(prev)
      if (next.has(href)) {
        next.delete(href)
      } else {
        next.add(href)
      }
      return next
    })
  }

  return (
    <>
      {/* Skip Navigation — WCAG 2.4.1 */}
      <a
        href="#main-content"
        className="skip-to-content"
      >
        Skip to main content
      </a>

      {/* Compliance Banner */}
      <div
        className="bg-slate-800 text-slate-300 text-xs text-center py-1.5 px-4 leading-snug"
        role="banner"
        aria-label="Site compliance notice"
      >
        <span className="font-medium text-white">Independent Research</span>
        {' · '}
        <Link to="/editorial-policy" className="underline hover:text-white transition-colors focus:outline-none focus:text-white">Affiliate Compensation Disclosed</Link>
        {' · '}
        Not Financial Advice
        {' · '}
        <span className="text-amber-400 font-medium">High Risks Involved — Including Total Loss of Principal</span>
      </div>

      <header className="bg-white border-b border-slate-200 sticky top-0 z-50" role="banner">
        <div className="container-site">
          <div className="flex items-center justify-between h-16">
            {/* Logo */}
            <Link
              to="/"
              className="flex items-center gap-2 flex-shrink-0 focus:outline-none focus:ring-2 focus:ring-sky-400 focus:ring-offset-2 rounded"
              aria-label="IRA Research Hub — Home"
            >
              <img
                src="/assets/logos/logo-dark.png"
                alt="IRA Research Hub"
                className="h-9 w-auto"
                width="107"
                height="72"
              />
            </Link>

            {/* Desktop Nav */}
            <nav className="hidden lg:flex items-center gap-0.5" aria-label="Main navigation" ref={dropdownRef}>
              {navLinks.map((link) => (
                <div
                  key={link.href}
                  className="relative"
                  onMouseEnter={() => link.children && setOpenDropdown(link.href)}
                  onMouseLeave={() => setOpenDropdown(null)}
                >
                  <NavLink
                    to={link.href}
                    className={({ isActive }) =>
                      `px-3 py-2 rounded-lg text-sm font-medium transition-colors duration-150 inline-flex items-center gap-1 whitespace-nowrap focus:outline-none focus:ring-2 focus:ring-sky-400 focus:ring-offset-1 ${
                        isActive
                          ? 'text-sky-600 bg-sky-50'
                          : 'text-slate-600 hover:text-slate-900 hover:bg-slate-50'
                      }`
                    }
                    aria-haspopup={link.children ? 'true' : undefined}
                    aria-expanded={link.children ? openDropdown === link.href : undefined}
                  >
                    {link.label}
                    {link.children && (
                      <svg
                        className={`w-3.5 h-3.5 opacity-50 transition-transform duration-150 ${openDropdown === link.href ? 'rotate-180' : ''}`}
                        fill="none"
                        viewBox="0 0 24 24"
                        stroke="currentColor"
                        aria-hidden="true"
                      >
                        <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M19 9l-7 7-7-7" />
                      </svg>
                    )}
                  </NavLink>

                  {/* Dropdown */}
                  {link.children && openDropdown === link.href && (
                    <div
                      className="absolute top-full left-0 mt-1 w-80 bg-white rounded-xl border border-slate-200 shadow-lg py-1.5 z-50 max-h-[80vh] overflow-y-auto"
                      role="menu"
                      aria-label={`${link.label} submenu`}
                    >
                      {link.children.map((child) =>
                        child.href === null ? (
                          <div
                            key={child.label}
                            className="px-4 py-1.5 text-xs font-semibold text-slate-400 uppercase tracking-wider border-t border-slate-100 mt-1 pt-2"
                            role="separator"
                            aria-hidden="true"
                          >
                            {child.label.replace(/^— | —$/g, '')}
                          </div>
                        ) : (
                          <NavLink
                            key={child.href}
                            to={child.href}
                            className={({ isActive }) =>
                              `block px-4 py-2.5 text-sm transition-colors duration-150 focus:outline-none focus:bg-sky-50 focus:text-sky-600 ${
                                isActive
                                  ? 'text-sky-600 bg-sky-50'
                                  : 'text-slate-600 hover:text-slate-900 hover:bg-slate-50'
                              }`
                            }
                            role="menuitem"
                            onClick={() => setOpenDropdown(null)}
                          >
                            {child.label}
                          </NavLink>
                        )
                      )}
                    </div>
                  )}
                </div>
              ))}
            </nav>

            {/* Desktop CTA */}
            <div className="hidden lg:flex items-center gap-3">
              <Link
                to="/crypto-ira/best-companies"
                className="btn-primary text-sm py-2 px-4"
                aria-label="Compare crypto IRA providers"
              >
                Compare Providers
              </Link>
            </div>

            {/* Mobile hamburger */}
            <button
              className="lg:hidden p-2 rounded-lg text-slate-600 hover:bg-slate-100 focus:outline-none focus:ring-2 focus:ring-sky-400 focus:ring-offset-1 transition-colors"
              onClick={() => setMobileOpen(!mobileOpen)}
              aria-label={mobileOpen ? 'Close navigation menu' : 'Open navigation menu'}
              aria-expanded={mobileOpen}
              aria-controls="mobile-menu"
            >
              {mobileOpen ? (
                <svg className="w-5 h-5" fill="none" viewBox="0 0 24 24" stroke="currentColor" aria-hidden="true">
                  <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M6 18L18 6M6 6l12 12" />
                </svg>
              ) : (
                <svg className="w-5 h-5" fill="none" viewBox="0 0 24 24" stroke="currentColor" aria-hidden="true">
                  <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M4 6h16M4 12h16M4 18h16" />
                </svg>
              )}
            </button>
          </div>

          {/* Mobile Menu — collapsible sections */}
          {mobileOpen && (
            <nav
              id="mobile-menu"
              className="lg:hidden border-t border-slate-100 py-3 pb-4"
              aria-label="Mobile navigation"
            >
              <ul className="space-y-0.5" role="list">
                {navLinks.map((link) => {
                  const isExpanded = mobileExpandedSections.has(link.href)
                  return (
                    <li key={link.href} role="listitem">
                      {link.children ? (
                        <>
                          {/* Expandable section header */}
                          <button
                            className="w-full flex items-center justify-between px-4 py-2.5 rounded-lg text-sm font-medium text-slate-700 hover:bg-slate-50 focus:outline-none focus:ring-2 focus:ring-sky-400 focus:ring-inset transition-colors"
                            onClick={() => toggleMobileSection(link.href)}
                            aria-expanded={isExpanded}
                            aria-controls={`mobile-section-${link.href.replace(/\//g, '-')}`}
                          >
                            <span>{link.label}</span>
                            <svg
                              className={`w-4 h-4 text-slate-400 transition-transform duration-200 ${isExpanded ? 'rotate-180' : ''}`}
                              fill="none"
                              viewBox="0 0 24 24"
                              stroke="currentColor"
                              aria-hidden="true"
                            >
                              <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M19 9l-7 7-7-7" />
                            </svg>
                          </button>
                          {/* Expandable children */}
                          {isExpanded && (
                            <ul
                              id={`mobile-section-${link.href.replace(/\//g, '-')}`}
                              className="mt-0.5 mb-1 bg-slate-50 rounded-lg mx-2 py-1"
                              role="list"
                            >
                              {/* Link to the parent page */}
                              <li role="listitem">
                                <NavLink
                                  to={link.href}
                                  className={({ isActive }) =>
                                    `block px-4 py-2 text-sm font-medium border-b border-slate-200 mb-1 focus:outline-none focus:bg-sky-50 ${
                                      isActive ? 'text-sky-600' : 'text-slate-700 hover:text-slate-900'
                                    }`
                                  }
                                  onClick={() => setMobileOpen(false)}
                                >
                                  View All {link.label}
                                </NavLink>
                              </li>
                              {link.children.map((child) =>
                                child.href === null ? (
                                  <li
                                    key={child.label}
                                    className="px-4 py-1 text-xs font-semibold text-slate-400 uppercase tracking-wider"
                                    role="separator"
                                    aria-hidden="true"
                                  >
                                    {child.label.replace(/^— | —$/g, '')}
                                  </li>
                                ) : (
                                  <li key={child.href} role="listitem">
                                    <NavLink
                                      to={child.href}
                                      className={({ isActive }) =>
                                        `block px-4 py-2 text-sm focus:outline-none focus:bg-sky-50 ${
                                          isActive ? 'text-sky-600 font-medium' : 'text-slate-600 hover:text-slate-900'
                                        }`
                                      }
                                      onClick={() => setMobileOpen(false)}
                                    >
                                      {child.label}
                                    </NavLink>
                                  </li>
                                )
                              )}
                            </ul>
                          )}
                        </>
                      ) : (
                        <NavLink
                          to={link.href}
                          className={({ isActive }) =>
                            `block px-4 py-2.5 rounded-lg text-sm font-medium focus:outline-none focus:ring-2 focus:ring-sky-400 focus:ring-inset transition-colors ${
                              isActive ? 'text-sky-600 bg-sky-50' : 'text-slate-700 hover:bg-slate-50 hover:text-slate-900'
                            }`
                          }
                          onClick={() => setMobileOpen(false)}
                        >
                          {link.label}
                        </NavLink>
                      )}
                    </li>
                  )
                })}
              </ul>
              <div className="pt-3 px-4">
                <Link
                  to="/crypto-ira/best-companies"
                  className="btn-primary w-full text-sm text-center"
                  onClick={() => setMobileOpen(false)}
                  aria-label="Compare crypto IRA providers"
                >
                  Compare Providers
                </Link>
              </div>
            </nav>
          )}
        </div>
      </header>
    </>
  )
}
