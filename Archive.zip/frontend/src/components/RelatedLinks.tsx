/**
 * RelatedLinks — Reusable internal linking component
 *
 * Renders a "Related Articles" / "You May Also Like" section with
 * contextually relevant internal links. Accepts a `variant` prop to
 * select a pre-built link set, or a custom `links` array for one-off use.
 *
 * Usage:
 *   <RelatedLinks variant="crypto-review" />
 *   <RelatedLinks variant="metals-review" />
 *   <RelatedLinks variant="crypto-guide" />
 *   <RelatedLinks variant="metals-guide" />
 *   <RelatedLinks variant="comparison" />
 *   <RelatedLinks variant="state" />
 *   <RelatedLinks links={[{ to: '/path', label: 'Label', desc: 'Optional description' }]} />
 */
import { Link } from 'react-router-dom'

export interface RelatedLink {
  to: string
  label: string
  desc?: string
  external?: boolean
}

type RelatedLinksVariant =
  | 'crypto-review'
  | 'metals-review'
  | 'crypto-guide'
  | 'metals-guide'
  | 'comparison-crypto'
  | 'comparison-metals'
  | 'state'
  | 'investor'
  | 'research'

interface RelatedLinksProps {
  variant?: RelatedLinksVariant
  links?: RelatedLink[]
  title?: string
  className?: string
}

// ── Pre-built link sets ────────────────────────────────────────────────────────

const LINK_SETS: Record<RelatedLinksVariant, RelatedLink[]> = {
  'crypto-review': [
    { to: '/crypto-ira', label: 'Best Crypto IRA Companies 2026', desc: 'Full ranked comparison of all providers' },
    { to: '/crypto-ira/blocktrust-ira-review', label: 'BlockTrust IRA Review', desc: '#1 rated — 9.6/10 overall score' },
    { to: '/crypto-ira/bitcoin-ira-review', label: 'Bitcoin IRA Review', desc: '75 cryptocurrencies, $1,000 minimum' },
    { to: '/crypto-ira/itrustcapital-review', label: 'iTrustCapital Review', desc: 'Low 1% trading fee, gold & silver too' },
    { to: '/crypto-ira/bitira-review', label: 'BitIRA Review', desc: 'End-to-end cold storage, $100M insurance' },
    { to: '/crypto-ira/swan-bitcoin-ira-review', label: 'Swan Bitcoin IRA Review', desc: 'Bitcoin-only, self-custody focus' },
    { to: '/crypto-ira/alto-crypto-ira-review', label: 'Alto CryptoIRA Review', desc: 'Coinbase-powered, 200+ cryptocurrencies' },
    { to: '/crypto-ira/unchained-ira-review', label: 'Unchained IRA Review', desc: 'Multisig self-custody Bitcoin IRA' },
    { to: '/crypto-ira/401k-to-crypto-ira-rollover', label: '401k to Crypto IRA Rollover Guide', desc: 'Tax-free rollover step-by-step' },
    { to: '/gold-ira-vs-crypto-ira', label: 'Gold IRA vs Crypto IRA', desc: 'Which is right for your retirement?' },
    { to: '/research/crypto-ira-fees-2026', label: 'Crypto IRA Fees 2026', desc: 'Full fee comparison across all providers' },
    { to: '/methodology', label: 'How We Rate Providers', desc: 'Our 6-category scoring methodology' },
  ],
  'metals-review': [
    { to: '/precious-metals-ira', label: 'Best Precious Metals IRA Companies 2026', desc: 'Full ranked comparison' },
    { to: '/precious-metals-ira/best-gold-ira', label: 'Best Gold IRA Companies 2026', desc: 'Top-rated gold IRA providers' },
    { to: '/precious-metals-ira/augusta-precious-metals-review', label: 'Augusta Precious Metals Review', desc: '#1 rated metals IRA — 9.8/10' },
    { to: '/precious-metals-ira/goldco-review', label: 'Goldco Review', desc: 'Top gold & silver IRA, A+ BBB' },
    { to: '/precious-metals-ira/birch-gold-group-review', label: 'Birch Gold Group Review', desc: 'Low $10K minimum, 4 metals' },
    { to: '/precious-metals-ira/genesis-gold-group-review', label: 'Genesis Gold Group Review', desc: 'Personalized service, IRS-approved storage' },
    { to: '/precious-metals-ira/american-hartford-gold-review', label: 'American Hartford Gold Review', desc: 'No first-year fees, A+ BBB' },
    { to: '/precious-metals-ira/noble-gold-investments-review', label: 'Noble Gold Investments Review', desc: '$2,000 minimum, Texas vault storage' },
    { to: '/precious-metals-ira/401k-to-gold-ira-rollover', label: '401k to Gold IRA Rollover Guide', desc: 'Complete tax-free rollover guide' },
    { to: '/precious-metals-ira/how-to-open-gold-ira', label: 'How to Open a Gold IRA', desc: 'Step-by-step account opening guide' },
    { to: '/gold-ira-vs-crypto-ira', label: 'Gold IRA vs Crypto IRA', desc: 'Side-by-side comparison' },
    { to: '/research/gold-ira-fees-2026', label: 'Gold IRA Fees 2026', desc: 'Full fee breakdown across all providers' },
    { to: '/methodology', label: 'How We Rate Providers', desc: 'Our 6-category scoring methodology' },
  ],
  'crypto-guide': [
    { to: '/crypto-ira', label: 'Best Crypto IRA Companies 2026', desc: 'Compare all top-rated providers' },
    { to: '/crypto-ira/blocktrust-ira-review', label: 'BlockTrust IRA Review', desc: '#1 rated crypto IRA — 9.6/10' },
    { to: '/crypto-ira/bitcoin-ira-review', label: 'Bitcoin IRA Review', desc: '75 cryptocurrencies supported' },
    { to: '/crypto-ira/itrustcapital-review', label: 'iTrustCapital Review', desc: 'Low 1% trading fee' },
    { to: '/crypto-ira/401k-to-crypto-ira-rollover', label: '401k to Crypto IRA Rollover Guide', desc: 'Tax-free rollover step-by-step' },
    { to: '/research/crypto-ira-fees-2026', label: 'Crypto IRA Fees 2026', desc: 'Full fee comparison' },
    { to: '/gold-ira-vs-crypto-ira', label: 'Gold IRA vs Crypto IRA', desc: 'Which is right for your retirement?' },
    { to: '/guides/ira-rollover-rules', label: 'IRA Rollover Rules', desc: 'IRS rules, timelines, and limits' },
    { to: '/guides/ira-contribution-limits-2026', label: 'IRA Contribution Limits 2026', desc: '2026 limits for Traditional & Roth' },
    { to: '/education/crypto-ira-guide', label: 'Complete Crypto IRA Guide', desc: 'Everything you need to know' },
    { to: '/education/irs-rules-digital-asset-iras', label: 'IRS Rules for Digital Asset IRAs', desc: 'Tax treatment and compliance' },
    { to: '/tools/crypto-ira-fee-calculator', label: 'Crypto IRA Fee Calculator', desc: 'Compare total costs across providers' },
  ],
  'metals-guide': [
    { to: '/precious-metals-ira', label: 'Best Precious Metals IRA Companies 2026', desc: 'Full ranked comparison' },
    { to: '/precious-metals-ira/best-gold-ira', label: 'Best Gold IRA Companies 2026', desc: 'Top-rated gold IRA providers' },
    { to: '/precious-metals-ira/augusta-precious-metals-review', label: 'Augusta Precious Metals Review', desc: '#1 rated metals IRA' },
    { to: '/precious-metals-ira/goldco-review', label: 'Goldco Review', desc: 'Top gold & silver IRA' },
    { to: '/precious-metals-ira/401k-to-gold-ira-rollover', label: '401k to Gold IRA Rollover Guide', desc: 'Tax-free rollover step-by-step' },
    { to: '/precious-metals-ira/how-to-open-gold-ira', label: 'How to Open a Gold IRA', desc: 'Step-by-step account opening guide' },
    { to: '/precious-metals-ira/how-to-buy-gold-in-ira', label: 'How to Buy Gold in an IRA', desc: 'IRS-approved metals and storage' },
    { to: '/research/gold-ira-fees-2026', label: 'Gold IRA Fees 2026', desc: 'Full fee breakdown' },
    { to: '/gold-ira-vs-crypto-ira', label: 'Gold IRA vs Crypto IRA', desc: 'Side-by-side comparison' },
    { to: '/precious-metals-ira/gold-ira-vs-silver-ira', label: 'Gold IRA vs Silver IRA', desc: 'Which metal is right for you?' },
    { to: '/guides/ira-rollover-rules', label: 'IRA Rollover Rules', desc: 'IRS rules, timelines, and limits' },
    { to: '/guides/precious-metals-in-ira', label: 'Precious Metals in IRA Guide', desc: 'IRS-approved metals explained' },
  ],
  'comparison-crypto': [
    { to: '/crypto-ira', label: 'Best Crypto IRA Companies 2026', desc: 'Full ranked comparison of all providers' },
    { to: '/crypto-ira/blocktrust-ira-review', label: 'BlockTrust IRA Review', desc: '#1 rated — 9.6/10 overall score' },
    { to: '/crypto-ira/bitcoin-ira-review', label: 'Bitcoin IRA Review', desc: '75 cryptocurrencies, $1,000 minimum' },
    { to: '/crypto-ira/itrustcapital-review', label: 'iTrustCapital Review', desc: 'Low 1% trading fee' },
    { to: '/crypto-ira/bitira-review', label: 'BitIRA Review', desc: 'End-to-end cold storage, $100M insurance' },
    { to: '/crypto-ira/swan-bitcoin-ira-review', label: 'Swan Bitcoin IRA Review', desc: 'Bitcoin-only, self-custody' },
    { to: '/crypto-ira/blocktrust-ira-vs-bitcoin-ira', label: 'BlockTrust IRA vs Bitcoin IRA', desc: 'Head-to-head comparison' },
    { to: '/crypto-ira/blocktrust-ira-vs-itrustcapital', label: 'BlockTrust IRA vs iTrustCapital', desc: 'Head-to-head comparison' },
    { to: '/crypto-ira/bitcoin-ira-vs-itrustcapital', label: 'Bitcoin IRA vs iTrustCapital', desc: 'Head-to-head comparison' },
    { to: '/research/crypto-ira-fees-2026', label: 'Crypto IRA Fees 2026', desc: 'Full fee comparison' },
    { to: '/gold-ira-vs-crypto-ira', label: 'Gold IRA vs Crypto IRA', desc: 'Cross-category comparison' },
  ],
  'comparison-metals': [
    { to: '/precious-metals-ira', label: 'Best Precious Metals IRA Companies 2026', desc: 'Full ranked comparison' },
    { to: '/precious-metals-ira/best-gold-ira', label: 'Best Gold IRA Companies 2026', desc: 'Top-rated gold IRA providers' },
    { to: '/precious-metals-ira/augusta-precious-metals-review', label: 'Augusta Precious Metals Review', desc: '#1 rated metals IRA' },
    { to: '/precious-metals-ira/goldco-review', label: 'Goldco Review', desc: 'Top gold & silver IRA' },
    { to: '/precious-metals-ira/birch-gold-group-review', label: 'Birch Gold Group Review', desc: 'Low $10K minimum' },
    { to: '/precious-metals-ira/genesis-gold-group-review', label: 'Genesis Gold Group Review', desc: 'Personalized service' },
    { to: '/precious-metals-ira/augusta-vs-goldco', label: 'Augusta vs Goldco', desc: 'Head-to-head comparison' },
    { to: '/precious-metals-ira/birch-gold-vs-augusta', label: 'Birch Gold vs Augusta', desc: 'Head-to-head comparison' },
    { to: '/precious-metals-ira/gold-ira-vs-silver-ira', label: 'Gold IRA vs Silver IRA', desc: 'Which metal is right for you?' },
    { to: '/research/gold-ira-fees-2026', label: 'Gold IRA Fees 2026', desc: 'Full fee breakdown' },
    { to: '/gold-ira-vs-crypto-ira', label: 'Gold IRA vs Crypto IRA', desc: 'Cross-category comparison' },
  ],
  'state': [
    { to: '/crypto-ira', label: 'Best Crypto IRA Companies 2026', desc: 'Full national comparison' },
    { to: '/crypto-ira/blocktrust-ira-review', label: 'BlockTrust IRA Review', desc: '#1 rated crypto IRA' },
    { to: '/crypto-ira/bitcoin-ira-review', label: 'Bitcoin IRA Review', desc: '75 cryptocurrencies supported' },
    { to: '/crypto-ira/itrustcapital-review', label: 'iTrustCapital Review', desc: 'Low 1% trading fee' },
    { to: '/precious-metals-ira/best-gold-ira', label: 'Best Gold IRA Companies', desc: 'Top-rated gold IRA providers' },
    { to: '/crypto-ira/401k-to-crypto-ira-rollover', label: '401k to Crypto IRA Rollover', desc: 'Tax-free rollover guide' },
    { to: '/precious-metals-ira/401k-to-gold-ira-rollover', label: '401k to Gold IRA Rollover', desc: 'Tax-free rollover guide' },
    { to: '/research/crypto-ira-fees-2026', label: 'Crypto IRA Fees 2026', desc: 'Full fee comparison' },
    { to: '/tools/crypto-ira-fee-calculator', label: 'Crypto IRA Fee Calculator', desc: 'Compare total costs' },
    { to: '/guides/ira-rollover-rules', label: 'IRA Rollover Rules', desc: 'IRS rules and timelines' },
  ],
  'investor': [
    { to: '/crypto-ira', label: 'Best Crypto IRA Companies 2026', desc: 'Full ranked comparison' },
    { to: '/crypto-ira/blocktrust-ira-review', label: 'BlockTrust IRA Review', desc: '#1 rated — 9.6/10' },
    { to: '/crypto-ira/bitcoin-ira-review', label: 'Bitcoin IRA Review', desc: '75 cryptocurrencies' },
    { to: '/crypto-ira/itrustcapital-review', label: 'iTrustCapital Review', desc: 'Low 1% trading fee' },
    { to: '/investor/best-crypto-ira-beginners', label: 'Best Crypto IRA for Beginners', desc: 'Easiest platforms to start with' },
    { to: '/investor/best-crypto-ira-high-net-worth', label: 'Best Crypto IRA for High Net Worth', desc: 'Premium managed options' },
    { to: '/investor/best-crypto-ira-bitcoin-only', label: 'Best Bitcoin-Only IRA', desc: 'Platforms focused on BTC' },
    { to: '/investor/best-crypto-ira-rollover', label: 'Best Crypto IRA for Rollovers', desc: 'Top picks for 401k rollovers' },
    { to: '/research/crypto-ira-fees-2026', label: 'Crypto IRA Fees 2026', desc: 'Full fee comparison' },
    { to: '/tools/crypto-ira-fee-calculator', label: 'Crypto IRA Fee Calculator', desc: 'Compare total costs' },
    { to: '/gold-ira-vs-crypto-ira', label: 'Gold IRA vs Crypto IRA', desc: 'Which is right for you?' },
  ],
  'research': [
    { to: '/crypto-ira', label: 'Best Crypto IRA Companies 2026', desc: 'Full ranked comparison' },
    { to: '/precious-metals-ira', label: 'Best Precious Metals IRA Companies 2026', desc: 'Full ranked comparison' },
    { to: '/research/crypto-ira-fees-2026', label: 'Crypto IRA Fees 2026', desc: 'Full fee comparison' },
    { to: '/research/gold-ira-fees-2026', label: 'Gold IRA Fees 2026', desc: 'Full fee breakdown' },
    { to: '/research/precious-metals-ira-fees-2026', label: 'Precious Metals IRA Fees 2026', desc: 'Comprehensive fee analysis' },
    { to: '/research/crypto-ira-industry-report-2026', label: 'Crypto IRA Industry Report 2026', desc: 'Market data and trends' },
    { to: '/tools/crypto-ira-fee-calculator', label: 'Crypto IRA Fee Calculator', desc: 'Interactive cost comparison tool' },
    { to: '/gold-ira-vs-crypto-ira', label: 'Gold IRA vs Crypto IRA', desc: 'Cross-category comparison' },
    { to: '/methodology', label: 'Our Rating Methodology', desc: 'How we score providers' },
  ],
}

// ── Component ──────────────────────────────────────────────────────────────────

export default function RelatedLinks({
  variant,
  links,
  title = 'Related Articles',
  className = '',
}: RelatedLinksProps) {
  const items = links ?? (variant ? LINK_SETS[variant] : [])

  if (!items.length) return null

  return (
    <nav
      aria-label={title}
      className={`border border-slate-200 rounded-xl bg-white p-6 ${className}`}
    >
      <h3 className="font-semibold text-slate-900 text-sm uppercase tracking-wider mb-4">
        {title}
      </h3>
      <ul className="space-y-3" role="list">
        {items.map(({ to, label, desc, external }) => (
          <li key={to}>
            {external ? (
              <a
                href={to}
                target="_blank"
                rel="noopener noreferrer"
                className="group flex flex-col gap-0.5"
              >
                <span className="text-sky-600 hover:underline text-sm font-medium leading-snug group-hover:text-sky-700">
                  {label} →
                </span>
                {desc && (
                  <span className="text-slate-500 text-xs leading-snug">{desc}</span>
                )}
              </a>
            ) : (
              <Link to={to} className="group flex flex-col gap-0.5">
                <span className="text-sky-600 hover:underline text-sm font-medium leading-snug group-hover:text-sky-700">
                  {label} →
                </span>
                {desc && (
                  <span className="text-slate-500 text-xs leading-snug">{desc}</span>
                )}
              </Link>
            )}
          </li>
        ))}
      </ul>
    </nav>
  )
}
