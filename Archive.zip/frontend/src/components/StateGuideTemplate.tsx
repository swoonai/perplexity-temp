import { Link } from 'react-router-dom'
import SEO from './SEO'
import AdvertiserDisclosure from './AdvertiserDisclosure'
import NewsletterSignup from './NewsletterSignup'
import BlockTrustCTA from './BlockTrustCTA'

interface StateGuideTemplateProps {
  stateName: string
  stateAbbr: string
  slug: string
  /** One or two sentences describing the state's IRA/crypto landscape */
  stateContext?: string
  /** Any state-specific regulatory note */
  regulatoryNote?: string
  /** Any state-specific tax note */
  taxNote?: string
}

export default function StateGuideTemplate({
  stateName,
  stateAbbr,
  slug,
  stateContext,
  regulatoryNote,
  taxNote,
}: StateGuideTemplateProps) {
  const pageSlug = `local/best-crypto-ira-${slug}`

  const defaultContext = `${stateName} residents have full access to all major national Crypto IRA custodians. Whether you are rolling over a 401(k) from a ${stateName}-based employer or opening a new self-directed IRA, the options available to ${stateAbbr} investors are the same as those available nationally.`

  const defaultRegulatoryNote = `${stateName} does not impose state-level restrictions on self-directed IRAs holding digital assets. Investors should confirm custodian availability with their chosen provider, as a small number of custodians voluntarily restrict service in certain states.`

  const defaultTaxNote = `Retirement distributions from a Crypto IRA are subject to federal income tax rules regardless of state. ${stateName} residents should consult a local CPA or tax advisor regarding state income tax treatment of IRA distributions, as state rules vary significantly.`

  return (
    <>
      <SEO
        title={`Best Crypto IRA in ${stateName} (${stateAbbr}) | 2026 Guide`}
        description={`Find the best Crypto IRA for ${stateName} residents in 2026. Compare fees, security, and coin selection — plus our top-rated pick for ${stateAbbr} investors.`}
        canonical={`/${pageSlug}`}
      />
      <div className="container-site section-padding">
        {/* Breadcrumb */}
        <nav className="text-sm text-slate-500 mb-6" aria-label="Breadcrumb">
          <ol className="flex flex-wrap gap-1 items-center">
            <li><Link to="/" className="hover:text-amber-600">Home</Link></li>
            <li className="text-slate-300">/</li>
            <li><Link to="/local" className="hover:text-amber-600">Local Guides</Link></li>
            <li className="text-slate-300">/</li>
            <li className="text-slate-700 font-medium">{stateName}</li>
          </ol>
        </nav>

        <div className="grid lg:grid-cols-[1fr_320px] gap-10">
          {/* Main content */}
          <main>
            <div className="mb-2">
              <div className="flex items-center gap-3 mb-3">
                <span className="text-xs font-semibold uppercase tracking-wider text-amber-600 bg-amber-50 border border-amber-200 px-2 py-1 rounded">State Guide</span>
                <span className="text-xs text-slate-500">Updated April 2026</span>
              </div>
              <h1 className="text-3xl md:text-4xl font-bold text-[#0F172A] mb-4">
                Best Crypto IRA Providers in {stateName} ({stateAbbr})
              </h1>
              <AdvertiserDisclosure />
            </div>

            <div className="prose prose-slate max-w-none mt-8 space-y-6">
              <p className="text-lg text-slate-700 leading-relaxed">
                {stateContext ?? defaultContext}
              </p>

              {/* #1 Recommendation — BlockTrust IRA */}
              <div className="not-prose rounded-xl border-2 border-amber-300 bg-gradient-to-br from-amber-50 to-orange-50 p-6 my-8">
                <div className="flex items-center gap-2 mb-3">
                  <span className="inline-flex items-center px-2.5 py-1 rounded-full text-xs font-bold bg-amber-500 text-white uppercase tracking-wide">
                    #1 Recommended — Crypto IRA
                  </span>
                  <span className="text-xs text-slate-500">Editor's Choice 2026</span>
                </div>
                <div className="flex flex-col sm:flex-row gap-5 items-start">
                  <div className="flex-1">
                    <h2 className="text-xl font-bold text-[#0F172A] mb-1">BlockTrust IRA</h2>
                    <div className="flex items-center gap-1 mb-3">
                      <span className="text-amber-400 text-base">★★★★★</span>
                      <span className="text-sm font-semibold text-slate-700 ml-1">4.9 / 5</span>
                    </div>
                    <p className="text-sm text-slate-700 leading-relaxed mb-3">
                      BlockTrust IRA is our top-rated Crypto IRA provider for {stateName} residents. It offers the lowest trading fees in the industry (0.14%–0.40%), access to 60+ cryptocurrencies, and a dedicated IRA specialist assigned to every account. Unlike competitors that charge flat annual fees regardless of account size, BlockTrust's fee structure rewards long-term holders.
                    </p>
                    <ul className="space-y-1.5 text-sm text-slate-700">
                      <li className="flex gap-2"><span className="text-green-500 font-bold mt-0.5">✓</span><span><strong>Fees:</strong> 0.14%–0.40% trading fee — no hidden annual charges</span></li>
                      <li className="flex gap-2"><span className="text-green-500 font-bold mt-0.5">✓</span><span><strong>Assets:</strong> 60+ cryptocurrencies including Bitcoin, Ethereum, and altcoins</span></li>
                      <li className="flex gap-2"><span className="text-green-500 font-bold mt-0.5">✓</span><span><strong>Custody:</strong> IRS-compliant cold storage with institutional-grade security</span></li>
                      <li className="flex gap-2"><span className="text-green-500 font-bold mt-0.5">✓</span><span><strong>Support:</strong> Dedicated IRA specialist — not a call center</span></li>
                      <li className="flex gap-2"><span className="text-green-500 font-bold mt-0.5">✓</span><span><strong>Rollovers:</strong> Free 401(k) and traditional IRA rollover assistance</span></li>
                    </ul>
                  </div>
                  <div className="flex-shrink-0 flex flex-col gap-2 sm:w-44">
                    <Link
                      to="/crypto-ira/blocktrust-ira-review"
                      className="block w-full text-center px-4 py-3 rounded-lg bg-amber-500 hover:bg-amber-600 text-white font-bold text-sm transition-colors"
                    >
                      Read Full Review →
                    </Link>
                    <p className="text-xs text-slate-400 text-center">Free · No obligation</p>
                  </div>
                </div>
              </div>

              {/* Precious Metals IRA section */}
              <h2 className="text-2xl font-bold text-[#0F172A] mt-10 mb-4">Also Considering a Precious Metals IRA?</h2>
              <p className="text-slate-700 leading-relaxed">
                Many {stateName} investors choose to diversify their retirement savings across both digital assets and physical precious metals. If you are interested in a Gold or Silver IRA rollover, Genesis Gold Group is our top recommendation for {stateAbbr} residents seeking a Precious Metals IRA.
              </p>

              {/* #1 Recommendation — Genesis Gold Group */}
              <div className="not-prose rounded-xl border-2 border-slate-200 bg-gradient-to-br from-slate-50 to-gray-50 p-6 my-6">
                <div className="flex items-center gap-2 mb-3">
                  <span className="inline-flex items-center px-2.5 py-1 rounded-full text-xs font-bold bg-slate-700 text-white uppercase tracking-wide">
                    #1 Recommended — Precious Metals IRA
                  </span>
                </div>
                <div className="flex flex-col sm:flex-row gap-5 items-start">
                  <div className="flex-1">
                    <h3 className="text-xl font-bold text-[#0F172A] mb-1">Genesis Gold Group</h3>
                    <div className="flex items-center gap-1 mb-3">
                      <span className="text-amber-400 text-base">★★★★★</span>
                      <span className="text-sm font-semibold text-slate-700 ml-1">4.8 / 5</span>
                    </div>
                    <p className="text-sm text-slate-700 leading-relaxed mb-3">
                      Genesis Gold Group specializes in 401(k) and IRA rollovers into physical gold and silver. They offer white-glove service, transparent pricing, and IRS-approved storage through Brinks and Delaware Depository. Their team handles all the paperwork for rollovers from employer-sponsored plans.
                    </p>
                    <ul className="space-y-1.5 text-sm text-slate-700">
                      <li className="flex gap-2"><span className="text-green-500 font-bold mt-0.5">✓</span><span><strong>Metals:</strong> IRS-approved gold, silver, platinum, and palladium coins and bars</span></li>
                      <li className="flex gap-2"><span className="text-green-500 font-bold mt-0.5">✓</span><span><strong>Storage:</strong> Segregated storage at Brinks and Delaware Depository</span></li>
                      <li className="flex gap-2"><span className="text-green-500 font-bold mt-0.5">✓</span><span><strong>Rollovers:</strong> Full-service 401(k) to Gold IRA rollover — zero out-of-pocket cost</span></li>
                      <li className="flex gap-2"><span className="text-green-500 font-bold mt-0.5">✓</span><span><strong>Buyback:</strong> Guaranteed buyback program at competitive market rates</span></li>
                    </ul>
                  </div>
                  <div className="flex-shrink-0 flex flex-col gap-2 sm:w-44">
                    <Link
                      to="/precious-metals-ira/genesis-gold-group-review"
                      className="block w-full text-center px-4 py-3 rounded-lg bg-slate-700 hover:bg-slate-800 text-white font-bold text-sm transition-colors"
                    >
                      Read Full Review →
                    </Link>
                    <p className="text-xs text-slate-400 text-center">Free · No obligation</p>
                  </div>
                </div>
              </div>

              {/* State regulations */}
              <h2 className="text-2xl font-bold text-[#0F172A] mt-10 mb-4">State Regulations &amp; Tax Considerations for {stateName} Residents</h2>
              <p className="text-slate-700 leading-relaxed">
                {regulatoryNote ?? defaultRegulatoryNote}
              </p>
              <p className="text-slate-700 leading-relaxed">
                {taxNote ?? defaultTaxNote}
              </p>

              {/* How to open section */}
              <h2 className="text-2xl font-bold text-[#0F172A] mt-10 mb-4">How to Open a Crypto IRA in {stateName}</h2>
              <p className="text-slate-700 leading-relaxed">
                Opening a Crypto IRA as a {stateName} resident follows the same process as anywhere in the United States. The IRS governs self-directed IRAs at the federal level, so state of residence does not change the core mechanics. The typical process takes 5–10 business days from application to funded account.
              </p>
              <ol className="space-y-3 text-slate-700 text-sm mt-4">
                <li className="flex gap-3">
                  <span className="flex-shrink-0 w-6 h-6 rounded-full bg-amber-100 text-amber-700 font-bold text-xs flex items-center justify-center">1</span>
                  <span><strong>Choose a custodian.</strong> Select a provider like BlockTrust IRA that is registered with the IRS and uses a qualified custodian for digital assets.</span>
                </li>
                <li className="flex gap-3">
                  <span className="flex-shrink-0 w-6 h-6 rounded-full bg-amber-100 text-amber-700 font-bold text-xs flex items-center justify-center">2</span>
                  <span><strong>Complete the application.</strong> Provide your Social Security number, date of birth, and beneficiary information. Most providers offer a fully online application.</span>
                </li>
                <li className="flex gap-3">
                  <span className="flex-shrink-0 w-6 h-6 rounded-full bg-amber-100 text-amber-700 font-bold text-xs flex items-center justify-center">3</span>
                  <span><strong>Fund your account.</strong> Roll over an existing 401(k) or IRA, or make a new contribution (up to $7,000 for 2026; $8,000 if age 50+).</span>
                </li>
                <li className="flex gap-3">
                  <span className="flex-shrink-0 w-6 h-6 rounded-full bg-amber-100 text-amber-700 font-bold text-xs flex items-center justify-center">4</span>
                  <span><strong>Select your assets.</strong> Choose from the available cryptocurrencies. Bitcoin and Ethereum are the most common starting points for new Crypto IRA investors.</span>
                </li>
                <li className="flex gap-3">
                  <span className="flex-shrink-0 w-6 h-6 rounded-full bg-amber-100 text-amber-700 font-bold text-xs flex items-center justify-center">5</span>
                  <span><strong>Monitor and manage.</strong> Your assets are held in IRS-compliant cold storage. You can rebalance or add to your account at any time through the provider's platform.</span>
                </li>
              </ol>

              {/* FAQ */}
              <h2 className="text-2xl font-bold text-[#0F172A] mt-10 mb-4">Frequently Asked Questions — {stateName} Crypto IRA</h2>
              <div className="space-y-4">
                <div>
                  <h3 className="font-semibold text-slate-900 mb-1">Can I open a Crypto IRA if I live in {stateName}?</h3>
                  <p className="text-slate-600 text-sm leading-relaxed">Yes. {stateName} residents can open a self-directed Crypto IRA with any federally registered custodian. There are no state-level prohibitions on holding digital assets inside an IRA structure.</p>
                </div>
                <div>
                  <h3 className="font-semibold text-slate-900 mb-1">What is the contribution limit for a Crypto IRA in 2026?</h3>
                  <p className="text-slate-600 text-sm leading-relaxed">The IRS contribution limit for all IRA types in 2026 is $7,000 per year ($8,000 if you are age 50 or older). This limit applies regardless of whether you hold crypto, gold, or traditional assets inside the IRA.</p>
                </div>
                <div>
                  <h3 className="font-semibold text-slate-900 mb-1">Is a Crypto IRA rollover from a 401(k) taxable?</h3>
                  <p className="text-slate-600 text-sm leading-relaxed">A direct rollover from a 401(k) to a self-directed IRA is generally not a taxable event, provided the funds are transferred directly between custodians (trustee-to-trustee transfer). Consult a tax advisor to confirm your specific situation.</p>
                </div>
                <div>
                  <h3 className="font-semibold text-slate-900 mb-1">How is BlockTrust IRA different from Bitcoin IRA or iTrustCapital?</h3>
                  <p className="text-slate-600 text-sm leading-relaxed">BlockTrust IRA charges significantly lower trading fees (0.14%–0.40%) compared to Bitcoin IRA (up to 2%) and iTrustCapital (1% flat). BlockTrust also assigns a dedicated IRA specialist to each account rather than routing clients through a general support queue.</p>
                </div>
              </div>

              {/* Bottom CTA */}
              <div className="not-prose mt-10">
                <BlockTrustCTA sourcePage={pageSlug} variant="banner" headline={`Ready to open a Crypto IRA in ${stateName}?`} subtext="BlockTrust IRA is our #1 rated provider — lowest fees, 60+ coins, dedicated specialist." />
              </div>
            </div>

            <div className="mt-10">
              <NewsletterSignup />
            </div>
          </main>

          {/* Sidebar */}
          <aside className="hidden lg:block space-y-6">
            <div className="sticky top-8 space-y-6">
              {/* BlockTrust sidebar CTA */}
              <BlockTrustCTA sourcePage={pageSlug} variant="sidebar" />

              {/* Genesis Gold Group sidebar card */}
              <div className="rounded-xl border border-slate-200 bg-white p-5">
                <p className="text-xs font-semibold uppercase tracking-wider text-slate-500 mb-2">Precious Metals IRA</p>
                <h3 className="font-bold text-slate-900 text-sm mb-1">Genesis Gold Group</h3>
                <div className="flex items-center gap-1 mb-3">
                  <span className="text-amber-400 text-sm">★★★★★</span>
                  <span className="text-xs text-slate-500 ml-1">4.8/5</span>
                </div>
                <ul className="space-y-1 text-xs text-slate-600 mb-4">
                  <li className="flex gap-1.5"><span className="text-green-500 font-bold">✓</span> Gold &amp; Silver IRA rollovers</li>
                  <li className="flex gap-1.5"><span className="text-green-500 font-bold">✓</span> Brinks &amp; Delaware storage</li>
                  <li className="flex gap-1.5"><span className="text-green-500 font-bold">✓</span> Guaranteed buyback program</li>
                  <li className="flex gap-1.5"><span className="text-green-500 font-bold">✓</span> Zero-cost 401k rollover</li>
                </ul>
                <Link
                  to="/precious-metals-ira/genesis-gold-group-review"
                  className="block w-full text-center px-3 py-2.5 rounded-lg bg-slate-700 hover:bg-slate-800 text-white font-semibold text-sm transition-colors"
                >
                  See Full Review →
                </Link>
              </div>

              {/* National rankings */}
              <div className="bg-slate-50 rounded-xl p-5 border border-slate-200">
                <h3 className="font-bold text-slate-900 mb-3 text-sm">National Rankings</h3>
                <ul className="space-y-2 text-sm">
                  <li><Link to="/crypto-ira" className="text-amber-600 hover:underline">Best Crypto IRA Companies 2026</Link></li>
                  <li><Link to="/crypto-ira/best-bitcoin-ira" className="text-amber-600 hover:underline">Best Bitcoin IRA 2026</Link></li>
                  <li><Link to="/precious-metals-ira/best-gold-ira" className="text-amber-600 hover:underline">Best Gold IRA Companies 2026</Link></li>
                  <li><Link to="/crypto-ira/blocktrust-ira-review" className="text-amber-600 hover:underline">BlockTrust IRA Review (#1 Rated)</Link></li>
                  <li><Link to="/crypto-ira/bitcoin-ira-review" className="text-amber-600 hover:underline">Bitcoin IRA Review</Link></li>
                  <li><Link to="/crypto-ira/itrustcapital-review" className="text-amber-600 hover:underline">iTrustCapital Review</Link></li>
                  <li><Link to="/precious-metals-ira/genesis-gold-group-review" className="text-amber-600 hover:underline">Genesis Gold Group Review</Link></li>
                  <li><Link to="/precious-metals-ira/augusta-precious-metals-review" className="text-amber-600 hover:underline">Augusta Precious Metals Review</Link></li>
                </ul>
              </div>
              {/* Guides */}
              <div className="bg-slate-50 rounded-xl p-5 border border-slate-200">
                <h3 className="font-bold text-slate-900 mb-3 text-sm">Guides &amp; Tools</h3>
                <ul className="space-y-2 text-sm">
                  <li><Link to="/crypto-ira/401k-to-crypto-ira-rollover" className="text-amber-600 hover:underline">401k to Crypto IRA Rollover</Link></li>
                  <li><Link to="/precious-metals-ira/401k-to-gold-ira-rollover" className="text-amber-600 hover:underline">401k to Gold IRA Rollover</Link></li>
                  <li><Link to="/research/crypto-ira-fees-2026" className="text-amber-600 hover:underline">Crypto IRA Fees 2026</Link></li>
                  <li><Link to="/tools/crypto-ira-fee-calculator" className="text-amber-600 hover:underline">Crypto IRA Fee Calculator</Link></li>
                  <li><Link to="/guides/ira-rollover-rules" className="text-amber-600 hover:underline">IRA Rollover Rules</Link></li>
                  <li><Link to="/guides/ira-contribution-limits-2026" className="text-amber-600 hover:underline">IRA Contribution Limits 2026</Link></li>
                  <li><Link to="/gold-ira-vs-crypto-ira" className="text-amber-600 hover:underline">Gold IRA vs Crypto IRA</Link></li>
                </ul>
              </div>
            </div>
          </aside>
        </div>
      </div>
    </>
  )
}
