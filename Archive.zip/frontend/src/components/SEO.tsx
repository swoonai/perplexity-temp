import { Helmet } from 'react-helmet-async'

interface SEOProps {
  title: string
  description: string
  canonical?: string
  ogType?: 'website' | 'article'
  ogImage?: string
  schema?: object | object[]
}

export default function SEO({ title, description, canonical, ogType = 'website', ogImage, schema }: SEOProps) {
  const siteTitle = 'IRA Research Hub'
  const baseUrl = 'https://iraresearchhub.com'

  // Build full title: append site name only if the result stays within 70 chars
  // If title already contains the site name, use as-is
  const fullTitle = (() => {
    if (title === siteTitle || title.includes(siteTitle)) return title
    const withSuffix = `${title} | ${siteTitle}`
    return withSuffix.length <= 70 ? withSuffix : title
  })()

  const defaultOgImage = `${baseUrl}/assets/og-image.png`
  const resolvedOgImage = ogImage
    ? (ogImage.startsWith('http') ? ogImage : `${baseUrl}${ogImage}`)
    : defaultOgImage

  // Normalise schema to an array for consistent rendering
  const schemaArray = schema
    ? (Array.isArray(schema) ? schema : [schema])
    : null

  return (
    <Helmet>
      <title>{fullTitle}</title>
      <meta name="description" content={description} />
      {canonical && <link rel="canonical" href={`${baseUrl}${canonical}`} />}
      {/* Open Graph */}
      <meta property="og:title" content={fullTitle} />
      <meta property="og:description" content={description} />
      <meta property="og:type" content={ogType} />
      <meta property="og:site_name" content={siteTitle} />
      <meta property="og:locale" content="en_US" />
      {canonical && <meta property="og:url" content={`${baseUrl}${canonical}`} />}
      <meta property="og:image" content={resolvedOgImage} />
      <meta property="og:image:width" content="1200" />
      <meta property="og:image:height" content="630" />
      <meta property="og:image:alt" content={title} />
      {/* Twitter Card */}
      <meta name="twitter:card" content="summary_large_image" />
      <meta name="twitter:site" content="@iraresearchhub" />
      <meta name="twitter:creator" content="@iraresearchhub" />
      <meta name="twitter:title" content={fullTitle} />
      <meta name="twitter:description" content={description} />
      <meta name="twitter:image" content={resolvedOgImage} />
      <meta name="twitter:image:alt" content={title} />
      {/* JSON-LD structured data */}
      {schemaArray && schemaArray.map((item, i) => (
        <script key={i} type="application/ld+json">
          {JSON.stringify(item)}
        </script>
      ))}
    </Helmet>
  )
}
