/**
 * BlockTrustCTA — Reusable cross-promotion component
 *
 * Renders a prominent BlockTrust IRA call-to-action card.
 * Tracks impressions and clicks via the engine's gscAndCta tRPC router.
 *
 * Usage:
 *   <BlockTrustCTA sourcePage="/precious-metals-ira/401k-to-gold-ira-rollover" variant="sidebar" />
 *   <BlockTrustCTA sourcePage="/gold-ira-vs-crypto-ira" variant="banner" />
 *
 * The BLOCKTRUST_LANDER_URL is a single env var in the engine — swap it when
 * Duncan's TV lander is ready without touching any component code.
 */
import { useEffect, useRef } from 'react'
import { Link } from 'react-router-dom'

// ── Config ────────────────────────────────────────────────────────────────────
// Points to our own review page until Duncan's lander URL is ready.
// When the lander is live, update BLOCKTRUST_LANDER_URL in the engine .env
// and this component will automatically use the new URL via the API.
const BLOCKTRUST_REVIEW_URL = '/crypto-ira/blocktrust-ira-review'
const CTA_ID = 'blocktrust-review-hero'

// ── Types ─────────────────────────────────────────────────────────────────────
interface BlockTrustCTAProps {
  /** The page this CTA is displayed on — used for analytics attribution */
  sourcePage: string
  /** 'sidebar' = compact card for sidebar column; 'banner' = wide inline banner */
  variant?: 'sidebar' | 'banner'
  /** Optional override for the CTA headline */
  headline?: string
  /** Optional override for the CTA sub-text */
  subtext?: string
}

// ── Tracking helper ───────────────────────────────────────────────────────────
async function trackEvent(
  ctaId: string,
  page: string,
  event: 'impression' | 'click'
) {
  try {
    await fetch('/api/trpc/gscAndCta.trackCtaEvent', {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({
        json: { ctaId, page, event, referrer: document.referrer, userAgent: navigator.userAgent },
      }),
    })
  } catch {
    // Silently fail — tracking should never break the page
  }
}

// ── Component ─────────────────────────────────────────────────────────────────
export default function BlockTrustCTA({
  sourcePage,
  variant = 'sidebar',
  headline,
  subtext,
}: BlockTrustCTAProps) {
  const impressionFired = useRef(false)

  // Fire impression once on mount
  useEffect(() => {
    if (!impressionFired.current) {
      impressionFired.current = true
      trackEvent(CTA_ID, sourcePage, 'impression')
    }
  }, [sourcePage])

  const handleClick = () => {
    trackEvent(CTA_ID, sourcePage, 'click')
  }

  if (variant === 'banner') {
    return (
      <div className="rounded-xl border border-amber-200 bg-gradient-to-r from-amber-50 to-orange-50 p-5 my-8">
        <div className="flex flex-col sm:flex-row items-start sm:items-center gap-4">
          <div className="flex-1">
            <div className="flex items-center gap-2 mb-1">
              <span className="inline-flex items-center px-2 py-0.5 rounded text-xs font-semibold bg-amber-100 text-amber-800">
                ★ Editor's Choice 2026
              </span>
              <span className="text-xs text-slate-500">Crypto IRA</span>
            </div>
            <p className="font-bold text-[#0F172A] text-base leading-snug">
              {headline ?? 'Also considering a Crypto IRA? BlockTrust IRA is our #1 pick.'}
            </p>
            <p className="text-sm text-slate-600 mt-1">
              {subtext ?? 'Low fees · 60+ cryptocurrencies · Dedicated IRA specialist · 4.9/5 rating'}
            </p>
          </div>
          <Link
            to={BLOCKTRUST_REVIEW_URL}
            onClick={handleClick}
            className="flex-shrink-0 inline-flex items-center gap-1.5 px-4 py-2.5 rounded-lg bg-amber-500 hover:bg-amber-600 text-white font-semibold text-sm transition-colors whitespace-nowrap"
          >
            See BlockTrust Review →
          </Link>
        </div>
      </div>
    )
  }

  // Sidebar variant
  return (
    <div className="card border border-amber-200 bg-gradient-to-b from-amber-50 to-white">
      <div className="flex items-center gap-1.5 mb-3">
        <span className="inline-flex items-center px-2 py-0.5 rounded text-xs font-semibold bg-amber-100 text-amber-800">
          ★ Editor's Choice 2026
        </span>
      </div>
      <h3 className="font-bold text-[#0F172A] text-sm mb-1">
        {headline ?? 'Our #1 Rated Crypto IRA'}
      </h3>
      <p className="text-xs text-slate-600 mb-1 font-semibold">BlockTrust IRA</p>
      <div className="flex items-center gap-1 mb-3">
        {'★★★★★'.split('').map((s, i) => (
          <span key={i} className="text-amber-400 text-sm">{s}</span>
        ))}
        <span className="text-xs text-slate-500 ml-1">4.9/5</span>
      </div>
      <ul className="space-y-1 text-xs text-slate-600 mb-4">
        <li className="flex gap-1.5"><span className="text-green-500 font-bold">✓</span> 60+ cryptocurrencies</li>
        <li className="flex gap-1.5"><span className="text-green-500 font-bold">✓</span> Lowest fees in class</li>
        <li className="flex gap-1.5"><span className="text-green-500 font-bold">✓</span> Dedicated IRA specialist</li>
        <li className="flex gap-1.5"><span className="text-green-500 font-bold">✓</span> IRS-compliant custody</li>
      </ul>
      <p className="text-xs text-slate-500 mb-3">
        {subtext ?? 'Considering alternatives to Gold? Bitcoin IRAs have outperformed gold 3 years running.'}
      </p>
      <Link
        to={BLOCKTRUST_REVIEW_URL}
        onClick={handleClick}
        className="block w-full text-center px-3 py-2.5 rounded-lg bg-amber-500 hover:bg-amber-600 text-white font-semibold text-sm transition-colors"
      >
        See Full Review →
      </Link>
      <p className="text-xs text-slate-400 text-center mt-2">Free · No obligation</p>
    </div>
  )
}
