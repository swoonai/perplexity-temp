import { Link } from 'react-router-dom'

/**
 * AdvertiserDisclosure
 * Renders a visually prominent disclosure banner immediately below the author byline
 * on all pages containing outbound affiliate links.
 * Required for Google Ads policy compliance (Zacks Publisher Model).
 */
export default function AdvertiserDisclosure() {
  return (
    <div className="bg-amber-50 border border-amber-200 rounded-lg px-5 py-4 sm:px-6 sm:py-5 text-xs sm:text-sm text-amber-800 leading-relaxed mt-5 mb-6">
      <strong className="font-semibold">Advertiser Disclosure:</strong>{' '}
      IRA Research Hub is an independent research publisher. We may receive compensation from the providers evaluated on this site. This compensation does not influence our objective scoring methodology.{' '}
      <Link to="/editorial-policy" className="underline hover:text-amber-900 font-medium">
        Read our full editorial policy
      </Link>.
    </div>
  )
}
