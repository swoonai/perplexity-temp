/**
 * useAnalytics.ts
 * GA4 + Google Ads event tracking for IRA Research Hub.
 *
 * Funnel stages:
 *   1. provider_research_start  — user arrives on a guide/article page from a paid ad
 *   2. provider_card_view       — user scrolls to a provider card or comparison table
 *   3. provider_review_click    — user clicks through to a provider review page
 *   4. provider_site_visit      — user clicks the final CTA to visit a provider's website (PRIMARY CONVERSION)
 */

declare global {
  interface Window {
    gtag?: (...args: unknown[]) => void
    rdt?: (...args: unknown[]) => void
  }
}

// ─── Reddit Pixel helper ──────────────────────────────────────────────────────
function fireRdt(eventName: string, params?: Record<string, unknown>) {
  if (typeof window !== 'undefined' && typeof window.rdt === 'function') {
    window.rdt('track', eventName, params ?? {})
  }
}

// ─── Google Ads conversion IDs ────────────────────────────────────────────────
// Primary conversion: provider_site_visit (replaces affiliate_click)
const ADS_CONVERSION_ID = 'AW-18039211350'
const ADS_CONVERSION_LABEL_SITE_VISIT = 'vZ2WCNmxnJAcENaK4plD'   // provider_site_visit (primary conversion)
const ADS_CONVERSION_LABEL_REVIEW_CLICK = 'bxXWCK6wmZMcENaK4plD'   // secondary conversion — provider_review_click

// ─── Helper ───────────────────────────────────────────────────────────────────
function fireGtag(eventName: string, params: Record<string, unknown>) {
  if (typeof window !== 'undefined' && typeof window.gtag === 'function') {
    window.gtag('event', eventName, params)
  }
}

// ─── Stage 1: Research Start ──────────────────────────────────────────────────
/**
 * Call on mount of any guide or article page when a paid ad UTM parameter is present.
 * Tells Google Ads the user reached the top of the funnel.
 */
export function trackResearchStart(pagePath: string, pageTitle: string, utmSource?: string) {
  fireGtag('provider_research_start', {
    event_category: 'funnel',
    page_path: pagePath,
    page_title: pageTitle,
    traffic_source: utmSource ?? 'direct',
  })
}

// ─── Stage 2: Provider Card View ─────────────────────────────────────────────
/**
 * Call when a provider card or comparison table enters the viewport.
 * Use an IntersectionObserver on the card component.
 */
export function trackProviderCardView(providerName: string, providerSlug: string, pageContext: string) {
  fireGtag('provider_card_view', {
    event_category: 'funnel',
    provider_name: providerName,
    provider_slug: providerSlug,
    page_context: pageContext,   // e.g. "best-crypto-ira", "rollover-guide"
  })
}

// ─── Stage 3: Provider Review Click ──────────────────────────────────────────
/**
 * Call when a user clicks "Read full review" or a provider name link
 * from a guide, comparison, or best-of page.
 * This is a micro-conversion — track in Google Ads as a secondary action.
 */
export function trackProviderReviewClick(
  providerName: string,
  providerSlug: string,
  sourcePagePath: string
) {
  fireGtag('provider_review_click', {
    event_category: 'funnel',
    provider_name: providerName,
    provider_slug: providerSlug,
    source_page: sourcePagePath,
  })

  // Google Ads micro-conversion (secondary action — create this label in Ads UI)
  if (ADS_CONVERSION_LABEL_REVIEW_CLICK) {
    fireGtag('conversion', {
      send_to: `${ADS_CONVERSION_ID}/${ADS_CONVERSION_LABEL_REVIEW_CLICK}`,
    })
  }
}

// ─── Stage 4: Provider Site Visit (PRIMARY CONVERSION) ───────────────────────
/**
 * Call when a user clicks the final CTA button to visit a provider's website.
 * This is the primary conversion — replaces the former affiliate_click event.
 *
 * @param providerName    Display name of the provider
 * @param providerSlug    URL slug (e.g. "blocktrust-ira")
 * @param destinationUrl  The outbound URL the user is navigating to
 * @param sourcePagePath  The page the click originated from (for funnel attribution)
 */
export function trackProviderSiteVisit(
  providerName: string,
  providerSlug: string,
  destinationUrl: string,
  sourcePagePath?: string
) {
  // GA4 event
  fireGtag('provider_site_visit', {
    event_category: 'funnel',
    provider_name: providerName,
    provider_slug: providerSlug,
    destination_url: destinationUrl,
    source_page: sourcePagePath ?? (typeof window !== 'undefined' ? window.location.pathname : ''),
  })

  // Google Ads primary conversion
  fireGtag('conversion', {
    send_to: `${ADS_CONVERSION_ID}/${ADS_CONVERSION_LABEL_SITE_VISIT}`,
  })

  // Reddit pixel — Lead event (fires on every provider site visit / CTA click)
  // conversionId is a unique string per event as required by Reddit Ads
  const rdtConversionId = `lead_${providerSlug}_${Date.now()}`
  fireRdt('Lead', {
    conversionId: rdtConversionId,
    customEventName: 'provider_site_visit',
    provider: providerSlug,
  })
}

// ─── Legacy alias (backwards-compatible — remove after verifying new events) ──
/**
 * @deprecated Use trackProviderSiteVisit() instead.
 * Kept temporarily so existing call sites don't break before migration.
 */
export function trackAffiliateCta(
  providerName: string,
  providerSlug: string,
  destinationUrl: string
) {
  trackProviderSiteVisit(providerName, providerSlug, destinationUrl)
}

// ─── Page View ────────────────────────────────────────────────────────────────
export function trackPageView(pagePath: string, pageTitle: string) {
  fireGtag('page_view', {
    page_path: pagePath,
    page_title: pageTitle,
  })
}
