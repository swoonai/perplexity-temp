import { useQuery } from '@tanstack/react-query'
import { providersApi, type Provider, type ProviderListResponse } from '../lib/api'

// Helper to safely read the prerender cache injected by prerender.cjs
function getPrerenderCache(): Record<string, unknown> | undefined {
  if (typeof window === 'undefined') return undefined
  return (window as unknown as { __PROVIDER_CACHE__?: Record<string, unknown> }).__PROVIDER_CACHE__
}

export function useRankedProviders(category: 'crypto' | 'precious_metals', limit = 10) {
  // During prerender, use injected cache data as initialData so the component
  // renders with full data on first pass (no async query, no loading state).
  const cache = getPrerenderCache()
  const initialData = cache?.ranked
    ? (cache.ranked as Record<string, ProviderListResponse>)[`${category}:${limit}`]
    : undefined

  return useQuery({
    queryKey: ['providers', 'ranked', category, limit],
    queryFn: () => providersApi.getRanked(category, limit),
    staleTime: 1000 * 60 * 10, // 10 minutes
    initialData,
    initialDataUpdatedAt: initialData ? Date.now() : undefined,
  })
}

export function useProvider(slug: string) {
  // During prerender, prerender.cjs injects window.__PROVIDER_CACHE__ before the
  // React bundle loads. Using initialData means the component renders with full
  // data on the first pass — no async query needed, no loading state.
  const cache = getPrerenderCache()
  const initialData: Provider | undefined = cache?.bySlug
    ? (cache.bySlug as Record<string, Provider>)[slug]
    : undefined

  return useQuery({
    queryKey: ['providers', 'detail', slug],
    queryFn: () => providersApi.getBySlug(slug),
    staleTime: 1000 * 60 * 10,
    enabled: !!slug,
    initialData,
    initialDataUpdatedAt: initialData ? Date.now() : undefined,
  })
}

export function useAllProviders(category?: 'crypto' | 'precious_metals') {
  const cache = getPrerenderCache()
  const initialData: ProviderListResponse | undefined = cache
    ? category === 'crypto'
      ? (cache.allCrypto as ProviderListResponse | undefined)
      : category === 'precious_metals'
        ? (cache.allMetals as ProviderListResponse | undefined)
        : (cache.all as ProviderListResponse | undefined)
    : undefined

  return useQuery({
    queryKey: ['providers', 'all', category],
    queryFn: () => providersApi.getAll(category),
    staleTime: 1000 * 60 * 10,
    initialData,
    initialDataUpdatedAt: initialData ? Date.now() : undefined,
  })
}

// Helper: compute score color class based on value
export function scoreColor(score: number | null): string {
  if (!score) return 'text-slate-400'
  if (score >= 9.0) return 'text-emerald-600'
  if (score >= 8.0) return 'text-sky-600'
  if (score >= 7.0) return 'text-amber-500'
  return 'text-red-400'
}

// Helper: render star rating (1-5 stars from 0-10 score)
export function scoreToStars(score: number | null): number {
  if (!score) return 0
  return Math.round((score / 10) * 5 * 2) / 2 // half-star precision
}

export type { Provider }

// Helper: compute score background color class based on value
export function scoreBgColor(score: number | null): string {
  if (!score) return 'bg-slate-400'
  if (score >= 9.0) return 'bg-emerald-600'
  if (score >= 8.0) return 'bg-sky-600'
  if (score >= 7.0) return 'bg-amber-500'
  return 'bg-red-400'
}
