import AwardDetailPage from './AwardDetailPage'

export default function BestGoldIra2026AwardPage() {
  return <AwardDetailPage awardSlug="best-gold-ira-2026" />
}
