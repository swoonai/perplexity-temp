import StateGuideTemplate from '../components/StateGuideTemplate'

export default function BestCryptoIRAARPage() {
  return (
    <StateGuideTemplate
      stateName="Arkansas"
      stateAbbr="AR"
      slug="arkansas"
    />
  )
}
