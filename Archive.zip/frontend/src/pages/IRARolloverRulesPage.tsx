import React from 'react'
import { Link } from 'react-router-dom'
import SEO from '../components/SEO'
import AdvertiserDisclosure from '../components/AdvertiserDisclosure'
import { trackResearchStart } from '../hooks/useAnalytics'
import NewsletterSignup from '../components/NewsletterSignup';
import RelatedLinks from '../components/RelatedLinks';

const LAST_UPDATED = 'March 31, 2026'

export default function IRARolloverRulesPage() {

  // Funnel tracking: fire research_start when arriving from a paid ad
  React.useEffect(() => {
    const params = new URLSearchParams(window.location.search)
    const utmSource = params.get('utm_source') ?? undefined
    if (utmSource) {
      trackResearchStart(window.location.pathname, document.title, utmSource)
    }
  }, [])

  return (
    <>
      <script type="application/ld+json" dangerouslySetInnerHTML={{ __html: JSON.stringify({"@context":"https://schema.org","@type":"BreadcrumbList","itemListElement":[{"@type":"ListItem","position":1,"name":"Guides","item":"https://iraresearchhub.com/guides"},{"@type":"ListItem","position":2,"name":"IRA Rollover Rules","item":"https://iraresearchhub.com/guides/ira-rollover-rules"}]}) }} />
      <SEO
        title="IRA Rollover Rules: Complete 2026 Guide — 60-Day Rule, Direct vs. Indirect, Tax Implications"
        description="Independent educational guide to IRA rollover rules. Covers the 60-day rule, direct vs. indirect rollovers, withholding requirements, one-rollover-per-year rule, and how to avoid costly mistakes."
        canonical="/guides/ira-rollover-rules"
        ogType="article"
      />
      <script type="application/ld+json" dangerouslySetInnerHTML={{ __html: JSON.stringify({"@context":"https://schema.org","@type":"Article","headline":"IRA Rollover Rules: Complete 2026 Guide","author":{"@type":"Person","name":"James Mitchell","jobTitle":"CFA"},"publisher":{"@type":"Organization","name":"IRA Research Hub"},"dateModified":"2026-03-31"}) }} />

      {/* Hero */}
      <div className="bg-[#F8FAFC] border-b border-slate-200 py-10">
        <div className="container-site max-w-4xl">
          <div className="flex flex-wrap gap-2 mb-4">
            <span className="inline-flex items-center px-2.5 py-0.5 rounded-full text-xs font-medium bg-indigo-100 text-indigo-700">Educational Guide</span>
            <span className="inline-flex items-center px-2.5 py-0.5 rounded-full text-xs font-medium bg-slate-100 text-slate-600">2026 Update</span>
          </div>
          <h1 className="text-4xl font-bold text-[#0F172A] mb-4 leading-tight">
            IRA Rollover Rules: Complete 2026 Guide
          </h1>
          <p className="text-lg text-[#64748B] mb-4 max-w-3xl">
            Rolling over a 401(k) or IRA incorrectly can trigger unexpected taxes and penalties. This guide explains the IRS rules governing rollovers — including the 60-day rule, the one-rollover-per-year limit, direct vs. indirect rollovers, withholding requirements, and how to avoid the most common costly mistakes.
          </p>
          <p className="text-sm text-slate-500">
            By <Link to="/author/james-mitchell" className="text-sky-600 hover:underline font-medium">James Mitchell, CFA</Link>
            {' · '}Last Updated: {LAST_UPDATED}
            {' · '}
            <Link to="/methodology" className="text-sky-600 hover:underline">Editorial Methodology</Link>
          </p>
          <AdvertiserDisclosure />
        </div>
      </div>

      <div className="container-site max-w-4xl py-8">
        {/* TOC */}
        <div className="bg-slate-50 border border-slate-200 rounded-xl p-5 mb-10">
          <p className="text-xs font-semibold text-slate-400 uppercase tracking-wider mb-3">In This Guide</p>
          <ol className="space-y-1.5 text-sm text-sky-700">
            {[
              ['What Is an IRA Rollover?', '#what-is'],
              ['Direct vs. Indirect Rollovers', '#direct-vs-indirect'],
              ['The 60-Day Rollover Rule', '#sixty-day'],
              ['The One-Rollover-Per-Year Rule', '#one-per-year'],
              ['Mandatory 20% Withholding on Indirect Rollovers', '#withholding'],
              ['Eligible Rollover Sources', '#eligible-sources'],
              ['Rollovers to a Self-Directed IRA (Crypto or Gold)', '#sdira-rollover'],
              ['Common Mistakes and How to Avoid Them', '#mistakes'],
              ['Primary Sources & References', '#sources'],
            ].map(([label, href]) => (
              <li key={href}><a href={href} className="hover:underline">{label}</a></li>
            ))}
          </ol>
        </div>

        <section id="what-is" className="mb-12">
          <h2 className="text-2xl font-bold text-[#0F172A] mb-4">What Is an IRA Rollover?</h2>
          <p className="text-slate-600 leading-relaxed mb-4">
            An IRA rollover is the movement of retirement funds from one account to another without triggering a taxable distribution. Rollovers allow you to consolidate retirement accounts, change custodians, or move funds from an employer-sponsored plan (such as a 401(k)) into an IRA when you leave a job.
          </p>
          <p className="text-slate-600 leading-relaxed mb-4">
            The IRS permits rollovers between most types of retirement accounts, but the rules governing how and when you can do so are strict. Violating these rules — even inadvertently — can result in the entire amount being treated as a taxable distribution, subject to ordinary income tax plus a 10% early withdrawal penalty if you are under age 59½.
          </p>
        </section>

        <section id="direct-vs-indirect" className="mb-12">
          <h2 className="text-2xl font-bold text-[#0F172A] mb-4">Direct vs. Indirect Rollovers</h2>
          <div className="grid md:grid-cols-2 gap-4 mb-6">
            <div className="p-5 bg-emerald-50 border border-emerald-200 rounded-xl">
              <p className="font-semibold text-emerald-800 mb-3">Direct Rollover (Trustee-to-Trustee Transfer)</p>
              <ul className="text-sm text-emerald-700 space-y-2">
                <li>• Funds move directly from the old custodian to the new custodian</li>
                <li>• You never receive a check — the money is never in your hands</li>
                <li>• No 20% withholding requirement</li>
                <li>• No 60-day deadline to worry about</li>
                <li>• No limit on the number of direct transfers per year</li>
                <li className="font-semibold">Generally the safest and simplest method</li>
              </ul>
            </div>
            <div className="p-5 bg-amber-50 border border-amber-200 rounded-xl">
              <p className="font-semibold text-amber-800 mb-3">Indirect Rollover (60-Day Rollover)</p>
              <ul className="text-sm text-amber-700 space-y-2">
                <li>• The old custodian sends a check to you personally</li>
                <li>• You have 60 days to deposit the full amount into the new IRA</li>
                <li>• Employer plans must withhold 20% for federal taxes</li>
                <li>• You must deposit the full pre-withholding amount (including the withheld 20%) to avoid tax on the withheld portion</li>
                <li>• Limited to one per 12-month period across all IRAs</li>
                <li className="font-semibold">Higher risk of mistakes and tax consequences</li>
              </ul>
            </div>
          </div>
          <div className="bg-sky-50 border border-sky-200 rounded-lg p-4 text-sm text-sky-900">
            <p className="font-semibold mb-1">Recommendation:</p>
            <p>For most investors, a direct trustee-to-trustee transfer is preferable to an indirect rollover. It eliminates withholding issues, the 60-day deadline, and the one-per-year limitation. Always request a direct transfer when moving retirement funds between institutions.</p>
          </div>
        </section>

        <section id="sixty-day" className="mb-12">
          <h2 className="text-2xl font-bold text-[#0F172A] mb-4">The 60-Day Rollover Rule</h2>
          <p className="text-slate-600 leading-relaxed mb-4">
            Under IRC §408(d)(3), if you receive a distribution from an IRA or retirement plan, you have <strong>60 calendar days</strong> from the date you receive the funds to roll them over into another eligible retirement account. If you miss this deadline:
          </p>
          <ul className="list-disc list-inside text-slate-600 space-y-2 mb-4 ml-2">
            <li>The entire distribution is treated as taxable income in the year received</li>
            <li>If you are under age 59½, a 10% early withdrawal penalty applies</li>
            <li>The funds cannot be re-contributed to an IRA after the deadline passes</li>
          </ul>
          <div className="bg-amber-50 border border-amber-200 rounded-lg p-4 text-sm text-amber-900 mb-4">
            <p className="font-semibold mb-1">Hardship Waivers:</p>
            <p>The IRS may waive the 60-day requirement in cases of hardship (e.g., hospitalization, natural disaster, financial institution error). Waivers are not automatic — you must request one from the IRS using Form 5329 or by requesting a private letter ruling. The process is complex and not guaranteed. Do not rely on a waiver being granted.</p>
          </div>
        </section>

        <section id="one-per-year" className="mb-12">
          <h2 className="text-2xl font-bold text-[#0F172A] mb-4">The One-Rollover-Per-Year Rule</h2>
          <p className="text-slate-600 leading-relaxed mb-4">
            Following the Tax Court decision in <em>Bobrow v. Commissioner</em> (2014) and subsequent IRS guidance (Announcement 2014-15 and 2014-32), you are permitted only <strong>one indirect (60-day) rollover per 12-month period</strong> across all of your IRAs combined — not per IRA account.
          </p>
          <p className="text-slate-600 leading-relaxed mb-4">
            This rule applies to:
          </p>
          <ul className="list-disc list-inside text-slate-600 space-y-1.5 mb-4 ml-2">
            <li>Traditional IRAs</li>
            <li>Roth IRAs</li>
            <li>SEP-IRAs</li>
            <li>SIMPLE IRAs (after the 2-year holding period)</li>
          </ul>
          <p className="text-slate-600 leading-relaxed mb-4">
            <strong>This rule does not apply to direct trustee-to-trustee transfers</strong>, which are unlimited. It also does not apply to rollovers from employer plans (401(k), 403(b), 457) into an IRA — those are not subject to the one-per-year limit.
          </p>
          <div className="bg-red-50 border border-red-200 rounded-lg p-4 text-sm text-red-900">
            <p className="font-semibold mb-1">Consequence of Violating the One-Per-Year Rule:</p>
            <p>If you attempt a second indirect rollover within 12 months, the second distribution is treated as a taxable distribution — not a rollover. It is subject to ordinary income tax and the 10% early withdrawal penalty (if under 59½). Additionally, if you deposit the funds into an IRA anyway, it may be treated as an excess contribution, subject to a 6% excise tax per year until corrected.</p>
          </div>
        </section>

        <section id="withholding" className="mb-12">
          <h2 className="text-2xl font-bold text-[#0F172A] mb-4">Mandatory 20% Withholding on Indirect Rollovers</h2>
          <p className="text-slate-600 leading-relaxed mb-4">
            When you take an indirect rollover from an employer-sponsored plan (401(k), 403(b), etc.), the plan administrator is <strong>required by law to withhold 20%</strong> of the distribution for federal income taxes. This withholding is not optional.
          </p>
          <div className="bg-slate-50 border border-slate-200 rounded-xl p-5 mb-4">
            <p className="font-semibold text-[#0F172A] mb-3">Example: The 20% Withholding Trap</p>
            <div className="text-sm text-slate-600 space-y-2">
              <p>You have $100,000 in a 401(k) and request an indirect rollover.</p>
              <p>The plan sends you a check for <strong>$80,000</strong> (withholds $20,000 for taxes).</p>
              <p>To complete a tax-free rollover, you must deposit <strong>the full $100,000</strong> into the new IRA within 60 days.</p>
              <p>This means you must come up with <strong>$20,000 from your own funds</strong> to make up the withheld amount.</p>
              <p>If you only deposit $80,000, the $20,000 withheld is treated as a taxable distribution — subject to income tax and potentially the 10% penalty.</p>
              <p className="font-semibold text-slate-700 mt-2">The withheld $20,000 will be credited against your tax liability when you file, but the distribution tax event has already occurred.</p>
            </div>
          </div>
          <p className="text-slate-600 leading-relaxed">
            This is one of the primary reasons financial professionals recommend direct trustee-to-trustee transfers over indirect rollovers whenever possible.
          </p>
        </section>

        <section id="eligible-sources" className="mb-12">
          <h2 className="text-2xl font-bold text-[#0F172A] mb-4">Eligible Rollover Sources</h2>
          <div className="overflow-x-auto mb-4">
            <table className="w-full text-sm border-collapse">
              <thead>
                <tr className="bg-slate-100">
                  <th className="text-left p-3 font-semibold text-slate-700 border border-slate-200">Source Account</th>
                  <th className="text-left p-3 font-semibold text-slate-700 border border-slate-200">Can Roll Into</th>
                  <th className="text-left p-3 font-semibold text-slate-700 border border-slate-200">Notes</th>
                </tr>
              </thead>
              <tbody>
                {[
                  ['Traditional IRA', 'Traditional IRA, Roth IRA (conversion), SEP-IRA, SIMPLE IRA (after 2 yrs), 401(k)', 'Roth conversion is taxable'],
                  ['Roth IRA', 'Roth IRA only', 'Cannot roll into Traditional IRA'],
                  ['401(k) (pre-tax)', 'Traditional IRA, Roth IRA (conversion), another 401(k)', 'Roth conversion is taxable'],
                  ['401(k) (Roth)', 'Roth IRA, designated Roth account in another plan', 'Tax-free if qualified'],
                  ['403(b)', 'Traditional IRA, Roth IRA (conversion), 401(k)', 'Same rules as 401(k)'],
                  ['457(b) (governmental)', 'Traditional IRA, Roth IRA (conversion), 401(k), 403(b)', 'No 10% penalty on distributions regardless of age'],
                  ['SEP-IRA', 'Traditional IRA, Roth IRA (conversion), 401(k)', 'Treated like Traditional IRA for rollover purposes'],
                  ['SIMPLE IRA', 'Traditional IRA, Roth IRA (conversion), 401(k) — but only after 2-year participation period', '2-year rule is critical'],
                ].map(([source, dest, notes]) => (
                  <tr key={source} className="border-b border-slate-100">
                    <td className="p-3 font-medium text-slate-700 border border-slate-200">{source}</td>
                    <td className="p-3 text-slate-600 border border-slate-200">{dest}</td>
                    <td className="p-3 text-slate-500 text-xs border border-slate-200">{notes}</td>
                  </tr>
                ))}
              </tbody>
            </table>
          </div>
        </section>

        <section id="sdira-rollover" className="mb-12">
          <h2 className="text-2xl font-bold text-[#0F172A] mb-4">Rollovers to a Self-Directed IRA (Crypto or Gold)</h2>
          <p className="text-slate-600 leading-relaxed mb-4">
            Rolling over funds into a self-directed IRA for the purpose of investing in cryptocurrency or precious metals follows the same IRS rollover rules as any other IRA. The rollover mechanics do not change — only the custodian and the investment options differ.
          </p>
          <p className="text-slate-600 leading-relaxed mb-4">
            Key additional considerations for SDIRA rollovers:
          </p>
          <ul className="list-disc list-inside text-slate-600 space-y-2 mb-4 ml-2">
            <li>The receiving custodian must be an IRS-qualified SDIRA custodian that supports your intended asset class</li>
            <li>Funds typically arrive in cash and are then used to purchase assets within the SDIRA — the rollover itself does not move crypto or metals</li>
            <li>Processing times for SDIRA account opening and asset purchase can be longer than standard IRAs — plan accordingly</li>
            <li>All rollover rules (60-day, one-per-year, withholding) apply equally to SDIRA rollovers</li>
          </ul>
          <div className="p-4 bg-indigo-50 border border-indigo-200 rounded-xl text-sm">
            <p className="font-semibold text-indigo-800 mb-2">Related Guides</p>
            <div className="flex flex-wrap gap-3">
              <Link to="/precious-metals-ira/401k-to-gold-ira-rollover" className="text-indigo-700 font-medium hover:underline text-xs">401(k) to Gold IRA Rollover Guide →</Link>
              <Link to="/crypto-ira/401k-to-crypto-ira-rollover" className="text-indigo-700 font-medium hover:underline text-xs">401(k) to Crypto IRA Rollover Guide →</Link>
            </div>
          </div>
        </section>

        <section id="mistakes" className="mb-12">
          <h2 className="text-2xl font-bold text-[#0F172A] mb-4">Common Mistakes and How to Avoid Them</h2>
          <div className="space-y-3">
            {[
              { mistake: 'Missing the 60-day deadline', fix: 'Use direct trustee-to-trustee transfers whenever possible. If you must do an indirect rollover, set a calendar reminder immediately upon receiving funds.' },
              { mistake: 'Attempting a second indirect rollover within 12 months', fix: 'Use direct transfers for all subsequent moves within the same 12-month period. Track your rollover history carefully.' },
              { mistake: 'Not making up the 20% withholding from personal funds', fix: 'Use direct transfers to avoid withholding entirely. If you receive a check, calculate the full pre-withholding amount and ensure you can fund the difference.' },
              { mistake: 'Rolling over required minimum distributions (RMDs)', fix: 'RMDs cannot be rolled over. If you are 73 or older, you must take your RMD before rolling over the remaining balance. Rolling over an RMD is treated as an excess contribution.' },
              { mistake: 'Rolling a Roth IRA into a Traditional IRA', fix: 'This is not permitted. Roth IRA funds can only be rolled into another Roth IRA.' },
              { mistake: 'Violating the 2-year SIMPLE IRA rule', fix: 'SIMPLE IRA funds cannot be rolled into a Traditional IRA or other plan until you have participated in the SIMPLE IRA for at least 2 years. Before 2 years, funds can only be rolled into another SIMPLE IRA.' },
            ].map((item, i) => (
              <div key={i} className="p-4 bg-white border border-slate-200 rounded-xl">
                <div className="flex gap-2 mb-2">
                  <span className="text-red-500 font-bold text-sm flex-shrink-0">✗ Mistake:</span>
                  <span className="font-medium text-slate-700 text-sm">{item.mistake}</span>
                </div>
                <div className="flex gap-2">
                  <span className="text-emerald-600 font-bold text-sm flex-shrink-0">✓ Fix:</span>
                  <span className="text-sm text-slate-600">{item.fix}</span>
                </div>
              </div>
            ))}
          </div>
        </section>

        {/* Sources */}
        <section id="sources" className="mb-12 pt-6 border-t border-slate-200">
          <h3 className="text-sm font-semibold text-slate-500 uppercase tracking-wider mb-3">Primary Sources & References</h3>
          <ul className="space-y-1.5 text-xs text-slate-500">
            <li><a href="https://www.irs.gov/publications/p590a" target="_blank" rel="noopener noreferrer" className="text-sky-600 hover:underline">IRS Publication 590-A: Contributions to Individual Retirement Arrangements</a></li>
            <li><a href="https://www.irs.gov/retirement-plans/rollovers-of-retirement-plan-and-ira-distributions" target="_blank" rel="noopener noreferrer" className="text-sky-600 hover:underline">IRS: Rollovers of Retirement Plan and IRA Distributions</a></li>
            <li><a href="https://www.irs.gov/irb/2014-21_IRB#ANN-2014-15" target="_blank" rel="noopener noreferrer" className="text-sky-600 hover:underline">IRS Announcement 2014-15: One-Rollover-Per-Year Rule</a></li>
            <li><a href="https://www.irs.gov/retirement-plans/plan-participant-employee/rollovers-of-after-tax-contributions-in-retirement-plans" target="_blank" rel="noopener noreferrer" className="text-sky-600 hover:underline">IRS: Rollovers of After-Tax Contributions in Retirement Plans</a></li>
          </ul>
        </section>

        {/* Risk Disclaimer */}
        <div className="mt-8 p-5 bg-amber-50 border border-amber-200 rounded-lg text-sm text-amber-900">
          <p className="font-semibold mb-1">Important Disclaimer</p>
          <p>This page is for informational and educational purposes only and does not constitute financial, investment, tax, or legal advice. IRA rollover rules are complex and violations can result in significant tax consequences. Always consult a qualified tax professional or financial advisor before executing a rollover. <Link to="/editorial-policy" className="underline font-medium">See our Editorial Policy</Link> for full disclosure.</p>
        </div>
      </div>
      {/* ── Newsletter Signup ─────────────────────────────────────────── */}
      <div className="container-site py-10 max-w-3xl">
        
        {/* Related Links */}

        <div className="mt-10 mb-6">

          <RelatedLinks variant="crypto-guide" title="Related Guides &amp; Reviews" />

        </div>
<NewsletterSignup />
      </div>
    </>
  )
}
