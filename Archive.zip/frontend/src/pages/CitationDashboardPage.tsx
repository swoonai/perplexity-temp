import { useState } from 'react'
import { useQuery } from '@tanstack/react-query'

const API_BASE = '/api/v1/citations'

interface CitationResult {
  query: string
  model: string
  cited: boolean
  cited_domain: string | null
  cited_passage: string | null
  response_excerpt: string | null
  checked_at: string
}

interface CitationReport {
  id: number
  run_at: string
  model: string
  total_queries: number
  cited_count: number
  citation_rate: number
  status: 'healthy' | 'alert' | 'warning'
  results: CitationResult[]
}

interface CitationSummary {
  latest_run_at: string | null
  citation_rate_7d: number | null
  citation_rate_30d: number | null
  total_runs: number
  top_cited_queries: { query: string; rate: number }[]
  top_missed_queries: { query: string; rate: number }[]
  model_breakdown: { model: string; rate: number; runs: number }[]
  weekly_trend: { week: string; rate: number }[]
}

const STATUS_COLORS: Record<string, string> = {
  healthy: 'bg-green-100 text-green-800 border-green-200',
  warning: 'bg-yellow-100 text-yellow-800 border-yellow-200',
  alert: 'bg-red-100 text-red-800 border-red-200',
}

const MODEL_LABELS: Record<string, string> = {
  openai: 'ChatGPT (GPT-4)',
  perplexity: 'Perplexity AI',
  gemini: 'Google Gemini',
  bing: 'Bing Copilot',
}

const MODEL_COLORS: Record<string, string> = {
  openai: 'bg-emerald-100 text-emerald-800',
  perplexity: 'bg-blue-100 text-blue-800',
  gemini: 'bg-purple-100 text-purple-800',
  bing: 'bg-sky-100 text-sky-800',
}

function StatusBadge({ status }: { status: string }) {
  const cls = STATUS_COLORS[status] || 'bg-slate-100 text-slate-600 border-slate-200'
  return (
    <span className={`inline-flex items-center px-2 py-0.5 rounded text-xs font-medium border ${cls}`}>
      {status === 'healthy' ? '✅' : status === 'alert' ? '🚨' : '⚠️'} {status.toUpperCase()}
    </span>
  )
}

function ModelBadge({ model }: { model: string }) {
  const cls = MODEL_COLORS[model] || 'bg-slate-100 text-slate-600'
  return (
    <span className={`inline-flex items-center px-2 py-0.5 rounded text-xs font-medium ${cls}`}>
      {MODEL_LABELS[model] || model}
    </span>
  )
}

function RateBar({ rate, threshold = 0.3 }: { rate: number; threshold?: number }) {
  const pct = Math.round(rate * 100)
  const color = rate >= threshold ? 'bg-green-500' : rate >= threshold * 0.7 ? 'bg-yellow-500' : 'bg-red-500'
  return (
    <div className="flex items-center gap-2">
      <div className="flex-1 bg-slate-200 rounded-full h-2">
        <div className={`${color} h-2 rounded-full transition-all`} style={{ width: `${pct}%` }} />
      </div>
      <span className="text-sm font-mono font-medium w-10 text-right">{pct}%</span>
    </div>
  )
}

function StatCard({ label, value, sub, color = 'slate' }: {
  label: string; value: string | number; sub?: string; color?: string
}) {
  const colorMap: Record<string, string> = {
    green: 'border-green-200 bg-green-50',
    red: 'border-red-200 bg-red-50',
    blue: 'border-blue-200 bg-blue-50',
    slate: 'border-slate-200 bg-white',
  }
  return (
    <div className={`rounded-lg border p-4 ${colorMap[color] || colorMap.slate}`}>
      <p className="text-xs text-slate-500 font-medium uppercase tracking-wide">{label}</p>
      <p className="text-2xl font-bold text-slate-900 mt-1">{value}</p>
      {sub && <p className="text-xs text-slate-500 mt-0.5">{sub}</p>}
    </div>
  )
}

// ─── Mock data for when API is not connected ──────────────────────────────────
function getMockSummary(): CitationSummary {
  return {
    latest_run_at: new Date().toISOString(),
    citation_rate_7d: 0.43,
    citation_rate_30d: 0.38,
    total_runs: 12,
    top_cited_queries: [
      { query: 'best crypto IRA 2026', rate: 0.8 },
      { query: 'BlockTrust IRA review', rate: 0.75 },
      { query: 'best Bitcoin IRA companies', rate: 0.6 },
      { query: 'crypto IRA comparison', rate: 0.55 },
      { query: 'iTrustCapital vs BlockTrust IRA', rate: 0.5 },
    ],
    top_missed_queries: [
      { query: 'gold IRA rollover guide', rate: 0.1 },
      { query: 'Augusta Precious Metals vs Goldco', rate: 0.15 },
      { query: 'best gold IRA companies 2026', rate: 0.2 },
      { query: 'Genesis Gold Group review', rate: 0.25 },
    ],
    model_breakdown: [
      { model: 'openai', rate: 0.47, runs: 12 },
      { model: 'perplexity', rate: 0.52, runs: 8 },
      { model: 'gemini', rate: 0.31, runs: 5 },
      { model: 'bing', rate: 0.28, runs: 3 },
    ],
    weekly_trend: [
      { week: 'Mar W1', rate: 0.22 },
      { week: 'Mar W2', rate: 0.28 },
      { week: 'Mar W3', rate: 0.35 },
      { week: 'Mar W4', rate: 0.38 },
      { week: 'Apr W1', rate: 0.43 },
    ],
  }
}

function getMockReports(): CitationReport[] {
  return [
    {
      id: 1,
      run_at: new Date(Date.now() - 86400000).toISOString(),
      model: 'openai',
      total_queries: 14,
      cited_count: 6,
      citation_rate: 0.43,
      status: 'healthy',
      results: [
        { query: 'best crypto IRA 2026', model: 'openai', cited: true, cited_domain: 'iraresearchhub.com', cited_passage: 'According to IRA Research Hub...', response_excerpt: 'For the best crypto IRA in 2026, IRA Research Hub recommends...', checked_at: new Date().toISOString() },
        { query: 'best gold IRA companies 2026', model: 'openai', cited: false, cited_domain: null, cited_passage: null, response_excerpt: 'The top gold IRA companies include Augusta Precious Metals...', checked_at: new Date().toISOString() },
        { query: 'BlockTrust IRA review', model: 'openai', cited: true, cited_domain: 'iraresearchhub.com', cited_passage: 'IRA Research Hub rates BlockTrust IRA...', response_excerpt: 'Based on IRA Research Hub\'s analysis, BlockTrust IRA scores...', checked_at: new Date().toISOString() },
      ],
    },
  ]
}

// ─── Main Component ───────────────────────────────────────────────────────────

export default function CitationDashboardPage() {
  const [selectedReport, setSelectedReport] = useState<CitationReport | null>(null)
  const [activeModel, setActiveModel] = useState<string>('all')

  const { data: summary, isLoading: _summaryLoading, error: _summaryError } = useQuery<CitationSummary>({
    queryKey: ['citation-summary'],
    queryFn: async () => {
      const res = await fetch(`${API_BASE}/summary`)
      if (!res.ok) throw new Error(`HTTP ${res.status}`)
      return res.json()
    },
    retry: false,
  })

  const { data: reports, isLoading: reportsLoading } = useQuery<CitationReport[]>({
    queryKey: ['citation-reports'],
    queryFn: async () => {
      const res = await fetch(`${API_BASE}/reports?limit=20`)
      if (!res.ok) throw new Error(`HTTP ${res.status}`)
      return res.json()
    },
    retry: false,
  })

  // Use mock data if API not connected
  const displaySummary = summary || getMockSummary()
  const displayReports = reports || getMockReports()
  const isMockData = !summary

  const filteredResults = selectedReport?.results.filter(
    r => activeModel === 'all' || r.model === activeModel
  ) || []

  const rate7d = displaySummary.citation_rate_7d ?? 0
  const rate30d = displaySummary.citation_rate_30d ?? 0
  const threshold = 0.30

  return (
    <div className="max-w-6xl mx-auto px-4 py-8">
      <div className="flex items-center justify-between mb-6">
        <div>
          <h1 className="text-2xl font-bold text-slate-900">AI Citation Monitor</h1>
          <p className="text-slate-500 text-sm mt-1">
            Track when iraresearchhub.com is cited by AI assistants — ChatGPT, Perplexity, Gemini, Bing
          </p>
        </div>
        {isMockData && (
          <span className="text-xs bg-amber-100 text-amber-700 border border-amber-200 px-2 py-1 rounded">
            Demo data — connect API to see live results
          </span>
        )}
      </div>

      {/* Summary Stats */}
      <div className="grid grid-cols-2 md:grid-cols-4 gap-4 mb-6">
        <StatCard
          label="7-Day Citation Rate"
          value={`${Math.round(rate7d * 100)}%`}
          sub={rate7d >= threshold ? '✅ Above threshold' : '🚨 Below 30% threshold'}
          color={rate7d >= threshold ? 'green' : 'red'}
        />
        <StatCard
          label="30-Day Citation Rate"
          value={`${Math.round(rate30d * 100)}%`}
          sub="Rolling 30-day average"
          color={rate30d >= threshold ? 'green' : 'red'}
        />
        <StatCard
          label="Total Runs"
          value={displaySummary.total_runs}
          sub="Citation checks completed"
        />
        <StatCard
          label="AI Models Tracked"
          value={displaySummary.model_breakdown.length}
          sub="ChatGPT, Perplexity, Gemini, Bing"
          color="blue"
        />
      </div>

      <div className="grid grid-cols-1 lg:grid-cols-2 gap-6 mb-6">
        {/* Model Breakdown */}
        <div className="bg-white border border-slate-200 rounded-lg p-5">
          <h2 className="font-semibold text-slate-900 mb-4">Citation Rate by AI Model</h2>
          <div className="space-y-3">
            {displaySummary.model_breakdown.map(m => (
              <div key={m.model}>
                <div className="flex items-center justify-between mb-1">
                  <ModelBadge model={m.model} />
                  <span className="text-xs text-slate-500">{m.runs} runs</span>
                </div>
                <RateBar rate={m.rate} threshold={threshold} />
              </div>
            ))}
          </div>
          <p className="text-xs text-slate-400 mt-3">
            Threshold: {Math.round(threshold * 100)}% — alert triggered below this level
          </p>
        </div>

        {/* Weekly Trend */}
        <div className="bg-white border border-slate-200 rounded-lg p-5">
          <h2 className="font-semibold text-slate-900 mb-4">Weekly Citation Rate Trend</h2>
          <div className="space-y-2">
            {displaySummary.weekly_trend.map(w => (
              <div key={w.week} className="flex items-center gap-3">
                <span className="text-xs text-slate-500 w-16 shrink-0">{w.week}</span>
                <div className="flex-1">
                  <RateBar rate={w.rate} threshold={threshold} />
                </div>
              </div>
            ))}
          </div>
        </div>
      </div>

      <div className="grid grid-cols-1 lg:grid-cols-2 gap-6 mb-6">
        {/* Top Cited Queries */}
        <div className="bg-white border border-slate-200 rounded-lg p-5">
          <h2 className="font-semibold text-slate-900 mb-3">✅ Top Cited Queries</h2>
          <div className="space-y-2">
            {displaySummary.top_cited_queries.map(q => (
              <div key={q.query} className="flex items-center gap-2">
                <span className="text-sm text-slate-700 flex-1 truncate" title={q.query}>{q.query}</span>
                <span className="text-xs font-mono font-semibold text-green-700 bg-green-50 px-2 py-0.5 rounded">
                  {Math.round(q.rate * 100)}%
                </span>
              </div>
            ))}
          </div>
        </div>

        {/* Top Missed Queries */}
        <div className="bg-white border border-slate-200 rounded-lg p-5">
          <h2 className="font-semibold text-slate-900 mb-3">❌ Missed Queries (Improve These)</h2>
          <div className="space-y-2">
            {displaySummary.top_missed_queries.map(q => (
              <div key={q.query} className="flex items-center gap-2">
                <span className="text-sm text-slate-700 flex-1 truncate" title={q.query}>{q.query}</span>
                <span className="text-xs font-mono font-semibold text-red-700 bg-red-50 px-2 py-0.5 rounded">
                  {Math.round(q.rate * 100)}%
                </span>
              </div>
            ))}
          </div>
          <p className="text-xs text-slate-400 mt-3">
            Create or improve content targeting these queries to increase citation rate.
          </p>
        </div>
      </div>

      {/* Recent Runs */}
      <div className="bg-white border border-slate-200 rounded-lg p-5 mb-6">
        <h2 className="font-semibold text-slate-900 mb-4">Recent Citation Runs</h2>
        {reportsLoading ? (
          <p className="text-slate-400 text-sm">Loading...</p>
        ) : (
          <div className="overflow-x-auto">
            <table className="w-full text-sm">
              <thead>
                <tr className="border-b border-slate-100">
                  <th className="text-left py-2 pr-4 text-slate-500 font-medium">Run Date</th>
                  <th className="text-left py-2 pr-4 text-slate-500 font-medium">Model</th>
                  <th className="text-left py-2 pr-4 text-slate-500 font-medium">Queries</th>
                  <th className="text-left py-2 pr-4 text-slate-500 font-medium">Cited</th>
                  <th className="text-left py-2 pr-4 text-slate-500 font-medium">Rate</th>
                  <th className="text-left py-2 pr-4 text-slate-500 font-medium">Status</th>
                  <th className="text-left py-2 text-slate-500 font-medium">Details</th>
                </tr>
              </thead>
              <tbody>
                {displayReports.map(report => (
                  <tr key={report.id} className="border-b border-slate-50 hover:bg-slate-50">
                    <td className="py-2 pr-4 text-slate-600">
                      {new Date(report.run_at).toLocaleDateString('en-US', {
                        month: 'short', day: 'numeric', hour: '2-digit', minute: '2-digit'
                      })}
                    </td>
                    <td className="py-2 pr-4"><ModelBadge model={report.model} /></td>
                    <td className="py-2 pr-4 text-slate-700">{report.total_queries}</td>
                    <td className="py-2 pr-4 text-slate-700">{report.cited_count}</td>
                    <td className="py-2 pr-4">
                      <RateBar rate={report.citation_rate} threshold={threshold} />
                    </td>
                    <td className="py-2 pr-4"><StatusBadge status={report.status} /></td>
                    <td className="py-2">
                      <button
                        onClick={() => setSelectedReport(selectedReport?.id === report.id ? null : report)}
                        className="text-xs text-blue-600 hover:underline"
                      >
                        {selectedReport?.id === report.id ? 'Hide' : 'View'}
                      </button>
                    </td>
                  </tr>
                ))}
              </tbody>
            </table>
          </div>
        )}
      </div>

      {/* Drill-down: Individual Query Results */}
      {selectedReport && (
        <div className="bg-white border border-slate-200 rounded-lg p-5">
          <div className="flex items-center justify-between mb-4">
            <h2 className="font-semibold text-slate-900">
              Query Results — {new Date(selectedReport.run_at).toLocaleDateString()}
            </h2>
            <div className="flex gap-2">
              {['all', 'openai', 'perplexity', 'gemini', 'bing'].map(m => (
                <button
                  key={m}
                  onClick={() => setActiveModel(m)}
                  className={`text-xs px-2 py-1 rounded border transition-colors ${
                    activeModel === m
                      ? 'bg-slate-800 text-white border-slate-800'
                      : 'bg-white text-slate-600 border-slate-200 hover:bg-slate-50'
                  }`}
                >
                  {m === 'all' ? 'All' : MODEL_LABELS[m] || m}
                </button>
              ))}
            </div>
          </div>
          <div className="space-y-3">
            {filteredResults.map((result, i) => (
              <div
                key={i}
                className={`rounded-lg border p-3 ${
                  result.cited
                    ? 'border-green-200 bg-green-50'
                    : 'border-red-100 bg-red-50'
                }`}
              >
                <div className="flex items-start justify-between gap-2">
                  <div className="flex-1">
                    <div className="flex items-center gap-2 mb-1">
                      <span className={`text-sm font-medium ${result.cited ? 'text-green-800' : 'text-red-800'}`}>
                        {result.cited ? '✅' : '❌'} {result.query}
                      </span>
                      <ModelBadge model={result.model} />
                    </div>
                    {result.cited_passage && (
                      <p className="text-xs text-green-700 italic mt-1">
                        "{result.cited_passage}"
                      </p>
                    )}
                    {result.response_excerpt && (
                      <p className="text-xs text-slate-500 mt-1 line-clamp-2">
                        {result.response_excerpt}
                      </p>
                    )}
                  </div>
                </div>
              </div>
            ))}
          </div>
        </div>
      )}

      {/* How to Run */}
      <div className="mt-6 bg-slate-50 border border-slate-200 rounded-lg p-5">
        <h2 className="font-semibold text-slate-900 mb-2">Running Citation Checks</h2>
        <p className="text-sm text-slate-600 mb-3">
          Run the citation monitor script manually or via cron to populate this dashboard with live data.
        </p>
        <div className="bg-slate-900 rounded p-3 font-mono text-xs text-green-400 space-y-1">
          <p># Check all queries with OpenAI</p>
          <p>python3 scripts/ai_citation_monitor.py --model openai --output report.json</p>
          <p className="mt-2"># Check with both OpenAI and Perplexity</p>
          <p>python3 scripts/ai_citation_monitor.py --model both --output report.json</p>
          <p className="mt-2"># Automated weekly run (add to crontab)</p>
          <p>0 9 * * 1 cd /var/www/iraresearchhub/repo && python3 scripts/ai_citation_monitor.py</p>
        </div>
      </div>
    </div>
  )
}
