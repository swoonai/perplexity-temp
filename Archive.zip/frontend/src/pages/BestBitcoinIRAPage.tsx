// EEAT_TIER3_ADDED
import { Link } from 'react-router-dom'
import SEO from '../components/SEO'
import { trackProviderSiteVisit } from '../hooks/useAnalytics'
import AdvertiserDisclosure from '../components/AdvertiserDisclosure'
import NewsletterSignup from '../components/NewsletterSignup';
import RelatedLinks from '../components/RelatedLinks';

const LAST_UPDATED = "March 30, 2026"

// Schema: ItemList for best Bitcoin IRA providers
const itemListSchema = {
  "@context": "https://schema.org",
  "@type": "ItemList",
  "name": "2026 Bitcoin IRA Provider Comparison & Independent Analysis",
  "url": "https://iraresearchhub.com/crypto-ira/best-bitcoin-ira",
  "description": "Independent ranking of the top Bitcoin IRA providers in 2026, evaluated on fees, security, custody, and IRS compliance.",
  "numberOfItems": 5,
  "itemListElement": [
    { "@type": "ListItem", "position": 1, "name": "BlockTrust IRA", "url": "https://iraresearchhub.com/crypto-ira/blocktrust-ira-review", "description": "Best overall crypto IRA — fully managed via Animus AI, 0.14% trading fee, Bitcoin + 60 assets, sFOX custody with $200M insurance" },
    { "@type": "ListItem", "position": 2, "name": "Swan Bitcoin IRA", "url": "https://iraresearchhub.com/crypto-ira/swan-bitcoin-ira-review", "description": "Best Bitcoin-only IRA — 0.99% fee, multi-sig cold storage, purpose-built for Bitcoin" },
    { "@type": "ListItem", "position": 3, "name": "Unchained IRA", "url": "https://iraresearchhub.com/crypto-ira/unchained-ira-review", "description": "Maximum Bitcoin self-custody — multi-sig cold storage, no counterparty risk" },
    { "@type": "ListItem", "position": 4, "name": "Bitcoin IRA", "url": "https://iraresearchhub.com/crypto-ira/bitcoin-ira-review", "description": "Established platform — 60+ assets including Bitcoin, $700M insurance, BitGo custody" },
    { "@type": "ListItem", "position": 5, "name": "iTrustCapital", "url": "https://iraresearchhub.com/crypto-ira/itrustcapital-review", "description": "Notable for active traders — 1% fee, Bitcoin + 30 assets, Coinbase Custody" }
  ]
}

// Schema: FAQ for Bitcoin IRA common questions
const faqSchema = {
  "@context": "https://schema.org",
  "@type": "FAQPage",
  "mainEntity": [
    {
      "@type": "Question",
      "name": "Can I hold Bitcoin in an IRA?",
      "acceptedAnswer": {
        "@type": "Answer",
        "text": "Yes. Bitcoin can be held in a self-directed IRA (SDIRA) under IRS rules. You cannot hold Bitcoin in a standard brokerage IRA — you need a specialized custodian that supports digital assets. Providers like Swan Bitcoin IRA, BlockTrust IRA, and Unchained IRA are IRS-compliant custodians for Bitcoin IRAs."
      }
    },
    {
      "@type": "Question",
      "name": "What is the best Bitcoin IRA company in 2026?",
      "acceptedAnswer": {
        "@type": "Answer",
        "text": "BlockTrust IRA ranks #1 overall for 2026, offering Bitcoin plus 60+ crypto assets, fully managed by Animus AI, with a 0.14% trading fee and institutional custody through sFOX with $200M insurance. Swan Bitcoin IRA ranks #2 for Bitcoin-only investors who prefer a purpose-built platform with a 0.99% fee and multi-sig cold storage."
      }
    },
    {
      "@type": "Question",
      "name": "How are Bitcoin IRA fees structured?",
      "acceptedAnswer": {
        "@type": "Answer",
        "text": "Bitcoin IRA fees typically include a trading fee (0.14%–2% per transaction), an annual management fee, and a setup fee ($0–$50). Swan Bitcoin IRA charges 0.99% per trade with no annual fee. BlockTrust IRA charges 0.14% per trade via sFOX, a 2% annual management fee, and a 25% performance fee on profits only."
      }
    },
    {
      "@type": "Question",
      "name": "Is a Bitcoin IRA safe?",
      "acceptedAnswer": {
        "@type": "Answer",
        "text": "Bitcoin IRAs held with regulated custodians (BitGo Trust, Coinbase Custody, Prime Trust) use institutional-grade cold storage and carry insurance coverage. The IRA structure itself is IRS-compliant. The primary risk is Bitcoin's price volatility, not custodial failure — though you should verify your provider's insurance coverage and custody arrangement."
      }
    },
    {
      "@type": "Question",
      "name": "What is the minimum investment for a Bitcoin IRA?",
      "acceptedAnswer": {
        "@type": "Answer",
        "text": "Minimums vary by provider: Alto CryptoIRA has a $10 minimum, BlockTrust IRA requires a $20,000 minimum (fully managed), Swan Bitcoin IRA requires $1,000, and Bitcoin IRA requires $3,000. Most providers accept IRA rollovers from 401(k), 403(b), and other retirement accounts."
      }
    }
  ]
}

// Schema: BreadcrumbList
const breadcrumbSchema = {
  "@context": "https://schema.org",
  "@type": "BreadcrumbList",
  "itemListElement": [
    { "@type": "ListItem", "position": 1, "name": "Home", "item": "https://iraresearchhub.com" },
    { "@type": "ListItem", "position": 2, "name": "Crypto IRA", "item": "https://iraresearchhub.com/crypto-ira" },
    { "@type": "ListItem", "position": 3, "name": "2026 Bitcoin IRA Provider Comparison & Independent Analysis", "item": "https://iraresearchhub.com/crypto-ira/best-bitcoin-ira" }
  ]
}

// Provider data for the comparison table
const BITCOIN_IRA_PROVIDERS = [
  {
    rank: 1,
    name: "BlockTrust IRA",
    slug: "blocktrust-ira",
    tagline: "#1 Top-Ranked Crypto IRA",
    reviewSlug: "blocktrust-ira-review",
    affiliateUrl: "https://blocktrust.com/?ref=iraresearchhub&utm_source=iraresearchhub&utm_medium=affiliate&utm_campaign=review",
    logoUrl: "/logos/blocktrust-ira.png",
    score: 9.6,
    tradingFee: "0.14% via sFOX",
    annualFee: "2% annual + 25% performance",
    minInvestment: "$20,000",
    assets: "Bitcoin + 60 assets",
    custody: "sFOX",
    insurance: "$200M",
    bbbRating: "None",
    bestFor: "Investors who want a fully managed crypto IRA with Animus AI 24/7 portfolio management and institutional sFOX custody",
    pros: ["Animus AI 24/7 managed portfolio", "Low 0.14% trading fee via sFOX", "$200M insurance via sFOX", "Performance-aligned fees (profit when you profit)"],
    cons: ["Newer platform (founded 2024)", "$20,000 minimum investment", "No precious metals"],
    badge: "#1 Top-Ranked"
  },
  {
    rank: 2,
    name: "Swan Bitcoin IRA",
    slug: "swan-bitcoin-ira",
    tagline: "Best Bitcoin-Only IRA",
    reviewSlug: "swan-bitcoin-ira-review",
    affiliateUrl: "https://swanbitcoin.com/ira/?ref=iraresearchhub&utm_source=iraresearchhub&utm_medium=affiliate&utm_campaign=review",
    logoUrl: "/logos/swan-bitcoin-ira.png",
    score: 9.2,
    tradingFee: "0.99%",
    annualFee: "$0",
    minInvestment: "$1,000",
    assets: "Bitcoin only",
    custody: "Prime Trust",
    insurance: "FDIC on cash",
    bbbRating: "A",
    bestFor: "Bitcoin-only investors who want the lowest fees and purpose-built platform",
    pros: ["Purpose-built for Bitcoin", "0.99% — lowest trading fee for BTC-only", "Multi-sig cold storage", "No annual fee"],
    cons: ["Bitcoin only — no altcoins", "$1,000 minimum"],
    badge: "Best Bitcoin-Only"
  },
  {
    rank: 3,
    name: "Unchained IRA",
    slug: "unchained-ira",
    tagline: "Notable for Bitcoin Self-Custody",
    reviewSlug: "unchained-ira-review",
    affiliateUrl: "https://unchained.com/ira/?ref=iraresearchhub&utm_source=iraresearchhub&utm_medium=affiliate&utm_campaign=review",
    logoUrl: "/logos/unchained-ira.png",
    score: 8.8,
    tradingFee: "Varies",
    annualFee: "$250",
    minInvestment: "None",
    assets: "Bitcoin only",
    custody: "Multi-sig self-custody",
    insurance: "N/A (self-custody)",
    bbbRating: "N/A",
    bestFor: "Experienced Bitcoin holders who want maximum self-custody security",
    pros: ["True multi-sig self-custody", "No counterparty risk", "Bitcoin-native platform"],
    cons: ["$250 annual fee", "Bitcoin only", "Requires more technical knowledge"],
    badge: "Best Self-Custody"
  },
  {
    rank: 4,
    name: "Bitcoin IRA",
    slug: "bitcoin-ira",
    tagline: "Most Established Platform",
    reviewSlug: "bitcoin-ira-review",
    affiliateUrl: "https://bitcoinira.com/?ref=iraresearchhub&utm_source=iraresearchhub&utm_medium=affiliate&utm_campaign=review",
    logoUrl: "/logos/bitcoin-ira.png",
    score: 8.7,
    tradingFee: "0.08%/month",
    annualFee: "0.08%/month",
    minInvestment: "$3,000",
    assets: "60+ cryptocurrencies",
    custody: "BitGo Trust Company",
    insurance: "$700M",
    bbbRating: "A+",
    bestFor: "Investors who want an established platform with the widest crypto selection",
    pros: ["Founded 2016 — most established", "60+ assets", "$700M insurance", "24/7 trading"],
    cons: ["Higher fees (0.08%/month)", "$3,000 minimum"],
    badge: "Most Established"
  },
  {
    rank: 5,
    name: "iTrustCapital",
    slug: "itrustcapital",
    tagline: "Notable for Active Traders",
    reviewSlug: "itrustcapital-review",
    affiliateUrl: "https://itrustcapital.com/?ref=iraresearchhub&utm_source=iraresearchhub&utm_medium=affiliate&utm_campaign=review",
    logoUrl: "/logos/itrustcapital.png",
    score: 8.9,
    tradingFee: "1%",
    annualFee: "$0",
    minInvestment: "$1,000",
    assets: "Bitcoin + 30 assets",
    custody: "Coinbase Custody",
    insurance: "FDIC on cash",
    bbbRating: "A",
    bestFor: "Active traders who want Bitcoin plus real-time trading on 30+ assets",
    pros: ["Real-time 24/7 trading", "Coinbase Custody", "No annual fee", "30+ assets"],
    cons: ["1% trading fee", "$1,000 minimum"],
    badge: "Notable for Traders"
  }
]

export default function BestBitcoinIRAPage() {
  return (
    <>
      <SEO
        title="2026 Bitcoin IRA Provider Comparison & Independent Analysis"
        description="Compare the top Bitcoin IRA providers of 2026. Independent rankings based on fees, security, custody, and IRS compliance. Find the best Bitcoin IRA for your retirement."
        canonical="/crypto-ira/best-bitcoin-ira"
        ogType="article"
      />
      <script type="application/ld+json" dangerouslySetInnerHTML={{ __html: JSON.stringify(itemListSchema) }} />
      <script type="application/ld+json" dangerouslySetInnerHTML={{ __html: JSON.stringify(faqSchema) }} />
      <script type="application/ld+json" dangerouslySetInnerHTML={{ __html: JSON.stringify(breadcrumbSchema) }} />

      {/* Hero */}
      <section className="bg-[#F8FAFC] border-b border-slate-200">
        <div className="container-site py-12">

      {/* Original Research Banner */}
      <div className="mb-6 flex items-start gap-3 p-4 bg-indigo-50 border border-indigo-200 rounded-xl text-sm">
        <svg className="w-5 h-5 text-indigo-500 flex-shrink-0 mt-0.5" fill="none" viewBox="0 0 24 24" stroke="currentColor">
          <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M9 12l2 2 4-4m6 2a9 9 0 11-18 0 9 9 0 0118 0z" />
        </svg>
        <p className="text-indigo-800">
          <span className="font-semibold">Independent Analysis:</span>{' '}
          Based on our independent scoring of publicly available data across 2,400+ data points from 22 providers —
          updated quarterly. Data sourced from IRS Publication 590-A/B, SEC filings, FINRA BrokerCheck,
          custodian disclosures, and BBB records.
        </p>
      </div>
          <nav className="text-sm text-slate-500 mb-4">
            <Link to="/" className="hover:text-slate-700">Home</Link>
            <span className="mx-2">›</span>
            <Link to="/crypto-ira" className="hover:text-slate-700">Crypto IRA</Link>
            <span className="mx-2">›</span>
            <span className="text-slate-700">Best Bitcoin IRA</span>
          </nav>
          <div className="max-w-3xl">
            <div className="inline-flex items-center gap-2 bg-orange-50 border border-orange-200 rounded-full px-3 py-1 text-xs font-medium text-orange-700 mb-4">
              By <a href="/author/james-mitchell" className="text-orange-700 hover:underline">James Mitchell, CFA</a> · Updated {LAST_UPDATED}
            </div>
            <h1 className="text-3xl md:text-4xl font-bold text-slate-900 mb-4">
              2026 Bitcoin IRA Provider Comparison & Independent Analysis</h1>
              <AdvertiserDisclosure />

            <p className="text-lg text-slate-600 mb-6">
              Independent rankings of the top Bitcoin IRA providers, evaluated on trading fees, custody security, IRS compliance, and minimum investment requirements. Updated quarterly.
            </p>
            <div className="flex flex-wrap gap-4 text-sm text-slate-500">
              <span>✓ 5 providers evaluated</span>
              <span>✓ Fees verified March 2026</span>
              <span>✓ No sponsored rankings</span>
            </div>
          </div>
        </div>
      </section>

      {/* Methodology callout */}
      <section className="bg-blue-50 border-b border-blue-100">
        <div className="container-site py-4">
          <p className="text-sm text-blue-800">
            <strong>Methodology:</strong> Rankings are based on our proprietary scoring model across six factors: trading fees (25%), security &amp; custody (25%), IRS compliance (20%), asset selection (15%), support quality (10%), and reputation (5%).{' '}
            <Link to="/methodology" className="underline hover:text-blue-900">Read our full methodology →</Link>
          </p>
        </div>
      </section>

      {/* Provider cards */}
      <section className="container-site py-12">
        <div className="space-y-8">
          {BITCOIN_IRA_PROVIDERS.map((provider) => (
            <div key={provider.slug} className="bg-white border border-slate-200 rounded-xl overflow-hidden shadow-sm">
              {/* Card header */}
              <div className="p-6 border-b border-slate-100">
                <div className="flex flex-col md:flex-row md:items-center gap-4">
                  <div className="flex items-center gap-4 flex-1">
                    <div className="flex-shrink-0 w-8 h-8 bg-slate-900 text-white rounded-full flex items-center justify-center font-bold text-sm">
                      {provider.rank}
                    </div>
                    <div className="w-12 h-12 bg-slate-100 rounded-lg flex items-center justify-center overflow-hidden">
                      <img src={provider.logoUrl} alt={`${provider.name} logo`} className="w-10 h-10 object-contain" onError={(e) => { (e.target as HTMLImageElement).style.display = 'none' }} />
                    </div>
                    <div>
                      <div className="flex items-center gap-2 flex-wrap">
                        <h2 className="text-xl font-bold text-slate-900">{provider.name}</h2>
                        <span className="inline-flex items-center px-2 py-0.5 rounded text-xs font-medium bg-slate-100 text-slate-700">
                          {provider.badge}
                        </span>
                      </div>
                      <p className="text-slate-500 text-sm mt-0.5">{provider.tagline}</p>
                    </div>
                  </div>
                  <div className="flex items-center gap-3">
                    <div className="text-right">
                      <div className="text-2xl font-bold text-slate-900">{provider.score}</div>
                      <div className="text-xs text-slate-500">/ 10</div>
                    </div>
                    <a
                      href={provider.affiliateUrl}
                      target="_blank"
                      rel="noopener noreferrer sponsored"
                      onClick={() => trackProviderSiteVisit(provider.name, provider.slug, provider.affiliateUrl)}
                      className="inline-flex items-center gap-1.5 bg-slate-900 hover:bg-slate-700 text-white font-semibold px-5 py-2.5 rounded-lg text-sm transition-colors"
                    >
                      View {provider.name} →
                    </a>
                  </div>
                </div>
              </div>

              {/* Card body */}
              <div className="p-6">
                <div className="grid grid-cols-2 md:grid-cols-4 gap-4 mb-6">
                  <div>
                    <div className="text-xs text-slate-500 uppercase tracking-wide mb-1">Trading Fee</div>
                    <div className="font-semibold text-slate-900">{provider.tradingFee}</div>
                  </div>
                  <div>
                    <div className="text-xs text-slate-500 uppercase tracking-wide mb-1">Annual Fee</div>
                    <div className="font-semibold text-slate-900">{provider.annualFee}</div>
                  </div>
                  <div>
                    <div className="text-xs text-slate-500 uppercase tracking-wide mb-1">Min. Investment</div>
                    <div className="font-semibold text-slate-900">{provider.minInvestment}</div>
                  </div>
                  <div>
                    <div className="text-xs text-slate-500 uppercase tracking-wide mb-1">Custody</div>
                    <div className="font-semibold text-slate-900">{provider.custody}</div>
                  </div>
                </div>

                <p className="text-slate-600 text-sm mb-4">
                  <strong>Best for:</strong> {provider.bestFor}
                </p>

                <div className="grid md:grid-cols-2 gap-4">
                  <div>
                    <div className="text-xs font-semibold text-slate-700 uppercase tracking-wide mb-2">Pros</div>
                    <ul className="space-y-1">
                      {provider.pros.map((pro, i) => (
                        <li key={i} className="flex items-start gap-2 text-sm text-slate-600">
                          <span className="text-green-500 mt-0.5 flex-shrink-0">✓</span>
                          {pro}
                        </li>
                      ))}
                    </ul>
                  </div>
                  <div>
                    <div className="text-xs font-semibold text-slate-700 uppercase tracking-wide mb-2">Cons</div>
                    <ul className="space-y-1">
                      {provider.cons.map((con, i) => (
                        <li key={i} className="flex items-start gap-2 text-sm text-slate-600">
                          <span className="text-red-400 mt-0.5 flex-shrink-0">✗</span>
                          {con}
                        </li>
                      ))}
                    </ul>
                  </div>
                </div>

                <div className="mt-4 pt-4 border-t border-slate-100 flex items-center justify-between">
                  <Link
                    to={`/crypto-ira/${provider.reviewSlug}`}
                    className="text-sm text-blue-600 hover:text-blue-800 font-medium"
                  >
                    Read full {provider.name} review →
                  </Link>
                  <a
                    href={provider.affiliateUrl}
                    target="_blank"
                    rel="noopener noreferrer sponsored"
                    onClick={() => trackProviderSiteVisit(provider.name, provider.slug, provider.affiliateUrl)}
                    className="text-sm text-slate-500 hover:text-slate-700"
                  >
                    Visit {provider.name} ↗
                  </a>
                </div>
              </div>
            </div>
          ))}
        </div>
      </section>

      {/* Comparison table */}
      <section className="container-site pb-12">
        <h2 className="text-2xl font-bold text-slate-900 mb-6">Bitcoin IRA Fee Comparison</h2>
        <div className="overflow-x-auto rounded-xl border border-slate-200">
          <table className="w-full text-sm">
            <thead className="bg-slate-50 border-b border-slate-200">
              <tr>
                <th className="text-left px-4 py-3 font-semibold text-slate-700">Provider</th>
                <th className="text-left px-4 py-3 font-semibold text-slate-700">Trading Fee</th>
                <th className="text-left px-4 py-3 font-semibold text-slate-700">Annual Fee</th>
                <th className="text-left px-4 py-3 font-semibold text-slate-700">Min. Investment</th>
                <th className="text-left px-4 py-3 font-semibold text-slate-700">Assets</th>
                <th className="text-left px-4 py-3 font-semibold text-slate-700">Score</th>
              </tr>
            </thead>
            <tbody className="divide-y divide-slate-100">
              {BITCOIN_IRA_PROVIDERS.map((p) => (
                <tr key={p.slug} className="hover:bg-slate-50">
                  <td className="px-4 py-3 font-medium text-slate-900">
                    <Link to={`/crypto-ira/${p.reviewSlug}`} className="hover:text-blue-600">{p.name}</Link>
                  </td>
                  <td className="px-4 py-3 text-slate-600">{p.tradingFee}</td>
                  <td className="px-4 py-3 text-slate-600">{p.annualFee}</td>
                  <td className="px-4 py-3 text-slate-600">{p.minInvestment}</td>
                  <td className="px-4 py-3 text-slate-600">{p.assets}</td>
                  <td className="px-4 py-3 font-semibold text-slate-900">{p.score}</td>
                </tr>
              ))}
            </tbody>
          </table>
        </div>
      </section>

      {/* FAQ */}
      <section className="bg-slate-50 border-t border-slate-200">
        <div className="container-site py-12">
          <h2 className="text-2xl font-bold text-slate-900 mb-8">Frequently Asked Questions</h2>
          <div className="space-y-6 max-w-3xl">
            {faqSchema.mainEntity.map((item, i) => (
              <div key={i} className="bg-white rounded-xl border border-slate-200 p-6">
                <h3 className="font-semibold text-slate-900 mb-3">{item.name}</h3>
                <p className="text-slate-600 text-sm leading-relaxed">{item.acceptedAnswer.text}</p>
              </div>
            ))}
          </div>
        </div>
      </section>

      {/* Disclosure */}
      <section className="border-t border-slate-200">
        <div className="container-site py-6">
          <p className="text-xs text-slate-400 leading-relaxed max-w-3xl">
            <strong>Advertiser Disclosure:</strong> IRA Research Hub may receive compensation when you click on links to provider websites. This compensation does not influence our rankings or editorial opinions. Our scores are based on independent research and our proprietary methodology. Always conduct your own due diligence before opening a retirement account.
          </p>
        </div>
      </section>
      {/* ── Newsletter Signup ─────────────────────────────────────────── */}
      <div className="container-site py-10 max-w-3xl">
        
        {/* Related Links */}

        <div className="mt-10 mb-6">

          <RelatedLinks variant="crypto-guide" title="Related Guides &amp; Reviews" />

        </div>
<NewsletterSignup />
      </div>
    </>
  )
}
