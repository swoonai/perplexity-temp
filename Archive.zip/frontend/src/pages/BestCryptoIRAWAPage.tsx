import StateGuideTemplate from '../components/StateGuideTemplate'

export default function BestCryptoIRAWAPage() {
  return (
    <StateGuideTemplate
      stateName="Washington"
      stateAbbr="WA"
      slug="washington"
    />
  )
}
