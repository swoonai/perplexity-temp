import { useState } from 'react'
import { useQuery, useMutation, useQueryClient } from '@tanstack/react-query'

const API_BASE = '/api/v1/domains'

interface MonitoredDomain {
  id: number
  domain: string
  brand: string
  variant_type: string | null
  tier: number | null
  status: string | null
  threat_level: string | null
  is_registered: boolean | null
  resolves_to_ip: string | null
  registrar: string | null
  registered_date: string | null
  expiry_date: string | null
  site_title: string | null
  redirects_to: string | null
  is_phishing: boolean | null
  is_brand_owned: boolean | null
  action_required: string | null
  action_taken: string | null
  notes: string | null
  last_scanned_at: string | null
  scan_count: number | null
  first_seen_registered: string | null
  alert_sent: boolean | null
}

interface ThreatSummary {
  brand: string
  total: number
  critical: number
  high: number
  medium: number
  low: number
  safe: number
  unscanned: number
  last_scan: string | null
}

const THREAT_COLORS: Record<string, string> = {
  critical: 'bg-red-100 text-red-800 border-red-200',
  high: 'bg-orange-100 text-orange-800 border-orange-200',
  medium: 'bg-yellow-100 text-yellow-800 border-yellow-200',
  low: 'bg-slate-100 text-slate-600 border-slate-200',
  safe: 'bg-green-100 text-green-800 border-green-200',
}

const BRAND_LABELS: Record<string, string> = {
  blocktrustira: 'BlockTrust IRA',
  blocktrust: 'BlockTrust (Rebrand)',
  genesisgoldgroup: 'Genesis Gold Group',
}

function ThreatBadge({ level }: { level: string | null }) {
  if (!level) return <span className="text-slate-400 text-xs">—</span>
  const cls = THREAT_COLORS[level] || 'bg-slate-100 text-slate-600 border-slate-200'
  return (
    <span className={`inline-flex items-center px-2 py-0.5 rounded text-xs font-semibold border ${cls}`}>
      {level.toUpperCase()}
    </span>
  )
}

function StatusDot({ registered }: { registered: boolean | null }) {
  if (registered === null) return <span className="inline-block w-2 h-2 rounded-full bg-slate-300" title="Unknown" />
  if (registered) return <span className="inline-block w-2 h-2 rounded-full bg-red-500" title="Registered" />
  return <span className="inline-block w-2 h-2 rounded-full bg-green-500" title="Available" />
}

export default function DomainMonitorPage() {
  const queryClient = useQueryClient()
  const [selectedBrand, setSelectedBrand] = useState<string>('all')
  const [selectedThreat, setSelectedThreat] = useState<string>('all')
  const [selectedDomain, setSelectedDomain] = useState<MonitoredDomain | null>(null)
  const [actionNote, setActionNote] = useState('')
  const [scanStatus, setScanStatus] = useState<string | null>(null)
  const [seedStatus, setSeedStatus] = useState<string | null>(null)

  // Fetch summary
  const { data: summaries = [] } = useQuery<ThreatSummary[]>({
    queryKey: ['domain-summary'],
    queryFn: () => fetch(`${API_BASE}/summary`).then(r => r.json()),
    refetchInterval: 60000,
  })

  // Fetch domains
  const { data: domains = [], isLoading } = useQuery<MonitoredDomain[]>({
    queryKey: ['domains', selectedBrand, selectedThreat],
    queryFn: () => {
      const params = new URLSearchParams()
      if (selectedBrand !== 'all') params.set('brand', selectedBrand)
      if (selectedThreat !== 'all') params.set('threat_level', selectedThreat)
      params.set('limit', '200')
      return fetch(`${API_BASE}/?${params}`).then(r => r.json())
    },
    refetchInterval: 120000,
  })

  // Fetch alerts
  const { data: alerts = [] } = useQuery<MonitoredDomain[]>({
    queryKey: ['domain-alerts'],
    queryFn: () => fetch(`${API_BASE}/alerts`).then(r => r.json()),
    refetchInterval: 60000,
  })

  // Seed mutation
  const seedMutation = useMutation({
    mutationFn: () => fetch(`${API_BASE}/seed`, { method: 'POST' }).then(r => r.json()),
    onSuccess: (data) => {
      setSeedStatus(`Seeded ${data.seeded} new domains. Total: ${data.total_in_watchlist}`)
      queryClient.invalidateQueries({ queryKey: ['domains'] })
      queryClient.invalidateQueries({ queryKey: ['domain-summary'] })
    },
  })

  // Scan mutation
  const scanMutation = useMutation({
    mutationFn: (brand?: string) => fetch(`${API_BASE}/scan`, {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({ brand: brand || null }),
    }).then(r => r.json()),
    onSuccess: (data) => {
      setScanStatus(data.message || `Scanned. Threats: ${data.threats_found}`)
      setTimeout(() => {
        queryClient.invalidateQueries({ queryKey: ['domains'] })
        queryClient.invalidateQueries({ queryKey: ['domain-summary'] })
        queryClient.invalidateQueries({ queryKey: ['domain-alerts'] })
      }, 3000)
    },
  })

  // Action mutation
  const actionMutation = useMutation({
    mutationFn: ({ domain, action, notes }: { domain: string; action: string; notes: string }) =>
      fetch(`${API_BASE}/${domain}/action`, {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ action_taken: action, notes, alert_sent: true }),
      }).then(r => r.json()),
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ['domains'] })
      queryClient.invalidateQueries({ queryKey: ['domain-alerts'] })
      setSelectedDomain(null)
      setActionNote('')
    },
  })

  return (
    <div className="min-h-screen bg-slate-50">
      {/* Header */}
      <div className="bg-[#0F172A] text-white px-6 py-8">
        <div className="max-w-7xl mx-auto">
          <div className="flex items-center justify-between flex-wrap gap-4">
            <div>
              <h1 className="text-2xl font-bold">Domain Threat Monitor</h1>
              <p className="text-slate-400 text-sm mt-1">
                Typosquatting &amp; impersonation detection for BlockTrust IRA, BlockTrust, and Genesis Gold Group
              </p>
            </div>
            <div className="flex gap-3 flex-wrap">
              <button
                onClick={() => seedMutation.mutate()}
                disabled={seedMutation.isPending}
                className="px-4 py-2 bg-slate-700 hover:bg-slate-600 text-white text-sm font-medium rounded-lg transition-colors"
              >
                {seedMutation.isPending ? 'Seeding…' : 'Seed Watchlist'}
              </button>
              <button
                onClick={() => scanMutation.mutate(undefined)}
                disabled={scanMutation.isPending}
                className="px-4 py-2 bg-[#0EA5E9] hover:bg-[#0284C7] text-white text-sm font-medium rounded-lg transition-colors"
              >
                {scanMutation.isPending ? 'Scanning…' : 'Run Full Scan'}
              </button>
            </div>
          </div>
          {(seedStatus || scanStatus) && (
            <div className="mt-3 text-sm text-emerald-400">{seedStatus || scanStatus}</div>
          )}
        </div>
      </div>

      <div className="max-w-7xl mx-auto px-6 py-8 space-y-8">

        {/* Alerts banner */}
        {alerts.length > 0 && (
          <div className="bg-red-50 border border-red-200 rounded-xl p-4">
            <div className="flex items-center gap-2 mb-2">
              <span className="text-red-600 font-semibold text-sm">⚠ {alerts.length} New Alert{alerts.length > 1 ? 's' : ''} — Action Required</span>
            </div>
            <div className="space-y-1">
              {alerts.slice(0, 5).map(a => (
                <div key={a.id} className="flex items-center gap-3 text-sm">
                  <ThreatBadge level={a.threat_level} />
                  <span className="font-mono text-slate-800">{a.domain}</span>
                  <span className="text-slate-500">{a.action_required}</span>
                  <button
                    onClick={() => setSelectedDomain(a)}
                    className="text-[#0EA5E9] hover:underline text-xs"
                  >
                    Review →
                  </button>
                </div>
              ))}
            </div>
          </div>
        )}

        {/* Summary cards */}
        <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
          {summaries.map(s => (
            <div key={s.brand} className="bg-white rounded-xl border border-slate-200 p-5">
              <div className="flex items-center justify-between mb-3">
                <h3 className="font-semibold text-slate-800 text-sm">{BRAND_LABELS[s.brand] || s.brand}</h3>
                <span className="text-xs text-slate-400">{s.total} domains</span>
              </div>
              <div className="grid grid-cols-3 gap-2 text-center">
                <div className="bg-red-50 rounded-lg p-2">
                  <div className="text-xl font-bold text-red-600">{s.critical}</div>
                  <div className="text-xs text-red-500">Critical</div>
                </div>
                <div className="bg-orange-50 rounded-lg p-2">
                  <div className="text-xl font-bold text-orange-600">{s.high}</div>
                  <div className="text-xs text-orange-500">High</div>
                </div>
                <div className="bg-yellow-50 rounded-lg p-2">
                  <div className="text-xl font-bold text-yellow-600">{s.medium}</div>
                  <div className="text-xs text-yellow-500">Medium</div>
                </div>
              </div>
              <div className="mt-3 flex items-center justify-between text-xs text-slate-400">
                <span>{s.unscanned} unscanned</span>
                <button
                  onClick={() => { setSelectedBrand(s.brand); scanMutation.mutate(s.brand) }}
                  className="text-[#0EA5E9] hover:underline"
                >
                  Scan brand →
                </button>
              </div>
            </div>
          ))}
        </div>

        {/* Filters */}
        <div className="flex gap-3 flex-wrap items-center">
          <select
            value={selectedBrand}
            onChange={e => setSelectedBrand(e.target.value)}
            className="px-3 py-2 border border-slate-200 rounded-lg text-sm bg-white"
          >
            <option value="all">All Brands</option>
            <option value="blocktrustira">BlockTrust IRA</option>
            <option value="blocktrust">BlockTrust (Rebrand)</option>
            <option value="genesisgoldgroup">Genesis Gold Group</option>
          </select>
          <select
            value={selectedThreat}
            onChange={e => setSelectedThreat(e.target.value)}
            className="px-3 py-2 border border-slate-200 rounded-lg text-sm bg-white"
          >
            <option value="all">All Threat Levels</option>
            <option value="critical">Critical</option>
            <option value="high">High</option>
            <option value="medium">Medium</option>
            <option value="low">Low</option>
            <option value="safe">Safe</option>
          </select>
          <span className="text-sm text-slate-500 ml-2">{domains.length} domains shown</span>
        </div>

        {/* Domain table */}
        <div className="bg-white rounded-xl border border-slate-200 overflow-hidden">
          <div className="overflow-x-auto">
            <table className="w-full text-sm">
              <thead>
                <tr className="bg-slate-50 border-b border-slate-200">
                  <th className="text-left px-4 py-3 font-semibold text-slate-600 text-xs uppercase tracking-wide">Domain</th>
                  <th className="text-left px-4 py-3 font-semibold text-slate-600 text-xs uppercase tracking-wide">Brand</th>
                  <th className="text-left px-4 py-3 font-semibold text-slate-600 text-xs uppercase tracking-wide">Type</th>
                  <th className="text-center px-4 py-3 font-semibold text-slate-600 text-xs uppercase tracking-wide">Tier</th>
                  <th className="text-center px-4 py-3 font-semibold text-slate-600 text-xs uppercase tracking-wide">Reg?</th>
                  <th className="text-left px-4 py-3 font-semibold text-slate-600 text-xs uppercase tracking-wide">Threat</th>
                  <th className="text-left px-4 py-3 font-semibold text-slate-600 text-xs uppercase tracking-wide">Action</th>
                  <th className="text-left px-4 py-3 font-semibold text-slate-600 text-xs uppercase tracking-wide">Last Scanned</th>
                  <th className="px-4 py-3"></th>
                </tr>
              </thead>
              <tbody className="divide-y divide-slate-100">
                {isLoading ? (
                  <tr><td colSpan={9} className="text-center py-8 text-slate-400">Loading…</td></tr>
                ) : domains.length === 0 ? (
                  <tr><td colSpan={9} className="text-center py-8 text-slate-400">
                    No domains found. Click "Seed Watchlist" to populate.
                  </td></tr>
                ) : (
                  domains.map(d => (
                    <tr
                      key={d.id}
                      className={`hover:bg-slate-50 transition-colors ${d.is_phishing ? 'bg-red-50' : ''}`}
                    >
                      <td className="px-4 py-3">
                        <div className="flex items-center gap-2">
                          <StatusDot registered={d.is_registered} />
                          <a
                            href={`https://${d.domain}`}
                            target="_blank"
                            rel="noopener noreferrer"
                            className="font-mono text-xs text-slate-800 hover:text-[#0EA5E9]"
                          >
                            {d.domain}
                          </a>
                          {d.is_phishing && (
                            <span className="text-xs bg-red-600 text-white px-1 rounded">PHISHING</span>
                          )}
                          {d.is_brand_owned && (
                            <span className="text-xs bg-green-600 text-white px-1 rounded">OWNED</span>
                          )}
                        </div>
                        {d.site_title && (
                          <div className="text-xs text-slate-400 mt-0.5 ml-4 truncate max-w-[200px]">{d.site_title}</div>
                        )}
                      </td>
                      <td className="px-4 py-3 text-xs text-slate-500">{BRAND_LABELS[d.brand] || d.brand}</td>
                      <td className="px-4 py-3 text-xs text-slate-500">{d.variant_type || '—'}</td>
                      <td className="px-4 py-3 text-center">
                        <span className={`text-xs font-bold ${d.tier === 1 ? 'text-red-600' : d.tier === 2 ? 'text-orange-500' : 'text-slate-400'}`}>
                          T{d.tier || '?'}
                        </span>
                      </td>
                      <td className="px-4 py-3 text-center">
                        {d.is_registered === null ? '?' : d.is_registered ? '✓' : '✗'}
                      </td>
                      <td className="px-4 py-3"><ThreatBadge level={d.threat_level} /></td>
                      <td className="px-4 py-3 text-xs text-slate-600">
                        {d.action_taken ? (
                          <span className="text-green-600">✓ {d.action_taken.slice(0, 30)}</span>
                        ) : (
                          <span className={d.action_required === 'purchase' ? 'text-orange-600 font-medium' :
                            d.action_required === 'file_complaint' ? 'text-red-600 font-medium' :
                            d.action_required === 'investigate' ? 'text-yellow-600' : 'text-slate-400'}>
                            {d.action_required || '—'}
                          </span>
                        )}
                      </td>
                      <td className="px-4 py-3 text-xs text-slate-400">
                        {d.last_scanned_at
                          ? new Date(d.last_scanned_at).toLocaleDateString()
                          : 'Never'}
                      </td>
                      <td className="px-4 py-3">
                        <button
                          onClick={() => setSelectedDomain(d)}
                          className="text-xs text-[#0EA5E9] hover:underline"
                        >
                          Details
                        </button>
                      </td>
                    </tr>
                  ))
                )}
              </tbody>
            </table>
          </div>
        </div>

        {/* How it works */}
        <div className="bg-white rounded-xl border border-slate-200 p-6">
          <h2 className="font-semibold text-slate-800 mb-3">How the Monitor Works</h2>
          <div className="grid grid-cols-1 md:grid-cols-3 gap-4 text-sm text-slate-600">
            <div>
              <div className="font-medium text-slate-800 mb-1">1. Watchlist (87 domains)</div>
              <p>Covers 3 brands across 7 variant types: alt TLDs, hyphenated, typosquats, homoglyphs, keyword-appended, suffix, and rebrand variants.</p>
            </div>
            <div>
              <div className="font-medium text-slate-800 mb-1">2. Scan Process</div>
              <p>Each domain is checked via WHOIS (registration status), DNS (live IP), and HTTP (content analysis for phishing indicators).</p>
            </div>
            <div>
              <div className="font-medium text-slate-800 mb-1">3. Alerts</div>
              <p>Any domain that transitions from unregistered to registered triggers an alert. Critical = active phishing site. High = resolving unknown registrant.</p>
            </div>
          </div>
        </div>
      </div>

      {/* Domain detail modal */}
      {selectedDomain && (
        <div className="fixed inset-0 bg-black/50 flex items-center justify-center z-50 p-4">
          <div className="bg-white rounded-2xl max-w-lg w-full p-6 shadow-2xl max-h-[90vh] overflow-y-auto">
            <div className="flex items-center justify-between mb-4">
              <h2 className="font-bold text-slate-800">{selectedDomain.domain}</h2>
              <button onClick={() => setSelectedDomain(null)} className="text-slate-400 hover:text-slate-600 text-xl">✕</button>
            </div>

            <div className="space-y-3 text-sm">
              <div className="grid grid-cols-2 gap-3">
                <div className="bg-slate-50 rounded-lg p-3">
                  <div className="text-xs text-slate-500 mb-1">Threat Level</div>
                  <ThreatBadge level={selectedDomain.threat_level} />
                </div>
                <div className="bg-slate-50 rounded-lg p-3">
                  <div className="text-xs text-slate-500 mb-1">Status</div>
                  <span className="font-medium">{selectedDomain.status || '—'}</span>
                </div>
              </div>

              {selectedDomain.resolves_to_ip && (
                <div className="bg-slate-50 rounded-lg p-3">
                  <div className="text-xs text-slate-500 mb-1">Resolves to IP</div>
                  <span className="font-mono">{selectedDomain.resolves_to_ip}</span>
                </div>
              )}

              {selectedDomain.registrar && (
                <div className="bg-slate-50 rounded-lg p-3">
                  <div className="text-xs text-slate-500 mb-1">Registrar</div>
                  <span>{selectedDomain.registrar}</span>
                </div>
              )}

              {selectedDomain.registered_date && (
                <div className="bg-slate-50 rounded-lg p-3">
                  <div className="text-xs text-slate-500 mb-1">Registered</div>
                  <span>{selectedDomain.registered_date}</span>
                  {selectedDomain.expiry_date && <span className="text-slate-400"> → Expires {selectedDomain.expiry_date}</span>}
                </div>
              )}

              {selectedDomain.site_title && (
                <div className="bg-slate-50 rounded-lg p-3">
                  <div className="text-xs text-slate-500 mb-1">Site Title</div>
                  <span>{selectedDomain.site_title}</span>
                </div>
              )}

              {selectedDomain.redirects_to && (
                <div className="bg-slate-50 rounded-lg p-3">
                  <div className="text-xs text-slate-500 mb-1">Redirects To</div>
                  <span className="font-mono text-xs break-all">{selectedDomain.redirects_to}</span>
                </div>
              )}

              {selectedDomain.first_seen_registered && (
                <div className="bg-orange-50 border border-orange-200 rounded-lg p-3">
                  <div className="text-xs text-orange-600 font-medium">First detected as registered: {new Date(selectedDomain.first_seen_registered).toLocaleString()}</div>
                </div>
              )}

              {selectedDomain.action_taken ? (
                <div className="bg-green-50 border border-green-200 rounded-lg p-3">
                  <div className="text-xs text-green-700 font-medium">Action taken: {selectedDomain.action_taken}</div>
                  {selectedDomain.notes && <div className="text-xs text-green-600 mt-1">{selectedDomain.notes}</div>}
                </div>
              ) : (
                <div className="border border-slate-200 rounded-lg p-3">
                  <div className="text-xs text-slate-500 mb-2 font-medium">Record action taken</div>
                  <input
                    type="text"
                    value={actionNote}
                    onChange={e => setActionNote(e.target.value)}
                    placeholder="e.g. Filed Dynadot abuse report, Purchased domain"
                    className="w-full px-3 py-2 border border-slate-200 rounded-lg text-sm mb-2"
                  />
                  <button
                    onClick={() => actionMutation.mutate({
                      domain: selectedDomain.domain,
                      action: actionNote,
                      notes: '',
                    })}
                    disabled={!actionNote || actionMutation.isPending}
                    className="btn-primary text-sm py-2 w-full"
                  >
                    {actionMutation.isPending ? 'Saving…' : 'Save Action'}
                  </button>
                </div>
              )}

              <div className="flex gap-2 pt-2">
                <button
                  onClick={() => scanMutation.mutate(selectedDomain.brand)}
                  className="flex-1 px-4 py-2 bg-slate-100 hover:bg-slate-200 text-slate-700 text-sm font-medium rounded-lg"
                >
                  Re-scan
                </button>
                <a
                  href={`https://www.whois.com/whois/${selectedDomain.domain}`}
                  target="_blank"
                  rel="noopener noreferrer"
                  className="flex-1 px-4 py-2 bg-slate-100 hover:bg-slate-200 text-slate-700 text-sm font-medium rounded-lg text-center"
                >
                  WHOIS Lookup
                </a>
              </div>
            </div>
          </div>
        </div>
      )}
    </div>
  )
}
