import StateGuideTemplate from '../components/StateGuideTemplate'

export default function BestCryptoIRAIDPage() {
  return (
    <StateGuideTemplate
      stateName="Idaho"
      stateAbbr="ID"
      slug="idaho"
    />
  )
}
