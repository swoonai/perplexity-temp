import { Link } from 'react-router-dom'
import SEO from '../components/SEO'
import AdvertiserDisclosure from '../components/AdvertiserDisclosure'
import NewsletterSignup from '../components/NewsletterSignup';
import RelatedLinks from '../components/RelatedLinks';

const DATE_MODIFIED = "2026-03-23"
const DATE_PUBLISHED = "2026-03-23"
const LAST_UPDATED = "March 23, 2026"

const articleSchema = {
  "@context": "https://schema.org",
  "@type": "HowTo",
  "@id": "https://iraresearchhub.com/precious-metals-ira/how-to-buy-gold-in-ira",
  "name": "How to Buy Gold in an IRA in 2026",
  "description": "Step-by-step guide to buying gold inside an IRA. Learn which gold products are IRS-approved, how to place a purchase order, and how to avoid common mistakes.",
  "totalTime": "PT15M",
  "step": [
    {
      "@type": "HowToStep",
      "name": "Verify Your Account Is Funded",
      "text": "Before buying gold, confirm your self-directed IRA has sufficient funds. Log in to your custodian's portal or contact your gold IRA provider to verify your available balance.",
      "url": "https://iraresearchhub.com/precious-metals-ira/how-to-buy-gold-in-ira#step-1"
    },
    {
      "@type": "HowToStep",
      "name": "Choose IRS-Approved Gold Products",
      "text": "Select from IRS-approved gold coins and bars. Gold must be at least 99.5% pure. Approved options include American Gold Eagles, American Gold Buffalos, Canadian Gold Maple Leafs, and gold bars from LBMA-approved refiners.",
      "url": "https://iraresearchhub.com/precious-metals-ira/how-to-buy-gold-in-ira#step-2"
    },
    {
      "@type": "HowToStep",
      "name": "Place Your Purchase Order",
      "text": "Contact your gold IRA provider to place a purchase order. Specify the product, quantity, and price. Most providers lock in the spot price at the time of order. Your provider handles the purchase on your behalf — you do not buy gold directly.",
      "url": "https://iraresearchhub.com/precious-metals-ira/how-to-buy-gold-in-ira#step-3"
    },
    {
      "@type": "HowToStep",
      "name": "Gold Is Shipped to an Approved Depository",
      "text": "After purchase, your gold is shipped directly to an IRS-approved depository. You will receive a confirmation showing the exact products, weight, and storage location. You cannot take personal possession of IRA gold.",
      "url": "https://iraresearchhub.com/precious-metals-ira/how-to-buy-gold-in-ira#step-4"
    }
  ],
  "author": {
    "@type": "Person",
    "@id": "https://iraresearchhub.com/author/james-mitchell",
    "name": "James Mitchell",
    "url": "https://iraresearchhub.com/author/james-mitchell"
  },
  "publisher": {
    "@type": "Organization",
    "@id": "https://iraresearchhub.com",
    "name": "IRA Research Hub",
    "url": "https://iraresearchhub.com"
  },
  "datePublished": DATE_PUBLISHED,
  "dateModified": DATE_MODIFIED
}

const faqSchema = {
  "@context": "https://schema.org",
  "@type": "FAQPage",
  "mainEntity": [
    {
      "@type": "Question",
      "name": "Can I buy gold directly in my IRA?",
      "acceptedAnswer": {
        "@type": "Answer",
        "text": "You cannot buy gold directly — you must work through an IRS-approved self-directed IRA custodian and a gold IRA provider. The provider places the purchase order on your behalf, and the gold is shipped directly to an IRS-approved depository. You never personally handle the gold while it is in your IRA."
      }
    },
    {
      "@type": "Question",
      "name": "What is the best gold to buy in an IRA?",
      "acceptedAnswer": {
        "@type": "Answer",
        "text": "American Gold Eagles are the most popular choice for gold IRAs because they are specifically exempted by the IRS (despite being 91.67% pure), are highly liquid, and carry the full faith and credit of the US government. American Gold Buffalos (99.99% pure) are also popular and trade at a smaller premium over spot price. For investors who prioritize lower premiums, gold bars from LBMA-approved refiners like PAMP Suisse or Credit Suisse offer the lowest markup over spot."
      }
    },
    {
      "@type": "Question",
      "name": "How much gold should I buy in my IRA?",
      "acceptedAnswer": {
        "@type": "Answer",
        "text": "Most financial advisors recommend allocating 5–15% of a retirement portfolio to precious metals, with gold as the primary holding. The exact allocation depends on your risk tolerance, investment timeline, and overall portfolio composition. Gold serves primarily as a hedge against inflation and currency devaluation, not as a growth asset."
      }
    },
    {
      "@type": "Question",
      "name": "What happens to my gold IRA when I retire?",
      "acceptedAnswer": {
        "@type": "Answer",
        "text": "When you reach age 59½, you can take distributions from your gold IRA. You have two options: (1) take a cash distribution — your provider sells the gold at current market prices and sends you the proceeds; or (2) take an in-kind distribution — you receive the actual physical gold. Both options trigger income tax on the distribution amount (for Traditional IRAs). Required Minimum Distributions (RMDs) begin at age 73."
      }
    },
    {
      "@type": "Question",
      "name": "Can I buy gold ETFs in my IRA instead of physical gold?",
      "acceptedAnswer": {
        "@type": "Answer",
        "text": "Yes. You can hold gold ETFs (like GLD or IAU) in a regular IRA or Roth IRA through any standard brokerage. However, gold ETFs are paper assets — you own shares in a fund that holds gold, not physical gold itself. A physical gold IRA (self-directed IRA) holds actual gold bars and coins in an approved depository. Physical gold provides direct ownership and eliminates counterparty risk, while gold ETFs are more liquid and have lower fees."
      }
    }
  ]
}

const APPROVED_PRODUCTS = [
  { name: 'American Gold Eagle', purity: '91.67%', sizes: '1 oz, ½ oz, ¼ oz, 1/10 oz', premium: 'High (5–8%)', notes: 'IRS-exempted; most popular' },
  { name: 'American Gold Buffalo', purity: '99.99%', sizes: '1 oz only', premium: 'Medium (3–5%)', notes: 'Purest US gold coin' },
  { name: 'Canadian Gold Maple Leaf', purity: '99.99%', sizes: '1 oz, ½ oz, ¼ oz, 1/10 oz', premium: 'Medium (3–5%)', notes: 'Highly liquid internationally' },
  { name: 'Austrian Gold Philharmonic', purity: '99.99%', sizes: '1 oz, ½ oz, ¼ oz, 1/10 oz', premium: 'Medium (3–5%)', notes: 'Popular in Europe' },
  { name: 'PAMP Suisse Gold Bar', purity: '99.99%', sizes: '1 oz, 10 oz, 1 kg', premium: 'Low (1–3%)', notes: 'Lowest premium over spot' },
  { name: 'Credit Suisse Gold Bar', purity: '99.99%', sizes: '1 oz, 10 oz', premium: 'Low (1–3%)', notes: 'Widely recognized' },
]

const breadcrumbSchema = {"@context": "https://schema.org", "@type": "BreadcrumbList", "itemListElement": [{"@type": "ListItem", "position": 1, "name": "Precious Metals IRA", "item": "https://iraresearchhub.com/precious-metals-ira"},
      {"@type": "ListItem", "position": 2, "name": "How to Buy Gold in an IRA", "item": "https://iraresearchhub.com/precious-metals-ira/how-to-buy-gold-in-ira"}]};
export default function HowToBuyGoldInIRAPage() {
  return (
    <>
      <SEO
        title="How to Buy Gold in an IRA in 2026: Complete Guide"
        description="How to buy gold in an IRA: which products are IRS-approved, how to place a purchase order, storage requirements, and how to avoid common mistakes. Updated for 2026."
        canonical="/precious-metals-ira/how-to-buy-gold-in-ira"
        ogType="article"
      />
      <script type="application/ld+json" dangerouslySetInnerHTML={{ __html: JSON.stringify(articleSchema) }} />
      <script type="application/ld+json" dangerouslySetInnerHTML={{ __html: JSON.stringify(faqSchema) }} />

      <script type="application/ld+json" dangerouslySetInnerHTML={{ __html: JSON.stringify(breadcrumbSchema) }} />
      {/* Header */}
      <section className="bg-[#F8FAFC] border-b border-slate-200">
        <div className="container-site py-12 max-w-4xl">
          <div className="flex flex-wrap items-center gap-2 mb-4">
            <Link to="/precious-metals-ira" className="text-sm text-[#64748B] hover:text-[#0EA5E9]">Precious Metals IRAs</Link>
            <span className="text-slate-300">/</span>
            <span className="text-sm text-[#0F172A]">How to Buy Gold in an IRA</span>
          </div>
          <div className="inline-flex items-center px-2.5 py-0.5 rounded-full text-xs font-medium bg-amber-100 text-amber-700 mb-4">
            Updated March 2026 · Practical Guide
          </div>
          <h1 className="text-4xl font-bold text-[#0F172A] mb-3">
            How to Buy Gold in an IRA in 2026
          </h1>
          <p className="text-sm text-slate-400 mt-2">
            By <a href="/author/james-mitchell" className="text-[#0EA5E9] hover:underline">James Mitchell, CFA</a> · Last updated: {LAST_UPDATED} · <a href="/methodology" className="text-[#0EA5E9] hover:underline">Methodology</a>
          </p>
          <AdvertiserDisclosure />
          <p className="text-lg text-[#64748B] max-w-2xl mt-3">
            Buying gold in an IRA is different from buying gold at a coin shop or online dealer. This guide explains the IRS rules, approved products, how to place a purchase order, and what happens to your gold after purchase.
          </p>
        </div>
      </section>

      <section className="container-site py-12 max-w-4xl">

        {/* Key Rules Box */}
        <div className="card border-l-4 border-l-[#D97706] mb-10">
          <h2 className="text-lg font-bold text-[#0F172A] mb-3">The 3 Key Rules for Buying Gold in an IRA</h2>
          <div className="space-y-3">
            <div className="flex items-start gap-3">
              <div className="flex-shrink-0 w-6 h-6 bg-amber-100 text-amber-700 rounded-full flex items-center justify-center text-xs font-bold">1</div>
              <div>
                <div className="font-semibold text-[#0F172A] text-sm">Purity requirement</div>
                <div className="text-sm text-[#64748B]">Gold must be at least 99.5% pure (0.995 fineness), except American Gold Eagles which are specifically exempted by the IRS.</div>
              </div>
            </div>
            <div className="flex items-start gap-3">
              <div className="flex-shrink-0 w-6 h-6 bg-amber-100 text-amber-700 rounded-full flex items-center justify-center text-xs font-bold">2</div>
              <div>
                <div className="font-semibold text-[#0F172A] text-sm">No personal possession</div>
                <div className="text-sm text-[#64748B]">You cannot take personal possession of IRA gold. It must be stored at an IRS-approved depository. Taking possession triggers a distribution and potential taxes/penalties.</div>
              </div>
            </div>
            <div className="flex items-start gap-3">
              <div className="flex-shrink-0 w-6 h-6 bg-amber-100 text-amber-700 rounded-full flex items-center justify-center text-xs font-bold">3</div>
              <div>
                <div className="font-semibold text-[#0F172A] text-sm">Custodian required</div>
                <div className="text-sm text-[#64748B]">All purchases must go through an IRS-approved custodian. You cannot buy gold directly and contribute it to your IRA — this is called a "prohibited transaction" and disqualifies the entire IRA.</div>
              </div>
            </div>
          </div>
        </div>

        {/* Step-by-Step */}
        <div className="space-y-10 mb-12">

          <div id="step-1" className="scroll-mt-20">
            <div className="flex items-start gap-4 mb-4">
              <div className="flex-shrink-0 w-12 h-12 bg-[#D97706] text-white rounded-full flex items-center justify-center font-bold text-lg">01</div>
              <div>
                <h2 className="text-2xl font-bold text-[#0F172A]">Verify Your Account Is Funded</h2>
                <div className="text-xs text-[#64748B] mt-0.5">Before placing any order</div>
              </div>
            </div>
            <div className="ml-16">
              <p className="text-[#64748B] leading-relaxed mb-4">
                Before buying gold, confirm your self-directed IRA has sufficient funds. Log in to your custodian's online portal or contact your gold IRA provider directly. Your available balance should reflect:
              </p>
              <ul className="text-sm text-[#64748B] space-y-2 mb-4">
                <li className="flex items-start gap-2"><span className="text-emerald-500 font-bold flex-shrink-0">✓</span><span>Funds from your 401(k) rollover or IRA transfer have cleared</span></li>
                <li className="flex items-start gap-2"><span className="text-emerald-500 font-bold flex-shrink-0">✓</span><span>Any wire transfer fees have been deducted</span></li>
                <li className="flex items-start gap-2"><span className="text-emerald-500 font-bold flex-shrink-0">✓</span><span>You have enough to cover the gold purchase plus storage setup fees</span></li>
              </ul>
              <p className="text-[#64748B] leading-relaxed">
                If you have not yet funded your account, see our guide on <Link to="/precious-metals-ira/how-to-open-gold-ira#step-3" className="text-[#0EA5E9] hover:underline">how to fund a gold IRA</Link>.
              </p>
            </div>
          </div>

          <div id="step-2" className="scroll-mt-20">
            <div className="flex items-start gap-4 mb-4">
              <div className="flex-shrink-0 w-12 h-12 bg-[#D97706] text-white rounded-full flex items-center justify-center font-bold text-lg">02</div>
              <div>
                <h2 className="text-2xl font-bold text-[#0F172A]">Choose IRS-Approved Gold Products</h2>
                <div className="text-xs text-[#64748B] mt-0.5">The most important decision</div>
              </div>
            </div>
            <div className="ml-16">
              <p className="text-[#64748B] leading-relaxed mb-4">
                Not all gold products are IRS-approved for IRAs. Below are the most popular approved options, with their purity, available sizes, and typical premium over spot price:
              </p>
              <div className="overflow-x-auto mb-4">
                <table className="w-full text-sm">
                  <thead>
                    <tr className="bg-[#0F172A] text-white">
                      <th className="text-left p-3 rounded-tl-lg">Product</th>
                      <th className="text-center p-3">Purity</th>
                      <th className="text-center p-3">Sizes</th>
                      <th className="text-center p-3">Premium</th>
                      <th className="text-left p-3 rounded-tr-lg">Notes</th>
                    </tr>
                  </thead>
                  <tbody>
                    {APPROVED_PRODUCTS.map((p, i) => (
                      <tr key={p.name} className={i % 2 === 0 ? 'bg-white' : 'bg-slate-50'}>
                        <td className="p-3 font-medium text-[#0F172A]">{p.name}</td>
                        <td className="p-3 text-center text-[#64748B]">{p.purity}</td>
                        <td className="p-3 text-center text-[#64748B]">{p.sizes}</td>
                        <td className="p-3 text-center text-[#64748B]">{p.premium}</td>
                        <td className="p-3 text-[#64748B]">{p.notes}</td>
                      </tr>
                    ))}
                  </tbody>
                </table>
              </div>
              <div className="bg-amber-50 border border-amber-200 rounded-lg p-4">
                <div className="font-semibold text-[#0F172A] mb-1 text-sm">Our Recommendation</div>
                <p className="text-sm text-[#64748B]">
                  For most investors, <strong>American Gold Eagles</strong> are the best choice for their IRA — they are the most liquid, widely recognized, and IRS-approved despite the lower purity. If minimizing the premium over spot price is your priority, <strong>PAMP Suisse or Credit Suisse gold bars</strong> offer the lowest markup.
                </p>
              </div>
            </div>
          </div>

          <div id="step-3" className="scroll-mt-20">
            <div className="flex items-start gap-4 mb-4">
              <div className="flex-shrink-0 w-12 h-12 bg-[#D97706] text-white rounded-full flex items-center justify-center font-bold text-lg">03</div>
              <div>
                <h2 className="text-2xl font-bold text-[#0F172A]">Place Your Purchase Order</h2>
                <div className="text-xs text-[#64748B] mt-0.5">Handled by your provider</div>
              </div>
            </div>
            <div className="ml-16">
              <p className="text-[#64748B] leading-relaxed mb-4">
                Contact your gold IRA provider (by phone or through their online portal) to place a purchase order. You will specify:
              </p>
              <ul className="text-sm text-[#64748B] space-y-2 mb-4">
                <li className="flex items-start gap-2"><span className="text-[#D97706] font-bold flex-shrink-0">→</span><span><strong className="text-[#0F172A]">Product:</strong> e.g., "1 oz American Gold Eagle"</span></li>
                <li className="flex items-start gap-2"><span className="text-[#D97706] font-bold flex-shrink-0">→</span><span><strong className="text-[#0F172A]">Quantity:</strong> number of coins or bars</span></li>
                <li className="flex items-start gap-2"><span className="text-[#D97706] font-bold flex-shrink-0">→</span><span><strong className="text-[#0F172A]">Price lock:</strong> most providers lock in the spot price at the time of order</span></li>
              </ul>
              <p className="text-[#64748B] leading-relaxed mb-3">
                Your provider will place the order with their precious metals dealer. You will receive a confirmation showing the exact products, quantity, price, and total cost. The funds are debited from your IRA account.
              </p>
              <div className="bg-slate-50 rounded-lg p-4">
                <div className="font-semibold text-[#0F172A] mb-1 text-sm">Important: Price Transparency</div>
                <p className="text-sm text-[#64748B]">
                  Ask your provider for the <strong>all-in price</strong> before confirming — this includes the spot price plus the dealer's markup (premium). Reputable providers will disclose the total cost upfront. Be wary of providers who are vague about the premium or markup.
                </p>
              </div>
            </div>
          </div>

          <div id="step-4" className="scroll-mt-20">
            <div className="flex items-start gap-4 mb-4">
              <div className="flex-shrink-0 w-12 h-12 bg-[#D97706] text-white rounded-full flex items-center justify-center font-bold text-lg">04</div>
              <div>
                <h2 className="text-2xl font-bold text-[#0F172A]">Gold Is Shipped to an Approved Depository</h2>
                <div className="text-xs text-[#64748B] mt-0.5">Automatic — no action required</div>
              </div>
            </div>
            <div className="ml-16">
              <p className="text-[#64748B] leading-relaxed mb-4">
                After your purchase order is confirmed, your gold is shipped directly from the dealer to an IRS-approved depository. You will receive a confirmation showing:
              </p>
              <ul className="text-sm text-[#64748B] space-y-2 mb-4">
                <li className="flex items-start gap-2"><span className="text-emerald-500 font-bold flex-shrink-0">✓</span><span>Exact products purchased (product name, weight, purity)</span></li>
                <li className="flex items-start gap-2"><span className="text-emerald-500 font-bold flex-shrink-0">✓</span><span>Storage location (depository name and address)</span></li>
                <li className="flex items-start gap-2"><span className="text-emerald-500 font-bold flex-shrink-0">✓</span><span>Storage type (segregated or commingled)</span></li>
                <li className="flex items-start gap-2"><span className="text-emerald-500 font-bold flex-shrink-0">✓</span><span>Account statement showing the new holdings</span></li>
              </ul>
              <p className="text-[#64748B] leading-relaxed">
                <strong className="text-[#0F172A]">You cannot take personal possession of IRA gold.</strong> If you take possession of the gold — even temporarily — the IRS treats it as a distribution. For Traditional IRAs, this triggers income tax plus a 10% early withdrawal penalty if you are under 59½.
              </p>
            </div>
          </div>

        </div>

        {/* Common Mistakes */}
        <div className="mb-10">
          <h2 className="text-2xl font-bold text-[#0F172A] mb-4">Common Mistakes to Avoid</h2>
          <div className="space-y-3">
            {[
              {
                title: 'Buying non-IRS-approved gold',
                desc: 'Collectible coins, numismatic coins, and gold below 99.5% purity (except American Gold Eagles) are not IRS-approved. Including them in your IRA triggers a distribution.',
              },
              {
                title: 'Using a "home storage" gold IRA',
                desc: 'Some companies market "home storage" gold IRAs, claiming you can store IRA gold at home. This is not IRS-compliant. The IRS requires storage at an approved depository. Home storage IRAs carry significant legal risk.',
              },
              {
                title: 'Paying excessive premiums',
                desc: 'Some providers charge 10–20% premiums over spot price, especially on numismatic or "rare" coins. Stick to standard bullion products (American Eagles, Maple Leafs, PAMP bars) where premiums are 1–8%.',
              },
              {
                title: 'Ignoring the gold-to-silver ratio',
                desc: 'If you are considering silver alongside gold, check the current gold-to-silver ratio. At historically high ratios (80:1+), silver may offer better value. See our Gold IRA vs Silver IRA guide for details.',
              },
              {
                title: 'Not comparing storage fees',
                desc: 'Annual storage fees vary significantly — from $100 to $300+/year. Over a 10-year period, a $200/year difference in storage fees amounts to $2,000 in additional costs. Always compare the total annual cost, not just the purchase price.',
              },
            ].map((item, i) => (
              <div key={i} className="flex items-start gap-3 p-4 bg-red-50 border border-red-100 rounded-lg">
                <span className="text-red-500 font-bold flex-shrink-0 text-lg">✗</span>
                <div>
                  <div className="font-semibold text-[#0F172A] text-sm mb-0.5">{item.title}</div>
                  <div className="text-sm text-[#64748B]">{item.desc}</div>
                </div>
              </div>
            ))}
          </div>
        </div>

        {/* FAQ Section */}
        <h2 className="text-2xl font-bold text-[#0F172A] mb-4">Frequently Asked Questions</h2>
        <div className="space-y-4 mb-8">
          {faqSchema.mainEntity.map((item) => (
            <details key={item.name} className="group border border-slate-200 rounded-lg overflow-hidden">
              <summary className="flex items-center justify-between gap-4 p-5 cursor-pointer bg-white hover:bg-slate-50 transition-colors list-none">
                <span className="font-semibold text-[#0F172A] text-sm leading-snug">{item.name}</span>
                <span className="flex-shrink-0 w-5 h-5 text-[#D97706] transition-transform group-open:rotate-180">
                  <svg viewBox="0 0 20 20" fill="currentColor"><path fillRule="evenodd" d="M5.293 7.293a1 1 0 011.414 0L10 10.586l3.293-3.293a1 1 0 111.414 1.414l-4 4a1 1 0 01-1.414 0l-4-4a1 1 0 010-1.414z" clipRule="evenodd" /></svg>
                </span>
              </summary>
              <div className="px-5 pb-5 text-[#64748B] text-sm leading-relaxed bg-white">
                {item.acceptedAnswer.text}
              </div>
            </details>
          ))}
        </div>

        {/* Bottom CTA */}
        <div className="bg-amber-50 border border-amber-200 rounded-xl p-6 text-center mb-8">
          <h2 className="text-xl font-bold text-[#0F172A] mb-2">Ready to buy gold in your IRA?</h2>
          <p className="text-sm text-slate-600 mb-4">
            Compare our top-rated gold IRA providers to find the best fees, minimums, and gold selection.
          </p>
          <Link
            to="/precious-metals-ira/best-companies"
            className="inline-flex items-center justify-center px-6 py-3 bg-[#D97706] text-white font-semibold rounded-lg hover:bg-[#B45309] transition-colors"
          >
            See All Gold IRA Rankings →
          </Link>
        </div>

        {/* Related Links */}
        <div className="grid md:grid-cols-3 gap-4 text-sm">
          <Link to="/precious-metals-ira/how-to-open-gold-ira" className="card hover:shadow-elevated transition-all">
            <div className="font-semibold text-[#0F172A] mb-1">How to Open a Gold IRA →</div>
            <div className="text-[#64748B]">Step-by-step account opening guide</div>
          </Link>
          <Link to="/precious-metals-ira/gold-ira-vs-silver-ira" className="card hover:shadow-elevated transition-all">
            <div className="font-semibold text-[#0F172A] mb-1">Gold IRA vs Silver IRA →</div>
            <div className="text-[#64748B]">Which metal is right for you?</div>
          </Link>
          <Link to="/precious-metals-ira/401k-to-gold-ira-rollover" className="card hover:shadow-elevated transition-all">
            <div className="font-semibold text-[#0F172A] mb-1">401k to Gold IRA Rollover →</div>
            <div className="text-[#64748B]">Rollover guide and rules</div>
          </Link>
        </div>

      </section>
      {/* ── Newsletter Signup ─────────────────────────────────────────── */}
      <div className="container-site py-10 max-w-3xl">
        
        {/* Related Links */}

        <div className="mt-10 mb-6">

          <RelatedLinks variant="metals-guide" title="Related Guides &amp; Reviews" />

        </div>
<NewsletterSignup />
      </div>
    </>
  )
}
