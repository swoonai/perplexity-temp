import React from 'react'
import { Link } from 'react-router-dom'
import SEO from '../components/SEO'
import AdvertiserDisclosure from '../components/AdvertiserDisclosure'
import { trackResearchStart } from '../hooks/useAnalytics'
import NewsletterSignup from '../components/NewsletterSignup';
import RelatedLinks from '../components/RelatedLinks';

const LAST_UPDATED = 'March 31, 2026'

export default function WhatIsSDIRAPage() {

  // Funnel tracking: fire research_start when arriving from a paid ad
  React.useEffect(() => {
    const params = new URLSearchParams(window.location.search)
    const utmSource = params.get('utm_source') ?? undefined
    if (utmSource) {
      trackResearchStart(window.location.pathname, document.title, utmSource)
    }
  }, [])

  return (
    <>
      <script type="application/ld+json" dangerouslySetInnerHTML={{ __html: JSON.stringify({"@context":"https://schema.org","@type":"BreadcrumbList","itemListElement":[{"@type":"ListItem","position":1,"name":"Guides","item":"https://iraresearchhub.com/guides"},{"@type":"ListItem","position":2,"name":"What Is a Self-Directed IRA?","item":"https://iraresearchhub.com/guides/what-is-self-directed-ira"}]}) }} />
      <SEO
        title="What Is a Self-Directed IRA? Complete Beginner's Guide (2026)"
        description="Independent educational guide to self-directed IRAs: IRS rules, eligible assets (crypto, gold, real estate), tax implications, risks, and how to research custodians. Not financial advice."
        canonical="/guides/what-is-self-directed-ira"
        ogType="article"
      />
      <script type="application/ld+json" dangerouslySetInnerHTML={{ __html: JSON.stringify({"@context":"https://schema.org","@type":"Article","headline":"What Is a Self-Directed IRA? Complete Beginner's Guide (2026)","author":{"@type":"Person","name":"James Mitchell","jobTitle":"CFA"},"publisher":{"@type":"Organization","name":"IRA Research Hub"},"dateModified":"2026-03-31","description":"Independent educational guide to self-directed IRAs covering IRS rules, eligible assets, tax implications, risks, and how to research custodians."}) }} />

      {/* Hero */}
      <div className="bg-[#F8FAFC] border-b border-slate-200 py-10">
        <div className="container-site max-w-4xl">
          <div className="flex flex-wrap gap-2 mb-4">
            <span className="inline-flex items-center px-2.5 py-0.5 rounded-full text-xs font-medium bg-indigo-100 text-indigo-700">Educational Guide</span>
            <span className="inline-flex items-center px-2.5 py-0.5 rounded-full text-xs font-medium bg-slate-100 text-slate-600">2026 Update</span>
          </div>
          <h1 className="text-4xl font-bold text-[#0F172A] mb-4 leading-tight">
            What Is a Self-Directed IRA? Complete Beginner's Guide (2026)
          </h1>
          <p className="text-lg text-[#64748B] mb-4 max-w-3xl">
            A self-directed IRA (SDIRA) is a type of individual retirement account that allows you to hold a broader range of assets than a standard IRA — including cryptocurrencies, precious metals, real estate, and private equity. This guide explains how SDIRAs work, what the IRS permits, the risks involved, and how to evaluate custodians independently.
          </p>
          <p className="text-sm text-slate-500">
            By <Link to="/author/james-mitchell" className="text-sky-600 hover:underline font-medium">James Mitchell, CFA</Link>
            {' · '}Last Updated: {LAST_UPDATED}
            {' · '}
            <Link to="/methodology" className="text-sky-600 hover:underline">Editorial Methodology</Link>
          </p>
          <AdvertiserDisclosure />
        </div>
      </div>

      {/* Table of Contents */}
      <div className="container-site max-w-4xl py-8">
        <div className="bg-slate-50 border border-slate-200 rounded-xl p-5 mb-10">
          <p className="text-xs font-semibold text-slate-400 uppercase tracking-wider mb-3">In This Guide</p>
          <ol className="space-y-1.5 text-sm text-sky-700">
            {[
              ['What Is a Self-Directed IRA?', '#what-is'],
              ['How SDIRAs Differ from Standard IRAs', '#how-different'],
              ['IRS-Eligible Asset Classes', '#eligible-assets'],
              ['IRS Rules and Prohibited Transactions', '#irs-rules'],
              ['Tax Implications: Traditional vs. Roth SDIRA', '#tax'],
              ['Risks You Must Understand Before Investing', '#risks'],
              ['The Role of the Custodian', '#custodian'],
              ['How to Research SDIRA Custodians Yourself', '#research'],
              ['Common Mistakes to Avoid', '#mistakes'],
              ['Primary Sources & References', '#sources'],
            ].map(([label, href]) => (
              <li key={href}>
                <a href={href} className="hover:underline">{label}</a>
              </li>
            ))}
          </ol>
        </div>

        {/* Section 1 */}
        <section id="what-is" className="mb-12">
          <h2 className="text-2xl font-bold text-[#0F172A] mb-4">What Is a Self-Directed IRA?</h2>
          <p className="text-slate-600 leading-relaxed mb-4">
            A <strong>self-directed IRA (SDIRA)</strong> is an individual retirement account that gives the account holder direct control over investment decisions and allows a significantly wider range of asset classes than a conventional IRA offered by a bank or brokerage. While a standard IRA at Fidelity or Vanguard restricts you to publicly traded securities (stocks, bonds, mutual funds, ETFs), an SDIRA can hold alternative assets such as:
          </p>
          <ul className="list-disc list-inside text-slate-600 space-y-1.5 mb-4 ml-2">
            <li>Cryptocurrencies (Bitcoin, Ethereum, and others)</li>
            <li>Precious metals (IRS-approved gold, silver, platinum, palladium)</li>
            <li>Real estate (residential, commercial, raw land)</li>
            <li>Private equity and venture capital</li>
            <li>Promissory notes and private lending</li>
            <li>Tax liens and deeds</li>
          </ul>
          <p className="text-slate-600 leading-relaxed mb-4">
            The "self-directed" designation refers to the investor's role in directing investment decisions — not to the absence of a custodian. The IRS requires all IRAs, including SDIRAs, to be held by a qualified custodian or trustee. The custodian administers the account, maintains records, and ensures IRS compliance, but does not provide investment advice or evaluate the quality of your investment choices.
          </p>
          <div className="bg-amber-50 border border-amber-200 rounded-lg p-4 text-sm text-amber-900">
            <p className="font-semibold mb-1">Important:</p>
            <p>The IRS does not approve or endorse any specific SDIRA custodian, investment, or strategy. The existence of an SDIRA does not mean any particular investment is safe, suitable, or IRS-compliant. Investors bear full responsibility for verifying that their investments comply with IRS rules.</p>
          </div>
        </section>

        {/* Section 2 */}
        <section id="how-different" className="mb-12">
          <h2 className="text-2xl font-bold text-[#0F172A] mb-4">How SDIRAs Differ from Standard IRAs</h2>
          <div className="overflow-x-auto mb-4">
            <table className="w-full text-sm border-collapse">
              <thead>
                <tr className="bg-slate-100">
                  <th className="text-left p-3 font-semibold text-slate-700 border border-slate-200">Feature</th>
                  <th className="text-left p-3 font-semibold text-slate-700 border border-slate-200">Standard IRA</th>
                  <th className="text-left p-3 font-semibold text-slate-700 border border-slate-200">Self-Directed IRA</th>
                </tr>
              </thead>
              <tbody>
                {[
                  ['Asset types', 'Stocks, bonds, ETFs, mutual funds', 'Crypto, metals, real estate, private equity, and more'],
                  ['Custodian type', 'Bank, brokerage, or robo-advisor', 'Specialized SDIRA custodian'],
                  ['Investment control', 'Limited to custodian\'s offerings', 'Investor directs all decisions'],
                  ['Due diligence', 'Custodian may screen investments', 'Investor bears full responsibility'],
                  ['Fees', 'Typically low (0–0.25%/yr)', 'Higher — setup, annual, transaction, storage fees'],
                  ['Complexity', 'Low', 'High — requires understanding of IRS rules'],
                  ['Fraud risk', 'Lower (regulated securities)', 'Higher — alternative assets are less regulated'],
                ].map(([feature, standard, sdira]) => (
                  <tr key={feature} className="border-b border-slate-100">
                    <td className="p-3 font-medium text-slate-700 border border-slate-200">{feature}</td>
                    <td className="p-3 text-slate-600 border border-slate-200">{standard}</td>
                    <td className="p-3 text-slate-600 border border-slate-200">{sdira}</td>
                  </tr>
                ))}
              </tbody>
            </table>
          </div>
        </section>

        {/* Section 3 */}
        <section id="eligible-assets" className="mb-12">
          <h2 className="text-2xl font-bold text-[#0F172A] mb-4">IRS-Eligible Asset Classes</h2>
          <p className="text-slate-600 leading-relaxed mb-4">
            The IRS permits SDIRAs to hold a wide range of assets, but also explicitly prohibits certain types. The following are generally permitted:
          </p>
          <div className="grid md:grid-cols-2 gap-4 mb-6">
            {[
              {
                title: 'Cryptocurrencies',
                desc: 'Bitcoin, Ethereum, and other digital assets. Must be held by a qualified custodian — you cannot take personal possession. The IRS treats crypto as property for tax purposes (Notice 2014-21).',
                link: '/guides/crypto-in-retirement',
                linkLabel: 'Crypto in IRAs: Full Guide →',
              },
              {
                title: 'Precious Metals',
                desc: 'IRS-approved gold (≥99.5% purity), silver (≥99.9%), platinum (≥99.95%), and palladium (≥99.95%). Must be stored in an IRS-approved depository — not at home.',
                link: '/guides/precious-metals-in-ira',
                linkLabel: 'Precious Metals in IRAs: Full Guide →',
              },
              {
                title: 'Real Estate',
                desc: 'Residential, commercial, raw land, and rental properties. The IRA — not you personally — must own the property. All income and expenses must flow through the IRA.',
                link: null,
                linkLabel: null,
              },
              {
                title: 'Private Equity & Notes',
                desc: 'Interests in private companies, LLCs, limited partnerships, and promissory notes. Subject to prohibited transaction rules if the counterparty is a disqualified person.',
                link: null,
                linkLabel: null,
              },
            ].map((item) => (
              <div key={item.title} className="bg-white border border-slate-200 rounded-xl p-5">
                <h3 className="font-semibold text-[#0F172A] mb-2">{item.title}</h3>
                <p className="text-sm text-slate-600 leading-relaxed mb-2">{item.desc}</p>
                {item.link && (
                  <Link to={item.link} className="text-xs text-sky-600 hover:underline font-medium">{item.linkLabel}</Link>
                )}
              </div>
            ))}
          </div>
          <div className="bg-red-50 border border-red-200 rounded-lg p-4 text-sm text-red-900">
            <p className="font-semibold mb-1">Prohibited Assets (IRC §408(m)):</p>
            <p>Life insurance contracts, S-corporation stock, collectibles (art, antiques, rugs, gems, most coins), and alcoholic beverages are explicitly prohibited inside an IRA. Holding these triggers immediate distribution and potential penalties.</p>
          </div>
        </section>

        {/* Section 4 */}
        <section id="irs-rules" className="mb-12">
          <h2 className="text-2xl font-bold text-[#0F172A] mb-4">IRS Rules and Prohibited Transactions</h2>
          <p className="text-slate-600 leading-relaxed mb-4">
            The most important — and most frequently violated — SDIRA rules relate to <strong>prohibited transactions</strong> under IRC §4975. A prohibited transaction occurs when you engage in a transaction between your IRA and a <em>disqualified person</em>.
          </p>
          <p className="text-slate-600 leading-relaxed mb-4">
            <strong>Disqualified persons</strong> include: you (the IRA owner), your spouse, lineal descendants (children, grandchildren), lineal ascendants (parents, grandparents), and any entity in which a disqualified person owns 50% or more.
          </p>
          <div className="bg-slate-50 border border-slate-200 rounded-xl p-5 mb-4">
            <p className="font-semibold text-[#0F172A] mb-3">Examples of Prohibited Transactions:</p>
            <ul className="space-y-2 text-sm text-slate-600">
              <li className="flex gap-2"><span className="text-red-500 font-bold">✗</span> Buying a property from your SDIRA and living in it (self-dealing)</li>
              <li className="flex gap-2"><span className="text-red-500 font-bold">✗</span> Lending IRA funds to yourself or a family member</li>
              <li className="flex gap-2"><span className="text-red-500 font-bold">✗</span> Storing IRA-owned gold or crypto in your personal possession ("home storage" IRAs are not IRS-approved)</li>
              <li className="flex gap-2"><span className="text-red-500 font-bold">✗</span> Paying yourself a salary to manage an IRA-owned property</li>
              <li className="flex gap-2"><span className="text-red-500 font-bold">✗</span> Selling your personal property to your IRA</li>
            </ul>
          </div>
          <div className="bg-red-50 border border-red-200 rounded-lg p-4 text-sm text-red-900">
            <p className="font-semibold mb-1">Consequence of a Prohibited Transaction:</p>
            <p>If a prohibited transaction occurs, the IRA is treated as distributing its entire fair market value on January 1 of the year the transaction occurred. This triggers ordinary income tax on the full amount, plus a 10% early withdrawal penalty if you are under age 59½. The IRA ceases to exist as a tax-advantaged account.</p>
          </div>
        </section>

        {/* Section 5 */}
        <section id="tax" className="mb-12">
          <h2 className="text-2xl font-bold text-[#0F172A] mb-4">Tax Implications: Traditional vs. Roth SDIRA</h2>
          <div className="overflow-x-auto mb-4">
            <table className="w-full text-sm border-collapse">
              <thead>
                <tr className="bg-slate-100">
                  <th className="text-left p-3 font-semibold text-slate-700 border border-slate-200">Feature</th>
                  <th className="text-left p-3 font-semibold text-slate-700 border border-slate-200">Traditional SDIRA</th>
                  <th className="text-left p-3 font-semibold text-slate-700 border border-slate-200">Roth SDIRA</th>
                </tr>
              </thead>
              <tbody>
                {[
                  ['Contributions', 'Pre-tax (may be deductible)', 'After-tax (not deductible)'],
                  ['Growth', 'Tax-deferred', 'Tax-free (if qualified)'],
                  ['Withdrawals in retirement', 'Taxed as ordinary income', 'Tax-free (if qualified)'],
                  ['Required Minimum Distributions', 'Yes — starting at age 73', 'No RMDs during owner\'s lifetime'],
                  ['2026 contribution limit', '$7,000 ($8,000 if age 50+)', '$7,000 ($8,000 if age 50+)'],
                  ['Income limits', 'None for contributions', 'Phase-out begins at $150,000 (single) / $236,000 (MFJ)'],
                ].map(([feature, trad, roth]) => (
                  <tr key={feature} className="border-b border-slate-100">
                    <td className="p-3 font-medium text-slate-700 border border-slate-200">{feature}</td>
                    <td className="p-3 text-slate-600 border border-slate-200">{trad}</td>
                    <td className="p-3 text-slate-600 border border-slate-200">{roth}</td>
                  </tr>
                ))}
              </tbody>
            </table>
          </div>
          <p className="text-sm text-slate-500 italic">Source: IRS Publication 590-A and 590-B (2025). Consult a tax advisor for your specific situation.</p>
        </section>

        {/* Section 6 */}
        <section id="risks" className="mb-12">
          <h2 className="text-2xl font-bold text-[#0F172A] mb-4">Risks You Must Understand Before Investing</h2>
          <p className="text-slate-600 leading-relaxed mb-4">
            SDIRAs carry significantly higher risk than standard IRAs. The SEC and FINRA have both issued investor alerts specifically about SDIRA fraud and losses. Understanding these risks is essential before proceeding.
          </p>
          <div className="space-y-4">
            {[
              {
                title: 'Total Loss of Principal',
                desc: 'Alternative assets like cryptocurrencies and private equity can lose their entire value. Unlike FDIC-insured bank deposits, there is no government protection for SDIRA assets. You could lose everything you invest.',
                level: 'Critical',
                color: 'red',
              },
              {
                title: 'Extreme Volatility',
                desc: 'Cryptocurrency prices can decline 50–80% in a matter of months. Precious metals prices fluctuate with global economic conditions. These are not stable, income-producing assets suitable for all investors.',
                level: 'High',
                color: 'red',
              },
              {
                title: 'Liquidity Risk',
                desc: 'Many SDIRA assets (real estate, private equity, certain metals) cannot be quickly sold. If you need funds for an emergency or RMDs, you may be unable to liquidate in time without significant losses.',
                level: 'High',
                color: 'orange',
              },
              {
                title: 'Fraud and Scams',
                desc: 'The SEC has warned that SDIRA promoters sometimes use the IRS-required custodian relationship to falsely imply government approval of investments. Custodians do not verify the legitimacy or quality of investments.',
                level: 'High',
                color: 'orange',
              },
              {
                title: 'Valuation Difficulty',
                desc: 'Many alternative assets lack transparent market pricing. Overvalued assets can inflate your IRA balance on paper while actual liquidation value is far lower.',
                level: 'Medium',
                color: 'amber',
              },
              {
                title: 'Regulatory and Tax Complexity',
                desc: 'Prohibited transaction rules are complex and easily violated. A single mistake can trigger taxation of your entire IRA balance plus penalties. Professional tax and legal guidance is strongly recommended.',
                level: 'Medium',
                color: 'amber',
              },
            ].map((risk) => (
              <div key={risk.title} className={`p-4 rounded-xl border ${risk.color === 'red' ? 'bg-red-50 border-red-200' : risk.color === 'orange' ? 'bg-orange-50 border-orange-200' : 'bg-amber-50 border-amber-200'}`}>
                <div className="flex items-center gap-2 mb-1">
                  <span className={`text-xs font-bold px-2 py-0.5 rounded ${risk.color === 'red' ? 'bg-red-200 text-red-800' : risk.color === 'orange' ? 'bg-orange-200 text-orange-800' : 'bg-amber-200 text-amber-800'}`}>{risk.level} Risk</span>
                  <span className="font-semibold text-[#0F172A] text-sm">{risk.title}</span>
                </div>
                <p className="text-sm text-slate-600 leading-relaxed">{risk.desc}</p>
              </div>
            ))}
          </div>
        </section>

        {/* Section 7 */}
        <section id="custodian" className="mb-12">
          <h2 className="text-2xl font-bold text-[#0F172A] mb-4">The Role of the Custodian</h2>
          <p className="text-slate-600 leading-relaxed mb-4">
            Every SDIRA must be held by a qualified custodian — a bank, federally insured credit union, savings and loan association, or other entity approved by the IRS under IRC §408(a). The custodian's responsibilities include:
          </p>
          <ul className="list-disc list-inside text-slate-600 space-y-2 mb-4 ml-2">
            <li>Maintaining the IRA account and records</li>
            <li>Filing required IRS reports (Form 5498, Form 1099-R)</li>
            <li>Executing investment transactions at the account holder's direction</li>
            <li>Ensuring assets are held in the IRA's name (not the investor's personal name)</li>
          </ul>
          <div className="bg-sky-50 border border-sky-200 rounded-lg p-4 text-sm text-sky-900 mb-4">
            <p className="font-semibold mb-1">What Custodians Do NOT Do:</p>
            <p>SDIRA custodians are not investment advisors. They do not evaluate the quality, safety, or legitimacy of your investment choices. They do not verify whether an investment is a good idea, whether a promoter is honest, or whether an asset is fairly valued. Due diligence is entirely your responsibility.</p>
          </div>
        </section>

        {/* Section 8 */}
        <section id="research" className="mb-12">
          <h2 className="text-2xl font-bold text-[#0F172A] mb-4">How to Research SDIRA Custodians Yourself</h2>
          <p className="text-slate-600 leading-relaxed mb-4">
            Before opening an SDIRA, independently verify the following about any custodian you are considering:
          </p>
          <div className="space-y-3">
            {[
              {
                step: '1',
                title: 'Verify IRS Approval',
                desc: 'Confirm the custodian is a bank, trust company, or other IRS-approved entity. Ask for their charter number and verify with the relevant state banking regulator.',
              },
              {
                step: '2',
                title: 'Check FINRA BrokerCheck',
                desc: 'Search the custodian\'s name at brokercheck.finra.org to review any regulatory actions, complaints, or disciplinary history.',
              },
              {
                step: '3',
                title: 'Review SEC EDGAR',
                desc: 'Search sec.gov/cgi-bin/browse-edgar for any SEC filings or enforcement actions against the custodian.',
              },
              {
                step: '4',
                title: 'Check BBB Accreditation',
                desc: 'Review the custodian\'s BBB rating, accreditation status, and complaint history at bbb.org.',
              },
              {
                step: '5',
                title: 'Request a Full Fee Schedule',
                desc: 'Get the complete fee schedule in writing before opening an account. SDIRA fees can be complex — setup fees, annual fees, transaction fees, storage fees, and wire fees can add up significantly.',
              },
              {
                step: '6',
                title: 'Understand Custody Arrangements',
                desc: 'For crypto SDIRAs, ask specifically: who holds the private keys? Is storage cold (offline) or hot (online)? What insurance covers the assets? What happens if the custodian goes bankrupt?',
              },
            ].map((item) => (
              <div key={item.step} className="flex gap-4 p-4 bg-white border border-slate-200 rounded-xl">
                <div className="flex-shrink-0 w-8 h-8 bg-sky-100 text-sky-700 rounded-full flex items-center justify-center font-bold text-sm">{item.step}</div>
                <div>
                  <p className="font-semibold text-[#0F172A] text-sm mb-1">{item.title}</p>
                  <p className="text-sm text-slate-600 leading-relaxed">{item.desc}</p>
                </div>
              </div>
            ))}
          </div>
          <div className="mt-6 p-4 bg-indigo-50 border border-indigo-200 rounded-xl text-sm">
            <p className="font-semibold text-indigo-800 mb-2">Our Independent Provider Research</p>
            <p className="text-indigo-700 mb-3">
              IRA Research Hub has independently analyzed 22 SDIRA providers across 2,400+ data points including fee structures, custody arrangements, regulatory compliance records, and customer support quality. Our research is updated quarterly.
            </p>
            <div className="flex flex-wrap gap-3">
              <Link to="/crypto-ira/best-companies" className="text-indigo-700 font-medium hover:underline text-xs">Crypto IRA Provider Comparison →</Link>
              <Link to="/precious-metals-ira/best-companies" className="text-indigo-700 font-medium hover:underline text-xs">Precious Metals IRA Provider Comparison →</Link>
              <Link to="/guides/how-to-research-sdira-providers" className="text-indigo-700 font-medium hover:underline text-xs">Full Provider Research Guide →</Link>
            </div>
          </div>
        </section>

        {/* Section 9 */}
        <section id="mistakes" className="mb-12">
          <h2 className="text-2xl font-bold text-[#0F172A] mb-4">Common Mistakes to Avoid</h2>
          <div className="space-y-3">
            {[
              'Assuming the custodian has vetted the investment — they have not.',
              'Storing IRA-owned gold or crypto at home (this is a prohibited transaction).',
              'Transacting with a disqualified person without realizing it violates IRC §4975.',
              'Failing to take required minimum distributions (RMDs) from a Traditional SDIRA after age 73.',
              'Underfunding the IRA — alternative assets often require larger minimum investments and have higher fee structures that erode small balances.',
              'Choosing a custodian based solely on marketing materials without independent verification.',
              'Investing in illiquid assets without a plan for RMDs or emergency liquidity needs.',
            ].map((mistake, i) => (
              <div key={i} className="flex gap-3 p-3 bg-red-50 border border-red-100 rounded-lg text-sm">
                <span className="text-red-500 font-bold flex-shrink-0">✗</span>
                <span className="text-slate-700">{mistake}</span>
              </div>
            ))}
          </div>
        </section>

        {/* Primary Sources */}
        <section id="sources" className="mb-12 pt-6 border-t border-slate-200">
          <h3 className="text-sm font-semibold text-slate-500 uppercase tracking-wider mb-3">Primary Sources & References</h3>
          <ul className="space-y-1.5 text-xs text-slate-500">
            <li><a href="https://www.irs.gov/publications/p590a" target="_blank" rel="noopener noreferrer" className="text-sky-600 hover:underline">IRS Publication 590-A: Contributions to Individual Retirement Arrangements (IRAs)</a></li>
            <li><a href="https://www.irs.gov/publications/p590b" target="_blank" rel="noopener noreferrer" className="text-sky-600 hover:underline">IRS Publication 590-B: Distributions from Individual Retirement Arrangements (IRAs)</a></li>
            <li><a href="https://www.irs.gov/retirement-plans/self-directed-iras" target="_blank" rel="noopener noreferrer" className="text-sky-600 hover:underline">IRS: Self-Directed IRAs and the Risk of Fraud</a></li>
            <li><a href="https://www.sec.gov/investor/alerts/sdira.htm" target="_blank" rel="noopener noreferrer" className="text-sky-600 hover:underline">SEC Investor Alert: Self-Directed IRAs and the Risk of Fraud</a></li>
            <li><a href="https://www.finra.org/investors/alerts/self-directed-iras-look-custodian" target="_blank" rel="noopener noreferrer" className="text-sky-600 hover:underline">FINRA Investor Alert: Self-Directed IRAs — Look Before You Leap</a></li>
            <li><a href="https://www.irs.gov/irb/2014-16_IRB#NOT-2014-21" target="_blank" rel="noopener noreferrer" className="text-sky-600 hover:underline">IRS Notice 2014-21: Virtual Currency Guidance</a></li>
          </ul>
        </section>

        {/* Risk Disclaimer */}
        <div className="mt-8 p-5 bg-amber-50 border border-amber-200 rounded-lg text-sm text-amber-900">
          <p className="font-semibold mb-1">Important Disclaimer</p>
          <p>
            This page is for informational and educational purposes only and does not constitute financial, investment, tax, or legal advice. Self-directed IRAs involve significant risks, including the potential for total loss of principal. Cryptocurrency and precious metals investments are highly volatile and may not be suitable for all investors. Past performance is not indicative of future results. Always consult a qualified, licensed financial advisor, tax professional, and attorney before making any investment decisions.{' '}
            <Link to="/editorial-policy" className="underline font-medium">See our Editorial Policy</Link> for full disclosure of how IRA Research Hub is compensated.
          </p>
        </div>
      </div>
      {/* ── Newsletter Signup ─────────────────────────────────────────── */}
      <div className="container-site py-10 max-w-3xl">
        
        {/* Related Links */}

        <div className="mt-10 mb-6">

          <RelatedLinks variant="crypto-guide" title="Related Guides &amp; Reviews" />

        </div>
<NewsletterSignup />
      </div>
    </>
  )
}
