import { Link } from 'react-router-dom'
import SEO from '../components/SEO'
import AdvertiserDisclosure from '../components/AdvertiserDisclosure'
import NewsletterSignup from '../components/NewsletterSignup';
import RelatedLinks from '../components/RelatedLinks';

const LAST_UPDATED = "March 22, 2026"
const PUBLISH_DATE = "2026-03-22"

// Normalized fee data — sourced from provider disclosures, March 2026
const goldProviders = [
  {
    name: "Genesis Gold Group",
    slug: "genesis-gold-group",
    reviewPath: "/precious-metals-ira/genesis-gold-group-review",
    setupFee: 0,
    annualFee: 160,
    annualFeeDisplay: "$160/year",
    storageFee: "Included",
    minimumInvestment: 10000,
    minimumInvestmentDisplay: "$10,000",
    custodian: "Equity Trust / STRATA",
    storage: "Brinks",
    metalsOffered: ["Gold", "Silver", "Platinum", "Palladium"],
    insuranceCoverage: "Lloyd's of London",
    irsApproved: true,
    scoreOverall: 9.4,
    scoreFees: 9.2,
    scoreSecurity: 9.6,
    highlight: "#1 Gold IRA — transparent fees, faith-based values, all 4 metals",
    affiliateUrl: "https://genesisgoldgroup.com/?ref=iraresearchhub",
  },
  {
    name: "Goldco",
    slug: "goldco",
    reviewPath: "/precious-metals-ira/goldco-review",
    setupFee: 0,
    annualFee: 200,
    annualFeeDisplay: "$175–$225/year",
    storageFee: "Included",
    minimumInvestment: 25000,
    minimumInvestmentDisplay: "$25,000",
    custodian: "Kingdom Trust",
    storage: "Brinks / Delaware Depository",
    metalsOffered: ["Gold", "Silver", "Platinum", "Palladium"],
    insuranceCoverage: "Lloyd's of London",
    irsApproved: true,
    scoreOverall: 9.2,
    scoreFees: 8.9,
    scoreSecurity: 9.2,
    highlight: "Notable for $25K–$50K investors — 4 metals, strong brand",
    affiliateUrl: "https://www.goldco.com/?ref=iraresearchhub",
  },
  {
    name: "Augusta Precious Metals",
    slug: "augusta-precious-metals",
    reviewPath: "/precious-metals-ira/augusta-precious-metals-review",
    setupFee: 0,
    annualFee: 180,
    annualFeeDisplay: "$180/year",
    storageFee: "Included",
    minimumInvestment: 50000,
    minimumInvestmentDisplay: "$50,000",
    custodian: "Equity Trust",
    storage: "Delaware Depository",
    metalsOffered: ["Gold", "Silver"],
    insuranceCoverage: "Lloyd's of London",
    irsApproved: true,
    scoreOverall: 9.1,
    scoreFees: 8.5,
    scoreSecurity: 9.4,
    highlight: "Best customer education — dedicated 1-on-1 support, lifetime service",
    affiliateUrl: "https://www.augustapreciousmetals.com/?ref=iraresearchhub",
  },
  {
    name: "Birch Gold Group",
    slug: "birch-gold-group",
    reviewPath: "/precious-metals-ira/birch-gold-group-review",
    setupFee: 0,
    annualFee: 200,
    annualFeeDisplay: "$200/year",
    storageFee: "Included",
    minimumInvestment: 10000,
    minimumInvestmentDisplay: "$10,000",
    custodian: "Equity Trust",
    storage: "Delaware Depository",
    metalsOffered: ["Gold", "Silver", "Platinum", "Palladium"],
    insuranceCoverage: "Lloyd's of London",
    irsApproved: true,
    scoreOverall: 9.1,
    scoreFees: 8.5,
    scoreSecurity: 8.8,
    highlight: "4 metals, $10K minimum — good for diversified portfolios",
    affiliateUrl: null,
  },
  {
    name: "American Hartford Gold",
    slug: "american-hartford-gold",
    reviewPath: "/precious-metals-ira/american-hartford-gold-review",
    setupFee: 0,
    annualFee: 180,
    annualFeeDisplay: "$180/year",
    storageFee: "Included",
    minimumInvestment: 10000,
    minimumInvestmentDisplay: "$10,000",
    custodian: "Equity Trust",
    storage: "Brinks / Delaware Depository",
    metalsOffered: ["Gold", "Silver", "Platinum"],
    insuranceCoverage: "Lloyd's of London",
    irsApproved: true,
    scoreOverall: 8.8,
    scoreFees: 8.7,
    scoreSecurity: 8.6,
    highlight: "Competitive fees, strong customer service",
    affiliateUrl: "https://www.americanhartfordgold.com/?ref=iraresearchhub",
  },
  {
    name: "Lear Capital",
    slug: "lear-capital",
    reviewPath: "/precious-metals-ira/lear-capital-review",
    setupFee: 0,
    annualFee: 280,
    annualFeeDisplay: "$280/year",
    storageFee: "Included",
    minimumInvestment: 7500,
    minimumInvestmentDisplay: "$7,500",
    custodian: "Equity Trust",
    storage: "Brinks",
    metalsOffered: ["Gold", "Silver", "Platinum", "Palladium"],
    insuranceCoverage: "Lloyd's of London",
    irsApproved: true,
    scoreOverall: 8.5,
    scoreFees: 7.8,
    scoreSecurity: 8.5,
    highlight: "Lowest minimum ($7,500) — 4 metals available",
    affiliateUrl: "https://www.learcapital.com/?ref=iraresearchhub",
  },
]

const dataSchema = {
  "@context": "https://schema.org",
  "@type": "Dataset",
  "name": "Gold IRA Fees Comparison 2026",
  "description": "Proprietary fee data for all major gold IRA companies, including annual fees, minimums, storage costs, and custodian details. Sourced from provider disclosures, March 2026.",
  "url": "https://iraresearchhub.com/research/gold-ira-fees-2026",
  "creator": {
    "@type": "Organization",
    "@id": "https://iraresearchhub.com",
    "name": "IRA Research Hub"
  },
  "datePublished": PUBLISH_DATE,
  "dateModified": PUBLISH_DATE,
  "license": "https://creativecommons.org/licenses/by/4.0/",
  "variableMeasured": ["Annual Fee", "Minimum Investment", "Setup Fee", "Storage Fee", "Custodian"]
}

const faqSchema = {
  "@context": "https://schema.org",
  "@type": "FAQPage",
  "mainEntity": [
    {
      "@type": "Question",
      "name": "What are the typical fees for a gold IRA in 2026?",
      "acceptedAnswer": {
        "@type": "Answer",
        "text": "Gold IRA fees in 2026 typically include: (1) Setup fee: $0 at most providers; (2) Annual custodian fee: $75–$300/year; (3) Storage fee: usually included in the annual fee, ranging from $100–$200/year for segregated storage; (4) Transaction fees: usually a fixed spread over spot price (no per-trade percentage). Total annual cost typically ranges from $160–$300/year."
      }
    },
    {
      "@type": "Question",
      "name": "Which gold IRA company has the lowest fees?",
      "acceptedAnswer": {
        "@type": "Answer",
        "text": "Genesis Gold Group has the lowest annual fee at $160/year with a $10,000 minimum. Augusta Precious Metals and American Hartford Gold both charge $180/year. Lear Capital is the most expensive at $280/year but has the lowest minimum at $7,500."
      }
    },
    {
      "@type": "Question",
      "name": "What is the minimum investment for a gold IRA?",
      "acceptedAnswer": {
        "@type": "Answer",
        "text": "Gold IRA minimums in 2026 range from $7,500 (Lear Capital) to $50,000 (Augusta Precious Metals). Most providers require $10,000–$25,000. Augusta's $50,000 minimum is the highest in the industry but comes with premium education and lifetime support."
      }
    },
    {
      "@type": "Question",
      "name": "Are gold IRA fees tax-deductible?",
      "acceptedAnswer": {
        "@type": "Answer",
        "text": "Gold IRA fees are generally not tax-deductible when paid from outside the IRA. However, if fees are paid directly from the IRA account, they reduce your taxable distribution. Consult a tax advisor for your specific situation."
      }
    },
    {
      "@type": "Question",
      "name": "What is a segregated storage fee for a gold IRA?",
      "acceptedAnswer": {
        "@type": "Answer",
        "text": "Segregated storage means your gold is stored separately from other customers' metals in a dedicated vault. This typically costs $100–$200/year more than commingled storage. All providers in our comparison offer segregated storage as standard."
      }
    }
  ]
}

const speakableSchema = {
  "@context": "https://schema.org",
  "@type": "WebPage",
  "speakable": {
    "@type": "SpeakableSpecification",
    "cssSelector": [".speakable-summary", "h1", ".citation-block"]
  },
  "url": "https://iraresearchhub.com/research/gold-ira-fees-2026"
}

function ScoreBadge({ score }: { score: number }) {
  const color = score >= 9 ? "bg-green-100 text-green-800" : score >= 8 ? "bg-amber-100 text-amber-800" : "bg-red-100 text-red-800"
  return <span className={`inline-flex items-center px-2 py-0.5 rounded text-xs font-bold ${color}`}>{score.toFixed(1)}</span>
}

export default function GoldIRAFees2026Page() {
  const sortedByFee = [...goldProviders].sort((a, b) => a.annualFee - b.annualFee)
  const sortedByMin = [...goldProviders].sort((a, b) => a.minimumInvestment - b.minimumInvestment)

  return (
    <>
      <SEO
        title="Gold IRA Fees 2026: Full Comparison of All 6 Providers"
        description="Gold IRA fees compared: annual fees, minimums, storage costs, and custodians for Augusta, Goldco, Genesis Gold, Birch Gold, AHG, and Lear Capital. Updated March 2026."
        canonical="/research/gold-ira-fees-2026"
        ogType="article"
      />
      <script type="application/ld+json" dangerouslySetInnerHTML={{ __html: JSON.stringify(dataSchema) }} />
      <script type="application/ld+json" dangerouslySetInnerHTML={{ __html: JSON.stringify(faqSchema) }} />
      <script type="application/ld+json" dangerouslySetInnerHTML={{ __html: JSON.stringify(speakableSchema) }} />

      {/* Hero */}
      <section className="bg-[#F8FAFC] border-b border-slate-200">
        <div className="container-site py-12">
          <div className="flex flex-wrap items-center gap-2 mb-4">
            <Link to="/precious-metals-ira" className="text-sm text-[#64748B] hover:text-[#D97706]">Precious Metals IRAs</Link>
            <span className="text-slate-300">/</span>
            <span className="text-sm text-[#0F172A]">Gold IRA Fees 2026</span>
          </div>
          <div className="inline-flex items-center px-2.5 py-0.5 rounded-full text-xs font-medium bg-amber-100 text-amber-700 mb-4">
            Proprietary Data · Updated {LAST_UPDATED}
          </div>
          <h1 className="text-4xl font-bold text-[#0F172A] mb-3">Gold IRA Fees 2026: Full Comparison</h1>
              <AdvertiserDisclosure />
          <p className="text-sm text-slate-400 mt-2">
            By <a href="/author/james-mitchell" className="text-[#D97706] hover:underline">James Mitchell, CFA</a> · Last updated: {LAST_UPDATED} · <a href="/methodology" className="text-[#D97706] hover:underline">Methodology</a>
          </p>
          <p className="speakable-summary text-lg text-[#64748B] max-w-2xl mt-3">
            We collected fee data directly from all 6 major gold IRA providers in March 2026. 
            Annual fees range from <strong>$160/year</strong> (Genesis Gold Group) to <strong>$280/year</strong> (Lear Capital). 
            Minimums range from <strong>$7,500</strong> to <strong>$50,000</strong>.
          </p>
          {/* Key Stats */}
          <div className="grid grid-cols-2 md:grid-cols-4 gap-4 mt-6">
            {[
              { label: "Providers Compared", value: "6" },
              { label: "Lowest Annual Fee", value: "$160/yr" },
              { label: "Lowest Minimum", value: "$7,500" },
              { label: "Data Updated", value: "Mar 2026" },
            ].map((stat) => (
              <div key={stat.label} className="bg-white border border-slate-200 rounded-lg p-4 text-center">
                <p className="text-2xl font-bold text-[#D97706]">{stat.value}</p>
                <p className="text-xs text-slate-500 mt-1">{stat.label}</p>
              </div>
            ))}
          </div>
        </div>
      </section>

      {/* Main Fee Table */}
      <section className="section-padding">
        <div className="container-site">
          <h2 className="text-2xl font-bold text-[#0F172A] mb-2">Complete Fee Comparison Table</h2>
          <p className="text-sm text-slate-500 mb-4">All data sourced from provider disclosures as of March 2026. Annual fees include custodian + storage unless noted.</p>
          <div className="overflow-x-auto mb-8">
            <table className="w-full border-collapse">
              <thead>
                <tr className="bg-slate-50">
                  <th className="text-left p-3 text-sm font-semibold text-slate-600 border border-slate-200">Provider</th>
                  <th className="text-center p-3 text-sm font-semibold text-slate-600 border border-slate-200">Setup Fee</th>
                  <th className="text-center p-3 text-sm font-semibold text-slate-600 border border-slate-200">Annual Fee</th>
                  <th className="text-center p-3 text-sm font-semibold text-slate-600 border border-slate-200">Minimum</th>
                  <th className="text-center p-3 text-sm font-semibold text-slate-600 border border-slate-200">Custodian</th>
                  <th className="text-center p-3 text-sm font-semibold text-slate-600 border border-slate-200">Metals</th>
                  <th className="text-center p-3 text-sm font-semibold text-slate-600 border border-slate-200">Score</th>
                </tr>
              </thead>
              <tbody>
                {goldProviders.map((p) => (
                  <tr key={p.slug} className="hover:bg-slate-50">
                    <td className="p-3 border border-slate-200">
                      <Link to={p.reviewPath} className="font-semibold text-[#D97706] hover:underline text-sm">
                        {p.name}
                      </Link>
                      <p className="text-xs text-slate-500 mt-0.5">{p.highlight}</p>
                    </td>
                    <td className="p-3 text-center text-sm text-[#0F172A] border border-slate-200">
                      {p.setupFee === 0 ? <span className="text-green-600 font-semibold">$0</span> : `$${p.setupFee}`}
                    </td>
                    <td className="p-3 text-center text-sm font-semibold text-[#0F172A] border border-slate-200">{p.annualFeeDisplay}</td>
                    <td className="p-3 text-center text-sm text-[#0F172A] border border-slate-200">{p.minimumInvestmentDisplay}</td>
                    <td className="p-3 text-center text-xs text-slate-500 border border-slate-200">{p.custodian}</td>
                    <td className="p-3 text-center text-xs text-slate-500 border border-slate-200">{p.metalsOffered.join(", ")}</td>
                    <td className="p-3 text-center border border-slate-200">
                      <ScoreBadge score={p.scoreOverall} />
                    </td>
                  </tr>
                ))}
              </tbody>
            </table>
          </div>

          {/* Sorted by Fee */}
          <div className="grid md:grid-cols-2 gap-8 mb-8">
            <div>
              <h2 className="text-xl font-bold text-[#0F172A] mb-3">Ranked by Annual Fee (Lowest First)</h2>
              <div className="space-y-2">
                {sortedByFee.map((p, i) => (
                  <div key={p.slug} className="flex items-center justify-between bg-slate-50 rounded-lg p-3 border border-slate-200">
                    <div className="flex items-center gap-3">
                      <span className="text-sm font-bold text-slate-400">#{i + 1}</span>
                      <Link to={p.reviewPath} className="text-sm font-semibold text-[#D97706] hover:underline">{p.name}</Link>
                    </div>
                    <span className="text-sm font-bold text-[#0F172A]">{p.annualFeeDisplay}</span>
                  </div>
                ))}
              </div>
            </div>
            <div>
              <h2 className="text-xl font-bold text-[#0F172A] mb-3">Ranked by Minimum Investment (Lowest First)</h2>
              <div className="space-y-2">
                {sortedByMin.map((p, i) => (
                  <div key={p.slug} className="flex items-center justify-between bg-slate-50 rounded-lg p-3 border border-slate-200">
                    <div className="flex items-center gap-3">
                      <span className="text-sm font-bold text-slate-400">#{i + 1}</span>
                      <Link to={p.reviewPath} className="text-sm font-semibold text-[#D97706] hover:underline">{p.name}</Link>
                    </div>
                    <span className="text-sm font-bold text-[#0F172A]">{p.minimumInvestmentDisplay}</span>
                  </div>
                ))}
              </div>
            </div>
          </div>

          {/* Citation Block */}
          <div className="citation-block bg-amber-50 border-l-4 border-amber-400 p-5 rounded-lg mb-8">
            <p className="text-sm font-semibold text-amber-900 mb-1">Key Finding</p>
            <p className="text-sm text-amber-800">
              The average annual gold IRA fee in 2026 is <strong>$200/year</strong>. No provider charges a setup fee. 
              All providers include storage in their annual fee. The lowest-cost option is Genesis Gold Group at <strong>$160/year</strong> with a <strong>$10,000 minimum</strong>.
            </p>
          </div>

          {/* FAQ */}
          <h2 className="text-2xl font-bold text-[#0F172A] mb-4">Frequently Asked Questions</h2>
          <div className="space-y-4 mb-8">
            {faqSchema.mainEntity.map((item) => (
              <details key={item.name} className="bg-slate-50 border border-slate-200 rounded-lg p-4">
                <summary className="font-semibold text-[#0F172A] cursor-pointer">{item.name}</summary>
                <p className="mt-2 text-sm text-[#334155]">{item.acceptedAnswer.text}</p>
              </details>
            ))}
          </div>

          {/* Bottom CTA */}
          <div className="bg-amber-50 border border-amber-200 rounded-xl p-6 text-center">
            <h2 className="text-xl font-bold text-[#0F172A] mb-2">Ready to compare providers in full?</h2>
            <p className="text-sm text-slate-600 mb-4">
              See our full rankings of all 12 precious metals IRA providers, including independent scores and affiliate disclosures.
            </p>
            <Link
              to="/precious-metals-ira/best-companies"
              className="inline-flex items-center justify-center px-6 py-3 bg-[#D97706] text-white font-semibold rounded-lg hover:bg-[#B45309] transition-colors"
            >
              See Full Gold IRA Rankings →
            </Link>
          </div>
        </div>
      </section>
      {/* ── Newsletter Signup ─────────────────────────────────────────── */}
      <div className="container-site py-10 max-w-3xl">
        
        {/* Related Links */}

        <div className="mt-10 mb-6">

          <RelatedLinks variant="research" title="Related Guides &amp; Reviews" />

        </div>
<NewsletterSignup />
      </div>
    </>
  )
}
