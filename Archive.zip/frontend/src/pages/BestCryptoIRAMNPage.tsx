import StateGuideTemplate from '../components/StateGuideTemplate'

export default function BestCryptoIRAMNPage() {
  return (
    <StateGuideTemplate
      stateName="Minnesota"
      stateAbbr="MN"
      slug="minnesota"
    />
  )
}
