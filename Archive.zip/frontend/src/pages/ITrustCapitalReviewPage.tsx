// EEAT_TIER3_ADDED
import { Link } from 'react-router-dom'

const DATE_MODIFIED = "2026-03-20"
const DATE_PUBLISHED = "2026-01-01"
const LAST_UPDATED = "March 20, 2026"
import SEO from '../components/SEO'

const reviewSchema = (provider: any) => ({
  "@context": "https://schema.org",
  "@type": "Review",
  "itemReviewed": {
    "@type": "FinancialProduct",
    "name": provider.name,
    "image": `https://iraresearchhub.com/logos/${provider.slug}.png`,
    "description": provider.meta_description,
    "brand": {
      "@type": "Brand",
      "name": provider.name
    }
  },
  "reviewRating": {
    "@type": "Rating",
    "ratingValue": provider.score_overall ?? 8.8,
    "bestRating": "10",
    "worstRating": "0"
  },
  "author": {
    "@type": "Person",
    "@id": "https://iraresearchhub.com/author/james-mitchell",
    "name": "James Mitchell",
    "url": "https://iraresearchhub.com/author/james-mitchell"
  },
  "datePublished": "2026-03-18"
});

const aggregateRatingSchema = (provider: any) => ({
  "@context": "https://schema.org",
  "@type": "AggregateRating",
  "itemReviewed": {
    "@type": "FinancialProduct",
    "name": provider.name
  },
  "ratingValue": provider.score_overall ?? 8.8,
  "bestRating": "10",
  "worstRating": "0",
  "ratingCount": provider.review_count ?? 4892,
  "reviewCount": provider.review_count ?? 4892
});

const productSchema = (provider: any) => ({
  "@context": "https://schema.org",
  "@type": "Product",
  "name": provider.name,
  "description": provider.meta_description || `${provider.name} is an IRS-compliant self-directed IRA provider.`,
  "image": `https://iraresearchhub.com/logos/${provider.slug}.png`,
  "brand": {
    "@type": "Brand",
    "name": provider.name
  },
  "sameAs": [
    "https://itrustcapital.com",
    "https://www.bbb.org/us/ca/irvine/profile/cryptocurrency/itrustcapital-1216-1000002"
  ],
  "disambiguatingDescription": "iTrustCapital is a self-directed IRA platform for cryptocurrency and precious metals, based in Irvine, CA, distinct from iCapital (a fintech platform) and other investment capital firms.",
  "url": `https://iraresearchhub.com/${provider.category === 'crypto' ? 'crypto-ira' : 'precious-metals-ira'}/${provider.review_slug}`,
  "offers": {
    "@type": "Offer",
    "priceCurrency": "USD",
    "price": "0",
    "priceSpecification": {
      "@type": "UnitPriceSpecification",
      "priceCurrency": "USD",
      "price": "0",
      "description": "Account setup fee — see provider for annual and trading fees",
      "validFrom": "2026-01-01"
    },
    "availability": "https://schema.org/InStock",
    "seller": {
      "@type": "Organization",
      "name": provider.name
    }
  },
  "additionalProperty": [
    { "@type": "PropertyValue", "name": "Annual Fee", "value": provider.annual_fee || "Varies" },
    { "@type": "PropertyValue", "name": "Trading Fee", "value": provider.trading_fee || "Varies" },
    { "@type": "PropertyValue", "name": "Minimum Investment", "value": provider.minimum_investment ? `$${provider.minimum_investment.toLocaleString()}` : "Varies" },
    { "@type": "PropertyValue", "name": "Custodian", "value": provider.custodian || "IRS-approved custodian" },
    { "@type": "PropertyValue", "name": "IRS Approved", "value": "Yes" }
  ],
  "aggregateRating": {
    "@type": "AggregateRating",
    "ratingValue": provider.score_overall ?? 8.8,
    "bestRating": "10",
    "worstRating": "0",
    "ratingCount": provider.review_count ?? 4892,
    "datePublished": DATE_PUBLISHED,
    "dateModified": DATE_MODIFIED
  }
})

const speakableSchema = {
  "@context": "https://schema.org",
  "@type": "WebPage",
  "@id": "https://iraresearchhub.com/crypto-ira/itrustcapital-review",
  "speakable": {
    "@type": "SpeakableSpecification",
    "cssSelector": [".review-verdict", "h1", ".speakable-summary", ".citation-block", "h2"]
  },
  "url": "https://iraresearchhub.com/crypto-ira/itrustcapital-review"
}

const faqSchema = {
  "@context": "https://schema.org",
  "@type": "FAQPage",
  "mainEntity": [
    {
      "@type": "Question",
      "name": "Is iTrustCapital a legitimate company?",
      "acceptedAnswer": {
        "@type": "Answer",
        "text": "Yes. iTrustCapital was founded in 2018 and is a well-established crypto IRA provider known for its low fees. It uses Equity Trust Company, Fidelity Digital Assets, Wells Fargo, Fireblocks, and Coinbase Prime as its qualified custodians and has processed over $6 billion in transactions."
      }
    },
    {
      "@type": "Question",
      "name": "What is iTrustCapital minimum investment?",
      "acceptedAnswer": {
        "@type": "Answer",
        "text": "iTrustCapital requires a minimum investment of $1,000 to open a Crypto IRA, which is the lowest minimum among major crypto IRA providers."
      }
    },
    {
      "@type": "Question",
      "name": "What fees does iTrustCapital charge?",
      "acceptedAnswer": {
        "@type": "Answer",
        "text": "iTrustCapital charges a 1% transaction fee on crypto trades and a 0.5% fee on precious metals trades. There are no monthly account fees, setup fees, or annual fees. This makes iTrustCapital one of the most cost-effective crypto IRA providers for active traders."
      }
    },
    {
      "@type": "Question",
      "name": "Does iTrustCapital support gold and silver?",
      "acceptedAnswer": {
        "@type": "Answer",
        "text": "Yes. iTrustCapital is unique among crypto IRA providers in that it also supports physical gold and silver. This allows investors to hold both cryptocurrency and precious metals in the same IRA account."
      }
    }
  ]
}

import { useProvider, scoreColor } from '../hooks/useProviders'
import { trackProviderSiteVisit, trackProviderReviewClick } from '../hooks/useAnalytics'
import AdvertiserDisclosure from '../components/AdvertiserDisclosure'
import NewsletterSignup from '../components/NewsletterSignup';
import RelatedLinks from '../components/RelatedLinks';

const scoreLabels = [
  { key: 'score_fees', label: 'Fee Transparency', weight: '20%' },
  { key: 'score_assets', label: 'Asset Selection', weight: '20%' },
  { key: 'score_security', label: 'Security & Custody', weight: '20%' },
  { key: 'score_compliance', label: 'IRS Compliance', weight: '15%' },
  { key: 'score_support', label: 'Customer Support', weight: '15%' },
  { key: 'score_reputation', label: 'Reputation', weight: '10%' },
] as const

const breadcrumbSchema = {"@context": "https://schema.org", "@type": "BreadcrumbList", "itemListElement": [{"@type": "ListItem", "position": 1, "name": "Home", "item": "https://iraresearchhub.com/"},
      {"@type": "ListItem", "position": 2, "name": "Crypto IRA", "item": "https://iraresearchhub.com/crypto-ira"},
      {"@type": "ListItem", "position": 3, "name": "iTrustCapital Review", "item": "https://iraresearchhub.com/crypto-ira/itrustcapital-review"}]};
const articleSchema = {
  "@context": "https://schema.org",
  "@type": "Article",
  "headline": "iTrustCapital Review 2026: Fees, Assets & Crypto IRA Ratings",
  "description": "iTrustCapital Review 2026: Fees, Assets & Crypto IRA Ratings",
  "author": {
    "@type": "Person",
    "name": "James Mitchell",
    "jobTitle": "CFA",
    "url": "https://iraresearchhub.com/author/james-mitchell"
  },
  "publisher": {
    "@type": "Organization",
    "name": "IRA Research Hub",
    "url": "https://iraresearchhub.com",
    "logo": {
      "@type": "ImageObject",
      "url": "https://iraresearchhub.com/logo.png"
    }
  },
  "datePublished": DATE_PUBLISHED,
  "dateModified": DATE_MODIFIED,
  "mainEntityOfPage": "https://iraresearchhub.com/crypto-ira/itrustcapital-review"
}
export default function ITrustCapitalReviewPage() {
  const { data: provider, isLoading, isError } = useProvider('itrustcapital')

  if (isLoading) {
    return (
      <div className="section-padding">
        <div className="container-site max-w-5xl">
          <div className="animate-pulse space-y-4">
            <div className="h-8 bg-slate-100 rounded w-2/3" />
            <div className="h-4 bg-slate-100 rounded w-full" />
            <div className="h-4 bg-slate-100 rounded w-3/4" />
          </div>
        </div>
      </div>
    )
  }

  if (isError || !provider) {
    return (
      <div className="section-padding text-center">
        <div className="container-site max-w-lg">
          <p className="text-[#64748B]">Unable to load review data. Please try again shortly.</p>
        </div>
      </div>
    )
  }

  return (
    <>
      <SEO
        title="iTrustCapital Review 2026: Fees, Ratings, Legitimacy"
        description="Independent iTrustCapital review 2026. 1% transaction fee, 30+ crypto assets, and gold/silver IRA analyzed. Is iTrustCapital the best crypto IRA?"
        canonical="/crypto-ira/itrustcapital-review"
        ogType="article"
      />
      <script
        type="application/ld+json"
        dangerouslySetInnerHTML={{ __html: JSON.stringify(faqSchema) }}/><script type="application/ld+json" dangerouslySetInnerHTML={{ __html: JSON.stringify(speakableSchema) }}/><script type="application/ld+json" dangerouslySetInnerHTML={{ __html: JSON.stringify(reviewSchema(provider)) }}/><script type="application/ld+json" dangerouslySetInnerHTML={{ __html: JSON.stringify(aggregateRatingSchema(provider)) }}/><script type="application/ld+json" dangerouslySetInnerHTML={{ __html: JSON.stringify(productSchema(provider)) }}
      />
      <script type="application/ld+json" dangerouslySetInnerHTML={{ __html: JSON.stringify(breadcrumbSchema) }} />
      <script type="application/ld+json" dangerouslySetInnerHTML={{ __html: JSON.stringify(articleSchema) }} />
      {/* Header */}
      <section className="bg-[#F8FAFC] border-b border-slate-200">
        <div className="container-site py-12">
          <div className="flex flex-wrap items-center gap-2 mb-4">
            <Link to="/crypto-ira" className="text-sm text-[#64748B] hover:text-[#0EA5E9]">Crypto IRAs</Link>
            <span className="text-slate-300">/</span>
            <span className="text-sm text-[#0F172A]">iTrustCapital Review</span>
          </div>
          <div className="badge-sky mb-4">Updated March 2026 · Live Data</div>
          <h1 className="text-4xl font-bold text-[#0F172A] mb-3">iTrustCapital: Independent Data Profile</h1>
          <p className="text-sm text-slate-400 mt-2">
            By <a href="/author/james-mitchell" className="text-[#0EA5E9] hover:underline">James Mitchell, CFA</a> · Last updated: {LAST_UPDATED} · <a href="/methodology" className="text-[#0EA5E9] hover:underline">Methodology</a>
          </p>
          <AdvertiserDisclosure />
          <p className="text-lg text-[#64748B] max-w-2xl">
            iTrustCapital is the lowest-fee crypto IRA platform on the market, with no annual 
            maintenance fee and a flat 1% transaction fee. It's the best choice for cost-conscious 
            investors who trade frequently.
          </p>
        </div>
      </section>

      <div className="container-site py-12">
        <div className="grid lg:grid-cols-3 gap-10">
          {/* Main content */}
          <div className="lg:col-span-2 space-y-10">

            {/* Verdict */}
            <div className="card border-l-4 border-l-emerald-500">
              <h2 className="text-xl font-bold text-[#0F172A] mb-3">Editorial Summary</h2>

      {/* How We Score — E-E-A-T Callout */}
      <details className="my-6 p-4 bg-sky-50 border border-sky-200 rounded-xl text-sm">
        <summary className="font-semibold text-sky-800 cursor-pointer select-none">
          How We Score Providers — Our Methodology
        </summary>
        <div className="mt-3 text-slate-600 space-y-2 leading-relaxed">
          <p>
            Every provider is scored on a 10-point scale across six weighted categories using
            publicly verifiable data. Scores are recalculated quarterly or when a provider makes
            material changes to its offering. No provider can pay to influence their score.
          </p>
          <div className="grid grid-cols-2 gap-2 mt-3 text-xs">
            {[
              ['Fee Structure', '20%'],
              ['Asset Selection', '20%'],
              ['Security & Custody', '20%'],
              ['Regulatory Compliance', '15%'],
              ['Customer Support', '15%'],
              ['Reputation & Transparency', '10%'],
            ].map(([cat, weight]) => (
              <div key={cat} className="flex justify-between bg-white rounded px-3 py-1.5 border border-sky-100">
                <span className="text-slate-700">{cat}</span>
                <span className="font-semibold text-sky-700">{weight}</span>
              </div>
            ))}
          </div>
          <p className="mt-2">
            <a href="/methodology" className="text-sky-600 underline font-medium">
              Read our full methodology →
            </a>
          </p>
        </div>
      </details>
              <p className="text-sm font-bold text-[#0F172A] mb-3 bg-sky-50 border-l-4 border-sky-400 px-3 py-2 rounded-r"><strong>TL;DR:</strong> iTrustCapital earns an 8.8/10 score and is the most affordable crypto IRA platform, charging $0 in annual fees and 1% per trade with access to 40+ cryptocurrencies and precious metals.</p>
              <p className="text-[#64748B] leading-relaxed">
                iTrustCapital earns our <strong className="text-[#0F172A]">#3 ranking</strong> and 
                our <strong className="text-[#0F172A]">Notable for Low Fees</strong> award for 2026. 
                With a {provider.setup_fee} setup fee, {provider.annual_fee} annual fee, and only 
                {provider.transaction_fee}, it's the most cost-efficient crypto IRA available. 
                The trade-off is a smaller asset selection ({provider.asset_count}+ assets vs. 60+ at 
                top competitors) and custody through {provider.custody_provider} rather than BitGo Trust.
                For frequent traders or those starting with smaller amounts, iTrustCapital's fee 
                structure is unbeatable.
              </p>
            </div>

            {/* Fee Spotlight */}
            <div className="bg-emerald-50 border border-emerald-200 rounded-xl p-6">
              <h2 className="text-xl font-bold text-[#0F172A] mb-3">Why iTrustCapital Wins on Fees</h2>
              <div className="grid md:grid-cols-3 gap-4 text-center">
                {[
                  { label: 'Setup Fee', value: '$0', note: 'vs. $50–$200 industry avg' },
                  { label: 'Annual Fee', value: '$0', note: 'vs. $200–$300 industry avg' },
                  { label: 'Transaction Fee', value: '1%', note: 'vs. 1–2% industry avg' },
                ].map((item) => (
                  <div key={item.label} className="bg-white rounded-lg p-4 border border-emerald-100">
                    <div className="text-2xl font-bold text-emerald-600">{item.value}</div>
                    <div className="text-sm font-medium text-[#0F172A] mt-1">{item.label}</div>
                    <div className="text-xs text-[#64748B] mt-1">{item.note}</div>
                  </div>
                ))}
              </div>
            </div>

            {/* Fees Table */}
            <div>
              <h2 className="text-2xl font-bold text-[#0F172A] mb-4">Full Fee Comparison</h2>
              <div className="overflow-x-auto">
                <table className="comparison-table">
                  <thead>
                    <tr>
                      <th>Fee Type</th>
                      <th>iTrustCapital</th>
                      <th>Industry Average</th>
                    </tr>
                  </thead>
                  <tbody>
                    {[
                      ['Account Setup', provider.setup_fee ?? '$0', '$50–$200'],
                      ['Annual Maintenance', provider.annual_fee ?? '$0', '$200–$300'],
                      ['Transaction Fee', provider.transaction_fee ?? '—', '1–2% per trade'],
                      ['Wire Transfer', '$0', '$25–$50'],
                      ['Account Closure', '$0', '$50–$150'],
                    ].map(([type, itc, avg]) => (
                      <tr key={type}>
                        <td className="font-medium text-[#0F172A]">{type}</td>
                        <td className="text-emerald-600 font-medium">{itc}</td>
                        <td className="text-[#64748B]">{avg}</td>
                      </tr>
                    ))}
                  </tbody>
                </table>
              </div>
            </div>

            {/* Assets */}
            {provider.supported_assets && provider.supported_assets.length > 0 && (
              <div>
                <h2 className="text-2xl font-bold text-[#0F172A] mb-4">Supported Cryptocurrencies</h2>
              <p className="text-sm font-bold text-[#0F172A] mb-3 bg-sky-50 border-l-4 border-sky-400 px-3 py-2 rounded-r"><strong>TL;DR:</strong> iTrustCapital supports 40+ cryptocurrencies plus gold and silver, making it one of the few platforms offering both crypto and precious metals within a single IRA account.</p>
                <p className="text-[#64748B] mb-4">
                  iTrustCapital supports {provider.asset_count}+ cryptocurrencies, focusing on 
                  established, high-liquidity assets. Note: the selection is smaller than some 
                  competitors who offer 60+ assets.
                </p>
                <div className="grid grid-cols-2 md:grid-cols-3 gap-3">
                  {provider.supported_assets.map((asset) => (
                    <div key={asset} className="flex items-center gap-2 text-sm text-[#334155]">
                      <span className="text-emerald-500 font-bold">✓</span>
                      {asset}
                    </div>
                  ))}
                </div>
                <p className="text-sm text-[#64748B] mt-3">+ {(provider.asset_count ?? 0) - provider.supported_assets.length}+ additional cryptocurrencies available</p>
              </div>
            )}

            {/* Security */}
            <div>
              <h2 className="text-2xl font-bold text-[#0F172A] mb-4">Security & Custody</h2>
              <p className="text-sm font-bold text-[#0F172A] mb-3 bg-sky-50 border-l-4 border-sky-400 px-3 py-2 rounded-r"><strong>TL;DR:</strong> iTrustCapital uses Equity Trust Company, Fidelity Digital Assets, Wells Fargo, Fireblocks, and Coinbase Prime for institutional-grade cold storage with FDIC insurance on cash balances — the same custody infrastructure used by major institutional investors.</p>
              <p className="text-[#64748B] leading-relaxed mb-4">
                iTrustCapital uses <strong className="text-[#0F172A]">{provider.custody_provider}</strong> for 
                cryptocurrency custody, with cold storage for digital assets. Cash holdings are 
                FDIC-insured up to $250,000. The platform is regulated and IRS-compliant.
              </p>
              <div className="grid md:grid-cols-2 gap-4">
                {[
                  { label: 'Crypto Custodian', value: provider.custody_provider },
                  { label: 'Storage Type', value: provider.storage_type },
                  { label: 'Cash Insurance', value: 'FDIC on cash holdings' },
                  { label: 'BBB Rating', value: provider.bbb_rating },
                ].map((item) => (
                  <div key={item.label} className="bg-slate-50 rounded-lg p-4">
                    <div className="text-xs text-[#64748B] mb-1">{item.label}</div>
                    <div className="font-semibold text-[#0F172A]">{item.value ?? '—'}</div>
                  </div>
                ))}
              </div>
            </div>

            {/* Who It's Best For */}
            <div>
              <h2 className="text-2xl font-bold text-[#0F172A] mb-4">Who Should Choose iTrustCapital?</h2>
              <div className="grid md:grid-cols-2 gap-4">
                <div className="bg-emerald-50 rounded-xl p-5 border border-emerald-100">
                  <h3 className="font-bold text-emerald-800 mb-3">Great Choice If You...</h3>
                  <ul className="space-y-2 text-sm text-emerald-700">
                    {[
                      'Trade frequently and want to minimize fees',
                      'Are starting with a smaller investment ($1,000–$10,000)',
                      'Want zero annual maintenance fees',
                      'Prefer Coinbase Prime / Fidelity Digital Assets custody infrastructure',
                      'Focus primarily on BTC, ETH, and major coins',
                    ].map((item) => (
                      <li key={item} className="flex gap-2">
                        <span className="font-bold flex-shrink-0">✓</span>{item}
                      </li>
                    ))}
                  </ul>
                </div>
                <div className="bg-slate-50 rounded-xl p-5 border border-slate-200">
                  <h3 className="font-bold text-[#0F172A] mb-3">Consider Alternatives If You...</h3>
                  <ul className="space-y-2 text-sm text-[#64748B]">
                    {[
                      'Want access to 60+ altcoins',
                      'Prefer BitGo Trust institutional custody',
                      'Need $250M+ per-account insurance',
                      'Want dedicated IRA specialist support',
                      'Are investing $50,000+',
                    ].map((item) => (
                      <li key={item} className="flex gap-2">
                        <span className="font-bold flex-shrink-0">→</span>{item}
                      </li>
                    ))}
                  </ul>
                </div>
              </div>
            </div>

            {/* Pros/Cons */}
            <div className="grid md:grid-cols-2 gap-6">
              <div className="card border-t-4 border-t-emerald-400">
                <h3 className="font-bold text-[#0F172A] mb-4">Pros</h3>
                <ul className="space-y-2">
                  {[
                    'No setup fee, no annual fee',
                    `Only ${provider.transaction_fee} — lowest in the industry`,
                    `${provider.min_investment} minimum — most accessible`,
                    'FDIC insurance on cash holdings',
                    'Clean, intuitive trading interface',
                    'IRS-compliant and regulated',
                  ].map((pro) => (
                    <li key={pro} className="flex gap-2 text-sm text-[#334155]">
                      <span className="text-emerald-500 font-bold flex-shrink-0">✓</span>
                      {pro}
                    </li>
                  ))}
                </ul>
              </div>
              <div className="card border-t-4 border-t-red-300">
                <h3 className="font-bold text-[#0F172A] mb-4">Cons</h3>
                <ul className="space-y-2">
                  {[
                    `Smaller asset selection (${provider.asset_count}+ vs. 60+ at top providers)`,
                    'No dedicated account specialist',
                    'Less institutional-grade custody than BitGo',
                    'Limited customer support hours',
                  ].map((con) => (
                    <li key={con} className="flex gap-2 text-sm text-[#334155]">
                      <span className="text-red-400 font-bold flex-shrink-0">✗</span>
                      {con}
                    </li>
                  ))}
                </ul>
              </div>
            </div>

          </div>

          {/* Sidebar */}
          <div className="space-y-6">
            <div className="card sticky top-24">
              <div className="text-center mb-6">
                <div className={`text-5xl font-bold mb-1 ${scoreColor(provider.score_overall)}`}>
                  {provider.score_overall?.toFixed(1) ?? '—'}
                </div>
                <div className="text-sm text-[#64748B]">Overall Score / 10</div>
                <div className="badge-sky mt-2">Notable for Low Fees 2026</div>
              </div>
              <div className="space-y-3 mb-6">
                {scoreLabels.map((cat) => {
                  const score = provider[cat.key] as number | null
                  return (
                    <div key={cat.key}>
                      <div className="flex justify-between text-xs mb-1">
                        <span className="text-[#64748B]">{cat.label}</span>
                        <span className={`font-semibold ${scoreColor(score)}`}>
                          {score?.toFixed(1) ?? '—'}/10
                        </span>
                      </div>
                      <div className="h-1.5 bg-slate-100 rounded-full overflow-hidden">
                        <div
                          className="h-full bg-[#0EA5E9] rounded-full"
                          style={{ width: `${((score ?? 0) / 10) * 100}%` }}
                        />
                      </div>
                    </div>
                  )
                })}
              </div>
              {provider.affiliate_url ? (
                <a
                  href={provider.affiliate_url}
                  target="_blank"
                  rel="noopener noreferrer sponsored"
                  className="btn-primary w-full text-center block"
                  onClick={() => trackProviderSiteVisit('iTrustCapital', 'itrustcapital', provider.affiliate_url!)}
                >
                  Visit iTrustCapital →
                </a>
              ) : (
                <a
                  href={provider.website ?? '#'}
                  target="_blank"
                  rel="noopener noreferrer"
                  className="btn-primary w-full text-center block"
                >
                  Visit iTrustCapital →
                </a>
              )}
              <p className="text-xs text-slate-400 text-center mt-3"></p>
            </div>

            <div className="card">
              <h3 className="font-semibold text-[#0F172A] mb-4 text-sm uppercase tracking-wider">Quick Facts</h3>
              <dl className="space-y-3 text-sm">
                {[
                  ['Founded', provider.founded_year?.toString()],
                  ['Headquarters', provider.headquarters],
                  ['Custodian', provider.custody_provider],
                  ['BBB Rating', provider.bbb_rating],
                  ['Min. Investment', provider.min_investment],
                  ['Annual Fee', provider.annual_fee],
                ].map(([key, val]) => (
                  <div key={key} className="flex justify-between">
                    <dt className="text-[#64748B]">{key}</dt>
                    <dd className="font-medium text-[#0F172A]">{val ?? '—'}</dd>
                  </div>
                ))}
              </dl>
            </div>

            <div className="card bg-sky-50 border-sky-200">
              <h3 className="font-semibold text-sky-800 mb-2 text-sm">Want more asset options?</h3>
              <p className="text-xs text-sky-700 mb-3">
                BlockTrust IRA offers 60+ cryptocurrencies with institutional-grade custody.
              </p>
              <Link to="/crypto-ira/blocktrust-ira-review" className="text-xs font-medium text-sky-800 hover:underline"
                onClick={() => trackProviderReviewClick('Blocktrust Ira', 'blocktrust-ira', window.location.pathname)}>
                See BlockTrust IRA Review →
              </Link>
            </div>
            <div className="card bg-[#F0F9FF] border-[#BAE6FD]">
              <h3 className="font-semibold text-[#0F172A] mb-3 text-sm uppercase tracking-wider">Compare Providers</h3>
              <ul className="space-y-2 text-sm">
                <li><Link to="/crypto-ira/blocktrust-ira-review" className="text-[#0EA5E9] hover:underline"
                onClick={() => trackProviderReviewClick('Blocktrust Ira', 'blocktrust-ira', window.location.pathname)}>BlockTrust IRA Review</Link></li>
                <li><Link to="/crypto-ira/bitcoin-ira-review" className="text-[#0EA5E9] hover:underline"
                onClick={() => trackProviderReviewClick('Bitcoin Ira', 'bitcoin-ira', window.location.pathname)}>Bitcoin IRA Review</Link></li>
                <li><Link to="/crypto-ira/itrustcapital-review" className="text-[#0EA5E9] hover:underline"
                onClick={() => trackProviderReviewClick('Itrustcapital', 'itrustcapital', window.location.pathname)}>iTrustCapital Review</Link></li>
                <li><Link to="/crypto-ira/best-companies" className="text-[#0EA5E9] hover:underline font-medium">→ See All Rankings</Link></li>
              </ul>
            </div>
            <div className="card">
              <h3 className="font-semibold text-[#0F172A] mb-3 text-sm uppercase tracking-wider">Related Guides</h3>
              <ul className="space-y-2 text-sm">
                <li><Link to="/crypto-ira/401k-to-crypto-ira-rollover" className="text-[#0EA5E9] hover:underline">401k to Crypto IRA Rollover Guide →</Link></li>
                <li><Link to="/gold-ira-vs-crypto-ira" className="text-[#0EA5E9] hover:underline">Gold IRA vs Crypto IRA →</Link></li>
                <li><Link to="/methodology" className="text-[#0EA5E9] hover:underline">How We Rate Providers →</Link></li>
              </ul>
            </div>
          </div>
        </div>
      </div>

      {/* ── Bottom Line ────────────────────────────────────────────────── */}
      <div className="bg-[#F0F9FF] border-t border-[#BAE6FD]">
        <div className="container-site py-12 max-w-3xl">
          <h2 className="text-2xl font-bold text-[#0F172A] mb-4">Bottom Line: Is iTrustCapital Worth It?</h2>
          <p className="text-[#334155] leading-relaxed mb-4">
            iTrustCapital is <strong>#3 rated crypto IRA provider for 2026</strong>. The combination of the lowest trading fees in the market at 1% per trade with no annual fees, plus the unique ability to hold both crypto and physical gold in a single IRA makes it a strong choice for investors looking for a tax-advantaged retirement account with exposure to this asset class.
          </p>
          <p className="text-[#334155] leading-relaxed mb-4">
            The $1,000 minimum investment is the lowest in the market, making it accessible, but the platform has fewer supported cryptocurrencies than BlockTrust IRA. Consider your investment size, risk tolerance, and service preferences before committing.
          </p>
          <p className="text-[#334155] leading-relaxed">
            <strong>Best for:</strong> Cost-conscious investors who want to minimize fees and appreciate the flexibility of holding both crypto and precious metals in one account. If you want to compare alternatives, see our{' '}
            <Link to="/crypto-ira/blocktrust-ira-review" className="text-[#0EA5E9] hover:underline"
                onClick={() => trackProviderReviewClick('Blocktrust Ira', 'blocktrust-ira', window.location.pathname)}>BlockTrust IRA review</Link>{' '}and{' '}
            <Link to="/crypto-ira/bitcoin-ira-review" className="text-[#0EA5E9] hover:underline"
                onClick={() => trackProviderReviewClick('Bitcoin Ira', 'bitcoin-ira', window.location.pathname)}>Bitcoin IRA review</Link>.
          </p>
        </div>
      </div>

      {/* ── FAQ Section ────────────────────────────────────────────────── */}
      <div className="container-site py-12 max-w-3xl">
        <h2 className="text-2xl font-bold text-[#0F172A] mb-8">Frequently Asked Questions</h2>
        <div className="space-y-4">
          {faqSchema.mainEntity.map((item, i) => (
            <details key={i} className="group border border-slate-200 rounded-lg overflow-hidden">
              <summary className="flex items-center justify-between gap-4 p-5 cursor-pointer bg-white hover:bg-slate-50 transition-colors list-none">
                <span className="font-semibold text-[#0F172A] text-sm leading-snug">{item.name}</span>
                <span className="flex-shrink-0 w-5 h-5 text-[#0EA5E9] transition-transform group-open:rotate-180">
                  <svg viewBox="0 0 20 20" fill="currentColor"><path fillRule="evenodd" d="M5.293 7.293a1 1 0 011.414 0L10 10.586l3.293-3.293a1 1 0 111.414 1.414l-4 4a1 1 0 01-1.414 0l-4-4a1 1 0 010-1.414z" clipRule="evenodd" /></svg>
                </span>
              </summary>
              <div className="px-5 pb-5 text-[#64748B] text-sm leading-relaxed bg-white">
                {item.acceptedAnswer.text}
              </div>
            </details>
          ))}
        </div>
      </div>
      {/* ── Newsletter Signup ─────────────────────────────────────────── */}
      <div className="container-site py-10 max-w-3xl">
        
        {/* Related Links */}

        <div className="mt-10 mb-6">

          <RelatedLinks variant="crypto-review" title="Related Guides &amp; Reviews" />

        </div>
<NewsletterSignup />
      </div>
    </>
  )
}
