import StateGuideTemplate from '../components/StateGuideTemplate'

export default function BestCryptoIRATXPage() {
  return (
    <StateGuideTemplate
      stateName="Texas"
      stateAbbr="TX"
      slug="texas"
    />
  )
}
