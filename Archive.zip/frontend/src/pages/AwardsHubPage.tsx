import { Link } from 'react-router-dom'
import SEO from '../components/SEO'

const awardsSchema = {
  "@context": "https://schema.org",
  "@type": "ItemList",
  "name": "IRA Research Hub Awards 2026",
  "description": "Annual independent awards recognizing the best IRA providers across crypto, precious metals, and service categories.",
  "url": "https://iraresearchhub.com/awards",
  "numberOfItems": 6,
  "itemListElement": [
    {
      "@type": "ListItem",
      "position": 1,
      "name": "Best Crypto IRA 2026 — BlockTrust IRA",
      "url": "https://iraresearchhub.com/awards/best-crypto-ira-2026"
    },
    {
      "@type": "ListItem",
      "position": 2,
      "name": "Best Gold IRA 2026 — Genesis Gold Group",
      "url": "https://iraresearchhub.com/awards/best-gold-ira-2026"
    },
    {
      "@type": "ListItem",
      "position": 3,
      "name": "Best Fee Transparency 2026 — BlockTrust IRA",
      "url": "https://iraresearchhub.com/awards/best-fee-transparency-2026"
    },
    {
      "@type": "ListItem",
      "position": 4,
      "name": "Best Customer Service 2026 — Genesis Gold Group",
      "url": "https://iraresearchhub.com/awards/best-customer-service-2026"
    },
    {
      "@type": "ListItem",
      "position": 5,
      "name": "Best Crypto IRA 2025 — BlockTrust IRA",
      "url": "https://iraresearchhub.com/awards/best-crypto-ira-2025"
    },
    {
      "@type": "ListItem",
      "position": 6,
      "name": "Best Gold IRA 2025 — Genesis Gold Group",
      "url": "https://iraresearchhub.com/awards/best-gold-ira-2025"
    }
  ]
}

const awards = [
  {
    slug: 'best-crypto-ira-2026',
    year: 2026,
    category: 'Best Crypto IRA',
    winner: 'BlockTrust IRA',
    score: 94.5,
    reviewPath: '/crypto-ira/blocktrust-ira-review',
    badgeUrl: 'https://iraresearchhub.com/badges/best-bitcoin-ira-2026-dark.svg',
    description: 'Awarded for the highest overall score in our 2026 crypto IRA evaluation — driven by Animus AI 24/7 managed portfolio, 60+ asset selection, and institutional-grade sFOX cold storage custody.',
    color: 'amber',
    icon: '₿',
  },
  {
    slug: 'best-gold-ira-2026',
    year: 2026,
    category: 'Best Gold IRA',
    winner: 'Genesis Gold Group',
    score: 94.0,
    reviewPath: '/precious-metals-ira/genesis-gold-group-review',
    badgeUrl: 'https://iraresearchhub.com/badges/best-gold-ira-2026-dark.svg',
    description: 'Awarded for exceptional white-glove service, transparent pricing, A+ BBB rating, and a streamlined rollover process that sets the standard for precious metals IRAs in 2026.',
    color: 'yellow',
    icon: '🥇',
  },
  {
    slug: 'best-fee-transparency-2026',
    year: 2026,
    category: 'Best Fee Transparency',
    winner: 'BlockTrust IRA',
    score: 97.0,
    reviewPath: '/crypto-ira/blocktrust-ira-review',
    badgeUrl: 'https://iraresearchhub.com/badges/featured-light.svg',
    description: 'Awarded for publishing all fees upfront with no hidden markups — 2% annual management fee, 25% performance fee on profits only, plus 0.14% trading fee via sFOX. The most transparent fee structure in the IRA industry.',
    color: 'sky',
    icon: '💰',
  },
  {
    slug: 'best-customer-service-2026',
    year: 2026,
    category: 'Best Customer Service',
    winner: 'Genesis Gold Group',
    score: 96.0,
    reviewPath: '/precious-metals-ira/genesis-gold-group-review',
    badgeUrl: 'https://iraresearchhub.com/badges/top-rated-2026-light.svg',
    description: 'Awarded for verified 4.9/5 customer reviews, dedicated account specialist model, and average response times under 2 hours — the highest customer satisfaction score in our 2026 evaluation.',
    color: 'green',
    icon: '⭐',
  },
  {
    slug: 'best-crypto-ira-2025',
    year: 2025,
    category: 'Best Crypto IRA',
    winner: 'BlockTrust IRA',
    score: 91.0,
    reviewPath: '/crypto-ira/blocktrust-ira-review',
    badgeUrl: null,
    description: 'Recognized in 2025 for leading the crypto IRA space with competitive fees, broad asset selection, and strong compliance track record.',
    color: 'slate',
    icon: '₿',
  },
  {
    slug: 'best-gold-ira-2025',
    year: 2025,
    category: 'Best Gold IRA',
    winner: 'Genesis Gold Group',
    score: 91.5,
    reviewPath: '/precious-metals-ira/genesis-gold-group-review',
    badgeUrl: null,
    description: 'Recognized in 2025 for outstanding precious metals IRA service, transparent pricing, and exceptional client onboarding experience.',
    color: 'slate',
    icon: '🥇',
  },
]

const colorMap: Record<string, string> = {
  amber: 'border-amber-300 bg-amber-50',
  yellow: 'border-yellow-300 bg-yellow-50',
  sky: 'border-sky-300 bg-sky-50',
  green: 'border-green-300 bg-green-50',
  slate: 'border-slate-200 bg-slate-50',
}

const badgeColorMap: Record<string, string> = {
  amber: 'bg-amber-100 text-amber-800 border-amber-300',
  yellow: 'bg-yellow-100 text-yellow-800 border-yellow-300',
  sky: 'bg-sky-100 text-sky-800 border-sky-300',
  green: 'bg-green-100 text-green-800 border-green-300',
  slate: 'bg-slate-100 text-slate-700 border-slate-300',
}

export default function AwardsHubPage() {
  const current = awards.filter(a => a.year === 2026)
  const past = awards.filter(a => a.year < 2026)

  return (
    <>
      <SEO
        title="IRA Awards 2026 | Best Crypto IRA & Gold IRA — Annual Rankings"
        description="The IRA Research Hub Awards recognize the best IRA providers each year across crypto, precious metals, fee transparency, and customer service. Independent, data-driven, no pay-to-play."
        canonical="https://iraresearchhub.com/awards"
        schema={awardsSchema}
      />
      <script
        type="application/ld+json"
        dangerouslySetInnerHTML={{ __html: JSON.stringify(awardsSchema) }}
      />

      {/* Hero */}
      <section className="bg-[#0F172A] text-white py-16 px-4">
        <div className="max-w-4xl mx-auto text-center">
          <div className="text-5xl mb-4">🏆</div>
          <h1 className="text-4xl md:text-5xl font-bold mb-4">IRA Research Hub Awards</h1>
          <p className="text-xl text-slate-300 max-w-2xl mx-auto mb-6">
            Annual independent recognition for the best IRA providers across crypto, precious metals, fee transparency, and customer service. No company pays to be nominated or to win.
          </p>
          <div className="flex flex-wrap justify-center gap-3 text-sm">
            <span className="bg-white/10 border border-white/20 rounded-full px-4 py-1.5">Independent Research</span>
            <span className="bg-white/10 border border-white/20 rounded-full px-4 py-1.5">Data-Driven Scoring</span>
            <span className="bg-white/10 border border-white/20 rounded-full px-4 py-1.5">No Pay-to-Play</span>
            <span className="bg-white/10 border border-white/20 rounded-full px-4 py-1.5">Updated Annually</span>
          </div>
        </div>
      </section>

      <div className="max-w-4xl mx-auto px-4 py-12">

        {/* 2026 Awards */}
        <h2 className="text-2xl font-bold text-[#0F172A] mb-2">2026 Award Winners</h2>
        <p className="text-slate-500 mb-8">Based on our comprehensive evaluation of IRA providers conducted in Q1 2026. <Link to="/methodology" className="text-[#0EA5E9] hover:underline">View methodology →</Link></p>

        <div className="grid gap-6 mb-16">
          {current.map(award => (
            <div key={award.slug} className={`border-2 rounded-xl p-6 ${colorMap[award.color]}`}>
              <div className="flex flex-col md:flex-row md:items-start gap-4">
                <div className="flex-1">
                  <div className="flex flex-wrap items-center gap-2 mb-3">
                    <span className="text-2xl">{award.icon}</span>
                    <span className={`text-xs font-bold px-3 py-1 rounded-full border ${badgeColorMap[award.color]}`}>
                      {award.category} {award.year}
                    </span>
                    <span className="text-xs text-slate-500 font-medium">Score: {award.score}/100</span>
                  </div>
                  <h3 className="text-xl font-bold text-[#0F172A] mb-1">
                    <Link to={`/awards/${award.slug}`} className="hover:text-[#0EA5E9] transition-colors">
                      {award.category} {award.year} — {award.winner}
                    </Link>
                  </h3>
                  <p className="text-slate-600 text-sm mb-4">{award.description}</p>
                  <div className="flex flex-wrap gap-3">
                    <Link
                      to={`/awards/${award.slug}`}
                      className="inline-flex items-center gap-1.5 bg-[#0F172A] text-white text-sm font-semibold px-4 py-2 rounded-lg hover:bg-slate-700 transition-colors"
                    >
                      View Award Page →
                    </Link>
                    <Link
                      to={award.reviewPath}
                      className="inline-flex items-center gap-1.5 border border-slate-300 text-slate-700 text-sm font-medium px-4 py-2 rounded-lg hover:bg-white transition-colors"
                    >
                      Full Review
                    </Link>
                  </div>
                </div>
                {award.badgeUrl && (
                  <div className="flex-shrink-0">
                    <img
                      src={award.badgeUrl}
                      alt={`${award.category} ${award.year} badge`}
                      className="w-28 h-28 object-contain"
                      onError={(e) => { (e.target as HTMLImageElement).style.display = 'none' }}
                    />
                  </div>
                )}
              </div>
            </div>
          ))}
        </div>

        {/* Past Awards */}
        <h2 className="text-2xl font-bold text-[#0F172A] mb-6">Past Award Winners</h2>
        <div className="grid md:grid-cols-2 gap-4 mb-16">
          {past.map(award => (
            <div key={award.slug} className="border border-slate-200 rounded-xl p-5 bg-slate-50">
              <div className="flex items-center gap-2 mb-2">
                <span className="text-lg">{award.icon}</span>
                <span className="text-xs font-bold text-slate-500 uppercase tracking-wide">{award.category} {award.year}</span>
              </div>
              <h3 className="font-bold text-[#0F172A] mb-1">{award.winner}</h3>
              <p className="text-xs text-slate-500 mb-3">Score: {award.score}/100</p>
              <Link to={award.reviewPath} className="text-[#0EA5E9] text-sm hover:underline">View Review →</Link>
            </div>
          ))}
        </div>

        {/* Methodology */}
        <div className="bg-slate-50 border border-slate-200 rounded-xl p-8 mb-12">
          <h2 className="text-xl font-bold text-[#0F172A] mb-3">Our Evaluation Methodology</h2>
          <p className="text-slate-600 mb-4">
            IRA Research Hub Awards are determined through an independent, data-driven evaluation process. No company pays to be considered, and no award is sponsored. Our research team evaluates providers across six weighted criteria using publicly available data, regulatory filings, and verified customer reviews.
          </p>
          <div className="grid md:grid-cols-3 gap-4 mb-4">
            {[
              ['Fee Transparency', '25%'],
              ['Investment Options', '20%'],
              ['Security & Compliance', '20%'],
              ['Customer Service', '15%'],
              ['Platform Usability', '10%'],
              ['Track Record', '10%'],
            ].map(([label, weight]) => (
              <div key={label} className="bg-white border border-slate-200 rounded-lg p-3">
                <div className="text-xs font-bold text-[#0EA5E9] mb-1">{weight}</div>
                <div className="text-sm font-medium text-[#0F172A]">{label}</div>
              </div>
            ))}
          </div>
          <Link to="/methodology" className="text-[#0EA5E9] text-sm hover:underline">Read the full methodology →</Link>
        </div>

        {/* Embed CTA */}
        <div className="bg-[#0F172A] text-white rounded-xl p-8 text-center">
          <h2 className="text-xl font-bold mb-2">Are You an Award Winner?</h2>
          <p className="text-slate-300 text-sm mb-4">
            Award winners may embed the official badge on their website. Download the SVG or PNG badge and link it to the canonical award page.
          </p>
          <div className="flex flex-wrap justify-center gap-3">
            <a
              href="https://iraresearchhub.com/badges/best-bitcoin-ira-2026-dark.svg"
              className="bg-amber-500 text-white text-sm font-semibold px-4 py-2 rounded-lg hover:bg-amber-600 transition-colors"
              download
            >
              Download Crypto IRA Badge
            </a>
            <a
              href="https://iraresearchhub.com/badges/best-gold-ira-2026-dark.svg"
              className="bg-yellow-500 text-[#0F172A] text-sm font-semibold px-4 py-2 rounded-lg hover:bg-yellow-600 transition-colors"
              download
            >
              Download Gold IRA Badge
            </a>
          </div>
        </div>

      </div>
    </>
  )
}
