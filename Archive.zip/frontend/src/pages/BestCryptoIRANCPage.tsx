import StateGuideTemplate from '../components/StateGuideTemplate'

export default function BestCryptoIRANCPage() {
  return (
    <StateGuideTemplate
      stateName="North Carolina"
      stateAbbr="NC"
      slug="north-carolina"
    />
  )
}
