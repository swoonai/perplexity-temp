import { useState } from 'react'
import { useQuery } from '@tanstack/react-query'

const API_BASE = '/api/v1/seo'

// ─── Types ────────────────────────────────────────────────────────────────────

interface WeeklyMetric {
  week: string           // e.g. "2026-W14"
  week_label: string     // e.g. "Apr W2"
  organic_sessions: number | null
  clicks: number | null
  impressions: number | null
  ctr: number | null     // 0-1
  indexed_pages: number | null
  pages_published: number | null
  avg_position: number | null
}

interface KeywordRanking {
  keyword: string
  position: number | null
  prev_position: number | null
  change: number | null
  clicks: number | null
  impressions: number | null
  ctr: number | null
  url: string | null
}

interface SEOSummary {
  last_updated: string | null
  organic_sessions_7d: number | null
  organic_sessions_prev_7d: number | null
  clicks_7d: number | null
  impressions_7d: number | null
  avg_ctr_7d: number | null
  avg_position_7d: number | null
  indexed_pages: number | null
  pages_published_this_week: number | null
  weekly_trend: WeeklyMetric[]
  top_keywords: KeywordRanking[]
  top_pages: { url: string; clicks: number; impressions: number; ctr: number; position: number }[]
}

// ─── Mock Data ────────────────────────────────────────────────────────────────

function getMockSummary(): SEOSummary {
  return {
    last_updated: new Date().toISOString(),
    organic_sessions_7d: 3842,
    organic_sessions_prev_7d: 3210,
    clicks_7d: 1247,
    impressions_7d: 48300,
    avg_ctr_7d: 0.0258,
    avg_position_7d: 14.3,
    indexed_pages: 63,
    pages_published_this_week: 2,
    weekly_trend: [
      { week: '2026-W10', week_label: 'Mar W1', organic_sessions: 2100, clicks: 680, impressions: 31000, ctr: 0.022, indexed_pages: 55, pages_published: 3, avg_position: 18.2 },
      { week: '2026-W11', week_label: 'Mar W2', organic_sessions: 2450, clicks: 790, impressions: 34500, ctr: 0.023, indexed_pages: 57, pages_published: 2, avg_position: 17.1 },
      { week: '2026-W12', week_label: 'Mar W3', organic_sessions: 2890, clicks: 940, impressions: 39200, ctr: 0.024, indexed_pages: 59, pages_published: 4, avg_position: 16.0 },
      { week: '2026-W13', week_label: 'Mar W4', organic_sessions: 3210, clicks: 1050, impressions: 43800, ctr: 0.024, indexed_pages: 61, pages_published: 2, avg_position: 15.2 },
      { week: '2026-W14', week_label: 'Apr W1', organic_sessions: 3842, clicks: 1247, impressions: 48300, ctr: 0.026, indexed_pages: 63, pages_published: 2, avg_position: 14.3 },
    ],
    top_keywords: [
      { keyword: 'best crypto IRA 2026', position: 4, prev_position: 7, change: 3, clicks: 142, impressions: 2100, ctr: 0.068, url: '/crypto-ira/best-crypto-ira-companies' },
      { keyword: 'BlockTrust IRA review', position: 2, prev_position: 3, change: 1, clicks: 98, impressions: 890, ctr: 0.110, url: '/crypto-ira/blocktrust-ira-review' },
      { keyword: 'best Bitcoin IRA companies', position: 6, prev_position: 9, change: 3, clicks: 87, impressions: 1450, ctr: 0.060, url: '/crypto-ira/best-bitcoin-ira' },
      { keyword: 'iTrustCapital review 2026', position: 5, prev_position: 5, change: 0, clicks: 76, impressions: 1200, ctr: 0.063, url: '/crypto-ira/itrustcapital-review' },
      { keyword: 'best gold IRA companies 2026', position: 11, prev_position: 14, change: 3, clicks: 65, impressions: 3200, ctr: 0.020, url: '/precious-metals-ira/best-gold-ira-companies' },
      { keyword: 'Genesis Gold Group review', position: 3, prev_position: 4, change: 1, clicks: 54, impressions: 620, ctr: 0.087, url: '/precious-metals-ira/genesis-gold-group-review' },
      { keyword: 'crypto IRA fees comparison', position: 8, prev_position: 12, change: 4, clicks: 43, impressions: 980, ctr: 0.044, url: '/research/crypto-ira-fees-2026' },
      { keyword: 'Augusta Precious Metals review', position: 15, prev_position: 18, change: 3, clicks: 38, impressions: 2800, ctr: 0.014, url: '/precious-metals-ira/augusta-precious-metals-review' },
    ],
    top_pages: [
      { url: '/crypto-ira/best-crypto-ira-companies', clicks: 312, impressions: 8400, ctr: 0.037, position: 5.2 },
      { url: '/crypto-ira/blocktrust-ira-review', clicks: 198, impressions: 2100, ctr: 0.094, position: 2.8 },
      { url: '/precious-metals-ira/best-gold-ira-companies', clicks: 187, impressions: 9200, ctr: 0.020, position: 10.4 },
      { url: '/crypto-ira/best-bitcoin-ira', clicks: 156, impressions: 3800, ctr: 0.041, position: 6.1 },
      { url: '/precious-metals-ira/genesis-gold-group-review', clicks: 134, impressions: 1800, ctr: 0.074, position: 3.2 },
    ],
  }
}

// ─── Helper Components ────────────────────────────────────────────────────────

function Delta({ value, inverse = false }: { value: number | null; inverse?: boolean }) {
  if (value === null || value === 0) return <span className="text-slate-400 text-xs">—</span>
  const positive = inverse ? value < 0 : value > 0
  const color = positive ? 'text-green-600' : 'text-red-600'
  const arrow = positive ? '↑' : '↓'
  return (
    <span className={`text-xs font-medium ${color}`}>
      {arrow} {Math.abs(value).toLocaleString()}
    </span>
  )
}

function StatCard({ label, value, delta, deltaInverse = false, sub, color = 'slate' }: {
  label: string
  value: string | number
  delta?: number | null
  deltaInverse?: boolean
  sub?: string
  color?: string
}) {
  const colorMap: Record<string, string> = {
    green: 'border-green-200 bg-green-50',
    blue: 'border-blue-200 bg-blue-50',
    purple: 'border-purple-200 bg-purple-50',
    slate: 'border-slate-200 bg-white',
  }
  return (
    <div className={`rounded-lg border p-4 ${colorMap[color] || colorMap.slate}`}>
      <p className="text-xs text-slate-500 font-medium uppercase tracking-wide">{label}</p>
      <div className="flex items-end gap-2 mt-1">
        <p className="text-2xl font-bold text-slate-900">{value}</p>
        {delta !== undefined && delta !== null && (
          <div className="mb-0.5"><Delta value={delta} inverse={deltaInverse} /></div>
        )}
      </div>
      {sub && <p className="text-xs text-slate-500 mt-0.5">{sub}</p>}
    </div>
  )
}

function MiniBar({ value, max, color = 'bg-blue-500' }: { value: number; max: number; color?: string }) {
  const pct = max > 0 ? Math.min(100, (value / max) * 100) : 0
  return (
    <div className="w-full bg-slate-100 rounded-full h-1.5">
      <div className={`${color} h-1.5 rounded-full`} style={{ width: `${pct}%` }} />
    </div>
  )
}

function TrendChart({ data, field, color = '#3b82f6' }: {
  data: WeeklyMetric[]
  field: keyof WeeklyMetric
  color?: string
}) {
  const values = data.map(d => (d[field] as number) || 0)
  const max = Math.max(...values, 1)
  const min = Math.min(...values)
  const range = max - min || 1
  const w = 100 / (values.length - 1 || 1)

  const points = values.map((v, i) => {
    const x = i * w
    const y = 100 - ((v - min) / range) * 80 - 10
    return `${x},${y}`
  }).join(' ')

  return (
    <div className="relative h-16">
      <svg viewBox="0 0 100 100" preserveAspectRatio="none" className="w-full h-full">
        <polyline
          points={points}
          fill="none"
          stroke={color}
          strokeWidth="2"
          vectorEffect="non-scaling-stroke"
        />
        {values.map((v, i) => (
          <circle
            key={i}
            cx={i * w}
            cy={100 - ((v - min) / range) * 80 - 10}
            r="2"
            fill={color}
            vectorEffect="non-scaling-stroke"
          />
        ))}
      </svg>
      <div className="flex justify-between mt-1">
        {data.map(d => (
          <span key={d.week} className="text-[10px] text-slate-400">{d.week_label}</span>
        ))}
      </div>
    </div>
  )
}

// ─── Main Component ───────────────────────────────────────────────────────────

export default function SEODashboardPage() {
  const [activeTab, setActiveTab] = useState<'overview' | 'keywords' | 'pages' | 'setup'>('overview')

  const { data: summary, isLoading: _isLoading, error: _error } = useQuery<SEOSummary>({
    queryKey: ['seo-summary'],
    queryFn: async () => {
      const res = await fetch(`${API_BASE}/summary`)
      if (!res.ok) throw new Error(`HTTP ${res.status}`)
      return res.json()
    },
    retry: false,
  })

  const displayData = summary || getMockSummary()
  const isMockData = !summary

  const sessionDelta = displayData.organic_sessions_7d !== null && displayData.organic_sessions_prev_7d !== null
    ? displayData.organic_sessions_7d - displayData.organic_sessions_prev_7d
    : null

  const maxClicks = Math.max(...(displayData.top_pages?.map(p => p.clicks) || [1]))
  const maxImpressions = Math.max(...(displayData.top_keywords?.map(k => k.impressions || 0) || [1]))

  return (
    <div className="max-w-6xl mx-auto px-4 py-8">
      <div className="flex items-center justify-between mb-6">
        <div>
          <h1 className="text-2xl font-bold text-slate-900">SEO Metrics Dashboard</h1>
          <p className="text-slate-500 text-sm mt-1">
            Organic traffic · Keyword rankings · CTR · Indexed pages · Content velocity
          </p>
        </div>
        <div className="flex items-center gap-3">
          {isMockData && (
            <span className="text-xs bg-amber-100 text-amber-700 border border-amber-200 px-2 py-1 rounded">
              Demo data — connect GA4 + GSC to see live metrics
            </span>
          )}
          {displayData.last_updated && (
            <span className="text-xs text-slate-400">
              Updated {new Date(displayData.last_updated).toLocaleDateString()}
            </span>
          )}
        </div>
      </div>

      {/* Tabs */}
      <div className="flex gap-1 mb-6 border-b border-slate-200">
        {(['overview', 'keywords', 'pages', 'setup'] as const).map(tab => (
          <button
            key={tab}
            onClick={() => setActiveTab(tab)}
            className={`px-4 py-2 text-sm font-medium capitalize transition-colors border-b-2 -mb-px ${
              activeTab === tab
                ? 'border-blue-600 text-blue-600'
                : 'border-transparent text-slate-500 hover:text-slate-700'
            }`}
          >
            {tab === 'setup' ? '⚙️ Setup' : tab.charAt(0).toUpperCase() + tab.slice(1)}
          </button>
        ))}
      </div>

      {activeTab === 'overview' && (
        <>
          {/* KPI Cards */}
          <div className="grid grid-cols-2 md:grid-cols-4 gap-4 mb-6">
            <StatCard
              label="Organic Sessions (7d)"
              value={(displayData.organic_sessions_7d || 0).toLocaleString()}
              delta={sessionDelta}
              sub="vs previous 7 days"
              color="blue"
            />
            <StatCard
              label="Clicks (7d)"
              value={(displayData.clicks_7d || 0).toLocaleString()}
              sub="From Google Search Console"
              color="green"
            />
            <StatCard
              label="Avg CTR (7d)"
              value={`${((displayData.avg_ctr_7d || 0) * 100).toFixed(1)}%`}
              sub={`Avg position: ${displayData.avg_position_7d?.toFixed(1) || '—'}`}
            />
            <StatCard
              label="Indexed Pages"
              value={displayData.indexed_pages || 0}
              sub={`+${displayData.pages_published_this_week || 0} published this week`}
              color="purple"
            />
          </div>

          {/* Trend Charts */}
          <div className="grid grid-cols-1 md:grid-cols-2 gap-6 mb-6">
            <div className="bg-white border border-slate-200 rounded-lg p-5">
              <h2 className="font-semibold text-slate-900 mb-1">Organic Sessions</h2>
              <p className="text-xs text-slate-400 mb-3">Weekly trend (GA4)</p>
              <TrendChart data={displayData.weekly_trend} field="organic_sessions" color="#3b82f6" />
            </div>
            <div className="bg-white border border-slate-200 rounded-lg p-5">
              <h2 className="font-semibold text-slate-900 mb-1">Click-Through Rate</h2>
              <p className="text-xs text-slate-400 mb-3">Weekly trend (GSC)</p>
              <TrendChart data={displayData.weekly_trend} field="ctr" color="#10b981" />
            </div>
            <div className="bg-white border border-slate-200 rounded-lg p-5">
              <h2 className="font-semibold text-slate-900 mb-1">Indexed Pages</h2>
              <p className="text-xs text-slate-400 mb-3">Weekly trend (GSC)</p>
              <TrendChart data={displayData.weekly_trend} field="indexed_pages" color="#8b5cf6" />
            </div>
            <div className="bg-white border border-slate-200 rounded-lg p-5">
              <h2 className="font-semibold text-slate-900 mb-1">Content Velocity</h2>
              <p className="text-xs text-slate-400 mb-3">Pages published per week</p>
              <TrendChart data={displayData.weekly_trend} field="pages_published" color="#f59e0b" />
              <p className="text-xs text-slate-400 mt-2">
                Target: 3+ pages/week for topical authority growth
              </p>
            </div>
          </div>

          {/* Weekly Data Table */}
          <div className="bg-white border border-slate-200 rounded-lg p-5">
            <h2 className="font-semibold text-slate-900 mb-4">Weekly Breakdown</h2>
            <div className="overflow-x-auto">
              <table className="w-full text-sm">
                <thead>
                  <tr className="border-b border-slate-100">
                    <th className="text-left py-2 pr-4 text-slate-500 font-medium">Week</th>
                    <th className="text-right py-2 pr-4 text-slate-500 font-medium">Sessions</th>
                    <th className="text-right py-2 pr-4 text-slate-500 font-medium">Clicks</th>
                    <th className="text-right py-2 pr-4 text-slate-500 font-medium">Impressions</th>
                    <th className="text-right py-2 pr-4 text-slate-500 font-medium">CTR</th>
                    <th className="text-right py-2 pr-4 text-slate-500 font-medium">Avg Pos.</th>
                    <th className="text-right py-2 pr-4 text-slate-500 font-medium">Indexed</th>
                    <th className="text-right py-2 text-slate-500 font-medium">Published</th>
                  </tr>
                </thead>
                <tbody>
                  {[...displayData.weekly_trend].reverse().map(w => (
                    <tr key={w.week} className="border-b border-slate-50 hover:bg-slate-50">
                      <td className="py-2 pr-4 font-medium text-slate-700">{w.week_label}</td>
                      <td className="py-2 pr-4 text-right text-slate-600">{(w.organic_sessions || 0).toLocaleString()}</td>
                      <td className="py-2 pr-4 text-right text-slate-600">{(w.clicks || 0).toLocaleString()}</td>
                      <td className="py-2 pr-4 text-right text-slate-600">{(w.impressions || 0).toLocaleString()}</td>
                      <td className="py-2 pr-4 text-right text-slate-600">{((w.ctr || 0) * 100).toFixed(1)}%</td>
                      <td className="py-2 pr-4 text-right text-slate-600">{w.avg_position?.toFixed(1) || '—'}</td>
                      <td className="py-2 pr-4 text-right text-slate-600">{w.indexed_pages || '—'}</td>
                      <td className="py-2 text-right">
                        <span className={`text-xs font-medium px-1.5 py-0.5 rounded ${
                          (w.pages_published || 0) >= 3
                            ? 'bg-green-100 text-green-700'
                            : (w.pages_published || 0) >= 1
                            ? 'bg-yellow-100 text-yellow-700'
                            : 'bg-red-100 text-red-700'
                        }`}>
                          {w.pages_published ?? 0}
                        </span>
                      </td>
                    </tr>
                  ))}
                </tbody>
              </table>
            </div>
          </div>
        </>
      )}

      {activeTab === 'keywords' && (
        <div className="bg-white border border-slate-200 rounded-lg p-5">
          <h2 className="font-semibold text-slate-900 mb-4">Keyword Rankings</h2>
          <div className="overflow-x-auto">
            <table className="w-full text-sm">
              <thead>
                <tr className="border-b border-slate-100">
                  <th className="text-left py-2 pr-4 text-slate-500 font-medium">Keyword</th>
                  <th className="text-right py-2 pr-4 text-slate-500 font-medium">Position</th>
                  <th className="text-right py-2 pr-4 text-slate-500 font-medium">Change</th>
                  <th className="text-right py-2 pr-4 text-slate-500 font-medium">Clicks</th>
                  <th className="text-left py-2 pr-4 text-slate-500 font-medium">Impressions</th>
                  <th className="text-right py-2 text-slate-500 font-medium">CTR</th>
                </tr>
              </thead>
              <tbody>
                {displayData.top_keywords.map((kw, i) => (
                  <tr key={i} className="border-b border-slate-50 hover:bg-slate-50">
                    <td className="py-2 pr-4">
                      <div>
                        <span className="text-slate-800 font-medium">{kw.keyword}</span>
                        {kw.url && (
                          <p className="text-xs text-slate-400 truncate max-w-xs">{kw.url}</p>
                        )}
                      </div>
                    </td>
                    <td className="py-2 pr-4 text-right">
                      <span className={`font-bold text-sm ${
                        (kw.position || 99) <= 3 ? 'text-green-600' :
                        (kw.position || 99) <= 10 ? 'text-blue-600' :
                        'text-slate-500'
                      }`}>
                        #{kw.position || '—'}
                      </span>
                    </td>
                    <td className="py-2 pr-4 text-right">
                      <Delta value={kw.change} inverse={true} />
                    </td>
                    <td className="py-2 pr-4 text-right text-slate-600">{(kw.clicks || 0).toLocaleString()}</td>
                    <td className="py-2 pr-4">
                      <div className="flex items-center gap-2">
                        <MiniBar value={kw.impressions || 0} max={maxImpressions} />
                        <span className="text-xs text-slate-500 w-12 text-right">
                          {(kw.impressions || 0).toLocaleString()}
                        </span>
                      </div>
                    </td>
                    <td className="py-2 text-right text-slate-600">
                      {((kw.ctr || 0) * 100).toFixed(1)}%
                    </td>
                  </tr>
                ))}
              </tbody>
            </table>
          </div>
          <p className="text-xs text-slate-400 mt-3">
            Data source: Google Search Console API · Position change vs. previous week
          </p>
        </div>
      )}

      {activeTab === 'pages' && (
        <div className="bg-white border border-slate-200 rounded-lg p-5">
          <h2 className="font-semibold text-slate-900 mb-4">Top Pages by Clicks</h2>
          <div className="space-y-3">
            {displayData.top_pages.map((page, i) => (
              <div key={i} className="border border-slate-100 rounded-lg p-3 hover:bg-slate-50">
                <div className="flex items-center justify-between mb-2">
                  <span className="text-sm font-medium text-blue-600 truncate max-w-sm">{page.url}</span>
                  <div className="flex items-center gap-4 text-xs text-slate-500 shrink-0 ml-4">
                    <span><strong className="text-slate-800">{page.clicks.toLocaleString()}</strong> clicks</span>
                    <span><strong className="text-slate-800">{page.impressions.toLocaleString()}</strong> impr.</span>
                    <span><strong className="text-slate-800">{(page.ctr * 100).toFixed(1)}%</strong> CTR</span>
                    <span>pos. <strong className="text-slate-800">{page.position.toFixed(1)}</strong></span>
                  </div>
                </div>
                <MiniBar value={page.clicks} max={maxClicks} color="bg-blue-400" />
              </div>
            ))}
          </div>
        </div>
      )}

      {activeTab === 'setup' && (
        <div className="space-y-6">
          <div className="bg-white border border-slate-200 rounded-lg p-5">
            <h2 className="font-semibold text-slate-900 mb-3">📊 Connect Data Sources</h2>
            <p className="text-sm text-slate-600 mb-4">
              This dashboard requires three data sources to show live metrics. Configure each one below.
            </p>

            <div className="space-y-4">
              {/* GA4 */}
              <div className="border border-slate-200 rounded-lg p-4">
                <div className="flex items-center justify-between mb-2">
                  <h3 className="font-medium text-slate-800">1. Google Analytics 4 (GA4)</h3>
                  <span className="text-xs bg-yellow-100 text-yellow-700 px-2 py-0.5 rounded">Not Connected</span>
                </div>
                <p className="text-sm text-slate-600 mb-2">Used for: Organic sessions, user behavior</p>
                <div className="bg-slate-900 rounded p-3 font-mono text-xs text-green-400 space-y-1">
                  <p># Add to server .env:</p>
                  <p>GA4_PROPERTY_ID=properties/XXXXXXXXX</p>
                  <p>GOOGLE_APPLICATION_CREDENTIALS=/path/to/service-account.json</p>
                  <p className="mt-2"># Install:</p>
                  <p>pip install google-analytics-data</p>
                </div>
              </div>

              {/* GSC */}
              <div className="border border-slate-200 rounded-lg p-4">
                <div className="flex items-center justify-between mb-2">
                  <h3 className="font-medium text-slate-800">2. Google Search Console (GSC)</h3>
                  <span className="text-xs bg-yellow-100 text-yellow-700 px-2 py-0.5 rounded">Not Connected</span>
                </div>
                <p className="text-sm text-slate-600 mb-2">Used for: Clicks, impressions, CTR, avg position, indexed pages</p>
                <div className="bg-slate-900 rounded p-3 font-mono text-xs text-green-400 space-y-1">
                  <p># Add to server .env:</p>
                  <p>GSC_SITE_URL=https://iraresearchhub.com</p>
                  <p>GOOGLE_APPLICATION_CREDENTIALS=/path/to/service-account.json</p>
                  <p className="mt-2"># Install:</p>
                  <p>pip install google-api-python-client</p>
                </div>
              </div>

              {/* DataForSEO / Semrush */}
              <div className="border border-slate-200 rounded-lg p-4">
                <div className="flex items-center justify-between mb-2">
                  <h3 className="font-medium text-slate-800">3. Keyword Rankings (DataForSEO or Semrush)</h3>
                  <span className="text-xs bg-yellow-100 text-yellow-700 px-2 py-0.5 rounded">Not Connected</span>
                </div>
                <p className="text-sm text-slate-600 mb-2">Used for: Keyword position tracking with historical data</p>
                <div className="bg-slate-900 rounded p-3 font-mono text-xs text-green-400 space-y-1">
                  <p># Add to server .env (choose one):</p>
                  <p>DATAFORSEO_LOGIN=your_login</p>
                  <p>DATAFORSEO_PASSWORD=your_password</p>
                  <p className="mt-1"># OR:</p>
                  <p>SEMRUSH_API_KEY=your_api_key</p>
                </div>
              </div>
            </div>
          </div>

          <div className="bg-white border border-slate-200 rounded-lg p-5">
            <h2 className="font-semibold text-slate-900 mb-3">🔄 Automated Data Collection</h2>
            <p className="text-sm text-slate-600 mb-3">
              Once connected, add these cron jobs to collect metrics weekly:
            </p>
            <div className="bg-slate-900 rounded p-3 font-mono text-xs text-green-400 space-y-1">
              <p># Weekly SEO metrics collection (every Monday at 8am)</p>
              <p>0 8 * * 1 cd /var/www/iraresearchhub/repo && python3 scripts/seo_metrics_collector.py</p>
              <p className="mt-2"># Daily keyword ranking check</p>
              <p>0 6 * * * cd /var/www/iraresearchhub/repo && python3 scripts/seo_metrics_collector.py --rankings-only</p>
            </div>
          </div>
        </div>
      )}
    </div>
  )
}
