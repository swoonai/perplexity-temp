import { Link } from 'react-router-dom'
import SEO from '../components/SEO'
import { useProvider, scoreColor } from '../hooks/useProviders'
import AdvertiserDisclosure from '../components/AdvertiserDisclosure'
import { trackProviderSiteVisit } from '../hooks/useAnalytics'
import NewsletterSignup from '../components/NewsletterSignup';
import RelatedLinks from '../components/RelatedLinks';

const DATE_MODIFIED = "2026-03-22"
const DATE_PUBLISHED = "2026-03-22"
const LAST_UPDATED = "March 22, 2026"

const comparisonSchema = {
  "@context": "https://schema.org",
  "@type": "Article",
  "@id": "https://iraresearchhub.com/precious-metals-ira/augusta-vs-goldco",
  "headline": "Augusta Precious Metals vs Goldco (2026): Which Gold IRA Is Better?",
  "description": "Side-by-side comparison of Augusta Precious Metals and Goldco. We compare fees, minimums, BBB ratings, storage options, and overall scores to help you choose the best gold IRA.",
  "author": {
    "@type": "Person",
    "@id": "https://iraresearchhub.com/author/james-mitchell",
    "name": "James Mitchell",
    "url": "https://iraresearchhub.com/author/james-mitchell"
  },
  "publisher": {
    "@type": "Organization",
    "@id": "https://iraresearchhub.com",
    "name": "IRA Research Hub",
    "url": "https://iraresearchhub.com"
  },
  "datePublished": DATE_PUBLISHED,
  "dateModified": DATE_MODIFIED,
  "url": "https://iraresearchhub.com/precious-metals-ira/augusta-vs-goldco"
}

const faqSchema = {
  "@context": "https://schema.org",
  "@type": "FAQPage",
  "mainEntity": [
    {
      "@type": "Question",
      "name": "Is Augusta Precious Metals better than Goldco?",
      "acceptedAnswer": {
        "@type": "Answer",
        "text": "Augusta Precious Metals scores 9.1/10 vs Goldco's 9.2/10 in our independent evaluation. Goldco edges ahead on overall score, but Augusta leads on customer education, fee transparency, and lifetime account support. Goldco is the better choice if you want a lower minimum investment ($25,000 vs Augusta's $50,000) or prefer a company with a broader product range."
      }
    },
    {
      "@type": "Question",
      "name": "What is the minimum investment for Augusta vs Goldco?",
      "acceptedAnswer": {
        "@type": "Answer",
        "text": "Augusta Precious Metals requires a $50,000 minimum investment for a gold IRA. Goldco requires a $25,000 minimum. Both are significantly higher than crypto IRA minimums, reflecting the higher cost of physical precious metals storage."
      }
    },
    {
      "@type": "Question",
      "name": "Which has better fees — Augusta or Goldco?",
      "acceptedAnswer": {
        "@type": "Answer",
        "text": "Both Augusta and Goldco charge similar annual fees: Augusta charges $180/year (custodian + storage), while Goldco charges $175-$225/year depending on account size. Augusta is more transparent about its fee structure, publishing all fees upfront on its website."
      }
    },
    {
      "@type": "Question",
      "name": "Are Augusta Precious Metals and Goldco IRS-approved?",
      "acceptedAnswer": {
        "@type": "Answer",
        "text": "Yes. Both Augusta Precious Metals and Goldco offer IRS-approved gold IRAs using IRS-qualified custodians (Equity Trust and Kingdom Trust respectively). All gold held must meet IRS purity requirements (99.5% for gold bars, 91.67% for American Gold Eagles)."
      }
    },
    {
      "@type": "Question",
      "name": "Which gold IRA company has better customer reviews?",
      "acceptedAnswer": {
        "@type": "Answer",
        "text": "Augusta Precious Metals has an A+ BBB rating with 4.9/5 stars and over 1,200 verified reviews. Goldco has an A+ BBB rating with 4.8/5 stars and over 3,500 verified reviews. Goldco has more reviews due to its larger customer base, while Augusta has a slightly higher average rating."
      }
    }
  ]
}

const speakableSchema = {
  "@context": "https://schema.org",
  "@type": "WebPage",
  "speakable": {
    "@type": "SpeakableSpecification",
    "cssSelector": [".speakable-summary", "h1", ".citation-block", ".verdict-box"]
  },
  "url": "https://iraresearchhub.com/precious-metals-ira/augusta-vs-goldco"
}

export default function AugustaVsGoldcoPage() {
  const { data: augustaData } = useProvider('augusta-precious-metals')
  const { data: goldcoData } = useProvider('goldco')

  // Fallback data for pre-rendering
  const augusta = augustaData ?? {
    name: "Augusta Precious Metals",
    score_overall: 9.1, score_fees: 8.5, score_assets: 8.0,
    score_security: 9.4, score_compliance: 9.5, score_support: 9.7, score_reputation: 9.6,
    annual_fee: "$180/year", transaction_fee: "N/A (fixed spread)", min_investment: "$50,000",
    asset_count: 4, custody_provider: "Equity Trust", storage_type: "Segregated Cold Storage",
    insurance_coverage: "Lloyd's of London", bbb_rating: "A+", founded_year: 2012,
    affiliate_url: "https://www.augustapreciousmetals.com/?ref=iraresearchhub"
  }

  const goldco = goldcoData ?? {
    name: "Goldco",
    score_overall: 9.2, score_fees: 8.9, score_assets: 8.5,
    score_security: 9.2, score_compliance: 9.3, score_support: 9.4, score_reputation: 9.5,
    annual_fee: "$175-$225/year", transaction_fee: "N/A (fixed spread)", min_investment: "$25,000",
    asset_count: 8, custody_provider: "Kingdom Trust", storage_type: "Segregated Cold Storage",
    insurance_coverage: "Lloyd's of London", bbb_rating: "A+", founded_year: 2006,
    affiliate_url: "https://www.goldco.com/?ref=iraresearchhub"
  }

  return (
    <>
      <SEO
        title="Augusta Precious Metals vs Goldco (2026): Which Gold IRA Wins?"
        description="Augusta Precious Metals vs Goldco: independent side-by-side comparison of fees, minimums, BBB ratings, storage, and scores. Augusta scores 9.1/10 vs Goldco's 9.2/10."
        canonical="/precious-metals-ira/augusta-vs-goldco"
        ogType="article"
      />
      <script type="application/ld+json" dangerouslySetInnerHTML={{ __html: JSON.stringify(comparisonSchema) }} />
      <script type="application/ld+json" dangerouslySetInnerHTML={{ __html: JSON.stringify(faqSchema) }} />
      <script type="application/ld+json" dangerouslySetInnerHTML={{ __html: JSON.stringify(speakableSchema) }} />

      {/* Hero */}
      <section className="bg-[#F8FAFC] border-b border-slate-200">
        <div className="container-site py-12">
          <div className="flex flex-wrap items-center gap-2 mb-4">
            <Link to="/precious-metals-ira" className="text-sm text-[#64748B] hover:text-[#D97706]">Precious Metals IRAs</Link>
            <span className="text-slate-300">/</span>
            <Link to="/precious-metals-ira/best-companies" className="text-sm text-[#64748B] hover:text-[#D97706]">Gold IRA Provider Comparison & Independent Analysis</Link>
            <span className="text-slate-300">/</span>
            <span className="text-sm text-[#0F172A]">Augusta vs Goldco</span>
          </div>
          <div className="inline-flex items-center px-2.5 py-0.5 rounded-full text-xs font-medium bg-amber-100 text-amber-700 mb-4">
            Updated {LAST_UPDATED} · Independent Research
          </div>
          <h1 className="text-4xl font-bold text-[#0F172A] mb-3">
            Augusta Precious Metals vs Goldco (2026)
          </h1>
          <p className="text-sm text-slate-400 mt-2">
            By <a href="/author/james-mitchell" className="text-[#D97706] hover:underline">James Mitchell, CFA</a> · Last updated: {LAST_UPDATED} · <a href="/methodology" className="text-[#D97706] hover:underline">Methodology</a>
          </p>
          <AdvertiserDisclosure />
          <p className="speakable-summary text-lg text-[#64748B] max-w-2xl mt-3">
            Augusta Precious Metals and Goldco are the two most-reviewed gold IRA companies in 2026. 
            Augusta scores <strong>9.1/10</strong> vs Goldco's <strong>9.2/10</strong> in our independent evaluation. 
            Augusta leads on education, fee transparency, and customer support — but Goldco's lower $25,000 minimum makes it more accessible.
          </p>
        </div>
      </section>

      {/* Quick Verdict */}
      <section className="section-padding">
        <div className="container-site">
          <div className="verdict-box bg-amber-50 border border-amber-200 rounded-xl p-6 mb-8">
            <h2 className="text-xl font-bold text-[#0F172A] mb-3">Quick Verdict</h2>
            <div className="grid md:grid-cols-2 gap-4">
              <div className="bg-white rounded-lg p-4 border border-amber-200">
                <div className="flex items-center gap-2 mb-2">
                  <span className="text-2xl">🥇</span>
                  <span className="font-bold text-[#D97706]">Top-Ranked by Score</span>
                </div>
                <p className="font-semibold text-[#0F172A]">Goldco</p>
                <p className="text-sm text-slate-500 mt-1">Best for: Investors with $25,000–$50,000 who want a trusted brand with a broader product range.</p>
                <p className="text-2xl font-bold text-[#D97706] mt-2">9.2/10</p>
              </div>
              <div className="bg-white rounded-lg p-4 border border-slate-200">
                <div className="flex items-center gap-2 mb-2">
                  <span className="text-2xl">🥈</span>
                  <span className="font-bold text-slate-600">Runner-Up</span>
                </div>
                <p className="font-semibold text-[#0F172A]">Augusta Precious Metals</p>
                <p className="text-sm text-slate-500 mt-1">Best for: High-net-worth investors who want premium education, transparent fees, and lifetime account support.</p>
                <p className="text-2xl font-bold text-slate-600 mt-2">9.1/10</p>
              </div>
            </div>
          </div>

          {/* Score Comparison Table */}
          <h2 className="text-2xl font-bold text-[#0F172A] mb-4">Score Comparison</h2>
          <div className="overflow-x-auto mb-8">
            <table className="w-full border-collapse">
              <thead>
                <tr className="bg-slate-50">
                  <th className="text-left p-3 text-sm font-semibold text-slate-600 border border-slate-200">Criterion (Weight)</th>
                  <th className="text-center p-3 text-sm font-semibold text-[#D97706] border border-slate-200">Augusta</th>
                  <th className="text-center p-3 text-sm font-semibold text-slate-600 border border-slate-200">Goldco</th>
                  <th className="text-center p-3 text-sm font-semibold text-slate-600 border border-slate-200">Winner</th>
                </tr>
              </thead>
              <tbody>
                {[
                  { label: "Fee Transparency (20%)", aug: augusta.score_fees, gc: goldco.score_fees },
                  { label: "Asset Selection (20%)", aug: augusta.score_assets, gc: goldco.score_assets },
                  { label: "Security & Custody (20%)", aug: augusta.score_security, gc: goldco.score_security },
                  { label: "IRS Compliance (15%)", aug: augusta.score_compliance, gc: goldco.score_compliance },
                  { label: "Customer Support (15%)", aug: augusta.score_support, gc: goldco.score_support },
                  { label: "Reputation (10%)", aug: augusta.score_reputation, gc: goldco.score_reputation },
                ].map((row) => (
                  <tr key={row.label} className="hover:bg-slate-50">
                    <td className="p-3 text-sm text-[#334155] border border-slate-200">{row.label}</td>
                    <td className={`p-3 text-center font-semibold border border-slate-200 ${scoreColor(row.aug)}`}>
                      {row.aug?.toFixed(1) ?? "—"}
                    </td>
                    <td className={`p-3 text-center font-semibold border border-slate-200 ${scoreColor(row.gc)}`}>
                      {row.gc?.toFixed(1) ?? "—"}
                    </td>
                    <td className="p-3 text-center text-sm border border-slate-200">
                      {(row.aug ?? 0) > (row.gc ?? 0) ? "🥇 Augusta" : (row.gc ?? 0) > (row.aug ?? 0) ? "🥇 Goldco" : "Tie"}
                    </td>
                  </tr>
                ))}
                <tr className="bg-amber-50 font-bold">
                  <td className="p-3 text-sm text-[#0F172A] border border-slate-200">Overall Score</td>
                  <td className="p-3 text-center text-[#D97706] border border-slate-200">{augusta.score_overall?.toFixed(1) ?? "9.1"}</td>
                  <td className="p-3 text-center text-slate-600 border border-slate-200">{goldco.score_overall?.toFixed(1) ?? "9.2"}</td>
                  <td className="p-3 text-center text-sm border border-slate-200">🥇 Goldco</td>
                </tr>
              </tbody>
            </table>
          </div>

          {/* Key Specs Comparison */}
          <h2 className="text-2xl font-bold text-[#0F172A] mb-4">Key Specs: Side-by-Side</h2>
          <div className="overflow-x-auto mb-8">
            <table className="w-full border-collapse">
              <thead>
                <tr className="bg-slate-50">
                  <th className="text-left p-3 text-sm font-semibold text-slate-600 border border-slate-200">Feature</th>
                  <th className="text-center p-3 text-sm font-semibold text-[#D97706] border border-slate-200">Augusta Precious Metals</th>
                  <th className="text-center p-3 text-sm font-semibold text-slate-600 border border-slate-200">Goldco</th>
                </tr>
              </thead>
              <tbody>
                {[
                  { feature: "Minimum Investment", aug: "$50,000", gc: "$25,000" },
                  { feature: "Annual Fee", aug: "$180/year", gc: "$175–$225/year" },
                  { feature: "Setup Fee", aug: "$0", gc: "$0" },
                  { feature: "Custodian", aug: "Equity Trust", gc: "Kingdom Trust" },
                  { feature: "Storage", aug: "Segregated cold storage", gc: "Segregated cold storage" },
                  { feature: "Insurance", aug: "Lloyd's of London", gc: "Lloyd's of London" },
                  { feature: "Metals Offered", aug: "Gold, Silver", gc: "Gold, Silver, Platinum, Palladium" },
                  { feature: "BBB Rating", aug: "A+", gc: "A+" },
                  { feature: "Founded", aug: "2012", gc: "2006" },
                  { feature: "IRS-Approved", aug: "✅ Yes", gc: "✅ Yes" },
                  { feature: "Free Education Kit", aug: "✅ Yes (gold IRA guide)", gc: "✅ Yes (wealth protection kit)" },
                  { feature: "Buyback Program", aug: "✅ Lifetime guarantee", gc: "✅ Yes" },
                ].map((row) => (
                  <tr key={row.feature} className="hover:bg-slate-50">
                    <td className="p-3 text-sm font-medium text-[#334155] border border-slate-200">{row.feature}</td>
                    <td className="p-3 text-center text-sm text-[#0F172A] border border-slate-200">{row.aug}</td>
                    <td className="p-3 text-center text-sm text-[#0F172A] border border-slate-200">{row.gc}</td>
                  </tr>
                ))}
              </tbody>
            </table>
          </div>

          {/* Detailed Analysis */}
          <div className="grid md:grid-cols-2 gap-8 mb-8">
            {/* Augusta */}
            <div className="bg-white border border-slate-200 rounded-xl p-6">
              <h2 className="text-xl font-bold text-[#0F172A] mb-3">Augusta Precious Metals — In Depth</h2>
              <div className="citation-block bg-amber-50 border-l-4 border-amber-400 p-4 rounded mb-4">
                <p className="text-sm font-semibold text-amber-800">Notable for high-net-worth investors who want premium education and transparent pricing.</p>
              </div>
              <h3 className="font-semibold text-[#0F172A] mb-2">Pros</h3>
              <ul className="space-y-1 mb-4">
                {[
                  "Highest transparency — all fees published upfront",
                  "Lifetime account support from dedicated agent",
                  "One-on-one web conference with Harvard economist",
                  "A+ BBB with 4.9/5 stars (1,200+ reviews)",
                  "Buyback guarantee at current market price",
                  "Zero complaints with BBB in 3+ years",
                ].map((pro) => (
                  <li key={pro} className="flex items-start gap-2 text-sm text-[#334155]">
                    <span className="text-green-500 mt-0.5">✓</span>
                    {pro}
                  </li>
                ))}
              </ul>
              <h3 className="font-semibold text-[#0F172A] mb-2">Cons</h3>
              <ul className="space-y-1 mb-4">
                {[
                  "$50,000 minimum — highest in the industry",
                  "Only gold and silver (no platinum/palladium)",
                  "Longer setup time (2–4 weeks for rollovers)",
                ].map((con) => (
                  <li key={con} className="flex items-start gap-2 text-sm text-[#334155]">
                    <span className="text-red-400 mt-0.5">✗</span>
                    {con}
                  </li>
                ))}
              </ul>
              {augusta.affiliate_url && (
                <a
                  href={augusta.affiliate_url}
                  target="_blank"
                  rel="noopener noreferrer sponsored"
                  className="inline-flex items-center justify-center w-full px-4 py-2 bg-[#D97706] text-white text-sm font-semibold rounded-lg hover:bg-[#B45309] transition-colors"
                  onClick={() => trackProviderSiteVisit('Augusta Precious Metals', 'augusta-precious-metals', augusta.affiliate_url!)}
                >
                  Visit Augusta Precious Metals →
                </a>
              )}
              <Link
                to="/precious-metals-ira/augusta-precious-metals-review"
                className="block text-center text-sm text-[#D97706] hover:underline mt-2"
                aria-label="Read our full Augusta Precious Metals review"
              >
                Read Full Augusta Precious Metals Review →
              </Link>
            </div>

            {/* Goldco */}
            <div className="bg-white border border-slate-200 rounded-xl p-6">
              <h2 className="text-xl font-bold text-[#0F172A] mb-3">Goldco — In Depth</h2>
              <div className="citation-block bg-slate-50 border-l-4 border-slate-400 p-4 rounded mb-4">
                <p className="text-sm font-semibold text-slate-700">Notable for investors with $25,000–$50,000 who want a trusted brand with broader metals selection.</p>
              </div>
              <h3 className="font-semibold text-[#0F172A] mb-2">Pros</h3>
              <ul className="space-y-1 mb-4">
                {[
                  "Lower $25,000 minimum — more accessible",
                  "4 metals: gold, silver, platinum, palladium",
                  "A+ BBB with 4.8/5 stars (3,500+ reviews)",
                  "20+ years in business (founded 2006)",
                  "Strong celebrity endorsements (Sean Hannity, Chuck Norris)",
                  "Aggressive promotions (up to $10,000 in free silver)",
                ].map((pro) => (
                  <li key={pro} className="flex items-start gap-2 text-sm text-[#334155]">
                    <span className="text-green-500 mt-0.5">✓</span>
                    {pro}
                  </li>
                ))}
              </ul>
              <h3 className="font-semibold text-[#0F172A] mb-2">Cons</h3>
              <ul className="space-y-1 mb-4">
                {[
                  "Less fee transparency than Augusta",
                  "High-pressure sales tactics reported by some customers",
                  "Promotional offers may inflate perceived value",
                ].map((con) => (
                  <li key={con} className="flex items-start gap-2 text-sm text-[#334155]">
                    <span className="text-red-400 mt-0.5">✗</span>
                    {con}
                  </li>
                ))}
              </ul>
              {goldco.affiliate_url && (
                <a
                  href={goldco.affiliate_url}
                  target="_blank"
                  rel="noopener noreferrer sponsored"
                  className="inline-flex items-center justify-center w-full px-4 py-2 bg-slate-700 text-white text-sm font-semibold rounded-lg hover:bg-slate-800 transition-colors"
                  onClick={() => trackProviderSiteVisit('Goldco', 'goldco', goldco.affiliate_url!)}
                >
                  Visit Goldco →
                </a>
              )}
              <Link
                to="/precious-metals-ira/goldco-review"
                className="block text-center text-sm text-[#D97706] hover:underline mt-2"
                aria-label="Read our full Goldco review"
              >
                Read Full Goldco Review →
              </Link>
            </div>
          </div>

          {/* FAQ Section */}
          <h2 className="text-2xl font-bold text-[#0F172A] mb-4">Frequently Asked Questions</h2>
          <div className="space-y-4 mb-8">
            {faqSchema.mainEntity.map((item) => (
              <details key={item.name} className="bg-slate-50 border border-slate-200 rounded-lg p-4">
                <summary className="font-semibold text-[#0F172A] cursor-pointer">{item.name}</summary>
                <p className="mt-2 text-sm text-[#334155]">{item.acceptedAnswer.text}</p>
              </details>
            ))}
          </div>

          {/* Bottom CTA */}
          <div className="bg-amber-50 border border-amber-200 rounded-xl p-6 text-center">
            <h2 className="text-xl font-bold text-[#0F172A] mb-2">Not sure which is right for you?</h2>
            <p className="text-sm text-slate-600 mb-4">
              Compare all 12 precious metals IRA providers side-by-side, including fees, minimums, and independent scores.
            </p>
            <Link
              to="/precious-metals-ira/best-companies"
              className="inline-flex items-center justify-center px-6 py-3 bg-[#D97706] text-white font-semibold rounded-lg hover:bg-[#B45309] transition-colors"
            >
              See All Gold IRA Rankings →
            </Link>
          </div>
        </div>
      </section>
      {/* ── Newsletter Signup ─────────────────────────────────────────── */}
      <div className="container-site py-10 max-w-3xl">
        
        {/* Related Links */}

        <div className="mt-10 mb-6">

          <RelatedLinks variant="crypto-guide" title="Related Guides &amp; Reviews" />

        </div>
<NewsletterSignup />
      </div>
    </>
  )
}
