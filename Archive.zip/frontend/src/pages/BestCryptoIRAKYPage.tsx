import StateGuideTemplate from '../components/StateGuideTemplate'

export default function BestCryptoIRAKYPage() {
  return (
    <StateGuideTemplate
      stateName="Kentucky"
      stateAbbr="KY"
      slug="kentucky"
    />
  )
}
