import StateGuideTemplate from '../components/StateGuideTemplate'

export default function BestCryptoIRAIAPage() {
  return (
    <StateGuideTemplate
      stateName="Iowa"
      stateAbbr="IA"
      slug="iowa"
    />
  )
}
