import { useState } from 'react';
import { Helmet } from 'react-helmet-async';
import BeehiivEmbed from '../components/BeehiivEmbed';

// ─── Quiz Data ────────────────────────────────────────────────────────────────
const QUESTIONS = [
  {
    id: 'goal',
    question: 'What is your primary retirement savings goal?',
    options: [
      { label: 'Protect wealth from inflation with physical gold/silver', value: 'gold' },
      { label: 'Grow wealth with Bitcoin and crypto assets', value: 'crypto' },
      { label: 'Diversify — I want both precious metals and crypto', value: 'both' },
      { label: "I'm not sure yet — I want to compare options", value: 'unsure' },
    ],
  },
  {
    id: 'amount',
    question: 'How much are you looking to invest in your IRA?',
    options: [
      { label: 'Under $10,000', value: 'small' },
      { label: '$10,000 – $50,000', value: 'medium' },
      { label: '$50,000 – $250,000', value: 'large' },
      { label: 'Over $250,000', value: 'xlarge' },
    ],
  },
  {
    id: 'risk',
    question: 'How would you describe your risk tolerance?',
    options: [
      { label: 'Conservative — I prioritize capital preservation', value: 'low' },
      { label: 'Moderate — I balance growth with stability', value: 'medium' },
      { label: 'Aggressive — I can handle significant volatility for higher returns', value: 'high' },
    ],
  },
  {
    id: 'crypto',
    question: 'How familiar are you with cryptocurrency?',
    options: [
      { label: "Not at all — I'm new to crypto", value: 'none' },
      { label: "I've heard of Bitcoin but haven't invested", value: 'basic' },
      { label: 'I own or have owned crypto before', value: 'experienced' },
    ],
  },
  {
    id: 'timeline',
    question: 'When do you plan to retire or access these funds?',
    options: [
      { label: 'Within 5 years', value: 'near' },
      { label: '5–15 years', value: 'medium' },
      { label: 'More than 15 years away', value: 'long' },
    ],
  },
];

// ─── Recommendation Logic ─────────────────────────────────────────────────────
type Answers = Record<string, string>;

interface Recommendation {
  type: 'crypto' | 'gold' | 'both';
  headline: string;
  description: string;
  providers: Array<{ name: string; url: string; badge: string }>;
}

function getRecommendation(answers: Answers): Recommendation {
  const { goal, risk, crypto: cryptoFamiliarity, amount } = answers;

  const wantsGold = goal === 'gold';
  const wantsCrypto = goal === 'crypto';
  const isConservative = risk === 'low';
  const isAggressive = risk === 'high';
  const hasCryptoExp = cryptoFamiliarity === 'experienced';
  const isLargeInvestor = amount === 'large' || amount === 'xlarge';

  if (wantsGold || (isConservative && !wantsCrypto)) {
    return {
      type: 'gold',
      headline: 'A Gold IRA is your best fit',
      description:
        'Based on your goals and risk profile, a Precious Metals IRA is the right choice. You get the inflation-hedging power of physical gold and silver inside a tax-advantaged retirement account.',
      providers: [
        { name: 'Genesis Gold Group', url: '/reviews/genesis-gold-group', badge: 'Best for High-Net-Worth' },
        { name: 'Augusta Precious Metals', url: '/reviews/augusta-precious-metals', badge: 'Best Customer Service' },
        { name: 'Goldco', url: '/reviews/goldco', badge: 'Most Popular' },
      ],
    };
  }

  if (wantsCrypto || (isAggressive && hasCryptoExp)) {
    return {
      type: 'crypto',
      headline: 'A Crypto IRA is your best fit',
      description:
        'Your goals and experience point to a Crypto IRA. You can hold Bitcoin, Ethereum, and other digital assets in a tax-advantaged account — combining crypto upside with IRA tax benefits.',
      providers: [
        { name: 'BlockTrust IRA', url: '/reviews/blocktrust-ira', badge: 'Best Overall 2026' },
        { name: 'iTrustCapital', url: '/reviews/itrustcapital', badge: 'Best for Active Traders' },
        { name: 'Bitcoin IRA', url: '/reviews/bitcoin-ira', badge: 'Largest Selection' },
      ],
    };
  }

  // Default: both / diversified
  return {
    type: 'both',
    headline: 'A diversified Self-Directed IRA is your best fit',
    description:
      isLargeInvestor
        ? "With your investment size, diversifying across both precious metals and crypto inside a Self-Directed IRA gives you inflation protection and growth potential. This is the strategy many high-net-worth investors use."
        : "Diversifying across both precious metals and crypto inside a Self-Directed IRA gives you the best of both worlds — inflation protection from gold and growth potential from crypto.",
    providers: [
      { name: 'BlockTrust IRA', url: '/reviews/blocktrust-ira', badge: 'Best Crypto IRA 2026' },
      { name: 'Genesis Gold Group', url: '/reviews/genesis-gold-group', badge: 'Best Gold IRA 2026' },
      { name: 'Augusta Precious Metals', url: '/reviews/augusta-precious-metals', badge: 'Best Customer Service' },
    ],
  };
}

// ─── Progress Bar ─────────────────────────────────────────────────────────────
function ProgressBar({ current, total }: { current: number; total: number }) {
  const pct = Math.round((current / total) * 100);
  return (
    <div className="w-full bg-slate-100 rounded-full h-1.5 mb-6">
      <div
        className="bg-blue-600 h-1.5 rounded-full transition-all duration-300"
        style={{ width: `${pct}%` }}
      />
    </div>
  );
}

// ─── Main Page ────────────────────────────────────────────────────────────────
export default function IRAFitQuizPage() {
  const [step, setStep] = useState<'intro' | 'quiz' | 'email' | 'result'>('intro');
  const [currentQ, setCurrentQ] = useState(0);
  const [answers, setAnswers] = useState<Answers>({});
  const [recommendation, setRecommendation] = useState<Recommendation | null>(null);

  function handleAnswer(questionId: string, value: string) {
    const newAnswers = { ...answers, [questionId]: value };
    setAnswers(newAnswers);

    if (currentQ < QUESTIONS.length - 1) {
      setCurrentQ(currentQ + 1);
    } else {
      // All questions answered — compute recommendation and show email gate
      const rec = getRecommendation(newAnswers);
      setRecommendation(rec);
      setStep('email');
    }
  }

  function handleEmailSubmitted() {
    setStep('result');
    // Fire GA4 event
    if (typeof window !== 'undefined' && (window as any).gtag) {
      (window as any).gtag('event', 'quiz_complete', {
        event_category: 'engagement',
        event_label: recommendation?.type ?? 'unknown',
      });
    }
  }

  const q = QUESTIONS[currentQ];

  return (
    <>
      <Helmet>
        <title>IRA Fit Quiz — Find the Right IRA for You | IRA Research Hub</title>
        <meta
          name="description"
          content="Answer 5 quick questions to find out whether a Crypto IRA, Gold IRA, or diversified Self-Directed IRA is right for your retirement goals."
        />
        <meta name="robots" content="index, follow" />
        <link rel="canonical" href="https://iraresearchhub.com/quiz" />
      </Helmet>

      <div className="max-w-2xl mx-auto px-4 py-12 sm:py-16">

        {/* ── Intro ── */}
        {step === 'intro' && (
          <div className="text-center">
            <span className="inline-block bg-blue-50 text-blue-700 text-xs font-semibold uppercase tracking-widest px-3 py-1 rounded-full mb-4">
              Free · 2 minutes
            </span>
            <h1 className="text-3xl sm:text-4xl font-bold text-slate-900 mb-4">
              Which IRA is right for you?
            </h1>
            <p className="text-lg text-slate-600 mb-8 max-w-lg mx-auto">
              Answer 5 quick questions and we'll match you with the IRA type and providers that best fit your retirement goals.
            </p>
            <div className="grid grid-cols-3 gap-4 mb-10 text-center">
              {([
                { icon: '🪙', label: 'Gold IRA' },
                { icon: '₿', label: 'Crypto IRA' },
                { icon: '📊', label: 'Diversified SDIRA' },
              ] as Array<{ icon: string; label: string }>).map((item) => (
                <div key={item.label} className="bg-slate-50 rounded-xl p-4 border border-slate-100">
                  <div className="text-2xl mb-1">{item.icon}</div>
                  <div className="text-sm font-medium text-slate-700">{item.label}</div>
                </div>
              ))}
            </div>
            <button
              onClick={() => setStep('quiz')}
              className="inline-flex items-center gap-2 bg-blue-600 hover:bg-blue-700 text-white font-semibold px-8 py-4 rounded-xl text-lg transition-colors shadow-sm"
            >
              Start the Quiz →
            </button>
            <p className="text-xs text-slate-400 mt-4">No email required to start. Takes ~2 minutes.</p>
          </div>
        )}

        {/* ── Quiz ── */}
        {step === 'quiz' && (
          <div>
            <ProgressBar current={currentQ + 1} total={QUESTIONS.length} />
            <p className="text-xs font-semibold text-slate-400 uppercase tracking-widest mb-3">
              Question {currentQ + 1} of {QUESTIONS.length}
            </p>
            <h2 className="text-xl sm:text-2xl font-bold text-slate-900 mb-6">{q.question}</h2>
            <div className="space-y-3">
              {q.options.map((opt) => (
                <button
                  key={opt.value}
                  onClick={() => handleAnswer(q.id, opt.value)}
                  className="w-full text-left px-5 py-4 rounded-xl border border-slate-200 hover:border-blue-400 hover:bg-blue-50 transition-all text-slate-800 font-medium text-sm sm:text-base"
                >
                  {opt.label}
                </button>
              ))}
            </div>
            {currentQ > 0 && (
              <button
                onClick={() => setCurrentQ(currentQ - 1)}
                className="mt-6 text-sm text-slate-400 hover:text-slate-600 transition-colors"
              >
                ← Back
              </button>
            )}
          </div>
        )}

        {/* ── Email Gate ── */}
        {step === 'email' && recommendation && (
          <div className="text-center">
            <div className="text-4xl mb-4">
              {recommendation.type === 'gold' ? '🪙' : recommendation.type === 'crypto' ? '₿' : '📊'}
            </div>
            <h2 className="text-2xl font-bold text-slate-900 mb-2">Your results are ready!</h2>
            <p className="text-slate-600 mb-6 max-w-md mx-auto">
              Enter your email to see your personalized IRA recommendation — plus a free weekly digest of IRA rule changes, fee updates, and provider news.
            </p>
            <div className="bg-white border border-slate-200 rounded-2xl p-6 shadow-sm mb-4">
              <BeehiivEmbed variant="light" />
            </div>
            <button
              onClick={handleEmailSubmitted}
              className="text-sm text-slate-400 hover:text-slate-600 underline transition-colors"
            >
              Skip — show my results without subscribing
            </button>
          </div>
        )}

        {/* ── Result ── */}
        {step === 'result' && recommendation && (
          <div>
            <div className="text-center mb-8">
              <div className="text-5xl mb-4">
                {recommendation.type === 'gold' ? '🪙' : recommendation.type === 'crypto' ? '₿' : '📊'}
              </div>
              <h1 className="text-2xl sm:text-3xl font-bold text-slate-900 mb-3">
                {recommendation.headline}
              </h1>
              <p className="text-slate-600 max-w-lg mx-auto">{recommendation.description}</p>
            </div>

            <h2 className="text-lg font-semibold text-slate-800 mb-4">Top providers for you:</h2>
            <div className="space-y-3 mb-10">
              {recommendation.providers.map((p, idx) => (
                <a
                  key={p.name}
                  href={p.url}
                  className="flex items-center justify-between p-4 bg-white border border-slate-200 rounded-xl hover:border-blue-400 hover:shadow-sm transition-all group"
                >
                  <div className="flex items-center gap-3">
                    <span className="w-7 h-7 flex items-center justify-center rounded-full bg-blue-50 text-blue-700 text-xs font-bold">
                      {idx + 1}
                    </span>
                    <div>
                      <div className="font-semibold text-slate-900 group-hover:text-blue-700 transition-colors">
                        {p.name}
                      </div>
                      <div className="text-xs text-slate-500">{p.badge}</div>
                    </div>
                  </div>
                  <span className="text-blue-600 text-sm font-medium group-hover:translate-x-0.5 transition-transform">
                    Read review →
                  </span>
                </a>
              ))}
            </div>

            <div className="bg-slate-50 border border-slate-100 rounded-xl p-5 text-center">
              <p className="text-sm text-slate-600 mb-3">
                Want a deeper comparison? See our full rankings.
              </p>
              <div className="flex flex-col sm:flex-row gap-3 justify-center">
                <a
                  href="/best-crypto-ira-2026"
                  className="inline-block bg-blue-600 hover:bg-blue-700 text-white font-semibold px-5 py-2.5 rounded-lg text-sm transition-colors"
                >
                  Best Crypto IRAs 2026
                </a>
                <a
                  href="/best-gold-ira-2026"
                  className="inline-block bg-slate-700 hover:bg-slate-800 text-white font-semibold px-5 py-2.5 rounded-lg text-sm transition-colors"
                >
                  Best Gold IRAs 2026
                </a>
              </div>
            </div>
          </div>
        )}
      </div>
    </>
  );
}
