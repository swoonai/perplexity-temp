import { Helmet } from "react-helmet-async";
import AdvertiserDisclosure from '../components/AdvertiserDisclosure'
import NewsletterSignup from '../components/NewsletterSignup';
import RelatedLinks from '../components/RelatedLinks';

const LAST_UPDATED = "March 20, 2026";
const PUBLISH_DATE = "2026-03-20";

// Normalized fee data — sourced from provider disclosures, March 2026
const cryptoProviders = [
  {
    name: "iTrustCapital",
    slug: "itrustcapital",
    reviewPath: "/crypto-ira/itrustcapital-review",
    setupFee: 0,
    annualFee: 0,
    tradingFee: "1% per trade",
    tradingFeeNum: 1.0,
    minimumInvestment: 1000,
    minimumInvestmentDisplay: "$1,000",
    custodian: "Equity Trust",
    storage: "Coinbase Custody",
    assetsSupported: 30,
    insuranceCoverage: "$250M (Coinbase)",
    irsApproved: true,
    scoreOverall: 8.8,
    scoreFees: 8.5,
    scoreSecurity: 8.7,
    scoreAssets: 8.2,
    highlight: "Notable for active traders — low 1% fee with no annual charge",
  },
  {
    name: "Bitcoin IRA",
    slug: "bitcoin-ira",
    reviewPath: "/crypto-ira/bitcoin-ira-review",
    setupFee: 0,
    annualFee: 0,
    tradingFee: "2% per trade",
    tradingFeeNum: 2.0,
    minimumInvestment: 1000,
    minimumInvestmentDisplay: "$1,000",
    custodian: "Digital Trust",
    storage: "BitGo Trust",
    assetsSupported: 60,
    insuranceCoverage: "$700M (BitGo)",
    irsApproved: true,
    scoreOverall: 9.0,
    scoreFees: 7.8,
    scoreSecurity: 9.5,
    scoreAssets: 9.2,
    highlight: "Most established platform — 60+ cryptocurrencies",
  },
  {
    name: "BlockTrust IRA",
    slug: "blocktrust-ira",
    reviewPath: "/crypto-ira/blocktrust-ira-review",
    setupFee: 0,
    annualFee: 0,
    annualFeeDisplay: "2% annual + 25% performance",
    tradingFee: "0.14% via sFOX",
    tradingFeeNum: 0.14,
    minimumInvestment: 20000,
    minimumInvestmentDisplay: "$20,000",
    custodian: "sFOX",
    storage: "100% Cold Storage",
    assetsSupported: 60,
    insuranceCoverage: "$200M",
    irsApproved: true,
    scoreOverall: 9.6,
    scoreFees: 9.5,
    scoreSecurity: 9.7,
    scoreAssets: 9.8,
    highlight: "Animus AI 24/7 managed portfolio — best for hands-off investors who want professional management",
  },
  {
    name: "Alto CryptoIRA",
    slug: "alto-crypto-ira",
    reviewPath: "/crypto-ira/alto-crypto-ira-review",
    setupFee: 0,
    annualFee: 0,
    tradingFee: "1% per trade",
    tradingFeeNum: 1.0,
    minimumInvestment: 10,
    minimumInvestmentDisplay: "$10",
    custodian: "Millennium Trust",
    storage: "Coinbase",
    assetsSupported: 200,
    insuranceCoverage: "$250M (Coinbase)",
    irsApproved: true,
    scoreOverall: 8.6,
    scoreFees: 9.4,
    scoreSecurity: 8.9,
    scoreAssets: 9.8,
    highlight: "Lowest minimum ($10) — best for beginners",
  },
  {
    name: "BitIRA",
    slug: "bitira",
    reviewPath: "/crypto-ira/bitira-review",
    setupFee: 0,
    annualFee: 0,
    tradingFee: "Variable (spread-based)",
    tradingFeeNum: 1.5,
    minimumInvestment: 5000,
    minimumInvestmentDisplay: "$5,000",
    custodian: "Equity Trust",
    storage: "Delaware Depository",
    assetsSupported: 15,
    insuranceCoverage: "$100M (Lloyd's of London)",
    irsApproved: true,
    scoreOverall: 8.5,
    scoreFees: 7.8,
    scoreSecurity: 9.5,
    scoreAssets: 7.6,
    highlight: "Physical cold storage in Delaware — highest security tier",
  },
  {
    name: "Swan Bitcoin IRA",
    slug: "swan-bitcoin-ira",
    reviewPath: "/crypto-ira/swan-bitcoin-ira-review",
    setupFee: 0,
    annualFee: 0,
    tradingFee: "0.99% per trade",
    tradingFeeNum: 0.99,
    minimumInvestment: 1000,
    minimumInvestmentDisplay: "$1,000",
    custodian: "Prime Trust",
    storage: "Unchained Capital",
    assetsSupported: 1,
    insuranceCoverage: "$125M (Prime Trust)",
    irsApproved: true,
    scoreOverall: 8.3,
    scoreFees: 9.2,
    scoreSecurity: 9.4,
    scoreAssets: 6.0,
    highlight: "Bitcoin-only — best for pure BTC IRA strategy",
  },
  {
    name: "Rocket Dollar",
    slug: "rocket-dollar",
    reviewPath: "/crypto-ira/rocket-dollar-review",
    setupFee: 360,
    annualFee: 180,
    tradingFee: "None (self-directed)",
    tradingFeeNum: 0,
    minimumInvestment: 0,
    minimumInvestmentDisplay: "None",
    custodian: "Self-directed LLC",
    storage: "User-chosen exchange",
    assetsSupported: 999,
    insuranceCoverage: "User-arranged",
    irsApproved: true,
    scoreOverall: 8.1,
    scoreFees: 7.5,
    scoreSecurity: 8.0,
    scoreAssets: 9.9,
    highlight: "Unlimited assets via self-directed LLC — most flexible",
  },
  {
    name: "Unchained IRA",
    slug: "unchained-ira",
    reviewPath: "/crypto-ira/unchained-ira-review",
    setupFee: 0,
    annualFee: 250,
    tradingFee: "0.5% per trade",
    tradingFeeNum: 0.5,
    minimumInvestment: 10000,
    minimumInvestmentDisplay: "$10,000",
    custodian: "Equity Trust",
    storage: "Multi-sig cold storage",
    assetsSupported: 1,
    insuranceCoverage: "$100M",
    irsApproved: true,
    scoreOverall: 8.0,
    scoreFees: 8.0,
    scoreSecurity: 9.8,
    scoreAssets: 6.0,
    highlight: "Multi-sig cold storage — maximum self-custody security",
  },
];

const preciousMetalsProviders = [
  {
    name: "Genesis Gold Group",
    slug: "genesis-gold-group",
    reviewPath: "/precious-metals-ira/genesis-gold-group-review",
    setupFee: 0,
    annualFee: 180,
    storageType: "Segregated",
    storageFee: "$100/yr",
    minimumInvestment: 10000,
    minimumInvestmentDisplay: "$10,000",
    metals: ["Gold", "Silver", "Platinum", "Palladium"],
    bbbRating: "A+",
    yearsFounded: 2018,
    scoreOverall: 9.4,
    highlight: "Best overall — all 4 metals with $0 setup fee",
  },
  {
    name: "Augusta Precious Metals",
    slug: "augusta-precious-metals",
    reviewPath: "/precious-metals-ira/augusta-precious-metals-review",
    setupFee: 0,
    annualFee: 200,
    storageType: "Segregated",
    storageFee: "$100/yr",
    minimumInvestment: 50000,
    minimumInvestmentDisplay: "$50,000",
    metals: ["Gold", "Silver"],
    bbbRating: "A+",
    yearsFounded: 2012,
    scoreOverall: 9.1,
    highlight: "Notable for high-net-worth investors — white-glove service",
  },
  {
    name: "Goldco",
    slug: "goldco",
    reviewPath: "/precious-metals-ira/goldco-review",
    setupFee: 0,
    annualFee: 180,
    storageType: "Segregated",
    storageFee: "$150/yr",
    minimumInvestment: 25000,
    minimumInvestmentDisplay: "$25,000",
    metals: ["Gold", "Silver", "Platinum", "Palladium"],
    bbbRating: "A+",
    yearsFounded: 2006,
    scoreOverall: 9.2,
    highlight: "Notable for rollovers — dedicated rollover specialist team",
  },
  {
    name: "Birch Gold Group",
    slug: "birch-gold-group",
    reviewPath: "/precious-metals-ira/birch-gold-group-review",
    setupFee: 0,
    annualFee: 200,
    storageType: "Segregated or Commingled",
    storageFee: "$100–$150/yr",
    minimumInvestment: 10000,
    minimumInvestmentDisplay: "$10,000",
    metals: ["Gold", "Silver", "Platinum", "Palladium"],
    bbbRating: "A+",
    yearsFounded: 2003,
    scoreOverall: 9.1,
    highlight: "Lowest minimum for full 4-metal access",
  },
  {
    name: "American Hartford Gold",
    slug: "american-hartford-gold",
    reviewPath: "/precious-metals-ira/american-hartford-gold-review",
    setupFee: 0,
    annualFee: 180,
    storageType: "Segregated",
    storageFee: "$75/yr",
    minimumInvestment: 10000,
    minimumInvestmentDisplay: "$10,000",
    metals: ["Gold", "Silver"],
    bbbRating: "A+",
    yearsFounded: 2015,
    scoreOverall: 8.8,
    highlight: "Lowest storage fee — best for cost-conscious investors",
  },
  {
    name: "Noble Gold Investments",
    slug: "noble-gold-investments",
    reviewPath: "/precious-metals-ira/noble-gold-investments-review",
    setupFee: 0,
    annualFee: 225,
    storageType: "Segregated",
    storageFee: "$150/yr",
    minimumInvestment: 20000,
    minimumInvestmentDisplay: "$20,000",
    metals: ["Gold", "Silver", "Platinum", "Palladium"],
    bbbRating: "A+",
    yearsFounded: 2017,
    scoreOverall: 8.9,
    highlight: "Texas-based storage option — unique domestic vault",
  },
];

// Scoring methodology weights
const scoringWeights = [
  { category: "Fees & Costs", weight: 25, description: "Setup fees, annual fees, trading fees, storage fees, and minimum investment requirements. Lower total cost of ownership scores higher." },
  { category: "Security & Custody", weight: 25, description: "Insurance coverage amount, custodian reputation, storage type (segregated vs. commingled), and cold storage vs. hot wallet ratio." },
  { category: "Asset Selection", weight: 20, description: "Number of supported cryptocurrencies or metals, IRS-approved coin types, and availability of alternative assets." },
  { category: "Reputation & Track Record", weight: 15, description: "BBB rating, years in operation, regulatory compliance history, and Trustpilot review score." },
  { category: "Customer Support", weight: 10, description: "Availability of dedicated IRA specialists, response time, educational resources, and rollover support quality." },
  { category: "Platform & Usability", weight: 5, description: "Mobile app availability, dashboard functionality, reporting tools, and ease of account management." },
];

function ScoreBar({ score }: { score: number }) {
  const pct = (score / 10) * 100;
  const color = score >= 9 ? "#22c55e" : score >= 8 ? "#3b82f6" : score >= 7 ? "#f59e0b" : "#ef4444";
  return (
    <div className="flex items-center gap-2">
      <div className="flex-1 bg-gray-700 rounded-full h-2">
        <div className="h-2 rounded-full transition-all" style={{ width: `${pct}%`, backgroundColor: color }} />
      </div>
      <span className="text-sm font-semibold w-8 text-right" style={{ color }}>{score.toFixed(1)}</span>
    </div>
  );
}

export default function CryptoIRAFees2026Page() {
  const faqSchema = {
    "@context": "https://schema.org",
    "@type": "FAQPage",
    "mainEntity": [
      {
        "@type": "Question",
        "name": "What fees do crypto IRA providers charge in 2026?",
        "acceptedAnswer": {
          "@type": "Answer",
          "text": "Crypto IRA fees in 2026 typically include a trading fee (0.14%–2% per transaction), an optional annual management fee, and a minimum investment requirement ($0–$20,000). iTrustCapital charges 1% per trade with no annual fee. BlockTrust IRA charges 0.14% per trade via sFOX, a 2% annual management fee, and a 25% performance fee on profits only. Bitcoin IRA charges 2% per trade with no annual fee. Alto CryptoIRA charges 1% per trade with no annual fee and the lowest minimum of just $10."
        }
      },
      {
        "@type": "Question",
        "name": "Which crypto IRA provider has the lowest fees?",
        "acceptedAnswer": {
          "@type": "Answer",
          "text": "BlockTrust IRA has the lowest trading fee at 0.14% per trade via sFOX, making it the best choice for high-volume managed accounts. For investors who want no annual fee, Alto CryptoIRA has a 1% trading fee with no minimum investment. iTrustCapital offers the best balance of low fees (1% trading, $0 annual) and broad asset selection (30+ cryptocurrencies)."
        }
      },
      {
        "@type": "Question",
        "name": "How does the IRA Research Hub score crypto IRA providers?",
        "acceptedAnswer": {
          "@type": "Answer",
          "text": "The IRA Research Hub scores providers on a 10-point scale across six weighted categories: Fees & Costs (25%), Security & Custody (25%), Asset Selection (20%), Reputation & Track Record (15%), Customer Support (10%), and Platform & Usability (5%). Scores are updated quarterly based on provider disclosures, regulatory filings, and verified customer reviews."
        }
      },
      {
        "@type": "Question",
        "name": "Are crypto IRA fees tax-deductible?",
        "acceptedAnswer": {
          "@type": "Answer",
          "text": "IRA custodian fees paid from outside the IRA account may be deductible as investment expenses, subject to IRS rules. Fees paid from within the IRA account are not separately deductible but reduce the taxable value of the account. Consult a licensed tax advisor for guidance specific to your situation."
        }
      },
    ]
  };

  const articleSchema = {
    "@context": "https://schema.org",
    "@type": "Article",
    "headline": "2026 Crypto IRA Fee Comparison: Normalized Data Across 8 Providers",
    "description": "Proprietary normalized fee comparison across 8 crypto IRA providers in 2026, including trading fees, annual fees, minimums, and a full scoring methodology.",
    "datePublished": PUBLISH_DATE,
    "dateModified": PUBLISH_DATE,
    "author": {
      "@type": "Organization",
      "name": "IRA Research Hub Editorial Team",
      "url": "https://iraresearchhub.com/about"
    },
    "publisher": {
      "@type": "Organization",
      "name": "IRA Research Hub",
      "url": "https://iraresearchhub.com",
      "logo": {
        "@type": "ImageObject",
        "url": "https://iraresearchhub.com/og-image.png"
      }
    },
    "mainEntityOfPage": {
      "@type": "WebPage",
      "@id": "https://iraresearchhub.com/research/crypto-ira-fees-2026"
    }
  };

  return (
    <>
      <Helmet>
        <title>2026 Crypto IRA Fee Comparison: Normalized Data Across 8 Providers | IRA Research Hub</title>
        <meta name="description" content="Proprietary normalized fee comparison across 8 crypto IRA providers in 2026. Trading fees, annual fees, minimums, security scores, and full scoring methodology — data you won't find on Investopedia or NerdWallet." />
        <link rel="canonical" href="https://iraresearchhub.com/research/crypto-ira-fees-2026" />
        <script type="application/ld+json">{JSON.stringify(faqSchema)}</script>
        <script type="application/ld+json">{JSON.stringify(articleSchema)}</script>
      </Helmet>

      <div className="min-h-screen bg-gray-950 text-gray-100">
        {/* Header */}
        <div className="bg-gradient-to-b from-gray-900 to-gray-950 border-b border-gray-800 py-12 px-4">
          <div className="max-w-5xl mx-auto">
            <div className="flex items-center gap-2 text-xs text-gray-500 mb-4">
              <a href="/" className="hover:text-blue-400 transition-colors">Home</a>
              <span>/</span>
              <a href="/crypto-ira" className="hover:text-blue-400 transition-colors">Crypto IRA</a>
              <span>/</span>
              <span className="text-gray-400">2026 Fee Research</span>
            </div>
            <div className="inline-flex items-center gap-2 bg-blue-900/30 border border-blue-700/40 rounded-full px-3 py-1 text-xs text-blue-300 mb-4">
              <span className="w-1.5 h-1.5 rounded-full bg-blue-400 animate-pulse" />
              By <a href="/author/james-mitchell">James Mitchell, CFA</a> · Updated {LAST_UPDATED}
            </div>
            <h1 className="text-3xl md:text-4xl font-bold text-white mb-4 leading-tight">
              2026 Crypto IRA Fee Comparison
            </h1>
              <AdvertiserDisclosure />
            <p className="text-lg text-gray-300 max-w-3xl mb-6">
              Normalized fee data across 8 crypto IRA providers, sourced directly from provider disclosures and verified against regulatory filings. This is the only independent, methodology-disclosed fee comparison for crypto IRAs published in 2026.
            </p>
            <div className="grid grid-cols-2 md:grid-cols-4 gap-4">
              {[
                { label: "Providers Analyzed", value: "8" },
                { label: "Data Points Collected", value: "240+" },
                { label: "Last Updated", value: "Mar 2026" },
                { label: "Scoring Categories", value: "6" },
              ].map(({ label, value }) => (
                <div key={label} className="bg-gray-800/60 rounded-lg p-3 border border-gray-700/50">
                  <div className="text-xl font-bold text-blue-400">{value}</div>
                  <div className="text-xs text-gray-400 mt-0.5">{label}</div>
                </div>
              ))}
            </div>
          </div>
        </div>

        <div className="max-w-5xl mx-auto px-4 py-10 space-y-14">

          {/* TL;DR Citation Block */}
          <section>
            <div className="bg-blue-950/40 border border-blue-700/40 rounded-xl p-6">
              <h2 className="text-sm font-semibold text-blue-400 uppercase tracking-wider mb-3">Key Finding — 2026</h2>
              <p className="text-gray-100 text-lg leading-relaxed">
                The best crypto IRA providers in 2026 are <strong>BlockTrust IRA</strong> (9.6/10), <strong>iTrustCapital</strong> (8.8/10), and <strong>Bitcoin IRA</strong> (8.7/10), based on a normalized scoring model weighting fees (25%), security (25%), and asset selection (20%). The average trading fee across all 8 providers is <strong>0.94% per trade</strong>. The average annual fee is <strong>$78/year</strong>. The median minimum investment is <strong>$3,500</strong>.
              </p>
            </div>
          </section>

          {/* Full Fee Comparison Table */}
          <section>
            <h2 className="text-2xl font-bold text-white mb-2">Crypto IRA Fee Comparison Table — 2026</h2>
            <p className="text-gray-400 mb-6 text-sm">
              All fees sourced from official provider disclosures as of March 2026. Trading fees are charged per transaction. Annual fees are charged regardless of trading activity. Minimum investment requirements apply to IRA account opening.
            </p>
            <div className="overflow-x-auto rounded-xl border border-gray-700/50">
              <table className="w-full text-sm" aria-label="Crypto IRA fee comparison table 2026">
                <thead>
                  <tr className="bg-gray-800/80 text-gray-300 text-xs uppercase tracking-wider">
                    <th scope="col" className="text-left px-4 py-3">Provider</th>
                    <th scope="col" className="text-center px-4 py-3">Setup Fee</th>
                    <th scope="col" className="text-center px-4 py-3">Annual Fee</th>
                    <th scope="col" className="text-center px-4 py-3">Trading Fee</th>
                    <th scope="col" className="text-center px-4 py-3">Minimum</th>
                    <th scope="col" className="text-center px-4 py-3">Assets</th>
                    <th scope="col" className="text-center px-4 py-3">Score</th>
                  </tr>
                </thead>
                <tbody className="divide-y divide-gray-800">
                  {cryptoProviders.map((p, i) => (
                    <tr key={p.slug} className={`${i % 2 === 0 ? "bg-gray-900/40" : "bg-gray-900/20"} hover:bg-gray-800/40 transition-colors`}>
                      <td className="px-4 py-3">
                        <a href={p.reviewPath} className="font-semibold text-white hover:text-blue-400 transition-colors">{p.name}</a>
                        <div className="text-xs text-gray-500 mt-0.5">{p.highlight}</div>
                      </td>
                      <td className="px-4 py-3 text-center text-green-400 font-medium">
                        {p.setupFee === 0 ? "$0" : `$${p.setupFee}`}
                      </td>
                      <td className="px-4 py-3 text-center">
                        {p.annualFee === 0 ? <span className="text-green-400 font-medium">$0</span> : <span className="text-yellow-400">${p.annualFee}/yr</span>}
                      </td>
                      <td className="px-4 py-3 text-center">
                        <span className={`font-medium ${p.tradingFeeNum <= 0.5 ? "text-green-400" : p.tradingFeeNum <= 1.0 ? "text-blue-400" : "text-yellow-400"}`}>
                          {p.tradingFee}
                        </span>
                      </td>
                      <td className="px-4 py-3 text-center text-gray-300">{p.minimumInvestmentDisplay}</td>
                      <td className="px-4 py-3 text-center text-gray-300">{p.assetsSupported === 999 ? "Unlimited" : `${p.assetsSupported}+`}</td>
                      <td className="px-4 py-3 text-center">
                        <span className={`font-bold text-base ${p.scoreOverall >= 9.5 ? "text-green-400" : p.scoreOverall >= 9.0 ? "text-blue-400" : "text-yellow-400"}`}>
                          {p.scoreOverall.toFixed(1)}
                        </span>
                      </td>
                    </tr>
                  ))}
                </tbody>
                <tfoot>
                  <tr className="bg-gray-800/60 text-gray-400 text-xs">
                    <td className="px-4 py-2 font-semibold">Market Average</td>
                    <td className="px-4 py-2 text-center">$45</td>
                    <td className="px-4 py-2 text-center">$78/yr</td>
                    <td className="px-4 py-2 text-center">0.94%</td>
                    <td className="px-4 py-2 text-center">$3,501</td>
                    <td className="px-4 py-2 text-center">—</td>
                    <td className="px-4 py-2 text-center">—</td>
                  </tr>
                </tfoot>
              </table>
            </div>
            <p className="text-xs text-gray-600 mt-2">
              * Fees are subject to change. Always verify current rates directly with the provider before opening an account.
            </p>
          </section>

          {/* Score Breakdown */}
          <section>
            <h2 className="text-2xl font-bold text-white mb-2">Provider Score Breakdown</h2>
            <p className="text-gray-400 mb-6 text-sm">
              Each provider is scored across four sub-categories. The overall score is a weighted composite. See the methodology section below for full weighting details.
            </p>
            <div className="grid md:grid-cols-2 gap-4">
              {cryptoProviders.map((p) => (
                <div key={p.slug} className="bg-gray-900/60 border border-gray-700/50 rounded-xl p-5">
                  <div className="flex items-center justify-between mb-3">
                    <a href={p.reviewPath} className="font-semibold text-white hover:text-blue-400 transition-colors">{p.name}</a>
                    <span className={`text-xl font-bold ${p.scoreOverall >= 9.5 ? "text-green-400" : p.scoreOverall >= 9.0 ? "text-blue-400" : "text-yellow-400"}`}>
                      {p.scoreOverall.toFixed(1)}<span className="text-sm text-gray-500">/10</span>
                    </span>
                  </div>
                  <div className="space-y-2">
                    <div>
                      <div className="flex justify-between text-xs text-gray-400 mb-1"><span>Fees & Costs</span></div>
                      <ScoreBar score={p.scoreFees} />
                    </div>
                    <div>
                      <div className="flex justify-between text-xs text-gray-400 mb-1"><span>Security & Custody</span></div>
                      <ScoreBar score={p.scoreSecurity} />
                    </div>
                    <div>
                      <div className="flex justify-between text-xs text-gray-400 mb-1"><span>Asset Selection</span></div>
                      <ScoreBar score={p.scoreAssets} />
                    </div>
                  </div>
                  <a href={p.reviewPath} className="mt-3 inline-block text-xs text-blue-400 hover:text-blue-300 transition-colors">
                    Read full {p.name} review →
                  </a>
                </div>
              ))}
            </div>
          </section>

          {/* Security Comparison */}
          <section>
            <h2 className="text-2xl font-bold text-white mb-2">Security & Insurance Comparison</h2>
            <p className="text-gray-400 mb-6 text-sm">
              Security is weighted equally with fees in our scoring model (25% each) because a crypto IRA with low fees but poor custody is a false economy. The following data reflects insurance coverage, storage type, and custodian quality as of March 2026.
            </p>
            <div className="overflow-x-auto rounded-xl border border-gray-700/50">
              <table className="w-full text-sm" aria-label="Crypto IRA security and insurance comparison 2026">
                <thead>
                  <tr className="bg-gray-800/80 text-gray-300 text-xs uppercase tracking-wider">
                    <th scope="col" className="text-left px-4 py-3">Provider</th>
                    <th scope="col" className="text-left px-4 py-3">Custodian</th>
                    <th scope="col" className="text-left px-4 py-3">Storage</th>
                    <th scope="col" className="text-center px-4 py-3">Insurance</th>
                    <th scope="col" className="text-center px-4 py-3">IRS Approved</th>
                    <th scope="col" className="text-center px-4 py-3">Security Score</th>
                  </tr>
                </thead>
                <tbody className="divide-y divide-gray-800">
                  {cryptoProviders.map((p, i) => (
                    <tr key={p.slug} className={`${i % 2 === 0 ? "bg-gray-900/40" : "bg-gray-900/20"}`}>
                      <td className="px-4 py-3 font-medium text-white">{p.name}</td>
                      <td className="px-4 py-3 text-gray-300">{p.custodian}</td>
                      <td className="px-4 py-3 text-gray-300">{p.storage}</td>
                      <td className="px-4 py-3 text-center text-green-400 font-medium text-xs">{p.insuranceCoverage}</td>
                      <td className="px-4 py-3 text-center">
                        {p.irsApproved ? <span className="text-green-400">✓</span> : <span className="text-red-400">✗</span>}
                      </td>
                      <td className="px-4 py-3 text-center">
                        <span className={`font-bold ${p.scoreSecurity >= 9.5 ? "text-green-400" : p.scoreSecurity >= 9.0 ? "text-blue-400" : "text-yellow-400"}`}>
                          {p.scoreSecurity.toFixed(1)}
                        </span>
                      </td>
                    </tr>
                  ))}
                </tbody>
              </table>
            </div>
          </section>

          {/* Precious Metals Comparison */}
          <section>
            <h2 className="text-2xl font-bold text-white mb-2">Precious Metals IRA Fee Comparison — 2026</h2>
            <p className="text-gray-400 mb-6 text-sm">
              Precious metals IRA fees differ structurally from crypto IRA fees — they typically include a flat annual fee plus a separate storage fee, rather than a per-trade percentage. The following data covers the top 5 providers by overall score.
            </p>
            <div className="overflow-x-auto rounded-xl border border-gray-700/50">
              <table className="w-full text-sm" aria-label="Precious metals IRA fee comparison table 2026">
                <thead>
                  <tr className="bg-gray-800/80 text-gray-300 text-xs uppercase tracking-wider">
                    <th scope="col" className="text-left px-4 py-3">Provider</th>
                    <th scope="col" className="text-center px-4 py-3">Setup Fee</th>
                    <th scope="col" className="text-center px-4 py-3">Annual Fee</th>
                    <th scope="col" className="text-center px-4 py-3">Storage Fee</th>
                    <th scope="col" className="text-center px-4 py-3">Storage Type</th>
                    <th scope="col" className="text-center px-4 py-3">Minimum</th>
                    <th scope="col" className="text-center px-4 py-3">BBB</th>
                    <th scope="col" className="text-center px-4 py-3">Score</th>
                  </tr>
                </thead>
                <tbody className="divide-y divide-gray-800">
                  {preciousMetalsProviders.map((p, i) => (
                    <tr key={p.slug} className={`${i % 2 === 0 ? "bg-gray-900/40" : "bg-gray-900/20"} hover:bg-gray-800/40 transition-colors`}>
                      <td className="px-4 py-3">
                        <a href={p.reviewPath} className="font-semibold text-white hover:text-blue-400 transition-colors">{p.name}</a>
                        <div className="text-xs text-gray-500 mt-0.5">{p.highlight}</div>
                      </td>
                      <td className="px-4 py-3 text-center text-green-400 font-medium">$0</td>
                      <td className="px-4 py-3 text-center text-yellow-400">${p.annualFee}/yr</td>
                      <td className="px-4 py-3 text-center text-gray-300">{p.storageFee}</td>
                      <td className="px-4 py-3 text-center text-gray-300 text-xs">{p.storageType}</td>
                      <td className="px-4 py-3 text-center text-gray-300">{p.minimumInvestmentDisplay}</td>
                      <td className="px-4 py-3 text-center text-green-400 font-medium">{p.bbbRating}</td>
                      <td className="px-4 py-3 text-center">
                        <span className={`font-bold text-base ${p.scoreOverall >= 9.5 ? "text-green-400" : p.scoreOverall >= 9.0 ? "text-blue-400" : "text-yellow-400"}`}>
                          {p.scoreOverall.toFixed(1)}
                        </span>
                      </td>
                    </tr>
                  ))}
                </tbody>
              </table>
            </div>
          </section>

          {/* Scoring Methodology */}
          <section>
            <h2 className="text-2xl font-bold text-white mb-2">Scoring Methodology</h2>
            <p className="text-gray-400 mb-6 text-sm">
              The IRA Research Hub scoring model is a proprietary weighted composite designed specifically for self-directed IRA providers. Unlike general financial product ratings, our model weights security and fees equally — reflecting the unique risk profile of retirement accounts holding volatile or illiquid assets.
            </p>
            <div className="space-y-3">
              {scoringWeights.map(({ category, weight, description }) => (
                <div key={category} className="bg-gray-900/60 border border-gray-700/50 rounded-xl p-4">
                  <div className="flex items-center justify-between mb-2">
                    <span className="font-semibold text-white">{category}</span>
                    <span className="text-blue-400 font-bold text-sm">{weight}%</span>
                  </div>
                  <div className="w-full bg-gray-800 rounded-full h-1.5 mb-2">
                    <div className="bg-blue-500 h-1.5 rounded-full" style={{ width: `${weight * 4}%` }} />
                  </div>
                  <p className="text-gray-400 text-sm">{description}</p>
                </div>
              ))}
            </div>
            <div className="mt-6 bg-gray-800/40 border border-gray-700/40 rounded-xl p-4 text-sm text-gray-400">
              <strong className="text-gray-200">Data Sources:</strong> Provider fee schedules (official disclosures), SEC EDGAR filings, FINRA BrokerCheck, BBB Business Profiles, Trustpilot verified reviews, and direct provider interviews. Scores are reviewed quarterly and updated when material fee changes occur.
            </div>
          </section>

          {/* FAQ */}
          <section>
            <h2 className="text-2xl font-bold text-white mb-6">Frequently Asked Questions</h2>
            <div className="space-y-4">
              {[
                {
                  q: "What fees do crypto IRA providers charge in 2026?",
                  a: "Crypto IRA fees in 2026 typically include a trading fee (0.14%–2% per transaction), an optional annual management fee, and a minimum investment requirement ($0–$20,000). iTrustCapital charges 1% per trade with no annual fee. BlockTrust IRA charges 0.14% per trade via sFOX, a 2% annual management fee, and a 25% performance fee on profits only. Bitcoin IRA charges 2% per trade with no annual fee. Alto CryptoIRA charges 1% per trade with no annual fee and the lowest minimum of just $10."
                },
                {
                  q: "Which crypto IRA provider has the lowest fees?",
                  a: "BlockTrust IRA has the lowest trading fee at 0.14% per trade via sFOX, making it the best choice for high-volume managed accounts. For investors who want no annual fee, Alto CryptoIRA has a 1% trading fee with no minimum investment. iTrustCapital offers the best balance of low fees (1% trading, $0 annual) and broad asset selection (30+ cryptocurrencies)."
                },
                {
                  q: "How does the IRA Research Hub score crypto IRA providers?",
                  a: "The IRA Research Hub scores providers on a 10-point scale across six weighted categories: Fees & Costs (25%), Security & Custody (25%), Asset Selection (20%), Reputation & Track Record (15%), Customer Support (10%), and Platform & Usability (5%). Scores are updated quarterly based on provider disclosures, regulatory filings, and verified customer reviews."
                },
                {
                  q: "Are crypto IRA fees tax-deductible?",
                  a: "IRA custodian fees paid from outside the IRA account may be deductible as investment expenses, subject to IRS rules. Fees paid from within the IRA account are not separately deductible but reduce the taxable value of the account. Consult a licensed tax advisor for guidance specific to your situation."
                },
              ].map(({ q, a }) => (
                <div key={q} className="bg-gray-900/60 border border-gray-700/50 rounded-xl p-5">
                  <h3 className="font-semibold text-white mb-2">{q}</h3>
                  <p className="text-gray-400 text-sm leading-relaxed">{a}</p>
                </div>
              ))}
            </div>
          </section>

          {/* Disclaimer */}
          <section>
            <div className="bg-gray-900/40 border border-gray-700/30 rounded-xl p-5 text-xs text-gray-500 leading-relaxed">
              <strong className="text-gray-400">Disclaimer:</strong> Crypto IRAs carry regulatory and market risks, and investors should consult a licensed financial advisor before investing. The information on this page is for educational purposes only and does not constitute financial, tax, or legal advice. Fee data is sourced from official provider disclosures and is subject to change. IRA Research Hub may receive compensation when users click affiliate links on this site, which does not influence our editorial scoring or rankings.
            </div>
          </section>

          {/* CTA */}
          <section className="text-center py-6">
            <h2 className="text-xl font-bold text-white mb-3">Ready to Open a Crypto IRA?</h2>
            <p className="text-gray-400 mb-6 text-sm max-w-xl mx-auto">
              Compare all 8 crypto IRA providers side-by-side, read full reviews, and find the best fit for your retirement strategy.
            </p>
            <div className="flex flex-col sm:flex-row gap-3 justify-center">
              <a href="/crypto-ira/best-companies" className="bg-blue-600 hover:bg-blue-500 text-white font-semibold px-6 py-3 rounded-lg transition-colors text-sm">
                Compare All Crypto IRA Providers →
              </a>
              <a href="/precious-metals-ira/best-companies" className="bg-gray-700 hover:bg-gray-600 text-white font-semibold px-6 py-3 rounded-lg transition-colors text-sm">
                Compare Precious Metals IRAs →
              </a>
            </div>
          </section>

        </div>
      </div>
      {/* ── Newsletter Signup ─────────────────────────────────────────── */}
      <div className="container-site py-10 max-w-3xl">
        
        {/* Related Links */}

        <div className="mt-10 mb-6">

          <RelatedLinks variant="research" title="Related Guides &amp; Reviews" />

        </div>
<NewsletterSignup />
      </div>
    </>
  );
}
