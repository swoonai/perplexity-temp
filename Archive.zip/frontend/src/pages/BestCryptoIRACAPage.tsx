import StateGuideTemplate from '../components/StateGuideTemplate'

export default function BestCryptoIRACAPage() {
  return (
    <StateGuideTemplate
      stateName="California"
      stateAbbr="CA"
      slug="california"
    />
  )
}
