import SEO from '../components/SEO'
import { trackProviderSiteVisit } from '../hooks/useAnalytics'
import NewsletterSignup from '../components/NewsletterSignup';
import RelatedLinks from '../components/RelatedLinks';

const DATE_MODIFIED = "2026-03-23"
const DATE_PUBLISHED = "2026-03-23"
const LAST_UPDATED = "March 23, 2026"

const articleSchema = {
  "@context": "https://schema.org",
  "@type": "Article",
  "@id": "https://iraresearchhub.com/crypto-ira/ethereum-ira",
  "headline": "Ethereum IRA: How to Hold ETH in a Self-Directed IRA (2026)",
  "description": "Can you hold Ethereum (ETH) in an IRA? Yes. Learn which custodians support Ethereum IRA accounts, the tax advantages, fees, and how to open an ETH IRA in 2026.",
  "datePublished": DATE_PUBLISHED,
  "dateModified": DATE_MODIFIED,
  "author": {
    "@type": "Person",
    "@id": "https://iraresearchhub.com/author/james-mitchell",
    "name": "James Mitchell",
    "url": "https://iraresearchhub.com/author/james-mitchell"
  },
  "publisher": {
    "@type": "Organization",
    "name": "IRA Research Hub",
    "url": "https://iraresearchhub.com"
  }
}

const faqSchema = {
  "@context": "https://schema.org",
  "@type": "FAQPage",
  "mainEntity": [
    {
      "@type": "Question",
      "name": "Can you hold Ethereum in an IRA?",
      "acceptedAnswer": {
        "@type": "Answer",
        "text": "Yes. Ethereum (ETH) can be held in a self-directed IRA through a qualified crypto IRA custodian. BlockTrust IRA supports ETH as one of its 60+ cryptocurrencies via American Estate & Trust."
      }
    },
    {
      "@type": "Question",
      "name": "What is an Ethereum IRA?",
      "acceptedAnswer": {
        "@type": "Answer",
        "text": "An Ethereum IRA is a self-directed Individual Retirement Account (SDIRA) that holds Ethereum (ETH) as its primary investment asset. It offers the same tax advantages as a traditional IRA — tax-deferred growth in a Traditional IRA or tax-free growth in a Roth IRA."
      }
    },
    {
      "@type": "Question",
      "name": "What are the tax benefits of an Ethereum IRA?",
      "acceptedAnswer": {
        "@type": "Answer",
        "text": "In a Traditional Ethereum IRA, contributions may be tax-deductible and gains grow tax-deferred until withdrawal. In a Roth Ethereum IRA, contributions are made with after-tax dollars but qualified withdrawals — including all ETH appreciation — are completely tax-free."
      }
    },
    {
      "@type": "Question",
      "name": "What is the minimum investment for an Ethereum IRA?",
      "acceptedAnswer": {
        "@type": "Answer",
        "text": "BlockTrust IRA has no minimum for unmanaged accounts ($20,000 for managed). This can be funded via cash contribution, IRA transfer, or 401(k) rollover."
      }
    },
    {
      "@type": "Question",
      "name": "Can I stake Ethereum in an IRA?",
      "acceptedAnswer": {
        "@type": "Answer",
        "text": "Staking ETH within an IRA is a complex area. The IRS has not issued specific guidance on staking rewards in IRAs. Most crypto IRA custodians, including BlockTrust IRA, hold ETH in cold storage without staking to avoid potential prohibited transaction issues. Consult a tax advisor before attempting to stake IRA assets."
      }
    },
    {
      "@type": "Question",
      "name": "How do I open an Ethereum IRA?",
      "acceptedAnswer": {
        "@type": "Answer",
        "text": "To open an Ethereum IRA: (1) Choose a qualified crypto IRA custodian such as BlockTrust IRA. (2) Complete the online application and identity verification. (3) Fund your account via cash contribution, IRA transfer, or 401(k) rollover. (4) Purchase ETH through the custodian's trading platform. The entire process typically takes 3–7 business days."
      }
    }
  ]
}

const howToSchema = {
  "@context": "https://schema.org",
  "@type": "HowTo",
  "name": "How to Open an Ethereum IRA",
  "description": "Step-by-step guide to opening a self-directed IRA that holds Ethereum (ETH).",
  "step": [
    { "@type": "HowToStep", "position": 1, "name": "Choose an Ethereum IRA custodian", "text": "Select a qualified crypto IRA custodian that supports Ethereum. BlockTrust IRA is the top-rated option, supporting 60+ cryptocurrencies including ETH via American Estate & Trust." },
    { "@type": "HowToStep", "position": 2, "name": "Complete the application", "text": "Fill out the online application with your personal information, Social Security Number, and beneficiary details. Identity verification (KYC) is required by law." },
    { "@type": "HowToStep", "position": 3, "name": "Fund your account", "text": "Transfer funds via direct contribution (up to $7,000/year in 2026, or $8,000 if age 50+), IRA-to-IRA transfer, or 401(k) rollover. Rollovers have no annual limit." },
    { "@type": "HowToStep", "position": 4, "name": "Purchase Ethereum", "text": "Once funds clear (typically 3–5 business days), log in to the trading portal and purchase ETH at the current market price via American Estate & Trust." },
    { "@type": "HowToStep", "position": 5, "name": "Monitor your account", "text": "Your ETH is held in institutional-grade cold storage. You can view your balance, trade additional assets, and manage beneficiaries through the online dashboard at any time." }
  ]
}

const faqs = [
  { q: "Can you hold Ethereum in an IRA?", a: "Yes. Ethereum (ETH) can be held in a self-directed IRA through a qualified crypto IRA custodian. BlockTrust IRA supports ETH as one of its 60+ cryptocurrencies via American Estate & Trust." },
  { q: "What is an Ethereum IRA?", a: "An Ethereum IRA is a self-directed Individual Retirement Account (SDIRA) that holds Ethereum (ETH) as its primary investment asset. It offers the same tax advantages as a traditional IRA — tax-deferred growth in a Traditional IRA or tax-free growth in a Roth IRA." },
  { q: "What are the tax benefits of an Ethereum IRA?", a: "In a Traditional Ethereum IRA, contributions may be tax-deductible and gains grow tax-deferred until withdrawal. In a Roth Ethereum IRA, all qualified withdrawals — including all ETH appreciation — are completely tax-free." },
  { q: "What is the minimum investment for an Ethereum IRA?", a: "BlockTrust IRA has no minimum for unmanaged accounts ($20,000 for managed). This can be funded via cash contribution, IRA transfer, or 401(k) rollover." },
  { q: "Can I stake Ethereum in an IRA?", a: "Most crypto IRA custodians hold ETH in cold storage without staking to avoid potential prohibited transaction issues. The IRS has not issued specific guidance on staking rewards in IRAs. Consult a tax advisor before attempting to stake IRA assets." },
  { q: "How do I open an Ethereum IRA?", a: "Choose a custodian like BlockTrust IRA, complete the application, fund via contribution or rollover, then purchase ETH through the trading portal. The entire process typically takes 3–7 business days." }
]

export default function EthereumIRAPage() {
  return (
    <>
      <SEO
        title="Ethereum IRA: How to Hold ETH in a Self-Directed IRA (2026)"
        description="Can you hold Ethereum (ETH) in an IRA? Yes. Learn which custodians support Ethereum IRA accounts, the tax advantages, fees, and how to open an ETH IRA in 2026."
        canonical="/crypto-ira/ethereum-ira"
        schema={[articleSchema, faqSchema, howToSchema]}
      />

      <div className="container-site section-padding">
        {/* Breadcrumb */}
        <nav className="text-sm text-gray-500 mb-6" aria-label="Breadcrumb">
          <ol className="flex items-center gap-1.5 flex-wrap">
            <li><a href="/" className="hover:text-amber-600 transition-colors">Home</a></li>
            <li className="text-gray-400">/</li>
            <li><a href="/crypto-ira" className="hover:text-amber-600 transition-colors">Crypto IRA</a></li>
            <li className="text-gray-400">/</li>
            <li className="text-gray-700 font-medium">Ethereum IRA</li>
          </ol>
        </nav>

        {/* Hero */}
        <div className="max-w-3xl mb-10">
          <div className="inline-flex items-center gap-2 bg-amber-50 border border-amber-200 text-amber-800 text-xs font-semibold px-3 py-1 rounded-full mb-4">
            CRYPTO IRA GUIDE · UPDATED {LAST_UPDATED.toUpperCase()}
          </div>
          <h1 className="text-3xl md:text-4xl font-bold text-gray-900 leading-tight mb-4">
            Ethereum IRA: How to Hold ETH in a Self-Directed IRA (2026)
          </h1>
          <p className="text-lg text-gray-600 leading-relaxed">
            Ethereum is the second-largest cryptocurrency by market cap and the backbone of decentralized finance. Yes, you can hold ETH inside a tax-advantaged IRA. This guide covers which custodians support Ethereum IRA accounts, staking considerations, fees, and how to open one in 2026.
          </p>
          <div className="flex items-center gap-3 mt-5 text-sm text-gray-500">
            <span>By <a href="/author/james-mitchell" className="text-amber-700 font-medium hover:underline">James Mitchell, CFA</a></span>
            <span>·</span>
            <span>Updated {LAST_UPDATED}</span>
          </div>
        </div>

        <div className="grid lg:grid-cols-[1fr_300px] gap-10">
          {/* Main content */}
          <div className="space-y-10">

            {/* Quick answer */}
            <div className="bg-green-50 border border-green-200 rounded-xl p-6">
              <h2 className="text-lg font-bold text-green-900 mb-2">Quick Answer: Can You Hold Ethereum in an IRA?</h2>
              <p className="text-green-800">
                <strong>Yes.</strong> Ethereum (ETH) can be held in a self-directed IRA. The IRS does not prohibit cryptocurrency in IRAs — it only requires that the assets be held by a qualified custodian. <strong>BlockTrust IRA</strong> supports ETH as one of 60+ cryptocurrencies via American Estate & Trust, with no minimum (unmanaged) and a 0.14%–0.4% trading fee.
              </p>
            </div>

            {/* What is it */}
            <section>
              <h2 className="text-2xl font-bold text-gray-900 mb-4">What Is an Ethereum IRA?</h2>
              <p className="text-gray-700 leading-relaxed mb-4">
                An Ethereum IRA is a self-directed Individual Retirement Account (SDIRA) that holds Ethereum (ETH) as its primary investment asset. Unlike a standard brokerage IRA that holds stocks and bonds, a crypto IRA requires a specialized custodian approved to hold digital assets on behalf of IRA holders.
              </p>
              <p className="text-gray-700 leading-relaxed mb-4">
                Ethereum is the world's leading smart contract platform, powering DeFi, NFTs, and thousands of decentralized applications. As of 2026, ETH has a market capitalization exceeding $300 billion and is widely held by institutional investors.
              </p>
              <p className="text-gray-700 leading-relaxed">
                In a <strong>Traditional Ethereum IRA</strong>, contributions may be tax-deductible and all gains grow tax-deferred. In a <strong>Roth Ethereum IRA</strong>, contributions are after-tax but all qualified withdrawals — including every dollar of ETH appreciation — are completely tax-free.
              </p>
            </section>

            {/* Tax benefits */}
            <section>
              <h2 className="text-2xl font-bold text-gray-900 mb-4">Tax Benefits of an Ethereum IRA</h2>
              <div className="grid md:grid-cols-2 gap-4">
                <div className="bg-blue-50 border border-blue-200 rounded-xl p-5">
                  <h3 className="font-bold text-blue-900 mb-2">Traditional Ethereum IRA</h3>
                  <ul className="space-y-2 text-sm text-blue-800">
                    <li>✓ Contributions may be tax-deductible</li>
                    <li>✓ ETH gains grow tax-deferred</li>
                    <li>✓ Pay taxes only at withdrawal</li>
                    <li>✓ Ideal if you expect lower tax rate in retirement</li>
                  </ul>
                </div>
                <div className="bg-purple-50 border border-purple-200 rounded-xl p-5">
                  <h3 className="font-bold text-purple-900 mb-2">Roth Ethereum IRA</h3>
                  <ul className="space-y-2 text-sm text-purple-800">
                    <li>✓ After-tax contributions</li>
                    <li>✓ All ETH gains grow tax-free</li>
                    <li>✓ Qualified withdrawals 100% tax-free</li>
                    <li>✓ Ideal for long-term ETH appreciation</li>
                  </ul>
                </div>
              </div>
              <p className="text-gray-600 text-sm mt-4">
                2026 IRA contribution limits: $7,000/year ($8,000 if age 50+). Rollover amounts from 401(k) or other IRAs have no annual limit.
              </p>
            </section>

            {/* Staking note */}
            <section>
              <h2 className="text-2xl font-bold text-gray-900 mb-4">Can You Stake Ethereum in an IRA?</h2>
              <div className="bg-yellow-50 border border-yellow-200 rounded-xl p-5">
                <p className="text-yellow-900 text-sm leading-relaxed">
                  <strong>Short answer: Not currently, and with caution.</strong> The IRS has not issued specific guidance on whether staking rewards generated within an IRA constitute a prohibited transaction or taxable event. Most qualified crypto IRA custodians — including BlockTrust IRA — hold ETH in cold storage without staking to avoid potential compliance issues. Attempting to stake IRA-held ETH through a third-party protocol could be treated as a prohibited transaction, potentially disqualifying the entire IRA. Consult a tax advisor with crypto IRA expertise before considering any staking activity.
                </p>
              </div>
            </section>

            {/* How to open */}
            <section>
              <h2 className="text-2xl font-bold text-gray-900 mb-6">How to Open an Ethereum IRA: 5 Steps</h2>
              <ol className="space-y-5">
                {[
                  { n: 1, title: "Choose an Ethereum IRA custodian", body: "Select a qualified crypto IRA custodian that supports Ethereum. BlockTrust IRA is the top-rated option, supporting 60+ cryptocurrencies including ETH via American Estate & Trust. Verify the custodian is IRS-compliant and has cold storage for digital assets." },
                  { n: 2, title: "Complete the application", body: "Fill out the online application with your personal information, Social Security Number, and beneficiary details. Identity verification (KYC) is required by law and typically takes 1–2 business days." },
                  { n: 3, title: "Fund your account", body: "Transfer funds via direct contribution (up to $7,000/year in 2026, or $8,000 if age 50+), IRA-to-IRA transfer, or 401(k) rollover. Rollovers have no annual limit and are the most common funding method for larger accounts." },
                  { n: 4, title: "Purchase Ethereum", body: "Once funds clear (typically 3–5 business days), log in to the trading portal and purchase ETH at the current market price. The trade executes via American Estate & Trust with a 0.14%–0.4% trading fee." },
                  { n: 5, title: "Monitor your account", body: "Your ETH is held in institutional-grade cold storage. You can view your balance, trade additional assets, and manage beneficiaries through the online dashboard at any time." }
                ].map(step => (
                  <li key={step.n} className="flex gap-4">
                    <div className="flex-shrink-0 w-8 h-8 rounded-full bg-amber-100 text-amber-800 font-bold text-sm flex items-center justify-center">{step.n}</div>
                    <div>
                      <h3 className="font-semibold text-gray-900 mb-1">{step.title}</h3>
                      <p className="text-gray-600 text-sm leading-relaxed">{step.body}</p>
                    </div>
                  </li>
                ))}
              </ol>
            </section>

            {/* Fees */}
            <section>
              <h2 className="text-2xl font-bold text-gray-900 mb-4">Ethereum IRA Fees</h2>
              <div className="overflow-x-auto">
                <table className="w-full text-sm border-collapse">
                  <thead>
                    <tr className="bg-gray-50">
                      <th className="text-left p-3 border border-gray-200 font-semibold">Fee Type</th>
                      <th className="text-left p-3 border border-gray-200 font-semibold">BlockTrust IRA</th>
                      <th className="text-left p-3 border border-gray-200 font-semibold">Industry Average</th>
                    </tr>
                  </thead>
                  <tbody>
                    {[
                      ["Account Setup", "$0", "$0–$50"],
                      ["Annual Account Fee", "$0", "$0–$300"],
                      ["Trading Fee", "1% per trade", "1–2% per trade"],
                      ["Storage Fee", "$0 (included)", "$0–$200/yr"],
                      ["Minimum Investment", "$10,000", "$1,000–$25,000"],
                    ].map(([fee, bt, avg]) => (
                      <tr key={fee} className="hover:bg-gray-50">
                        <td className="p-3 border border-gray-200 font-medium">{fee}</td>
                        <td className="p-3 border border-gray-200 text-green-700 font-medium">{bt}</td>
                        <td className="p-3 border border-gray-200 text-gray-500">{avg}</td>
                      </tr>
                    ))}
                  </tbody>
                </table>
              </div>
            </section>

            {/* Bottom Line */}
            <div className="bg-amber-50 border-l-4 border-amber-500 rounded-r-xl p-6">
              <h2 className="text-lg font-bold text-amber-900 mb-2">Bottom Line</h2>
              <p className="text-amber-800 leading-relaxed">
                An Ethereum IRA is one of the most compelling crypto IRA options available. ETH is the second-largest cryptocurrency, the foundation of DeFi, and has strong institutional adoption. For long-term investors, the Roth IRA structure is particularly attractive — all ETH appreciation is tax-free at withdrawal. <strong>BlockTrust IRA</strong> is the best option for an Ethereum IRA in 2026, supporting ETH natively with no annual fee and institutional cold storage via American Estate & Trust.
              </p>
              <a href="https://blocktrustira.com/?ref=iraresearchhub&utm_source=iraresearchhub&utm_medium=review&utm_campaign=cta" onClick={() => trackProviderSiteVisit('BlockTrust IRA', 'blocktrust-ira', 'https://blocktrustira.com/?ref=iraresearchhub&utm_source=iraresearchhub&utm_medium=review&utm_campaign=cta')} target="_blank" rel="noopener noreferrer sponsored" className="inline-flex items-center gap-2 mt-4 bg-amber-600 hover:bg-amber-700 text-white font-semibold text-sm px-5 py-2.5 rounded-lg transition-colors">
                Open an Ethereum IRA with BlockTrust →
              </a>
            </div>

            {/* FAQ */}
            <section>
              <h2 className="text-2xl font-bold text-gray-900 mb-5">Frequently Asked Questions</h2>
              <div className="space-y-3">
                {faqs.map((faq, i) => (
                  <details key={i} className="group border border-gray-200 rounded-xl overflow-hidden">
                    <summary className="flex items-center justify-between gap-4 p-4 cursor-pointer font-medium text-gray-900 hover:bg-gray-50 transition-colors list-none">
                      <span>{faq.q}</span>
                      <span className="text-gray-400 group-open:rotate-180 transition-transform shrink-0">▾</span>
                    </summary>
                    <div className="px-4 pb-4 text-gray-600 text-sm leading-relaxed">{faq.a}</div>
                  </details>
                ))}
              </div>
            </section>

          </div>

          {/* Sidebar */}
          <aside className="space-y-6">
            <div className="bg-white border border-gray-200 rounded-xl p-5 sticky top-6">
              <h3 className="font-bold text-gray-900 mb-4">Top Ethereum IRA Provider</h3>
              <div className="text-center">
                <div className="text-2xl font-bold text-gray-900 mb-1">BlockTrust IRA</div>
                <div className="text-amber-500 text-lg mb-2">★★★★★</div>
                <div className="text-sm text-gray-500 mb-4">60+ cryptocurrencies · American Estate & Trust custody</div>
                <div className="space-y-2 text-sm text-left mb-4">
                  <div className="flex justify-between"><span className="text-gray-500">Minimum</span><span className="font-medium">$10,000</span></div>
                  <div className="flex justify-between"><span className="text-gray-500">Trading Fee</span><span className="font-medium">1%</span></div>
                  <div className="flex justify-between"><span className="text-gray-500">Annual Fee</span><span className="font-medium text-green-600">$0</span></div>
                  <div className="flex justify-between"><span className="text-gray-500">ETH Supported</span><span className="font-medium text-green-600">✓ Yes</span></div>
                </div>
                <a href="https://blocktrustira.com/?ref=iraresearchhub&utm_source=iraresearchhub&utm_medium=review&utm_campaign=cta" onClick={() => trackProviderSiteVisit('BlockTrust IRA', 'blocktrust-ira', 'https://blocktrustira.com/?ref=iraresearchhub&utm_source=iraresearchhub&utm_medium=review&utm_campaign=cta')} target="_blank" rel="noopener noreferrer sponsored" className="block w-full bg-amber-600 hover:bg-amber-700 text-white font-semibold text-sm py-2.5 rounded-lg transition-colors text-center">
                  Open Account →
                </a>
                <a href="/crypto-ira/blocktrust-ira-review" className="block w-full text-center text-amber-700 hover:underline text-xs mt-2">Read Full Review</a>
              </div>
            </div>

            <div className="bg-gray-50 border border-gray-200 rounded-xl p-5">
              <h3 className="font-semibold text-gray-900 mb-3 text-sm">Related Guides</h3>
              <ul className="space-y-2 text-sm">
                <li><a href="/crypto-ira/solana-ira" className="text-amber-700 hover:underline">Solana IRA Guide</a></li>
                <li><a href="/crypto-ira/xrp-ripple-ira" className="text-amber-700 hover:underline">XRP / Ripple IRA Guide</a></li>
                <li><a href="/crypto-ira/litecoin-ira" className="text-amber-700 hover:underline">Litecoin IRA Guide</a></li>
                <li><a href="/crypto-ira/dogecoin-ira" className="text-amber-700 hover:underline">Dogecoin IRA Guide</a></li>
                <li><a href="/crypto-ira/blocktrust-ira-review" className="text-amber-700 hover:underline">BlockTrust IRA Review</a></li>
                <li><a href="/crypto-ira/best-companies" className="text-amber-700 hover:underline">Crypto IRA Provider Comparison & Independent Analysis</a></li>
              </ul>
            </div>
          </aside>
        </div>
      </div>
      {/* ── Newsletter Signup ─────────────────────────────────────────── */}
      <div className="container-site py-10 max-w-3xl">
        
        {/* Related Links */}

        <div className="mt-10 mb-6">

          <RelatedLinks variant="crypto-guide" title="Related Guides &amp; Reviews" />

        </div>
<NewsletterSignup />
      </div>
    </>
  )
}
