import StateGuideTemplate from '../components/StateGuideTemplate'

export default function BestCryptoIRANJPage() {
  return (
    <StateGuideTemplate
      stateName="New Jersey"
      stateAbbr="NJ"
      slug="new-jersey"
    />
  )
}
