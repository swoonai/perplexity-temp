import SEO from '../components/SEO'
export default function PrivacyPage() {
  return (
    <div className="section-padding">
      <SEO
        title="Privacy Policy"
        description="IRA Research Hub privacy policy. Learn how we collect, use, and protect your information when you visit iraresearchhub.com."
        canonical="/privacy"
      />
      <div className="container-site max-w-3xl">
        <h1 className="text-4xl font-bold text-[#0F172A] mb-6">Privacy Policy</h1>
        <p className="text-[#64748B] mb-4">Last updated: March 2026</p>
        <div className="space-y-6 text-[#64748B] leading-relaxed">
          <p>IRA Research Hub ("we", "us", or "our") operates iraresearchhub.com. This Privacy Policy describes how we collect, use, and protect your information when you visit our website.</p>
          <h2 className="text-xl font-bold text-[#0F172A]">Information We Collect</h2>
          <p>We collect information you provide directly to us, such as when you contact us via email. We also collect standard server logs and analytics data (page views, referrer, browser type) through privacy-respecting analytics tools.</p>
          <h2 className="text-xl font-bold text-[#0F172A]">Cookies</h2>
          <p>We use minimal cookies necessary for site functionality. We do not use tracking cookies or third-party advertising cookies.</p>
          <h2 className="text-xl font-bold text-[#0F172A]">Affiliate Disclosure</h2>
          <p>Some links on this site are affiliate links. If you click on an affiliate link and open an account, we may receive a commission. This does not affect our editorial ratings or recommendations.</p>
          <h2 className="text-xl font-bold text-[#0F172A]">Contact</h2>
          <p>For privacy-related inquiries, please contact us through the information provided on our About page.</p>
        </div>
      </div>
    </div>
  )
}
