import { Link } from 'react-router-dom'
import SEO from '../components/SEO'
import NewsletterSignup from '../components/NewsletterSignup';

export default function MethodologyPage() {
  return (
    <>
      <SEO
        title="How We Score IRA Providers — Our Methodology"
        description="How IRA Research Hub scores and ranks IRA providers. Transparent, data-driven methodology with no paid placements or affiliate-influenced rankings."
        canonical="/methodology"
        ogType="article"
      />
      {/* Header */}
      <section className="bg-[#F8FAFC] border-b border-slate-200">
        <div className="container-site py-12">
          <div className="inline-flex items-center px-2.5 py-0.5 rounded-full text-xs font-medium bg-sky-100 text-sky-700 mb-4">
            Last Updated March 2026
          </div>
          <h1 className="text-4xl font-bold text-[#0F172A] mb-3">How We Score IRA Providers</h1>
          <p className="text-lg text-[#64748B] max-w-2xl">
            Our scoring methodology is transparent, data-driven, and updated continuously. 
            Every score is derived from publicly verifiable data — no paid placements, 
            no affiliate-influenced rankings.
          </p>
        </div>
      </section>

      <div className="container-site py-12 max-w-4xl">
        <div className="space-y-12">

          {/* Independence Statement */}
          <div className="bg-emerald-50 border border-emerald-200 rounded-xl p-6">
            <h2 className="text-lg font-bold text-[#0F172A] mb-2">Our Independence Commitment</h2>
            <p className="text-[#64748B] text-sm leading-relaxed">
              IRA Research Hub does not accept payment for provider rankings or reviews. 
              Affiliate links (marked with →) may earn us a commission if you open an account, 
              but this never influences our scores or rankings. Providers cannot pay to improve 
              their score — all scores are calculated algorithmically from public data.
            </p>
          </div>

          {/* Scoring Overview */}
          <div>
            <h2 className="text-2xl font-bold text-[#0F172A] mb-4">Scoring Framework</h2>
            <p className="text-[#64748B] leading-relaxed mb-6">
              Every provider is scored on a 10-point scale across six weighted categories. 
              The overall score is a weighted average of these six dimensions. Scores are 
              recalculated quarterly or when a provider makes material changes to its offering.
            </p>
            <div className="overflow-x-auto">
              <table className="comparison-table">
                <thead>
                  <tr>
                    <th>Category</th>
                    <th>Weight</th>
                    <th>What We Measure</th>
                  </tr>
                </thead>
                <tbody>
                  {[
                    ['Fee Transparency', '20%', 'Setup fees, annual fees, transaction fees, storage fees — all disclosed clearly and competitively priced'],
                    ['Asset Selection', '20%', 'Number of supported assets, IRS compliance, quality of available products'],
                    ['Security & Custody', '20%', 'Custodian quality, insurance coverage, storage type (segregated vs commingled), cold storage protocols'],
                    ['IRS Compliance', '15%', 'Regulatory standing, IRS audit history, compliance documentation, custodian licensing'],
                    ['Customer Support', '15%', 'Response times, support channels, account manager availability, complaint resolution'],
                    ['Reputation', '10%', 'BBB rating, Trustpilot score, years in business, regulatory actions, customer review volume'],
                  ].map(([cat, weight, desc]) => (
                    <tr key={cat}>
                      <td className="font-medium text-[#0F172A]">{cat}</td>
                      <td className="font-bold text-[#0EA5E9]">{weight}</td>
                      <td className="text-[#64748B] text-sm">{desc}</td>
                    </tr>
                  ))}
                </tbody>
              </table>
            </div>
          </div>

          {/* Score Scale */}
          <div>
            <h2 className="text-2xl font-bold text-[#0F172A] mb-4">Score Scale</h2>
            <div className="grid md:grid-cols-4 gap-4">
              {[
                { range: '9.0–10.0', label: 'Exceptional', color: 'bg-emerald-100 border-emerald-300 text-emerald-700', desc: 'Best-in-class. Recommended without reservation.' },
                { range: '7.5–8.9', label: 'Good', color: 'bg-sky-100 border-sky-300 text-sky-700', desc: 'Strong provider with minor weaknesses.' },
                { range: '6.0–7.4', label: 'Average', color: 'bg-amber-100 border-amber-300 text-amber-700', desc: 'Acceptable but better options exist.' },
                { range: 'Below 6.0', label: 'Below Average', color: 'bg-red-100 border-red-300 text-red-700', desc: 'Significant concerns. Proceed with caution.' },
              ].map((s) => (
                <div key={s.range} className={`rounded-xl p-4 border ${s.color}`}>
                  <div className="font-bold text-lg mb-1">{s.range}</div>
                  <div className="font-semibold text-sm mb-2">{s.label}</div>
                  <div className="text-xs opacity-80">{s.desc}</div>
                </div>
              ))}
            </div>
          </div>

          {/* Data Sources */}
          <div>
            <h2 className="text-2xl font-bold text-[#0F172A] mb-4">Data Sources</h2>
            <p className="text-[#64748B] leading-relaxed mb-4">
              All data used in our scoring is sourced from publicly verifiable, primary sources. 
              We do not rely on provider-supplied marketing materials for factual claims.
            </p>
            <div className="grid md:grid-cols-2 gap-4">
              {[
                { source: 'Better Business Bureau (BBB)', use: 'Reputation scores, complaint history, accreditation status' },
                { source: 'Trustpilot', use: 'Customer review scores and volume (minimum 100 reviews required)' },
                { source: 'IRS Publication 590', use: 'IRS compliance requirements for SDIRAs' },
                { source: 'Provider websites', use: 'Fee schedules, asset lists, custodian disclosures' },
                { source: 'SEC / FINRA records', use: 'Regulatory actions, licensing, disciplinary history' },
                { source: 'Custodian disclosures', use: 'Insurance coverage amounts, storage facility details' },
              ].map((item) => (
                <div key={item.source} className="bg-slate-50 rounded-lg p-4 border border-slate-200">
                  <div className="font-semibold text-[#0F172A] text-sm mb-1">{item.source}</div>
                  <div className="text-xs text-[#64748B]">{item.use}</div>
                </div>
              ))}
            </div>
          </div>

          {/* Update Policy */}
          <div>
            <h2 className="text-2xl font-bold text-[#0F172A] mb-4">Update Policy</h2>
            <p className="text-[#64748B] leading-relaxed mb-4">
              Provider scores are updated on the following schedule:
            </p>
            <ul className="space-y-3">
              {[
                { trigger: 'Quarterly review', desc: 'All providers are re-evaluated every three months against current market data' },
                { trigger: 'Material fee changes', desc: 'Score updated within 7 days of any confirmed fee schedule change' },
                { trigger: 'Regulatory actions', desc: 'Score updated immediately upon any SEC, FINRA, or IRS enforcement action' },
                { trigger: 'BBB rating changes', desc: 'Score updated within 14 days of any BBB rating change' },
                { trigger: 'User-reported issues', desc: 'Credible user reports of material inaccuracies are investigated within 30 days' },
              ].map((item) => (
                <div key={item.trigger} className="flex gap-3">
                  <span className="text-[#0EA5E9] font-bold flex-shrink-0">→</span>
                  <div>
                    <span className="font-semibold text-[#0F172A]">{item.trigger}: </span>
                    <span className="text-[#64748B] text-sm">{item.desc}</span>
                  </div>
                </div>
              ))}
            </ul>
          </div>

          {/* What We Don't Do */}
          <div className="bg-slate-50 rounded-xl p-6 border border-slate-200">
            <h2 className="text-xl font-bold text-[#0F172A] mb-4">What We Don't Do</h2>
            <ul className="space-y-2">
              {[
                'Accept payment for higher rankings or scores',
                'Allow providers to review or approve their scores before publication',
                'Use "sponsored" or "featured" placements that affect ranking order',
                'Inflate scores for providers with higher affiliate commission rates',
                'Remove negative reviews or complaints from our analysis',
              ].map((item) => (
                <li key={item} className="flex gap-2 text-sm text-[#334155]">
                  <span className="text-red-400 font-bold flex-shrink-0">✗</span>
                  {item}
                </li>
              ))}
            </ul>
          </div>

          {/* CTA */}
          <div className="text-center border-t border-slate-200 pt-8">
            <p className="text-[#64748B] mb-4">Ready to compare providers using our methodology?</p>
            <div className="flex flex-wrap gap-4 justify-center">
              <Link to="/crypto-ira/best-companies" className="btn-primary">Crypto IRA Provider Comparison & Independent Analysis</Link>
              <Link to="/precious-metals-ira/best-companies" className="btn-outline">Gold IRA Provider Comparison & Independent Analysis</Link>
            </div>
          </div>

        </div>
      </div>
      {/* ── Newsletter Signup ─────────────────────────────────────────── */}
      <div className="container-site py-10 max-w-3xl">
        <NewsletterSignup />
      </div>
    </>
  )
}
