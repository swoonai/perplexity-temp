import React from 'react'
import { Link } from 'react-router-dom'
import SEO from '../components/SEO'
import AdvertiserDisclosure from '../components/AdvertiserDisclosure'
import { trackResearchStart } from '../hooks/useAnalytics'
import NewsletterSignup from '../components/NewsletterSignup';
import RelatedLinks from '../components/RelatedLinks';

const LAST_UPDATED = 'March 31, 2026'

export default function HowToResearchSDIRAProvidersPage() {

  // Funnel tracking: fire research_start when arriving from a paid ad
  React.useEffect(() => {
    const params = new URLSearchParams(window.location.search)
    const utmSource = params.get('utm_source') ?? undefined
    if (utmSource) {
      trackResearchStart(window.location.pathname, document.title, utmSource)
    }
  }, [])

  return (
    <>
      <script type="application/ld+json" dangerouslySetInnerHTML={{ __html: JSON.stringify({"@context":"https://schema.org","@type":"BreadcrumbList","itemListElement":[{"@type":"ListItem","position":1,"name":"Guides","item":"https://iraresearchhub.com/guides"},{"@type":"ListItem","position":2,"name":"How to Research SDIRA Providers","item":"https://iraresearchhub.com/guides/how-to-research-sdira-providers"}]}) }} />
      <SEO
        title="How to Research SDIRA Providers: Independent Due Diligence Guide (2026)"
        description="Step-by-step guide to independently researching self-directed IRA custodians. Covers FINRA BrokerCheck, SEC EDGAR, BBB records, fee schedule analysis, custody verification, and red flags to avoid."
        canonical="/guides/how-to-research-sdira-providers"
        ogType="article"
      />
      <script type="application/ld+json" dangerouslySetInnerHTML={{ __html: JSON.stringify({"@context":"https://schema.org","@type":"Article","headline":"How to Research SDIRA Providers: Independent Due Diligence Guide (2026)","author":{"@type":"Person","name":"James Mitchell","jobTitle":"CFA"},"publisher":{"@type":"Organization","name":"IRA Research Hub"},"dateModified":"2026-03-31"}) }} />

      <div className="bg-[#F8FAFC] border-b border-slate-200 py-10">
        <div className="container-site max-w-4xl">
          <div className="flex flex-wrap gap-2 mb-4">
            <span className="inline-flex items-center px-2.5 py-0.5 rounded-full text-xs font-medium bg-indigo-100 text-indigo-700">Due Diligence Guide</span>
            <span className="inline-flex items-center px-2.5 py-0.5 rounded-full text-xs font-medium bg-slate-100 text-slate-600">2026 Update</span>
          </div>
          <h1 className="text-4xl font-bold text-[#0F172A] mb-4 leading-tight">
            How to Research SDIRA Providers: Independent Due Diligence Guide (2026)
          </h1>
          <p className="text-lg text-[#64748B] mb-4 max-w-3xl">
            The SEC and FINRA have both issued investor alerts about self-directed IRA fraud. This guide gives you a step-by-step framework for independently verifying any SDIRA custodian before opening an account — using only publicly available government and regulatory databases.
          </p>
          <p className="text-sm text-slate-500">
            By <Link to="/author/james-mitchell" className="text-sky-600 hover:underline font-medium">James Mitchell, CFA</Link>
            {' · '}Last Updated: {LAST_UPDATED}
            {' · '}
            <Link to="/methodology" className="text-sky-600 hover:underline">Editorial Methodology</Link>
          </p>
          <AdvertiserDisclosure />
        </div>
      </div>

      <div className="container-site max-w-4xl py-8">
        <div className="bg-red-50 border border-red-200 rounded-xl p-5 mb-10">
          <p className="font-semibold text-red-800 mb-2">Why This Matters</p>
          <p className="text-sm text-red-700">
            The SEC has warned that SDIRA custodians do not evaluate the quality or legitimacy of investments. Fraudulent promoters frequently use the IRS-required custodian relationship to falsely imply government approval. Several SDIRA custodians have failed or been involved in enforcement actions, resulting in investor losses. Independent verification before opening an account is essential.
          </p>
        </div>

        {/* TOC */}
        <div className="bg-slate-50 border border-slate-200 rounded-xl p-5 mb-10">
          <p className="text-xs font-semibold text-slate-400 uppercase tracking-wider mb-3">In This Guide</p>
          <ol className="space-y-1.5 text-sm text-sky-700">
            {[
              ['Step 1: Verify IRS-Qualified Custodian Status', '#step1'],
              ['Step 2: Check FINRA BrokerCheck', '#step2'],
              ['Step 3: Search SEC EDGAR', '#step3'],
              ['Step 4: Review BBB Records', '#step4'],
              ['Step 5: Analyze the Fee Schedule', '#step5'],
              ['Step 6: Verify Custody and Insurance Arrangements', '#step6'],
              ['Step 7: Assess Customer Support Quality', '#step7'],
              ['Red Flags to Watch For', '#red-flags'],
              ['Our Independent Research Methodology', '#our-methodology'],
              ['Primary Sources & References', '#sources'],
            ].map(([label, href]) => (
              <li key={href}><a href={href} className="hover:underline">{label}</a></li>
            ))}
          </ol>
        </div>

        {[
          {
            id: 'step1',
            step: '1',
            title: 'Verify IRS-Qualified Custodian Status',
            color: 'sky',
            content: (
              <>
                <p className="text-slate-600 leading-relaxed mb-4">
                  Every IRA — including an SDIRA — must be held by a qualified custodian under IRC §408(a). Qualified custodians include banks, federally insured credit unions, savings and loan associations, and other entities specifically approved by the IRS.
                </p>
                <p className="text-slate-600 leading-relaxed mb-4">
                  To verify custodian status:
                </p>
                <ul className="list-disc list-inside text-slate-600 space-y-2 mb-4 ml-2">
                  <li>Ask the custodian directly for their state trust charter number and the state in which they are chartered</li>
                  <li>Contact the relevant state banking or financial institutions regulator to verify the charter is active and in good standing</li>
                  <li>For nationally chartered banks, verify with the Office of the Comptroller of the Currency (OCC) at occ.gov</li>
                </ul>
                <div className="bg-amber-50 border border-amber-200 rounded-lg p-4 text-sm text-amber-900">
                  <p className="font-semibold mb-1">Note:</p>
                  <p>The IRS does not publish a list of approved SDIRA custodians. The absence of an IRS endorsement does not mean a custodian is unqualified — but it means you must verify their status independently through state or federal regulators.</p>
                </div>
              </>
            ),
          },
          {
            id: 'step2',
            step: '2',
            title: 'Check FINRA BrokerCheck',
            color: 'sky',
            content: (
              <>
                <p className="text-slate-600 leading-relaxed mb-4">
                  FINRA BrokerCheck (brokercheck.finra.org) is a free public database that allows you to research the background of broker-dealers and registered investment advisors. Search for the custodian and any associated individuals.
                </p>
                <p className="text-slate-600 leading-relaxed mb-4">What to look for:</p>
                <ul className="list-disc list-inside text-slate-600 space-y-2 mb-4 ml-2">
                  <li>Regulatory actions, sanctions, or disciplinary history</li>
                  <li>Customer complaints and their resolution</li>
                  <li>Employment history of key personnel</li>
                  <li>Any disclosures about financial events (bankruptcies, liens, judgments)</li>
                </ul>
                <p className="text-slate-600 leading-relaxed">
                  Note: Not all SDIRA custodians are FINRA-registered broker-dealers. Trust companies that only act as custodians (not broker-dealers) may not appear in BrokerCheck. In that case, verify through state banking regulators instead.
                </p>
              </>
            ),
          },
          {
            id: 'step3',
            step: '3',
            title: 'Search SEC EDGAR',
            color: 'sky',
            content: (
              <>
                <p className="text-slate-600 leading-relaxed mb-4">
                  The SEC's EDGAR database (sec.gov/cgi-bin/browse-edgar) contains filings from registered investment advisors, broker-dealers, and companies subject to SEC oversight. Search for the custodian's legal name.
                </p>
                <ul className="list-disc list-inside text-slate-600 space-y-2 mb-4 ml-2">
                  <li>Check for any SEC enforcement actions or litigation releases</li>
                  <li>Review any Form ADV filings (investment advisor disclosure documents)</li>
                  <li>Search the SEC's Litigation Releases database for any enforcement history</li>
                </ul>
                <p className="text-slate-600 leading-relaxed">
                  The SEC's EDGAR full-text search (efts.sec.gov) allows you to search for a company name across all filings and enforcement actions.
                </p>
              </>
            ),
          },
          {
            id: 'step4',
            step: '4',
            title: 'Review BBB Records',
            color: 'sky',
            content: (
              <>
                <p className="text-slate-600 leading-relaxed mb-4">
                  The Better Business Bureau (bbb.org) provides accreditation status, letter grades (A+ through F), and complaint histories for businesses. While BBB ratings are not a definitive measure of quality, they provide useful data points.
                </p>
                <p className="text-slate-600 leading-relaxed mb-4">What to examine:</p>
                <ul className="list-disc list-inside text-slate-600 space-y-2 mb-4 ml-2">
                  <li>BBB rating and accreditation status</li>
                  <li>Number and nature of complaints filed in the past 3 years</li>
                  <li>How the company responded to complaints</li>
                  <li>Any government actions listed in the BBB profile</li>
                  <li>Customer reviews (note: these are self-selected and may not be representative)</li>
                </ul>
              </>
            ),
          },
          {
            id: 'step5',
            step: '5',
            title: 'Analyze the Fee Schedule',
            color: 'sky',
            content: (
              <>
                <p className="text-slate-600 leading-relaxed mb-4">
                  SDIRA fees are complex and can significantly erode returns. Always request a complete, written fee schedule before opening an account. Key fees to verify:
                </p>
                <div className="overflow-x-auto mb-4">
                  <table className="w-full text-sm border-collapse">
                    <thead>
                      <tr className="bg-slate-100">
                        <th className="text-left p-3 font-semibold text-slate-700 border border-slate-200">Fee Type</th>
                        <th className="text-left p-3 font-semibold text-slate-700 border border-slate-200">What to Ask</th>
                      </tr>
                    </thead>
                    <tbody>
                      {[
                        ['Setup/Account Opening Fee', 'Is this one-time or recurring? Is it waived for larger accounts?'],
                        ['Annual Custodian Fee', 'Is it flat or percentage-based? Does it scale with account value?'],
                        ['Transaction Fee', 'Charged per buy/sell? Per asset type? Per dollar amount?'],
                        ['Storage Fee (metals/crypto)', 'Flat or percentage? Segregated vs. commingled storage?'],
                        ['Wire Transfer Fee', 'Inbound and outbound? Per transfer?'],
                        ['Termination/Closure Fee', 'Charged when closing the account or transferring out?'],
                        ['Minimum Balance Fee', 'Is there a fee if your balance falls below a threshold?'],
                      ].map(([type, question]) => (
                        <tr key={type} className="border-b border-slate-100">
                          <td className="p-3 font-medium text-slate-700 border border-slate-200">{type}</td>
                          <td className="p-3 text-slate-600 border border-slate-200">{question}</td>
                        </tr>
                      ))}
                    </tbody>
                  </table>
                </div>
                <p className="text-slate-600 text-sm">
                  <Link to="/research/crypto-ira-fees-2026" className="text-sky-600 hover:underline">See our 2026 Crypto IRA Fee Research</Link> and <Link to="/research/gold-ira-fees-2026" className="text-sky-600 hover:underline">Gold IRA Fee Research</Link> for independent fee comparisons across 22 providers.
                </p>
              </>
            ),
          },
          {
            id: 'step6',
            step: '6',
            title: 'Verify Custody and Insurance Arrangements',
            color: 'sky',
            content: (
              <>
                <p className="text-slate-600 leading-relaxed mb-4">
                  For crypto and precious metals IRAs, custody arrangements are critical. Ask these specific questions and request written answers:
                </p>
                <div className="space-y-3">
                  {[
                    { q: 'Who holds the private keys (crypto) or physical metals?', why: 'Determines who controls the assets if the provider fails' },
                    { q: 'Are assets held in cold storage (offline) or hot wallets?', why: 'Cold storage is significantly more secure against hacking' },
                    { q: 'Are your assets segregated from other clients\' assets?', why: 'Segregated storage means your specific assets are identifiable and cannot be commingled with company assets' },
                    { q: 'What insurance covers the assets?', why: 'FDIC does not cover crypto or metals; look for specific crime, cyber, or specie insurance policies' },
                    { q: 'What happens to your assets if the custodian goes bankrupt?', why: 'Segregated assets held in trust should be protected from creditors, but this depends on the legal structure' },
                    { q: 'Who is the sub-custodian (if any)?', why: 'Many SDIRA custodians use third-party sub-custodians for actual asset storage — verify the sub-custodian independently' },
                  ].map((item) => (
                    <div key={item.q} className="p-3 bg-white border border-slate-200 rounded-lg">
                      <p className="font-medium text-slate-700 text-sm mb-1">{item.q}</p>
                      <p className="text-xs text-slate-500"><span className="font-medium">Why it matters:</span> {item.why}</p>
                    </div>
                  ))}
                </div>
              </>
            ),
          },
          {
            id: 'step7',
            step: '7',
            title: 'Assess Customer Support Quality',
            color: 'sky',
            content: (
              <>
                <p className="text-slate-600 leading-relaxed mb-4">
                  SDIRA administration involves complex transactions that may require urgent support. Before opening an account, test the provider's support quality:
                </p>
                <ul className="list-disc list-inside text-slate-600 space-y-2 mb-4 ml-2">
                  <li>Call their support line during business hours and measure response time</li>
                  <li>Send an email with a specific technical question and evaluate the quality of the response</li>
                  <li>Ask specifically about their process for handling distribution requests, RMDs, and account transfers</li>
                  <li>Ask about their average processing time for asset purchases and sales</li>
                  <li>Verify whether you have a dedicated account representative or a general support queue</li>
                </ul>
              </>
            ),
          },
        ].map((section) => (
          <section key={section.id} id={section.id} className="mb-12">
            <div className="flex items-center gap-3 mb-4">
              <div className="flex-shrink-0 w-10 h-10 bg-sky-100 text-sky-700 rounded-full flex items-center justify-center font-bold text-lg">{section.step}</div>
              <h2 className="text-2xl font-bold text-[#0F172A]">{section.title}</h2>
            </div>
            {section.content}
          </section>
        ))}

        <section id="red-flags" className="mb-12">
          <h2 className="text-2xl font-bold text-[#0F172A] mb-4">Red Flags to Watch For</h2>
          <div className="space-y-3">
            {[
              'Guarantees of returns or claims that an investment is "IRS-approved" — the IRS does not approve investments',
              'Pressure to act quickly or claims of limited availability',
              'Inability or unwillingness to provide a complete written fee schedule',
              'Vague answers about who holds the private keys or physical assets',
              'No verifiable state trust charter or banking license',
              'Multiple unresolved BBB complaints or SEC/FINRA enforcement actions',
              'Promoters who recommend both the investment and the custodian (conflict of interest)',
              'Claims that home storage of IRA-owned metals or crypto is permitted',
              'Unusually high promised returns with no clear explanation of the investment strategy',
            ].map((flag, i) => (
              <div key={i} className="flex gap-3 p-3 bg-red-50 border border-red-100 rounded-lg text-sm">
                <span className="text-red-500 font-bold flex-shrink-0">⚠</span>
                <span className="text-slate-700">{flag}</span>
              </div>
            ))}
          </div>
        </section>

        <section id="our-methodology" className="mb-12">
          <h2 className="text-2xl font-bold text-[#0F172A] mb-4">Our Independent Research Methodology</h2>
          <p className="text-slate-600 leading-relaxed mb-4">
            IRA Research Hub applies this same due diligence framework to every provider we research. Our scoring covers 22 providers across 2,400+ data points, updated quarterly. Our research process includes:
          </p>
          <ul className="list-disc list-inside text-slate-600 space-y-2 mb-4 ml-2">
            <li>Verification of custodian status through state banking regulators</li>
            <li>FINRA BrokerCheck and SEC EDGAR searches for all providers and key personnel</li>
            <li>BBB rating, accreditation, and complaint history review</li>
            <li>Direct fee schedule requests and comparison</li>
            <li>Custody arrangement verification (cold storage, insurance, segregation)</li>
            <li>Customer support quality testing</li>
          </ul>
          <div className="p-4 bg-indigo-50 border border-indigo-200 rounded-xl text-sm">
            <p className="font-semibold text-indigo-800 mb-2">View Our Research</p>
            <div className="flex flex-wrap gap-3">
              <Link to="/crypto-ira/best-companies" className="text-indigo-700 font-medium hover:underline text-xs">Crypto IRA Provider Comparison →</Link>
              <Link to="/precious-metals-ira/best-companies" className="text-indigo-700 font-medium hover:underline text-xs">Precious Metals IRA Provider Comparison →</Link>
              <Link to="/methodology" className="text-indigo-700 font-medium hover:underline text-xs">Full Scoring Methodology →</Link>
            </div>
          </div>
        </section>

        <section id="sources" className="mb-12 pt-6 border-t border-slate-200">
          <h3 className="text-sm font-semibold text-slate-500 uppercase tracking-wider mb-3">Primary Sources & References</h3>
          <ul className="space-y-1.5 text-xs text-slate-500">
            <li><a href="https://www.sec.gov/investor/alerts/sdira.htm" target="_blank" rel="noopener noreferrer" className="text-sky-600 hover:underline">SEC Investor Alert: Self-Directed IRAs and the Risk of Fraud</a></li>
            <li><a href="https://www.finra.org/investors/alerts/self-directed-iras-look-custodian" target="_blank" rel="noopener noreferrer" className="text-sky-600 hover:underline">FINRA Investor Alert: Self-Directed IRAs — Look Before You Leap</a></li>
            <li><a href="https://brokercheck.finra.org" target="_blank" rel="noopener noreferrer" className="text-sky-600 hover:underline">FINRA BrokerCheck</a></li>
            <li><a href="https://www.sec.gov/cgi-bin/browse-edgar" target="_blank" rel="noopener noreferrer" className="text-sky-600 hover:underline">SEC EDGAR Company Search</a></li>
            <li><a href="https://www.irs.gov/retirement-plans/self-directed-iras" target="_blank" rel="noopener noreferrer" className="text-sky-600 hover:underline">IRS: Self-Directed IRAs and the Risk of Fraud</a></li>
          </ul>
        </section>

        <div className="mt-8 p-5 bg-amber-50 border border-amber-200 rounded-lg text-sm text-amber-900">
          <p className="font-semibold mb-1">Important Disclaimer</p>
          <p>This page is for informational and educational purposes only and does not constitute financial, investment, tax, or legal advice. Always consult a qualified, licensed financial advisor, tax professional, and attorney before making any investment decisions. <Link to="/editorial-policy" className="underline font-medium">See our Editorial Policy</Link> for full disclosure.</p>
        </div>
      </div>
      {/* ── Newsletter Signup ─────────────────────────────────────────── */}
      <div className="container-site py-10 max-w-3xl">
        
        {/* Related Links */}

        <div className="mt-10 mb-6">

          <RelatedLinks variant="research" title="Related Guides &amp; Reviews" />

        </div>
<NewsletterSignup />
      </div>
    </>
  )
}
