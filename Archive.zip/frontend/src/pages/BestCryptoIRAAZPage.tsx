import StateGuideTemplate from '../components/StateGuideTemplate'

export default function BestCryptoIRAAZPage() {
  return (
    <StateGuideTemplate
      stateName="Arizona"
      stateAbbr="AZ"
      slug="arizona"
    />
  )
}
