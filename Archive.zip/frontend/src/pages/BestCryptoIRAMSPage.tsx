import StateGuideTemplate from '../components/StateGuideTemplate'

export default function BestCryptoIRAMSPage() {
  return (
    <StateGuideTemplate
      stateName="Mississippi"
      stateAbbr="MS"
      slug="mississippi"
    />
  )
}
