import { Link } from 'react-router-dom'
import SEO from '../components/SEO'
import NewsletterSignup from '../components/NewsletterSignup';

const DATE_MODIFIED = "2026-03-21"

// Person schema for James Mitchell — Lead IRA Research Analyst
const personSchema = {
  "@context": "https://schema.org",
  "@type": "Person",
  "@id": "https://iraresearchhub.com/author/james-mitchell",
  "name": "James Mitchell",
  "url": "https://iraresearchhub.com/author/james-mitchell",
  "image": "https://iraresearchhub.com/assets/logos/author-james-mitchell.jpg",
  "jobTitle": "Lead IRA Research Analyst",
  "worksFor": {
    "@type": "Organization",
    "@id": "https://iraresearchhub.com",
    "name": "IRA Research Hub",
    "url": "https://iraresearchhub.com"
  },
  "description": "James Mitchell is the Lead IRA Research Analyst at IRA Research Hub. He specialises in self-directed IRA structures, cryptocurrency IRA compliance, and precious metals IRA fee analysis. James has reviewed over 25 IRA providers and developed the IRA Research Hub scoring methodology.",
  "knowsAbout": [
    "Cryptocurrency IRAs",
    "Precious Metals IRAs",
    "Self-Directed IRAs",
    "IRA Fee Analysis",
    "IRS Retirement Account Regulations",
    "Bitcoin IRA Investing",
    "Gold IRA Investing",
    "401k Rollover Strategies",
    "ERISA Compliance",
    "Alternative Asset Custodians"
  ],
  "hasCredential": [
    {
      "@type": "EducationalOccupationalCredential",
      "credentialCategory": "Professional Certification",
      "name": "Chartered Financial Analyst (CFA)",
      "recognizedBy": {
        "@type": "Organization",
        "name": "CFA Institute"
      }
    }
  ],
  "email": "editorial@iraresearchhub.com",
  "alumniOf": {
    "@type": "CollegeOrUniversity",
    "name": "University of Chicago"
  },
  "dateModified": DATE_MODIFIED
}

// Articles authored by James Mitchell
const AUTHORED_REVIEWS = [
  // Crypto IRA reviews
  { title: "BlockTrust IRA Review 2026", url: "/crypto-ira/blocktrust-ira-review", category: "Crypto IRA" },
  { title: "Bitcoin IRA Review 2026", url: "/crypto-ira/bitcoin-ira-review", category: "Crypto IRA" },
  { title: "iTrustCapital Review 2026", url: "/crypto-ira/itrustcapital-review", category: "Crypto IRA" },
  { title: "Alto CryptoIRA Review 2026", url: "/crypto-ira/alto-crypto-ira-review", category: "Crypto IRA" },
  { title: "BitIRA Review 2026", url: "/crypto-ira/bitira-review", category: "Crypto IRA" },
  { title: "Swan Bitcoin IRA Review 2026", url: "/crypto-ira/swan-bitcoin-ira-review", category: "Crypto IRA" },
  { title: "Rocket Dollar Review 2026", url: "/crypto-ira/rocket-dollar-review", category: "Crypto IRA" },
  { title: "Unchained IRA Review 2026", url: "/crypto-ira/unchained-ira-review", category: "Crypto IRA" },
  // Precious metals IRA reviews
  { title: "Augusta Precious Metals Review 2026", url: "/precious-metals-ira/augusta-precious-metals-review", category: "Gold IRA" },
  { title: "Goldco Review 2026", url: "/precious-metals-ira/goldco-review", category: "Gold IRA" },
  { title: "Birch Gold Group Review 2026", url: "/precious-metals-ira/birch-gold-group-review", category: "Gold IRA" },
  { title: "American Hartford Gold Review 2026", url: "/precious-metals-ira/american-hartford-gold-review", category: "Gold IRA" },
  { title: "Genesis Gold Group Review 2026", url: "/precious-metals-ira/genesis-gold-group-review", category: "Gold IRA" },
  { title: "Lear Capital Review 2026", url: "/precious-metals-ira/lear-capital-review", category: "Gold IRA" },
  { title: "Noble Gold Investments Review 2026", url: "/precious-metals-ira/noble-gold-investments-review", category: "Gold IRA" },
  { title: "Advantage Gold Review 2026", url: "/precious-metals-ira/advantage-gold-review", category: "Gold IRA" },
  { title: "GoldenCrest Metals Review 2026", url: "/precious-metals-ira/goldencrest-metals-review", category: "Gold IRA" },
  { title: "Patriot Gold Group Review 2026", url: "/precious-metals-ira/patriot-gold-group-review", category: "Gold IRA" },
  { title: "Oxford Gold Group Review 2026", url: "/precious-metals-ira/oxford-gold-group-review", category: "Gold IRA" },
  { title: "Preserve Gold Review 2026", url: "/precious-metals-ira/preserve-gold-review", category: "Gold IRA" },
  { title: "Rosland Capital Review 2026", url: "/precious-metals-ira/rosland-capital-review", category: "Gold IRA" },
  { title: "Allegiance Gold Review 2026", url: "/precious-metals-ira/allegiance-gold-review", category: "Gold IRA" },
  // Guides
  { title: "401k to Crypto IRA Rollover Guide 2026", url: "/crypto-ira/401k-to-crypto-ira-rollover", category: "Guide" },
  { title: "401k to Gold IRA Rollover Guide 2026", url: "/precious-metals-ira/401k-to-gold-ira-rollover", category: "Guide" },
  { title: "Crypto IRA Fees 2026: Full Data Analysis", url: "/research/crypto-ira-fees-2026", category: "Research" },
]

export default function AuthorPage() {
  const cryptoReviews = AUTHORED_REVIEWS.filter(r => r.category === "Crypto IRA")
  const goldReviews = AUTHORED_REVIEWS.filter(r => r.category === "Gold IRA")
  const guides = AUTHORED_REVIEWS.filter(r => r.category === "Guide" || r.category === "Research")

  return (
    <>
      <SEO
        title="James Mitchell — Lead IRA Research Analyst"
        description="James Mitchell is the Lead IRA Research Analyst at IRA Research Hub. CFA-credentialed specialist in cryptocurrency IRAs, precious metals IRAs, and self-directed IRA fee analysis."
        canonical="/author/james-mitchell"
        ogType="article"
      />
      <script
        type="application/ld+json"
        dangerouslySetInnerHTML={{ __html: JSON.stringify(personSchema) }}
      />

      {/* Hero */}
      <section className="bg-[#F8FAFC] border-b border-slate-200">
        <div className="container-site py-12">
          <div className="flex flex-wrap items-center gap-2 mb-4">
            <Link to="/about" className="text-sm text-[#64748B] hover:text-[#0EA5E9]">About</Link>
            <span className="text-slate-300">/</span>
            <span className="text-sm text-[#0F172A]">James Mitchell</span>
          </div>
          <div className="flex items-start gap-6">
            <div className="flex-shrink-0">
              <div className="w-20 h-20 rounded-full bg-[#0EA5E9] flex items-center justify-center text-white text-2xl font-bold">
                JM
              </div>
            </div>
            <div>
              <h1 className="text-3xl font-bold text-[#0F172A] mb-1">James Mitchell, CFA</h1>
              <p className="text-[#0EA5E9] font-medium mb-2">Lead IRA Research Analyst · IRA Research Hub</p>
              <div className="flex flex-wrap gap-2 mb-3">
                <span className="badge-sky text-xs">CFA Charterholder</span>
                <span className="inline-flex items-center px-2 py-0.5 rounded-full text-xs font-medium bg-emerald-100 text-emerald-800">
                  {AUTHORED_REVIEWS.length} Reviews &amp; Guides
                </span>
              </div>
              <p className="text-sm text-slate-500">
                Last updated: March 21, 2026 ·{' '}
                <a href="mailto:editorial@iraresearchhub.com" className="text-[#0EA5E9] hover:underline">
                  editorial@iraresearchhub.com
                </a>
              </p>
            </div>
          </div>
        </div>
      </section>

      <div className="container-site py-12">
        <div className="grid lg:grid-cols-3 gap-10">
          {/* Main bio */}
          <div className="lg:col-span-2 space-y-8">
            <div className="card">
              <h2 className="text-xl font-bold text-[#0F172A] mb-4">About James Mitchell</h2>
              <div className="prose prose-slate max-w-none text-[#64748B] space-y-4">
                <p>
                  James Mitchell is the Lead IRA Research Analyst at IRA Research Hub, where he
                  oversees all provider reviews, develops the site's proprietary scoring
                  methodology, and conducts independent fee analysis across the self-directed IRA
                  industry.
                </p>
                <p>
                  A <strong className="text-[#0F172A]">CFA charterholder</strong>, James
                  specialises in the intersection of alternative assets and tax-advantaged
                  retirement accounts — specifically cryptocurrency IRAs, precious metals IRAs, and
                  the regulatory landscape governing self-directed IRA custodians. He has personally
                  reviewed more than 25 IRA providers, analysing fee structures, custody
                  arrangements, asset selection, and regulatory compliance.
                </p>
                <p>
                  James developed the IRA Research Hub{' '}
                  <Link to="/methodology" className="text-[#0EA5E9] hover:underline">
                    10-point scoring methodology
                  </Link>
                  , which evaluates providers across six weighted criteria: fee transparency,
                  asset selection, security and custody, customer support, regulatory compliance,
                  and user experience. All scores are updated quarterly using live data from
                  provider disclosures and independent verification.
                </p>
                <p>
                  Prior to IRA Research Hub, James worked in institutional fixed income and
                  alternative investment research. He holds a degree in Economics from the
                  University of Chicago.
                </p>
              </div>
            </div>

            {/* Areas of expertise */}
            <div className="card">
              <h2 className="text-xl font-bold text-[#0F172A] mb-4">Areas of Expertise</h2>
              <div className="grid sm:grid-cols-2 gap-3">
                {[
                  "Cryptocurrency IRAs (Bitcoin, Ethereum, Altcoins)",
                  "Precious Metals IRAs (Gold, Silver, Platinum, Palladium)",
                  "Self-Directed IRA Structures",
                  "IRA Fee Analysis & Comparison",
                  "IRS Retirement Account Regulations",
                  "401k to IRA Rollover Strategies",
                  "Alternative Asset Custodians",
                  "ERISA Compliance & Fiduciary Standards",
                ].map((expertise) => (
                  <div key={expertise} className="flex items-start gap-2">
                    <span className="text-[#0EA5E9] mt-0.5 flex-shrink-0">✓</span>
                    <span className="text-sm text-[#64748B]">{expertise}</span>
                  </div>
                ))}
              </div>
            </div>

            {/* Editorial standards */}
            <div className="card bg-blue-50 border-blue-200">
              <h2 className="text-lg font-bold text-[#0F172A] mb-3">Editorial Independence</h2>
              <p className="text-sm text-[#64748B] leading-relaxed">
                All reviews and rankings on IRA Research Hub are produced independently by James
                and the editorial team. Affiliate relationships with providers are disclosed but
                never influence scores, rankings, or editorial copy. See our{' '}
                <Link to="/editorial-policy" className="text-[#0EA5E9] hover:underline">
                  Editorial Policy
                </Link>{' '}
                for full details.
              </p>
            </div>

            {/* Authored content */}
            <div>
              <h2 className="text-xl font-bold text-[#0F172A] mb-6">Reviews &amp; Research by James Mitchell</h2>

              <h3 className="text-base font-semibold text-[#0F172A] mb-3 uppercase tracking-wider text-xs">
                Crypto IRA Reviews
              </h3>
              <div className="grid sm:grid-cols-2 gap-3 mb-6">
                {cryptoReviews.map((review) => (
                  <Link
                    key={review.url}
                    to={review.url}
                    className="block p-3 rounded-lg border border-slate-200 hover:border-[#0EA5E9] hover:bg-blue-50 transition-colors"
                  >
                    <span className="text-sm font-medium text-[#0F172A]">{review.title}</span>
                  </Link>
                ))}
              </div>

              <h3 className="text-base font-semibold text-[#0F172A] mb-3 uppercase tracking-wider text-xs">
                Gold &amp; Precious Metals IRA Reviews
              </h3>
              <div className="grid sm:grid-cols-2 gap-3 mb-6">
                {goldReviews.map((review) => (
                  <Link
                    key={review.url}
                    to={review.url}
                    className="block p-3 rounded-lg border border-slate-200 hover:border-[#0EA5E9] hover:bg-blue-50 transition-colors"
                  >
                    <span className="text-sm font-medium text-[#0F172A]">{review.title}</span>
                  </Link>
                ))}
              </div>

              <h3 className="text-base font-semibold text-[#0F172A] mb-3 uppercase tracking-wider text-xs">
                Guides &amp; Research
              </h3>
              <div className="grid sm:grid-cols-2 gap-3">
                {guides.map((guide) => (
                  <Link
                    key={guide.url}
                    to={guide.url}
                    className="block p-3 rounded-lg border border-slate-200 hover:border-[#0EA5E9] hover:bg-blue-50 transition-colors"
                  >
                    <span className="text-sm font-medium text-[#0F172A]">{guide.title}</span>
                  </Link>
                ))}
              </div>
            </div>
          </div>

          {/* Sidebar */}
          <div className="space-y-6">
            <div className="card">
              <h3 className="font-bold text-[#0F172A] mb-4">Credentials</h3>
              <div className="space-y-3">
                <div className="flex items-start gap-3">
                  <div className="w-8 h-8 rounded-full bg-[#0EA5E9] flex items-center justify-center text-white text-xs font-bold flex-shrink-0">
                    CFA
                  </div>
                  <div>
                    <p className="text-sm font-medium text-[#0F172A]">CFA Charterholder</p>
                    <p className="text-xs text-slate-500">CFA Institute</p>
                  </div>
                </div>
                <div className="flex items-start gap-3">
                  <div className="w-8 h-8 rounded-full bg-slate-200 flex items-center justify-center text-slate-600 text-xs font-bold flex-shrink-0">
                    BA
                  </div>
                  <div>
                    <p className="text-sm font-medium text-[#0F172A]">B.A. Economics</p>
                    <p className="text-xs text-slate-500">University of Chicago</p>
                  </div>
                </div>
              </div>
            </div>

            <div className="card">
              <h3 className="font-bold text-[#0F172A] mb-3">Contact</h3>
              <div className="space-y-2">
                <a
                  href="mailto:editorial@iraresearchhub.com"
                  className="flex items-center gap-2 text-sm text-[#0EA5E9] hover:underline"
                >
                  <span>✉</span>
                  editorial@iraresearchhub.com
                </a>

              </div>
            </div>

            <div className="card">
              <h3 className="font-bold text-[#0F172A] mb-3">Methodology</h3>
              <p className="text-sm text-[#64748B] mb-3">
                All reviews use the IRA Research Hub 10-point scoring system, updated quarterly.
              </p>
              <Link to="/methodology" className="btn-secondary text-sm w-full text-center block">
                View Methodology
              </Link>
            </div>
          </div>
        </div>
      </div>
      {/* ── Newsletter Signup ─────────────────────────────────────────── */}
      <div className="container-site py-10 max-w-3xl">
        <NewsletterSignup />
      </div>
    </>
  )
}
