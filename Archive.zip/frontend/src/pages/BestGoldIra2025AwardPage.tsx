import AwardDetailPage from './AwardDetailPage'

export default function BestGoldIra2025AwardPage() {
  return <AwardDetailPage awardSlug="best-gold-ira-2025" />
}
