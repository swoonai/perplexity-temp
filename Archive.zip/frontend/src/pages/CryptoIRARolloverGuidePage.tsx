import { Link } from 'react-router-dom'
import SEO from '../components/SEO'
import AdvertiserDisclosure from '../components/AdvertiserDisclosure'
import { trackProviderReviewClick } from '../hooks/useAnalytics'
import NewsletterSignup from '../components/NewsletterSignup';
import RelatedLinks from '../components/RelatedLinks';

const DATE_MODIFIED = "2026-03-20"
const DATE_PUBLISHED = "2026-01-15"
const LAST_UPDATED = "March 20, 2026"

// W2.F — HowTo schema for agentic AI and voice assistants
const howToSchema = {
  "@context": "https://schema.org",
  "@type": "HowTo",
  "name": "How to Roll Over a 401k to a Crypto IRA",
  "description": "A step-by-step guide to rolling over a 401(k) to a Cryptocurrency IRA tax-free and penalty-free under IRS rules.",
  "totalTime": "PT3W",
  "estimatedCost": {
    "@type": "MonetaryAmount",
    "currency": "USD",
    "value": "0",
    "description": "Direct rollovers are tax-free and penalty-free. Provider fees apply after account opening."
  },
  "step": [
    { "@type": "HowToStep", "position": 1, "name": "Choose a Crypto IRA Provider", "text": "Select an IRS-compliant Crypto IRA provider. Compare fees, supported cryptocurrencies, custody security, and minimum investment requirements. Top options include BlockTrust IRA, iTrustCapital, and Bitcoin IRA.", "url": "https://iraresearchhub.com/crypto-ira/best-companies" },
    { "@type": "HowToStep", "position": 2, "name": "Open Your Self-Directed IRA Account", "text": "Complete the provider's account application. Choose Traditional or Roth IRA type. Provide your SSN, employment information, and beneficiary details. Account opening typically takes 1-3 business days." },
    { "@type": "HowToStep", "position": 3, "name": "Request a Direct Rollover from Your 401k Plan", "text": "Contact your 401k plan administrator and request a direct rollover (trustee-to-trustee transfer). Specify that funds should be sent directly to your new Crypto IRA custodian. This avoids the 20% mandatory withholding that applies to indirect rollovers." },
    { "@type": "HowToStep", "position": 4, "name": "Fund Your Crypto IRA", "text": "Once rollover funds arrive (typically 1-3 weeks), they appear as cash in your Crypto IRA account. You can then purchase cryptocurrencies through your provider's trading platform." },
    { "@type": "HowToStep", "position": 5, "name": "Purchase Cryptocurrencies", "text": "Use your provider's platform to buy cryptocurrencies. Your assets are held in your name by an IRS-approved custodian using institutional cold storage. You can trade within the IRA without triggering taxable events." }
  ]
}

// W2.DD — Agent-ready action layer
const agentActionSchema = {
  "@context": "https://schema.org",
  "@type": "WebPage",
  "@id": "https://iraresearchhub.com/crypto-ira/401k-to-crypto-ira-rollover",
  "name": "401k to Crypto IRA Rollover Guide 2026",
  "datePublished": DATE_PUBLISHED,
  "dateModified": DATE_MODIFIED,
  "potentialAction": [
    { "@type": "ReadAction", "target": "https://iraresearchhub.com/crypto-ira/401k-to-crypto-ira-rollover" },
    { "@type": "SearchAction", "target": "https://iraresearchhub.com/crypto-ira/best-companies", "description": "Compare Crypto IRA providers" }
  ]
}

const faqSchema = {
  "@context": "https://schema.org",
  "@type": "FAQPage",
  "mainEntity": [
    {
      "@type": "Question",
      "name": "Can I roll over my 401k to a Crypto IRA without penalty?",
      "acceptedAnswer": {
        "@type": "Answer",
        "text": "Yes. A direct rollover from a 401k to a Crypto IRA (Self-Directed IRA) is tax-free and penalty-free under IRS rules, provided the funds go directly from your 401k custodian to your Crypto IRA custodian. You must complete an indirect rollover within 60 days to avoid taxes and penalties."
      }
    },
    {
      "@type": "Question",
      "name": "Which cryptocurrencies can I hold in a Crypto IRA?",
      "acceptedAnswer": {
        "@type": "Answer",
        "text": "The IRS does not specify which cryptocurrencies are allowed — it's up to your custodian. Most Crypto IRA providers support Bitcoin (BTC), Ethereum (ETH), Litecoin (LTC), Bitcoin Cash (BCH), and Ripple (XRP) at minimum. BlockTrust IRA supports 60+ cryptocurrencies. iTrustCapital supports 30+. Bitcoin IRA supports 60+."
      }
    },
    {
      "@type": "Question",
      "name": "How is cryptocurrency taxed in an IRA?",
      "acceptedAnswer": {
        "@type": "Answer",
        "text": "In a Traditional Crypto IRA, gains are tax-deferred — you pay income tax when you withdraw in retirement. In a Roth Crypto IRA, gains are tax-free if you follow the rules (account open 5+ years, age 59½+). The key advantage: you can trade crypto within the IRA without triggering a taxable event, unlike a regular brokerage account."
      }
    },
    {
      "@type": "Question",
      "name": "What is the minimum investment for a Crypto IRA?",
      "acceptedAnswer": {
        "@type": "Answer",
        "text": "Minimum investments vary: BlockTrust IRA requires $20,000 (fully managed). Bitcoin IRA requires $1,000. iTrustCapital requires $1,000. Most providers have no maximum. The lower minimums make Crypto IRAs more accessible than Gold IRAs."
      }
    },
    {
      "@type": "Question",
      "name": "Is cryptocurrency safe in an IRA?",
      "acceptedAnswer": {
        "@type": "Answer",
        "text": "Crypto IRA providers use institutional-grade custody. Top providers use qualified custodians like BitGo Trust, Equity Trust, or Kingdom Trust with cold storage (offline wallets), multi-signature security, and insurance coverage ($100M–$700M). Your crypto is held in your name, not pooled with other customers."
      }
    },
    {
      "@type": "Question",
      "name": "Can I roll over a Roth 401k to a Crypto IRA?",
      "acceptedAnswer": {
        "@type": "Answer",
        "text": "Yes. Roll a Roth 401k into a Roth Crypto IRA to preserve the tax-free treatment. The process is identical to a traditional rollover, but you must specify a Roth IRA account type when opening your Crypto IRA. Gains in a Roth Crypto IRA grow completely tax-free."
      }
    }
  ]
}

const speakableSchema = {
  "@context": "https://schema.org",
  "@type": "WebPage",
  "speakable": {
    "@type": "SpeakableSpecification",
    "cssSelector": [".speakable-summary", "h1", ".citation-block"]
  },
  "url": "https://iraresearchhub.com/crypto-ira/401k-to-crypto-ira-rollover"
}

const breadcrumbSchema = {"@context": "https://schema.org", "@type": "BreadcrumbList", "itemListElement": [{"@type": "ListItem", "position": 1, "name": "Crypto IRA", "item": "https://iraresearchhub.com/crypto-ira"},
      {"@type": "ListItem", "position": 2, "name": "401(k) to Crypto IRA Rollover", "item": "https://iraresearchhub.com/crypto-ira/401k-to-crypto-ira-rollover"}]};
export default function CryptoIRARolloverGuidePage() {
  return (
    <>
      <SEO
        title="How to Roll Over a 401k to a Crypto IRA (2026 Step-by-Step Guide)"
        description="Complete step-by-step guide to rolling over your 401k to a Crypto IRA in 2026. Tax rules, supported coins, fees, custody, and provider recommendations."
        canonical="/crypto-ira/401k-to-crypto-ira-rollover"
        ogType="article"
        ogImage="/og/401k-to-crypto-ira-rollover.jpg"
      />
      <script type="application/ld+json" dangerouslySetInnerHTML={{ __html: JSON.stringify(faqSchema) }} />
      <script type="application/ld+json" dangerouslySetInnerHTML={{ __html: JSON.stringify(howToSchema) }} />
      <script type="application/ld+json" dangerouslySetInnerHTML={{ __html: JSON.stringify(agentActionSchema) }} />
      <script type="application/ld+json" dangerouslySetInnerHTML={{ __html: JSON.stringify(speakableSchema) }} />

      <script type="application/ld+json" dangerouslySetInnerHTML={{ __html: JSON.stringify(breadcrumbSchema) }} />
      {/* Header */}
      <section className="bg-[#F8FAFC] border-b border-slate-200">
        <div className="container-site py-12">
          <div className="flex flex-wrap items-center gap-2 mb-4">
            <Link to="/crypto-ira" className="text-sm text-[#64748B] hover:text-[#0EA5E9]">Crypto IRAs</Link>
            <span className="text-slate-300">/</span>
            <span className="text-sm text-[#0F172A]">401k to Crypto IRA Rollover Guide</span>
          </div>
          <div className="badge-sky mb-4">By <a href="/author/james-mitchell" className="text-[#0EA5E9] hover:underline">James Mitchell, CFA</a> · Updated {LAST_UPDATED} · IRS-Verified</div>
          <h1 className="text-4xl font-bold text-[#0F172A] mb-4">
            How to Roll Over a 401k to a Crypto IRA (2026)
          </h1>
              <AdvertiserDisclosure />

          <p className="text-lg text-[#64748B] max-w-2xl leading-relaxed">
            A complete, step-by-step guide to moving your 401k into a Crypto IRA — tax-free and
            penalty-free. Includes IRS rules, supported cryptocurrencies, fee comparisons, and
            our top provider recommendations.
          </p>
        </div>
      </section>

      <div className="container-site py-12">
        <div className="grid lg:grid-cols-3 gap-10">
          {/* Main content */}
          <div className="lg:col-span-2 space-y-10">

            {/* Quick summary */}
            <div className="card border-l-4 border-l-[#0EA5E9]">
              <h2 className="text-lg font-bold text-[#0F172A] mb-3">Key Takeaways</h2>
              <ul className="space-y-2 text-sm text-[#334155]">
                {[
                  'A direct 401k rollover to a Crypto IRA is tax-free and penalty-free',
                  'The process takes 1–3 weeks — faster than a Gold IRA rollover',
                  'Trade crypto within the IRA without triggering capital gains tax',
                  'Institutional custody with cold storage and $100M–$700M insurance',
                  'Lower minimums than Gold IRAs — some providers start at $1,000',
                  'Roth Crypto IRA option: gains grow completely tax-free',
                ].map((point) => (
                  <li key={point} className="flex gap-2">
                    <span className="text-[#0EA5E9] font-bold flex-shrink-0">✓</span>
                    {point}
                  </li>
                ))}
              </ul>
            </div>

            {/* What is a Crypto IRA */}
            <div>
              <h2 className="text-2xl font-bold text-[#0F172A] mb-4">What Is a Crypto IRA?</h2>
              <p className="text-[#64748B] leading-relaxed mb-4">
                A Crypto IRA (also called a Bitcoin IRA or Digital Asset IRA) is a Self-Directed IRA
                that holds cryptocurrency instead of — or alongside — traditional assets like stocks
                and bonds. It operates under the same IRS rules as a traditional IRA, including the
                same contribution limits, RMD rules, and tax treatment.
              </p>
              <p className="text-[#64748B] leading-relaxed">
                The key advantage over a regular crypto account: gains are tax-deferred (Traditional)
                or tax-free (Roth). You can trade Bitcoin for Ethereum inside the IRA without
                triggering a taxable event — unlike a regular brokerage or exchange account where
                every trade is a taxable event.
              </p>
            </div>

            {/* Crypto IRA vs Regular Crypto */}
            <div>
              <h2 className="text-2xl font-bold text-[#0F172A] mb-4">Crypto IRA vs Regular Crypto Account</h2>
              <div className="overflow-x-auto">
                <table className="comparison-table">
                  <thead>
                    <tr>
                      <th>Feature</th>
                      <th>Crypto IRA</th>
                      <th>Regular Crypto Exchange</th>
                    </tr>
                  </thead>
                  <tbody>
                    {[
                      ['Tax on gains', 'Deferred (Traditional) or Tax-Free (Roth)', 'Capital gains tax on every trade'],
                      ['Tax on trading', 'No tax when trading within IRA', 'Taxable event on every trade'],
                      ['Contribution limit', '$7,000/year ($8,000 if 50+)', 'Unlimited'],
                      ['Early withdrawal', '10% penalty before age 59½', 'No penalty'],
                      ['Custody', 'Institutional (qualified custodian)', 'Exchange custody (counterparty risk)'],
                      ['Insurance', '$100M–$700M coverage', 'Varies (often limited)'],
                      ['FDIC/SIPC', 'Cash portion may be FDIC-insured', 'Not applicable'],
                    ].map(([feature, ira, exchange]) => (
                      <tr key={feature}>
                        <td className="font-medium text-[#0F172A]">{feature}</td>
                        <td className="text-emerald-600">{ira}</td>
                        <td className="text-[#64748B]">{exchange}</td>
                      </tr>
                    ))}
                  </tbody>
                </table>
              </div>
            </div>

            {/* Direct vs Indirect Rollover */}
            <div>
              <h2 className="text-2xl font-bold text-[#0F172A] mb-4">Direct vs. Indirect Rollovers</h2>
              <p className="text-[#64748B] leading-relaxed mb-4">
                When moving funds from a 401(k) to a Crypto IRA, you have two options: a direct rollover or an indirect rollover. For crypto's fast-moving market, a direct rollover is strongly recommended to avoid tax penalties and complications.
              </p>
              <div className="grid md:grid-cols-2 gap-6">
                <div className="card bg-slate-50">
                  <h3 className="font-semibold text-[#0F172A] mb-2">Direct Rollover (Recommended)</h3>
                  <p className="text-sm text-[#64748B] mb-3">
                    Funds are wired directly from your 401(k) provider to your new Crypto IRA custodian. You never personally receive the funds. This is the safest and most common method.
                  </p>
                  <ul className="space-y-2 text-sm">
                    <li className="flex gap-2"><span className="text-emerald-500 font-bold">✓</span> No taxes or penalties</li>
                    <li className="flex gap-2"><span className="text-emerald-500 font-bold">✓</span> No 60-day deadline to worry about</li>
                    <li className="flex gap-2"><span className="text-emerald-500 font-bold">✓</span> No limit on the number of rollovers</li>
                  </ul>
                </div>
                <div className="card bg-slate-50">
                  <h3 className="font-semibold text-[#0F172A] mb-2">Indirect Rollover</h3>
                  <p className="text-sm text-[#64748B] mb-3">
                    Your 401(k) administrator sends you a check. You have 60 days to deposit the funds into your new Crypto IRA. This method is risky and generally not advised.
                  </p>
                  <ul className="space-y-2 text-sm">
                    <li className="flex gap-2"><span className="text-red-500 font-bold">✗</span> 20% of funds are automatically withheld for taxes</li>
                    <li className="flex gap-2"><span className="text-red-500 font-bold">✗</span> If you miss the 60-day deadline, the entire amount is taxed as income + 10% penalty</li>
                    <li className="flex gap-2"><span className="text-red-500 font-bold">✗</span> You can only do one indirect rollover per year</li>
                  </ul>
                </div>
              </div>
            </div>

            {/* Risks and Considerations */}
            <div>
              <h2 className="text-2xl font-bold text-[#0F172A] mb-4">Risks and Considerations</h2>
               <p className="text-[#64748B] leading-relaxed mb-4">
                While Crypto IRAs offer significant tax advantages and growth potential, they also come with unique risks that are important to understand before investing.
              </p>
              <div className="grid md:grid-cols-2 gap-4">
                {
                  [
                    {
                      title: 'Market Volatility',
                      desc: 'Cryptocurrencies are notoriously volatile. Prices can swing dramatically in short periods. You should only invest an amount you are comfortable with, as part of a diversified portfolio.',
                    },
                    {
                      title: 'Regulatory Uncertainty',
                      desc: 'The regulatory landscape for cryptocurrencies is still evolving in the U.S. and globally. Future regulations could impact the value and legality of certain digital assets.',
                    },
                    {
                      title: 'No FDIC/SIPC Insurance',
                      desc: 'The crypto assets themselves are not FDIC or SIPC insured. However, reputable custodians provide substantial insurance policies from third-party insurers (e.g., $100M-$700M) to protect against theft.',
                    },
                    {
                      title: 'Custody and Security',
                      desc: 'You cannot hold your own private keys; the crypto must be held by a qualified custodian. It is crucial to choose a provider that uses institutional-grade cold storage and multi-signature security.',
                    },
                  ].map((item) => (
                    <div key={item.title} className="bg-slate-50 rounded-lg p-4">
                      <h3 className="font-semibold text-[#0F172A] mb-2">{item.title}</h3>
                      <p className="text-sm text-[#64748B]">{item.desc}</p>
                    </div>
                  ))
                }
              </div>
            </div>

            {/* Step-by-step */}
            <div>
              <h2 className="text-2xl font-bold text-[#0F172A] mb-6">Step-by-Step Rollover Process</h2>
              <div className="space-y-6">
                {[
                  {
                    step: '1',
                    title: 'Choose a Crypto IRA Custodian',
                    time: '1–2 days',
                    desc: 'Select an IRS-approved custodian that specializes in digital assets. Key factors: supported cryptocurrencies, fee structure, custody provider, and insurance coverage. Our top-rated options are BlockTrust IRA, iTrustCapital, and Bitcoin IRA.',
                    action: 'Compare top crypto IRA providers',
                    link: '/crypto-ira/best-companies',
                  },
                  {
                    step: '2',
                    title: 'Open Your Crypto IRA Account',
                    time: '1–3 business days',
                    desc: 'Complete the online application. You\'ll need: government-issued ID, Social Security number, and your 401k account details. Choose Traditional (tax-deferred) or Roth (tax-free) — this cannot be changed later.',
                    action: null,
                    link: null,
                  },
                  {
                    step: '3',
                    title: 'Initiate the Rollover',
                    time: '5–10 business days',
                    desc: 'Contact your 401k plan administrator and request a direct rollover to your new Crypto IRA custodian. Provide the custodian\'s name, address, and your new IRA account number. For a direct rollover, funds go directly between institutions — you never receive a check.',
                    action: null,
                    link: null,
                  },
                  {
                    step: '4',
                    title: 'Funds Arrive in Your IRA',
                    time: '2–5 business days',
                    desc: 'Your Crypto IRA custodian receives the cash from your 401k. The funds sit in a cash/money market position until you select your cryptocurrencies. This is not a taxable event.',
                    action: null,
                    link: null,
                  },
                  {
                    step: '5',
                    title: 'Buy Cryptocurrency',
                    time: 'Same day',
                    desc: 'Log into your Crypto IRA account and purchase your chosen cryptocurrencies. Most platforms offer real-time trading 24/7. Your crypto is immediately allocated to your account and held in cold storage by the qualified custodian.',
                    action: null,
                    link: null,
                  },
                ].map((item) => (
                  <div key={item.step} className="flex gap-4">
                    <div className="flex-shrink-0 w-10 h-10 rounded-full bg-[#0EA5E9] text-white font-bold flex items-center justify-center text-sm">
                      {item.step}
                    </div>
                    <div className="flex-1">
                      <div className="flex items-center gap-3 mb-2">
                        <h3 className="font-bold text-[#0F172A]">{item.title}</h3>
                        <span className="text-xs text-[#64748B] bg-slate-100 px-2 py-0.5 rounded-full">{item.time}</span>
                      </div>
                      <p className="text-[#64748B] text-sm leading-relaxed">{item.desc}</p>
                      {item.action && item.link && (
                        <Link to={item.link} className="text-[#0EA5E9] text-sm hover:underline mt-2 inline-block">
                          {item.action} →
                        </Link>
                      )}
                    </div>
                  </div>
                ))}
              </div>
            </div>

            {/* Provider fee comparison */}
            <div>
              <h2 className="text-2xl font-bold text-[#0F172A] mb-4">Crypto IRA Provider Comparison</h2>
              <div className="overflow-x-auto">
                <table className="comparison-table">
                  <thead>
                    <tr>
                      <th>Provider</th>
                      <th>Min. Investment</th>
                      <th>Trading Fee</th>
                      <th>Annual Fee</th>
                      <th>Coins</th>
                    </tr>
                  </thead>
                  <tbody>
                    {[
                      ['BlockTrust IRA', '$20,000', '0.14% via sFOX', '2% + 25% perf', '60+'],
                      ['iTrustCapital', '$1,000', '1%', '$0', '30+'],
                      ['Bitcoin IRA', '$1,000', '2%', '$0', '60+'],
                    ].map(([name, min, trading, annual, coins]) => (
                      <tr key={name}>
                        <td className="font-medium text-[#0F172A]">{name}</td>
                        <td>{min}</td>
                        <td>{trading}</td>
                        <td>{annual}</td>
                        <td>{coins}</td>
                      </tr>
                    ))}
                  </tbody>
                </table>
              </div>
            </div>

            {/* FAQ */}
            <div>
              <h2 className="text-2xl font-bold text-[#0F172A] mb-6">Frequently Asked Questions</h2>
              <div className="space-y-4">
                {faqSchema.mainEntity.map((faq) => (
                  <div key={faq.name} className="border border-slate-200 rounded-xl p-5">
                    <h3 className="font-semibold text-[#0F172A] mb-2">{faq.name}</h3>
                    <p className="text-sm text-[#64748B] leading-relaxed">{faq.acceptedAnswer.text}</p>
                  </div>
                ))}
              </div>
            </div>

            {/* CTA */}
            <div className="card bg-gradient-to-br from-sky-50 to-blue-50 border-sky-200">
              <h2 className="text-xl font-bold text-[#0F172A] mb-3">Ready to Start Your Rollover?</h2>
              <p className="text-[#64748B] mb-5">
                Compare our top-rated Crypto IRA providers and get started today. Most providers
                can complete your rollover in 1–3 weeks.
              </p>
              <div className="flex flex-wrap gap-3">
                <Link to="/crypto-ira/best-companies" className="btn-primary">
                  Compare Top Providers →
                </Link>
                <Link to="/crypto-ira/blocktrust-ira-review" className="btn-outline"
                onClick={() => trackProviderReviewClick('Blocktrust Ira', 'blocktrust-ira', window.location.pathname)}>
                  #1 Rated: BlockTrust IRA
                </Link>
              </div>
            </div>

          </div>

          {/* Sidebar */}
          <div className="space-y-6">
            <div className="card sticky top-24">
              <h3 className="font-semibold text-[#0F172A] mb-4 text-sm uppercase tracking-wider">In This Guide</h3>
              <nav className="space-y-2 text-sm">
                {[
                  'What Is a Crypto IRA?',
                  'Crypto IRA vs Regular Account',
                  'Step-by-Step Process',
                  'Provider Comparison',
                  'FAQ',
                ].map((label) => (
                  <a key={label} href="#" className="block text-[#64748B] hover:text-[#0EA5E9] py-1 border-b border-slate-100 last:border-0">
                    {label}
                  </a>
                ))}
              </nav>
            </div>

            <div className="card">
              <h3 className="font-semibold text-[#0F172A] mb-4 text-sm uppercase tracking-wider">Top Providers</h3>
              <div className="space-y-3">
                {[
                  { name: 'BlockTrust IRA', rank: '#1', slug: 'blocktrust-ira-review' },
                  { name: 'iTrustCapital', rank: '#2', slug: 'itrustcapital-review' },
                  { name: 'Bitcoin IRA', rank: '#3', slug: 'bitcoin-ira-review' },
                ].map((p) => (
                  <Link
                    key={p.name}
                    to={`/crypto-ira/${p.slug}`}
                    className="flex items-center justify-between text-sm hover:text-[#0EA5E9] py-1 border-b border-slate-100 last:border-0"
                  >
                    <span className="text-[#64748B]">{p.name}</span>
                    <span className="text-xs font-semibold text-[#0EA5E9]">{p.rank}</span>
                  </Link>
                ))}
              </div>
            </div>

            <div className="card">
              <h3 className="font-semibold text-[#0F172A] mb-3 text-sm uppercase tracking-wider">Related Guides</h3>
              <div className="space-y-2 text-sm">
                <Link to="/precious-metals-ira/401k-to-gold-ira-rollover" className="block text-[#0EA5E9] hover:underline">
                  401k to Gold IRA Rollover Guide →
                </Link>
                <Link to="/gold-ira-vs-crypto-ira" className="block text-[#0EA5E9] hover:underline">
                  Gold IRA vs Crypto IRA Comparison →
                </Link>
                <Link to="/methodology" className="block text-[#0EA5E9] hover:underline">
                  How We Rate Providers →
                </Link>
              </div>
            </div>
          </div>
        </div>
      </div>
      {/* ── Newsletter Signup ─────────────────────────────────────────── */}
      <div className="container-site py-10 max-w-3xl">
        
        {/* Related Links */}

        <div className="mt-10 mb-6">

          <RelatedLinks variant="crypto-guide" title="Related Guides &amp; Reviews" />

        </div>
<NewsletterSignup />
      </div>
    </>
  )
}
