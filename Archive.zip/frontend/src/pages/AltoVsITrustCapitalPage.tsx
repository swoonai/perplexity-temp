import SEO from '../components/SEO';
import { useProvider, scoreColor } from '../hooks/useProviders';
import { trackProviderSiteVisit } from '../hooks/useAnalytics';
import AdvertiserDisclosure from '../components/AdvertiserDisclosure'
import NewsletterSignup from '../components/NewsletterSignup';
import RelatedLinks from '../components/RelatedLinks';

const LAST_UPDATED = "March 30, 2026";

const AltoVsITrustCapitalPage = () => {
  const { data: altoCryptoIra } = useProvider('alto-crypto-ira');
  const { data: itrustcapital } = useProvider('itrustcapital');

  if (!altoCryptoIra || !itrustcapital) {
    return null; // Or a loading spinner, or fallback UI
  }

  const faqSchema = {
    "@context": "https://schema.org",
    "@type": "FAQPage",
    "mainEntity": [
      {
        "@type": "Question",
        "name": "What is Alto CryptoIRA?",
        "acceptedAnswer": {
          "@type": "Answer",
          "text": "Alto CryptoIRA allows you to invest in over 200 cryptocurrencies with a minimum investment of $10 and a 1% trading fee. It was founded in 2018 and uses Coinbase Custody for asset storage."
        }
      },
      {
        "@type": "Question",
        "name": "What is iTrustCapital?",
        "acceptedAnswer": {
          "@type": "Answer",
          "text": "iTrustCapital offers access to over 30 cryptocurrencies with a minimum investment of $1,000 and a 1% trading fee. Founded in 2018, it also utilizes Coinbase Custody for secure asset management."
        }
      },
      {
        "@type": "Question",
        "name": "How do Alto CryptoIRA and iTrustCapital compare on fees?",
        "acceptedAnswer": {
          "@type": "Answer",
          "text": "Both Alto CryptoIRA and iTrustCapital charge a 1% trading fee. Neither platform has annual fees."
        }
      },
      {
        "@type": "Question",
        "name": "Which platform offers more cryptocurrency assets?",
        "acceptedAnswer": {
          "@type": "Answer",
          "text": "Alto CryptoIRA offers a significantly wider selection with over 200 cryptocurrencies, compared to iTrustCapital's 30+ assets."
        }
      },
      {
        "@type": "Question",
        "name": "What are the minimum investment requirements for Alto CryptoIRA and iTrustCapital?",
        "acceptedAnswer": {
          "@type": "Answer",
          "text": "Alto CryptoIRA has a low minimum investment of $10, making it accessible to more investors. iTrustCapital requires a higher minimum investment of $1,000."
        }
      }
    ]
  };

  const breadcrumbSchema = {
    "@context": "https://schema.org",
    "@type": "BreadcrumbList",
    "itemListElement": [
      {
        "@type": "ListItem",
        "position": 1,
        "name": "Crypto IRA",
        "item": "https://iraresearchhub.com/crypto-ira"
      },
      {
        "@type": "ListItem",
        "position": 2,
        "name": "Alto CryptoIRA vs iTrustCapital",
        "item": "https://iraresearchhub.com/crypto-ira/alto-crypto-ira-vs-itrustcapital"
      }
    ]
  };

  const comparisonTableSchema = {
    "@context": "https://schema.org",
    "@type": "Table",
    "about": "Comparison of Alto CryptoIRA and iTrustCapital",
    "name": "Alto CryptoIRA vs iTrustCapital Comparison Table",
    "description": "A detailed comparison of key features, fees, and offerings between Alto CryptoIRA and iTrustCapital for cryptocurrency IRAs.",
    "hasPart": [
      {
        "@type": "TableColumn",
        "name": "Feature"
      },
      {
        "@type": "TableColumn",
        "name": "Alto CryptoIRA"
      },
      {
        "@type": "TableColumn",
        "name": "iTrustCapital"
      }
    ],
    "mainEntity": [
      {
        "@type": "TableRow",
        "name": "Score",
        "hasPart": [
          {
            "@type": "TableCell",
            "name": "Score"
          },
          {
            "@type": "TableCell",
            "name": (altoCryptoIra.score_overall ?? 0)?.toString() ?? "0"
          },
          {
            "@type": "TableCell",
            "name": (itrustcapital.score_overall ?? 0)?.toString() ?? "0"
          }
        ]
      },
      {
        "@type": "TableRow",
        "name": "Fee",
        "hasPart": [
          {
            "@type": "TableCell",
            "name": "Fee"
          },
          {
            "@type": "TableCell",
            "name": altoCryptoIra.transaction_fee
          },
          {
            "@type": "TableCell",
            "name": itrustcapital.transaction_fee
          }
        ]
      },
      {
        "@type": "TableRow",
        "name": "Annual Fee",
        "hasPart": [
          {
            "@type": "TableCell",
            "name": "Annual Fee"
          },
          {
            "@type": "TableCell",
            "name": altoCryptoIra.annual_fee
          },
          {
            "@type": "TableCell",
            "name": itrustcapital.annual_fee
          }
        ]
      },
      {
        "@type": "TableRow",
        "name": "Minimum Investment",
        "hasPart": [
          {
            "@type": "TableCell",
            "name": "Minimum Investment"
          },
          {
            "@type": "TableCell",
            "name": altoCryptoIra.min_investment
          },
          {
            "@type": "TableCell",
            "name": itrustcapital.min_investment
          }
        ]
      },
      {
        "@type": "TableRow",
        "name": "Custody",
        "hasPart": [
          {
            "@type": "TableCell",
            "name": "Custody"
          },
          {
            "@type": "TableCell",
            "name": altoCryptoIra.custody_provider
          },
          {
            "@type": "TableCell",
            "name": itrustcapital.custody_provider
          }
        ]
      },
      {
        "@type": "TableRow",
        "name": "Assets",
        "hasPart": [
          {
            "@type": "TableCell",
            "name": "Assets"
          },
          {
            "@type": "TableCell",
            "name": altoCryptoIra.asset_count
          },
          {
            "@type": "TableCell",
            "name": itrustcapital.asset_count
          }
        ]
      },
      {
        "@type": "TableRow",
        "name": "BBB Rating",
        "hasPart": [
          {
            "@type": "TableCell",
            "name": "BBB Rating"
          },
          {
            "@type": "TableCell",
            "name": altoCryptoIra.bbb_rating
          },
          {
            "@type": "TableCell",
            "name": itrustcapital.bbb_rating
          }
        ]
      },
      {
        "@type": "TableRow",
        "name": "Founded",
        "hasPart": [
          {
            "@type": "TableCell",
            "name": "Founded"
          },
          {
            "@type": "TableCell",
            "name": (altoCryptoIra.founded_year ?? "N/A")?.toString() ?? "N/A"
          },
          {
            "@type": "TableCell",
            "name": (itrustcapital.founded_year ?? "N/A")?.toString() ?? "N/A"
          }
        ]
      }
    ]
  };

  return (
    <>
      <SEO
        title="Alto CryptoIRA vs iTrustCapital (2026)"
        description="Head-to-head comparison of Alto CryptoIRA vs iTrustCapital."
        canonical="/crypto-ira/alto-crypto-ira-vs-itrustcapital"
        ogType="article"
      />

      <script
        type="application/ld+json"
        dangerouslySetInnerHTML={{ __html: JSON.stringify(faqSchema) }}
      />
      <script
        type="application/ld+json"
        dangerouslySetInnerHTML={{ __html: JSON.stringify(breadcrumbSchema) }}
      />
      <script
        type="application/ld+json"
        dangerouslySetInnerHTML={{ __html: JSON.stringify(comparisonTableSchema) }}
      />

      <div className="bg-[#F8FAFC] py-10">
        <div className="container-site text-slate-900">
          <h1 className="text-4xl font-bold mb-4">Alto CryptoIRA vs iTrustCapital (2026)</h1>
          <p className="text-xl mb-6 text-slate-600">Head-to-head comparison of Alto CryptoIRA vs iTrustCapital to help you choose the best crypto IRA provider.</p>
          <p className="text-sm text-slate-500">Last Updated: {LAST_UPDATED} | By <a href="/author/james-mitchell">James Mitchell, CFA</a></p>
              <AdvertiserDisclosure />
        </div>
      </div>

      <div className="container-site py-10">
        <div className="grid grid-cols-1 lg:grid-cols-2 gap-8">
          <div>
            <h2 className="text-3xl font-bold text-slate-900 mb-4">Alto CryptoIRA Overview</h2>
            <p className="text-slate-600 mb-4">
              Alto CryptoIRA stands out for its extensive selection of over {altoCryptoIra.asset_count} cryptocurrencies, offering investors a broad range of digital assets to choose from. With a remarkably low minimum investment of {altoCryptoIra.min_investment}, it makes crypto investing accessible to a wider audience. Alto CryptoIRA charges a {altoCryptoIra.transaction_fee} trading fee and has no annual fees, making it a cost-effective option for many. Founded in {(altoCryptoIra.founded_year ?? "N/A") ?? "N/A"}, Alto utilizes Coinbase Custody for secure storage of assets, ensuring peace of mind for its users. It holds a BBB rating of {altoCryptoIra.bbb_rating}.
            </p>
            <a
              href={`${altoCryptoIra.affiliate_url}?ref=iraresearchhub&utm_source=iraresearchhub&utm_medium=affiliate&utm_campaign=review`}
              target="_blank"
              rel="noopener noreferrer"
              className="inline-block bg-blue-600 text-white px-6 py-3 rounded-md hover:bg-blue-700 transition-colors"
              onClick={() => trackProviderSiteVisit(altoCryptoIra.name, altoCryptoIra.slug, 'comparison-cta')}
            >
              Visit Alto CryptoIRA
            </a>
          </div>
          <div>
            <h2 className="text-3xl font-bold text-slate-900 mb-4">iTrustCapital Overview</h2>
            <p className="text-slate-600 mb-4">
              iTrustCapital provides a solid platform for crypto IRA investments, featuring over {itrustcapital.asset_count} cryptocurrencies. It requires a minimum investment of {itrustcapital.min_investment} and also charges a {itrustcapital.transaction_fee} trading fee with no annual fees. Established in {(itrustcapital.founded_year ?? "N/A") ?? "N/A"}, iTrustCapital also partners with Coinbase Custody for the safekeeping of digital assets. The platform maintains a BBB rating of {itrustcapital.bbb_rating}, reflecting its commitment to customer satisfaction and operational integrity.
            </p>
            <a
              href={`${itrustcapital.affiliate_url}?ref=iraresearchhub&utm_source=iraresearchhub&utm_medium=affiliate&utm_campaign=review`}
              target="_blank"
              rel="noopener noreferrer"
              className="inline-block bg-blue-600 text-white px-6 py-3 rounded-md hover:bg-blue-700 transition-colors"
              onClick={() => trackProviderSiteVisit(itrustcapital.name, itrustcapital.slug, 'comparison-cta')}
            >
              Visit iTrustCapital
            </a>
          </div>
        </div>

        <div className="mt-12">
          <h2 className="text-3xl font-bold text-slate-900 mb-6 text-center">Detailed Comparison</h2>
          <div className="overflow-x-auto">
            <table className="min-w-full bg-white shadow-md rounded-lg overflow-hidden">
              <thead className="bg-gray-100">
                <tr>
                  <th className="py-3 px-4 text-left text-sm font-semibold text-gray-600">Feature</th>
                  <th className="py-3 px-4 text-left text-sm font-semibold text-gray-600">Alto CryptoIRA</th>
                  <th className="py-3 px-4 text-left text-sm font-semibold text-gray-600">iTrustCapital</th>
                </tr>
              </thead>
              <tbody>
                <tr className="border-b border-gray-200">
                  <td className="py-3 px-4 text-slate-900 font-medium">Overall Score</td>
                  <td className={`py-3 px-4 ${scoreColor((altoCryptoIra.score_overall ?? 0) ?? 0)}`}>{(altoCryptoIra.score_overall ?? 0) ?? 0}</td>
                  <td className={`py-3 px-4 ${scoreColor((itrustcapital.score_overall ?? 0) ?? 0)}`}>{(itrustcapital.score_overall ?? 0) ?? 0}</td>
                </tr>
                <tr className="border-b border-gray-200">
                  <td className="py-3 px-4 text-slate-900 font-medium">Trading Fee</td>
                  <td className="py-3 px-4 text-slate-600">{altoCryptoIra.transaction_fee}</td>
                  <td className="py-3 px-4 text-slate-600">{itrustcapital.transaction_fee}</td>
                </tr>
                <tr className="border-b border-gray-200">
                  <td className="py-3 px-4 text-slate-900 font-medium">Annual Fee</td>
                  <td className="py-3 px-4 text-slate-600">{altoCryptoIra.annual_fee}</td>
                  <td className="py-3 px-4 text-slate-600">{itrustcapital.annual_fee}</td>
                </tr>
                <tr className="border-b border-gray-200">
                  <td className="py-3 px-4 text-slate-900 font-medium">Minimum Investment</td>
                  <td className="py-3 px-4 text-slate-600">{altoCryptoIra.min_investment}</td>
                  <td className="py-3 px-4 text-slate-600">{itrustcapital.min_investment}</td>
                </tr>
                <tr className="border-b border-gray-200">
                  <td className="py-3 px-4 text-slate-900 font-medium">Assets Available</td>
                  <td className="py-3 px-4 text-slate-600">{altoCryptoIra.asset_count}</td>
                  <td className="py-3 px-4 text-slate-600">{itrustcapital.asset_count}</td>
                </tr>
                <tr className="border-b border-gray-200">
                  <td className="py-3 px-4 text-slate-900 font-medium">Custody Provider</td>
                  <td className="py-3 px-4 text-slate-600">{altoCryptoIra.custody_provider}</td>
                  <td className="py-3 px-4 text-slate-600">{itrustcapital.custody_provider}</td>
                </tr>
                <tr className="border-b border-gray-200">
                  <td className="py-3 px-4 text-slate-900 font-medium">BBB Rating</td>
                  <td className="py-3 px-4 text-slate-600">{altoCryptoIra.bbb_rating}</td>
                  <td className="py-3 px-4 text-slate-600">{itrustcapital.bbb_rating}</td>
                </tr>
                <tr>
                  <td className="py-3 px-4 text-slate-900 font-medium">Founded</td>
                  <td className="py-3 px-4 text-slate-600">{(altoCryptoIra.founded_year ?? "N/A") ?? "N/A"}</td>
                  <td className="py-3 px-4 text-slate-600">{(itrustcapital.founded_year ?? "N/A") ?? "N/A"}</td>
                </tr>
              </tbody>
            </table>
          </div>
        </div>

        <div className="mt-12">
          <h2 className="text-3xl font-bold text-slate-900 mb-6 text-center">Frequently Asked Questions</h2>
          <div className="space-y-6">
            <div className="border border-gray-200 rounded-lg p-6">
              <h3 className="text-xl font-semibold text-slate-900 mb-3">What is Alto CryptoIRA?</h3>
              <p className="text-slate-600">
                Alto CryptoIRA allows you to invest in over 200 cryptocurrencies with a minimum investment of $10 and a 1% trading fee. It was founded in 2018 and uses Coinbase Custody for asset storage.
              </p>
            </div>
            <div className="border border-gray-200 rounded-lg p-6">
              <h3 className="text-xl font-semibold text-slate-900 mb-3">What is iTrustCapital?</h3>
              <p className="text-slate-600">
                iTrustCapital offers access to over 30 cryptocurrencies with a minimum investment of $1,000 and a 1% trading fee. Founded in 2018, it also utilizes Coinbase Custody for secure asset management.
              </p>
            </div>
            <div className="border border-gray-200 rounded-lg p-6">
              <h3 className="text-xl font-semibold text-slate-900 mb-3">How do Alto CryptoIRA and iTrustCapital compare on fees?</h3>
              <p className="text-slate-600">
                Both Alto CryptoIRA and iTrustCapital charge a 1% trading fee. Neither platform has annual fees.
              </p>
            </div>
            <div className="border border-gray-200 rounded-lg p-6">
              <h3 className="text-xl font-semibold text-slate-900 mb-3">Which platform offers more cryptocurrency assets?</h3>
              <p className="text-slate-600">
                Alto CryptoIRA offers a significantly wider selection with over 200 cryptocurrencies, compared to iTrustCapital's 30+ assets.
              </p>
            </div>
            <div className="border border-gray-200 rounded-lg p-6">
              <h3 className="text-xl font-semibold text-slate-900 mb-3">What are the minimum investment requirements for Alto CryptoIRA and iTrustCapital?</h3>
              <p className="text-slate-600">
                Alto CryptoIRA has a low minimum investment of $10, making it accessible to more investors. iTrustCapital requires a higher minimum investment of $1,000.
              </p>
            </div>
          </div>
        </div>

        <div className="mt-12 p-6 bg-gray-50 rounded-lg shadow-inner">
          <h2 className="text-2xl font-bold text-slate-900 mb-4">Advertiser Disclosure</h2>
          <p className="text-slate-600 text-sm">
            IRAResearchHub.com is an independent professional comparison site supported by referral fees from the companies featured. We are not a financial advisor. The information provided is for educational purposes only and should not be considered financial advice. Please consult with a qualified financial professional before making any investment decisions.
          </p>
        </div>
      </div>
      {/* ── Newsletter Signup ─────────────────────────────────────────── */}
      <div className="container-site py-10 max-w-3xl">
        
        {/* Related Links */}

        <div className="mt-10 mb-6">

          <RelatedLinks variant="comparison-crypto" title="Related Guides &amp; Reviews" />

        </div>
<NewsletterSignup />
      </div>
    </>
  );
};

export default AltoVsITrustCapitalPage;
