import StateGuideTemplate from '../components/StateGuideTemplate'

export default function BestCryptoIRAALPage() {
  return (
    <StateGuideTemplate
      stateName="Alabama"
      stateAbbr="AL"
      slug="alabama"
    />
  )
}
