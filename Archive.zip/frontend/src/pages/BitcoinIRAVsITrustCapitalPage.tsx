import { Link } from 'react-router-dom'
import SEO from '../components/SEO'
import { useProvider, scoreColor } from '../hooks/useProviders'
import AdvertiserDisclosure from '../components/AdvertiserDisclosure'
import { trackProviderReviewClick, trackProviderSiteVisit } from '../hooks/useAnalytics'
import NewsletterSignup from '../components/NewsletterSignup';
import RelatedLinks from '../components/RelatedLinks';

const DATE_MODIFIED = "2026-03-21"
const DATE_PUBLISHED = "2026-03-21"
const LAST_UPDATED = "March 21, 2026"

const comparisonSchema = {
  "@context": "https://schema.org",
  "@type": "Article",
  "@id": "https://iraresearchhub.com/crypto-ira/bitcoin-ira-vs-itrustcapital",
  "headline": "Bitcoin IRA vs iTrustCapital: 2026 Comparison",
  "description": "Bitcoin IRA vs iTrustCapital: detailed comparison of fees, asset selection, security, and scores. Bitcoin IRA scores 9.0/10 vs iTrustCapital's 8.8/10. See which is right for you.",
  "author": {
    "@type": "Person",
    "@id": "https://iraresearchhub.com/author/james-mitchell",
    "name": "James Mitchell",
    "url": "https://iraresearchhub.com/author/james-mitchell"
  },
  "publisher": {
    "@type": "Organization",
    "@id": "https://iraresearchhub.com",
    "name": "IRA Research Hub",
    "url": "https://iraresearchhub.com"
  },
  "datePublished": DATE_PUBLISHED,
  "dateModified": DATE_MODIFIED,
  "url": "https://iraresearchhub.com/crypto-ira/bitcoin-ira-vs-itrustcapital"
}

export default function BitcoinIRAVsITrustCapitalPage() {
  const { data: bitcoinIRA } = useProvider('bitcoin-ira')
  const { data: iTrust } = useProvider('itrustcapital')

  const bi = bitcoinIRA ?? {
    name: "Bitcoin IRA", score_overall: 9.0, score_fees: 8.5, score_assets: 9.0,
    score_security: 9.5, score_compliance: 9.0, score_support: 8.8, score_reputation: 9.3,
    annual_fee: "$240", transaction_fee: "2% per trade", min_investment: "$1,000",
    asset_count: 75, custody_provider: "Digital Trust / BitGo Trust Company", storage_type: "Cold Storage",
    insurance_coverage: "$700M", bbb_rating: "A+", founded_year: 2016,
    affiliate_url: null
  }
  const it = iTrust ?? {
    name: "iTrustCapital", score_overall: 8.8, score_fees: 9.8, score_assets: 8.0,
    score_security: 8.8, score_compliance: 9.0, score_support: 8.5, score_reputation: 8.7,
    annual_fee: "$0", transaction_fee: "1% per trade", min_investment: "$1,000",
    asset_count: 40, custody_provider: "Coinbase Custody", storage_type: "Cold Storage",
    insurance_coverage: "FDIC on cash", bbb_rating: "A", founded_year: 2018,
    affiliate_url: null
  }

  return (
    <>
      <SEO
        title="Bitcoin IRA vs iTrustCapital (2026): Which Is Better?"
        description="Bitcoin IRA vs iTrustCapital: Bitcoin IRA scores 9.0/10 with 75 assets; iTrustCapital scores 8.8/10 with $0 annual fee. Full comparison of fees, assets, and security."
        canonical="/crypto-ira/bitcoin-ira-vs-itrustcapital"
        ogType="article"
      />
      <script
        type="application/ld+json"
        dangerouslySetInnerHTML={{ __html: JSON.stringify(comparisonSchema) }}
      />

      <section className="bg-[#F8FAFC] border-b border-slate-200">
        <div className="container-site py-12">
          <div className="flex flex-wrap items-center gap-2 mb-4">
            <Link to="/crypto-ira" className="text-sm text-[#64748B] hover:text-[#0EA5E9]">Crypto IRAs</Link>
            <span className="text-slate-300">/</span>
            <span className="text-sm text-[#0F172A]">Bitcoin IRA vs iTrustCapital</span>
          </div>
          <div className="badge-sky mb-4">Updated March 2026 · Live Data</div>
          <h1 className="text-4xl font-bold text-[#0F172A] mb-3">Bitcoin IRA vs iTrustCapital (2026)</h1>
          <p className="text-sm text-slate-400 mt-2">
            By <a href="/author/james-mitchell" className="text-[#0EA5E9] hover:underline">James Mitchell, CFA</a> · Last updated: {LAST_UPDATED} · <a href="/methodology" className="text-[#0EA5E9] hover:underline">Methodology</a>
          </p>
          <AdvertiserDisclosure />
          <p className="text-lg text-[#64748B] max-w-2xl mt-3">
            Bitcoin IRA and iTrustCapital are both strong crypto IRA options. Bitcoin IRA leads on asset selection and reputation; iTrustCapital wins on fees ($0 annual). Both share the same $1,000 minimum. Here's how to choose.
          </p>
        </div>
      </section>

      <div className="container-site py-12">
        <div className="space-y-12">

          <div className="grid md:grid-cols-2 gap-6">
            <div className="card border-t-4 border-t-slate-400">
              <div className="flex items-center justify-between mb-3">
                <h2 className="text-lg font-bold text-[#0F172A]">Bitcoin IRA</h2>
                <span className={`text-3xl font-bold ${scoreColor(bi.score_overall)}`}>{bi.score_overall}/10</span>
              </div>
              <p className="text-sm text-[#64748B] mb-3">Notable for Bitcoin Focus &amp; Asset Selection</p>
              <ul className="space-y-1 text-sm text-[#64748B]">
                <li className="flex gap-2"><span className="text-sky-500">✓</span> Higher overall score (9.0 vs 8.8)</li>
                <li className="flex gap-2"><span className="text-sky-500">✓</span> More cryptocurrencies (75 vs 40)</li>
                <li className="flex gap-2"><span className="text-sky-500">✓</span> $700M total insurance coverage</li>
                <li className="flex gap-2"><span className="text-sky-500">✓</span> A+ BBB rating (vs A)</li>
                <li className="flex gap-2"><span className="text-slate-400">✗</span> Higher annual fee ($240 vs $0)</li>
                <li className="flex gap-2"><span className="text-slate-400">✗</span> Higher trading fee (2% vs 1%)</li>
              </ul>
              {bi.affiliate_url && (
                <a href={bi.affiliate_url} target="_blank" rel="noopener noreferrer sponsored"
                  className="btn-primary w-full text-center block mt-4 text-sm"
                  onClick={() => trackProviderSiteVisit('Bitcoin IRA', 'bitcoin-ira', bi.affiliate_url!)}>
                  Open Bitcoin IRA Account
                </a>
              )}
              <Link to="/crypto-ira/bitcoin-ira-review" className="btn-secondary w-full text-center block mt-2 text-sm"
                onClick={() => trackProviderReviewClick('Bitcoin Ira', 'bitcoin-ira', window.location.pathname)}>
                Read Full Review
              </Link>
            </div>
            <div className="card border-t-4 border-t-emerald-400">
              <div className="flex items-center justify-between mb-3">
                <h2 className="text-lg font-bold text-[#0F172A]">iTrustCapital</h2>
                <span className={`text-3xl font-bold ${scoreColor(it.score_overall)}`}>{it.score_overall}/10</span>
              </div>
              <p className="text-sm text-[#64748B] mb-3">Notable for Low Fees &amp; Low Minimum</p>
              <ul className="space-y-1 text-sm text-[#64748B]">
                <li className="flex gap-2"><span className="text-emerald-500">✓</span> $0 annual fee (vs $240)</li>
                <li className="flex gap-2"><span className="text-emerald-500">✓</span> Lower trading fee (1% vs 2%)</li>
                <li className="flex gap-2"><span className="text-emerald-500">✓</span> $1,000 minimum (same as Bitcoin IRA)</li>
                <li className="flex gap-2"><span className="text-emerald-500">✓</span> Gold &amp; silver IRA option</li>
                <li className="flex gap-2"><span className="text-slate-400">✗</span> Fewer cryptocurrencies (40 vs 75)</li>
              </ul>
              {it.affiliate_url && (
                <a href={it.affiliate_url} target="_blank" rel="noopener noreferrer sponsored"
                  className="btn-primary w-full text-center block mt-4 text-sm"
                  onClick={() => trackProviderSiteVisit('iTrustCapital', 'itrustcapital', it.affiliate_url!)}>
                  Open iTrustCapital Account
                </a>
              )}
              <Link to="/crypto-ira/itrustcapital-review" className="btn-secondary w-full text-center block mt-2 text-sm"
                onClick={() => trackProviderReviewClick('Itrustcapital', 'itrustcapital', window.location.pathname)}>
                Read Full Review
              </Link>
            </div>
          </div>

          <div>
            <h2 className="text-2xl font-bold text-[#0F172A] mb-6">Head-to-Head Comparison</h2>
            <div className="overflow-x-auto">
              <table className="comparison-table" aria-label="Bitcoin IRA vs iTrustCapital comparison table">
                <thead>
                  <tr>
                    <th scope="col">Feature</th>
                    <th scope="col">Bitcoin IRA</th>
                    <th scope="col">iTrustCapital</th>
                    <th scope="col">Winner</th>
                  </tr>
                </thead>
                <tbody>
                  {[
                    ['Overall Score', `${bi.score_overall}/10`, `${it.score_overall}/10`, '🏆 Bitcoin IRA'],
                    ['Annual Fee', bi.annual_fee ?? '—', it.annual_fee ?? '—', '🏆 iTrustCapital ($0 vs $240)'],
                    ['Trading Fee', bi.transaction_fee ?? '—', it.transaction_fee ?? '—', '🏆 iTrustCapital (1% vs 2%)'],
                    ['Minimum Investment', bi.min_investment ?? '—', it.min_investment ?? '—', '🏆 iTrustCapital ($1k vs $3k)'],
                    ['Cryptocurrencies', `${bi.asset_count ?? '—'}+`, `${it.asset_count ?? '—'}+`, '🏆 Bitcoin IRA (75 vs 40)'],
                    ['Custodian', bi.custody_provider ?? '—', it.custody_provider ?? '—', '🏆 Bitcoin IRA (BitGo)'],
                    ['Insurance', bi.insurance_coverage ?? '—', it.insurance_coverage ?? '—', '🏆 Bitcoin IRA ($700M)'],
                    ['BBB Rating', bi.bbb_rating ?? '—', it.bbb_rating ?? '—', '🏆 Bitcoin IRA (A+ vs A)'],
                    ['Founded', String(bi.founded_year ?? '—'), String(it.founded_year ?? '—'), '🏆 Bitcoin IRA (older)'],
                    ['Fee Score', `${bi.score_fees}/10`, `${it.score_fees}/10`, '🏆 iTrustCapital (9.8 vs 8.5)'],
                    ['Asset Score', `${bi.score_assets}/10`, `${it.score_assets}/10`, '🏆 Bitcoin IRA'],
                    ['Security Score', `${bi.score_security}/10`, `${it.score_security}/10`, '🏆 Bitcoin IRA'],
                    ['Reputation Score', `${bi.score_reputation}/10`, `${it.score_reputation}/10`, '🏆 Bitcoin IRA'],
                  ].map(([feature, biVal, itVal, winner]) => (
                    <tr key={feature}>
                      <td className="font-medium text-[#0F172A]" scope="row">{feature}</td>
                      <td className="text-[#64748B]">{biVal}</td>
                      <td className="text-[#64748B]">{itVal}</td>
                      <td className="font-medium text-[#334155] text-sm">{winner}</td>
                    </tr>
                  ))}
                </tbody>
              </table>
            </div>
          </div>

          <div>
            <h2 className="text-2xl font-bold text-[#0F172A] mb-6">Who Should Choose Each Provider?</h2>
            <div className="grid md:grid-cols-2 gap-6">
              <div className="card border-l-4 border-l-slate-400">
                <h3 className="font-bold text-[#0F172A] mb-3">Choose Bitcoin IRA if you:</h3>
                <ul className="space-y-2 text-sm text-[#64748B]">
                  <li className="flex gap-2"><span className="text-sky-500 flex-shrink-0">✓</span> Want access to 75+ cryptocurrencies</li>
                  <li className="flex gap-2"><span className="text-sky-500 flex-shrink-0">✓</span> Prioritise the highest security score (9.5)</li>
                  <li className="flex gap-2"><span className="text-sky-500 flex-shrink-0">✓</span> Value the longest track record (founded 2016)</li>
                  <li className="flex gap-2"><span className="text-sky-500 flex-shrink-0">✓</span> Want $700M total insurance coverage</li>
                  <li className="flex gap-2"><span className="text-sky-500 flex-shrink-0">✓</span> Have $1,000+ to invest</li>
                </ul>
              </div>
              <div className="card border-l-4 border-l-emerald-400">
                <h3 className="font-bold text-[#0F172A] mb-3">Choose iTrustCapital if you:</h3>
                <ul className="space-y-2 text-sm text-[#64748B]">
                  <li className="flex gap-2"><span className="text-emerald-500 flex-shrink-0">✓</span> Want to eliminate the annual fee entirely</li>
                  <li className="flex gap-2"><span className="text-emerald-500 flex-shrink-0">✓</span> Want the lowest possible annual fee ($0 vs $240)</li>
                  <li className="flex gap-2"><span className="text-emerald-500 flex-shrink-0">✓</span> Trade frequently (1% vs 2% fee matters)</li>
                  <li className="flex gap-2"><span className="text-emerald-500 flex-shrink-0">✓</span> Want gold and silver alongside crypto</li>
                  <li className="flex gap-2"><span className="text-emerald-500 flex-shrink-0">✓</span> Are a first-time crypto IRA investor</li>
                </ul>
              </div>
            </div>
          </div>

          <div className="card bg-blue-50 border-blue-200">
            <h2 className="text-xl font-bold text-[#0F172A] mb-4">The Key Tradeoff: Fees vs Track Record</h2>
            <div className="space-y-3 text-sm text-[#64748B]">
              <p>
                <strong className="text-[#0F172A]">Fee Advantage (iTrustCapital):</strong> iTrustCapital's $0 annual fee + 1% trading fee vs Bitcoin IRA's $240 annual fee + 2% trading fee is a significant cost difference. For a $50,000 portfolio with $20,000 in annual trades, iTrustCapital saves approximately $640/year.
              </p>
              <p>
                <strong className="text-[#0F172A]">Asset Selection (Bitcoin IRA):</strong> Bitcoin IRA supports 75 cryptocurrencies vs iTrustCapital's 40. If you want exposure to mid-cap or smaller-cap cryptocurrencies beyond the top 40, Bitcoin IRA has the edge.
              </p>
              <p>
                <strong className="text-[#0F172A]">Security (Bitcoin IRA):</strong> Bitcoin IRA uses Digital Trust / BitGo Trust Company with $700M total insurance. iTrustCapital uses Coinbase Custody with FDIC coverage on cash. Both are institutional-grade, but Bitcoin IRA's dedicated crypto insurance is more comprehensive.
              </p>
              <p>
                <strong className="text-[#0F172A]">Overall Verdict:</strong> Both providers share the same $1,000 minimum. For cost-conscious investors who prioritise eliminating the annual fee, iTrustCapital is the clear choice. For investors who prioritise asset breadth, security, and track record — and can absorb the higher fees — Bitcoin IRA is the better platform.
              </p>
            </div>
          </div>

          <div>
            <h2 className="text-xl font-bold text-[#0F172A] mb-4">Related Comparisons</h2>
            <div className="grid sm:grid-cols-2 gap-3">
              <Link to="/crypto-ira/blocktrust-ira-vs-bitcoin-ira" className="block p-4 rounded-lg border border-slate-200 hover:border-[#0EA5E9] hover:bg-blue-50 transition-colors">
                <p className="font-medium text-[#0F172A] text-sm">BlockTrust IRA vs Bitcoin IRA</p>
                <p className="text-xs text-slate-500 mt-1">Compare fees, assets, and scores</p>
              </Link>
              <Link to="/crypto-ira/blocktrust-ira-vs-itrustcapital" className="block p-4 rounded-lg border border-slate-200 hover:border-[#0EA5E9] hover:bg-blue-50 transition-colors">
                <p className="font-medium text-[#0F172A] text-sm">BlockTrust IRA vs iTrustCapital</p>
                <p className="text-xs text-slate-500 mt-1">Compare fees, assets, and scores</p>
              </Link>
              <Link to="/crypto-ira/bitcoin-ira-review" className="block p-4 rounded-lg border border-slate-200 hover:border-[#0EA5E9] hover:bg-blue-50 transition-colors"
                onClick={() => trackProviderReviewClick('Bitcoin Ira', 'bitcoin-ira', window.location.pathname)}>
                <p className="font-medium text-[#0F172A] text-sm">Bitcoin IRA Full Review</p>
                <p className="text-xs text-slate-500 mt-1">In-depth analysis, 9.0/10</p>
              </Link>
              <Link to="/crypto-ira/itrustcapital-review" className="block p-4 rounded-lg border border-slate-200 hover:border-[#0EA5E9] hover:bg-blue-50 transition-colors"
                onClick={() => trackProviderReviewClick('Itrustcapital', 'itrustcapital', window.location.pathname)}>
                <p className="font-medium text-[#0F172A] text-sm">iTrustCapital Full Review</p>
                <p className="text-xs text-slate-500 mt-1">In-depth analysis, 8.8/10</p>
              </Link>
            </div>
          </div>

        </div>
      </div>
      {/* ── Newsletter Signup ─────────────────────────────────────────── */}
      <div className="container-site py-10 max-w-3xl">
        
        {/* Related Links */}

        <div className="mt-10 mb-6">

          <RelatedLinks variant="comparison-crypto" title="Related Guides &amp; Reviews" />

        </div>
<NewsletterSignup />
      </div>
    </>
  )
}
