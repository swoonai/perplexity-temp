import StateGuideTemplate from '../components/StateGuideTemplate'

export default function BestCryptoIRAGAPage() {
  return (
    <StateGuideTemplate
      stateName="Georgia"
      stateAbbr="GA"
      slug="georgia"
    />
  )
}
