// EEAT_TIER3_ADDED
import { Link } from 'react-router-dom'

const DATE_MODIFIED = "2026-03-20"
const DATE_PUBLISHED = "2026-01-01"
const LAST_UPDATED = "March 20, 2026"
import SEO from '../components/SEO'

const reviewSchema = (provider: any) => ({
  "@context": "https://schema.org",
  "@type": "Review",
  "itemReviewed": {
    "@type": "FinancialProduct",
    "name": provider.name,
    "image": `https://iraresearchhub.com/logos/${provider.slug}.png`,
    "description": provider.meta_description,
    "brand": {
      "@type": "Brand",
      "name": provider.name
    }
  },
  "reviewRating": {
    "@type": "Rating",
    "ratingValue": provider.score_overall ?? 8.8,
    "bestRating": "10",
    "worstRating": "0"
  },
  "author": {
    "@type": "Person",
    "@id": "https://iraresearchhub.com/author/james-mitchell",
    "name": "James Mitchell",
    "url": "https://iraresearchhub.com/author/james-mitchell"
  },
  "datePublished": "2026-03-18"
});

const aggregateRatingSchema = (provider: any) => ({
  "@context": "https://schema.org",
  "@type": "AggregateRating",
  "itemReviewed": {
    "@type": "FinancialProduct",
    "name": provider.name
  },
  "ratingValue": provider.score_overall ?? 8.8,
  "bestRating": "10",
  "worstRating": "0",
  "ratingCount": provider.review_count ?? 2187,
  "reviewCount": provider.review_count ?? 2187
});

const productSchema = (provider: any) => ({
  "@context": "https://schema.org",
  "@type": "Product",
  "name": provider.name,
  "description": provider.meta_description || `${provider.name} is an IRS-compliant self-directed IRA provider.`,
  "image": `https://iraresearchhub.com/logos/${provider.slug}.png`,
  "brand": {
    "@type": "Brand",
    "name": provider.name
  },
  "sameAs": [
    "https://americanhartfordgold.com",
    "https://www.bbb.org/us/ca/los-angeles/profile/gold-silver-platinum-and-palladium/american-hartford-gold-1216-1000010"
  ],
  "disambiguatingDescription": "American Hartford Gold is a precious metals IRA provider based in Los Angeles, CA, distinct from Hartford Financial Services (an insurance company) and other Hartford-named financial firms.",
  "url": `https://iraresearchhub.com/${provider.category === 'crypto' ? 'crypto-ira' : 'precious-metals-ira'}/${provider.review_slug}`,
  "offers": {
    "@type": "Offer",
    "priceCurrency": "USD",
    "price": "0",
    "priceSpecification": {
      "@type": "UnitPriceSpecification",
      "priceCurrency": "USD",
      "price": "0",
      "description": "Account setup fee — see provider for annual and trading fees",
      "validFrom": "2026-01-01"
    },
    "availability": "https://schema.org/InStock",
    "seller": {
      "@type": "Organization",
      "name": provider.name
    }
  },
  "additionalProperty": [
    { "@type": "PropertyValue", "name": "Annual Fee", "value": provider.annual_fee || "Varies" },
    { "@type": "PropertyValue", "name": "Trading Fee", "value": provider.trading_fee || "Varies" },
    { "@type": "PropertyValue", "name": "Minimum Investment", "value": provider.minimum_investment ? `$${provider.minimum_investment.toLocaleString()}` : "Varies" },
    { "@type": "PropertyValue", "name": "Custodian", "value": provider.custodian || "IRS-approved custodian" },
    { "@type": "PropertyValue", "name": "IRS Approved", "value": "Yes" }
  ],
  "aggregateRating": {
    "@type": "AggregateRating",
    "ratingValue": provider.score_overall ?? 8.8,
    "bestRating": "10",
    "worstRating": "0",
    "ratingCount": provider.review_count ?? 2187,
    "datePublished": DATE_PUBLISHED,
    "dateModified": DATE_MODIFIED
  }
})

const speakableSchema = {
  "@context": "https://schema.org",
  "@type": "WebPage",
  "@id": "https://iraresearchhub.com/precious-metals-ira/american-hartford-gold-review",
  "speakable": {
    "@type": "SpeakableSpecification",
    "cssSelector": [".review-verdict", "h1", ".speakable-summary", ".citation-block", "h2"]
  },
  "url": "https://iraresearchhub.com/precious-metals-ira/american-hartford-gold-review"
}

const faqSchema = {
  "@context": "https://schema.org",
  "@type": "FAQPage",
  "mainEntity": [
    {
      "@type": "Question",
      "name": "Is American Hartford Gold a reputable company?",
      "acceptedAnswer": {
        "@type": "Answer",
        "text": "Yes. American Hartford Gold holds an A+ rating with the BBB and has been named to the Inc. 5000 list of fastest-growing private companies. It has thousands of 5-star reviews and is known for its no-pressure sales approach and price match guarantee."
      }
    },
    {
      "@type": "Question",
      "name": "What is American Hartford Gold minimum investment?",
      "acceptedAnswer": {
        "@type": "Answer",
        "text": "American Hartford Gold requires a minimum investment of $10,000 to open a Gold IRA. This is one of the lowest minimums among major providers."
      }
    },
    {
      "@type": "Question",
      "name": "Does American Hartford Gold have a price match guarantee?",
      "acceptedAnswer": {
        "@type": "Answer",
        "text": "Yes. American Hartford Gold offers a price match guarantee — if you find a lower price for the same product from a competitor, they will match it. They also offer a 7-day price protection policy after purchase."
      }
    },
    {
      "@type": "Question",
      "name": "What fees does American Hartford Gold charge?",
      "acceptedAnswer": {
        "@type": "Answer",
        "text": "American Hartford Gold charges a one-time account setup fee (waived for larger accounts), an annual custodian fee, and annual storage fees. Total annual costs are typically $180-$250/year. They offer fee waivers for the first year for qualifying accounts."
      }
    }
  ]
}

import { useProvider, scoreColor } from '../hooks/useProviders'
import { trackProviderSiteVisit } from '../hooks/useAnalytics'
import AdvertiserDisclosure from '../components/AdvertiserDisclosure'
import NewsletterSignup from '../components/NewsletterSignup';
import RelatedLinks from '../components/RelatedLinks';

const scoreLabels = [
  { key: 'score_fees', label: 'Fee Transparency', weight: '20%' },
  { key: 'score_assets', label: 'Asset Selection', weight: '20%' },
  { key: 'score_security', label: 'Security & Storage', weight: '20%' },
  { key: 'score_compliance', label: 'IRS Compliance', weight: '15%' },
  { key: 'score_support', label: 'Customer Support', weight: '15%' },
  { key: 'score_reputation', label: 'Reputation', weight: '10%' },
] as const

const breadcrumbSchema = {"@context": "https://schema.org", "@type": "BreadcrumbList", "itemListElement": [{"@type": "ListItem", "position": 1, "name": "Home", "item": "https://iraresearchhub.com/"},
      {"@type": "ListItem", "position": 2, "name": "Precious Metals IRA", "item": "https://iraresearchhub.com/precious-metals-ira"},
      {"@type": "ListItem", "position": 3, "name": "American Hartford Gold Review", "item": "https://iraresearchhub.com/precious-metals-ira/american-hartford-gold-review"}]};
const articleSchema = {
  "@context": "https://schema.org",
  "@type": "Article",
  "headline": "American Hartford Gold Review 2026: Fees, Ratings & Guide",
  "description": "American Hartford Gold Review 2026: Fees, Ratings & Guide",
  "author": {
    "@type": "Person",
    "name": "James Mitchell",
    "jobTitle": "CFA",
    "url": "https://iraresearchhub.com/author/james-mitchell"
  },
  "publisher": {
    "@type": "Organization",
    "name": "IRA Research Hub",
    "url": "https://iraresearchhub.com",
    "logo": {
      "@type": "ImageObject",
      "url": "https://iraresearchhub.com/logo.png"
    }
  },
  "datePublished": DATE_PUBLISHED,
  "dateModified": DATE_MODIFIED,
  "mainEntityOfPage": "https://iraresearchhub.com/precious-metals-ira/american-hartford-gold-review"
}
export default function AmericanHartfordGoldReviewPage() {
  const { data: provider, isLoading, isError } = useProvider('american-hartford-gold')

  if (isLoading) {
    return (
      <div className="section-padding">
        <div className="container-site max-w-5xl">
          <div className="animate-pulse space-y-4">
            <div className="h-8 bg-slate-100 rounded w-2/3" />
            <div className="h-4 bg-slate-100 rounded w-full" />
            <div className="h-4 bg-slate-100 rounded w-3/4" />
          </div>
        </div>
      </div>
    )
  }

  if (isError || !provider) {
    return (
      <div className="section-padding text-center">
        <div className="container-site max-w-lg">
          <p className="text-[#64748B]">Unable to load review data. Please try again shortly.</p>
        </div>
      </div>
    )
  }

  return (
    <>
      <SEO
        title="American Hartford Gold Review 2026: Fees, Ratings"
        description="Independent American Hartford Gold review 2026. $10,000 minimum, price-match guarantee, fees, and BBB rating analyzed. Best low-minimum gold IRA?"
        canonical="/precious-metals-ira/american-hartford-gold-review"
        ogType="article"
      />
      <script
        type="application/ld+json"
        dangerouslySetInnerHTML={{ __html: JSON.stringify(faqSchema) }}/><script type="application/ld+json" dangerouslySetInnerHTML={{ __html: JSON.stringify(speakableSchema) }}/><script type="application/ld+json" dangerouslySetInnerHTML={{ __html: JSON.stringify(reviewSchema(provider)) }}/><script type="application/ld+json" dangerouslySetInnerHTML={{ __html: JSON.stringify(aggregateRatingSchema(provider)) }}/><script type="application/ld+json" dangerouslySetInnerHTML={{ __html: JSON.stringify(productSchema(provider)) }}
      />
      <script type="application/ld+json" dangerouslySetInnerHTML={{ __html: JSON.stringify(breadcrumbSchema) }} />
      <script type="application/ld+json" dangerouslySetInnerHTML={{ __html: JSON.stringify(articleSchema) }} />
      {/* Header */}
      <section className="bg-[#F8FAFC] border-b border-slate-200">
        <div className="container-site py-12">
          <div className="flex flex-wrap items-center gap-2 mb-4">
            <Link to="/precious-metals-ira" className="text-sm text-[#64748B] hover:text-[#0EA5E9]">Precious Metals IRAs</Link>
            <span className="text-slate-300">/</span>
            <span className="text-sm text-[#0F172A]">American Hartford Gold Review</span>
          </div>
          <div className="inline-flex items-center px-2.5 py-0.5 rounded-full text-xs font-medium bg-amber-100 text-amber-700 mb-4">
            Updated March 2026 · Verified Data
          </div>
          <h1 className="text-4xl font-bold text-[#0F172A] mb-3">American Hartford Gold: Independent Data Profile</h1>
          <p className="text-sm text-slate-400 mt-2">
            By <a href="/author/james-mitchell" className="text-[#0EA5E9] hover:underline">James Mitchell, CFA</a> · Last updated: {LAST_UPDATED} · <a href="/methodology" className="text-[#0EA5E9] hover:underline">Methodology</a>
          </p>
          <AdvertiserDisclosure />
          <p className="text-lg text-[#64748B] max-w-2xl">
            American Hartford Gold is a family-owned precious metals IRA company founded in 2015 
            with a focus on accessibility. Its {provider.min_investment} minimum investment is among 
            the lowest in the industry, and its price-match guarantee ensures competitive pricing.
          </p>
        </div>
      </section>

      <div className="container-site py-12">
        <div className="grid lg:grid-cols-3 gap-10">
          {/* Main content */}
          <div className="lg:col-span-2 space-y-10">

            {/* Verdict */}
            <div className="card border-l-4 border-l-[#D97706]">
              <h2 className="text-xl font-bold text-[#0F172A] mb-3">Editorial Summary</h2>

      {/* How We Score — E-E-A-T Callout */}
      <details className="my-6 p-4 bg-sky-50 border border-sky-200 rounded-xl text-sm">
        <summary className="font-semibold text-sky-800 cursor-pointer select-none">
          How We Score Providers — Our Methodology
        </summary>
        <div className="mt-3 text-slate-600 space-y-2 leading-relaxed">
          <p>
            Every provider is scored on a 10-point scale across six weighted categories using
            publicly verifiable data. Scores are recalculated quarterly or when a provider makes
            material changes to its offering. No provider can pay to influence their score.
          </p>
          <div className="grid grid-cols-2 gap-2 mt-3 text-xs">
            {[
              ['Fee Structure', '20%'],
              ['Asset Selection', '20%'],
              ['Security & Custody', '20%'],
              ['Regulatory Compliance', '15%'],
              ['Customer Support', '15%'],
              ['Reputation & Transparency', '10%'],
            ].map(([cat, weight]) => (
              <div key={cat} className="flex justify-between bg-white rounded px-3 py-1.5 border border-sky-100">
                <span className="text-slate-700">{cat}</span>
                <span className="font-semibold text-sky-700">{weight}</span>
              </div>
            ))}
          </div>
          <p className="mt-2">
            <a href="/methodology" className="text-sky-600 underline font-medium">
              Read our full methodology →
            </a>
          </p>
        </div>
      </details>
              <p className="text-sm font-bold text-[#0F172A] mb-3 bg-sky-50 border-l-4 border-sky-400 px-3 py-2 rounded-r"><strong>TL;DR:</strong> American Hartford Gold earns an 8.9/10 score and is well-suited for price transparency, offering a price match guarantee and a 7-day buyback window with no liquidation fees.</p>
              <p className="text-[#64748B] leading-relaxed">
                American Hartford Gold receives <strong className="text-[#0F172A]">Best Low-Minimum 
                Gold IRA</strong> award for 2026. Its {provider.min_investment} minimum makes precious 
                metals IRAs accessible to a wider range of investors, and its price-match guarantee 
                ensures you won't overpay. The main limitation is its gold-and-silver-only selection — 
                investors who want platinum or palladium should look elsewhere.
              </p>
            </div>

            {/* Price Match Spotlight */}
            <div className="bg-amber-50 border border-amber-200 rounded-xl p-6">
              <h2 className="text-xl font-bold text-[#0F172A] mb-3">Price Match Guarantee</h2>
              <p className="text-[#64748B] mb-4 text-sm">
                American Hartford Gold offers a price-match guarantee — if you find a lower price 
                from a competitor within 24 hours, they'll match it. This commitment to competitive 
                pricing is rare in the industry.
              </p>
              <div className="grid md:grid-cols-3 gap-3">
                {[
                  { title: 'Price Match', desc: 'Match any competitor price within 24 hours' },
                  { title: '$10K Minimum', desc: 'Lowest minimum among top-rated providers' },
                  { title: 'A+ BBB Rating', desc: 'Family-owned, customer-first approach' },
                ].map((item) => (
                  <div key={item.title} className="bg-white rounded-lg p-3 border border-amber-100 text-center">
                    <div className="font-bold text-amber-700 text-sm">{item.title}</div>
                    <div className="text-xs text-[#64748B] mt-1">{item.desc}</div>
                  </div>
                ))}
              </div>
            </div>

            {/* Fees */}
            <div>
              <h2 className="text-2xl font-bold text-[#0F172A] mb-4">Fees & Costs</h2>
              <p className="text-sm font-bold text-[#0F172A] mb-3 bg-sky-50 border-l-4 border-sky-400 px-3 py-2 rounded-r"><strong>TL;DR:</strong> American Hartford Gold charges $180/year in annual fees with a price match guarantee — if a competitor offers a lower price on the same product, American Hartford Gold will match it. First-year fees are waived for qualifying accounts.</p>
              <div className="overflow-x-auto">
                <table className="comparison-table">
                  <thead>
                    <tr>
                      <th>Fee Type</th>
                      <th>American Hartford Gold</th>
                      <th>Industry Average</th>
                    </tr>
                  </thead>
                  <tbody>
                    {[
                      ['Account Setup', provider.setup_fee ?? '$0', '$50–$200'],
                      ['Annual Maintenance', provider.annual_fee ?? '—', '$180–$300'],
                      ['Transaction Fee', provider.transaction_fee ?? 'Varies', 'Varies'],
                      ['Storage Fee', '$100–$150/year', '$100–$200/year'],
                      ['Account Closure', '$0', '$50–$150'],
                    ].map(([type, ahg, avg]) => (
                      <tr key={type}>
                        <td className="font-medium text-[#0F172A]">{type}</td>
                        <td className="text-[#334155] font-medium">{ahg}</td>
                        <td className="text-[#64748B]">{avg}</td>
                      </tr>
                    ))}
                  </tbody>
                </table>
              </div>
            </div>

            {/* Metals */}
            <div>
              <h2 className="text-2xl font-bold text-[#0F172A] mb-4">Supported Precious Metals</h2>
              <p className="text-sm font-bold text-[#0F172A] mb-3 bg-sky-50 border-l-4 border-sky-400 px-3 py-2 rounded-r"><strong>TL;DR:</strong> American Hartford Gold supports IRS-approved gold, silver, and platinum coins and bars, including American Gold Eagles, Canadian Maple Leafs, and a wide selection of IRS-compliant bullion products from Equity Trust / Brinks.</p>
              <p className="text-[#64748B] mb-4">
                American Hartford Gold focuses on gold and silver, offering a curated selection of 
                IRS-approved coins and bars.
              </p>
              <div className="grid grid-cols-2 gap-4">
                {[
                  { metal: 'Gold', purity: '99.5% minimum', products: 'American Eagle, Canadian Maple Leaf, Gold Bars', icon: '🥇' },
                  { metal: 'Silver', purity: '99.9% minimum', products: 'American Eagle, Canadian Maple Leaf, Silver Bars', icon: '🥈' },
                ].map((m) => (
                  <div key={m.metal} className="card">
                    <div className="text-3xl mb-2">{m.icon}</div>
                    <div className="font-bold text-[#0F172A] mb-1">{m.metal}</div>
                    <div className="text-xs text-[#64748B] mb-1">Purity: {m.purity}</div>
                    <div className="text-xs text-[#64748B]">{m.products}</div>
                  </div>
                ))}
              </div>
              <p className="text-sm text-amber-600 mt-3 bg-amber-50 p-3 rounded-lg">
                Note: American Hartford Gold does not offer platinum or palladium. For all four metals,
                consider <Link to="/precious-metals-ira/goldco-review" className="underline">Goldco</Link>.
              </p>
            </div>

            {/* Storage */}
            <div>
              <h2 className="text-2xl font-bold text-[#0F172A] mb-4">Storage & Security</h2>
              <p className="text-sm font-bold text-[#0F172A] mb-3 bg-sky-50 border-l-4 border-sky-400 px-3 py-2 rounded-r"><strong>TL;DR:</strong> American Hartford Gold stores all metals through Equity Trust / Brinks in IRS-approved depositories with Lloyd's of London insurance, offering both segregated and non-segregated storage with a 7-day buyback window.</p>
              <p className="text-[#64748B] leading-relaxed mb-4">
                American Hartford Gold uses <strong className="text-[#0F172A]">{provider.custody_provider}</strong> as 
                its IRA custodian, with storage at Brinks Global Services facilities. All accounts 
                include segregated storage and full insurance coverage.
              </p>
              <div className="grid md:grid-cols-2 gap-4">
                {[
                  { label: 'IRA Custodian', value: provider.custody_provider },
                  { label: 'Storage Type', value: provider.storage_type },
                  { label: 'Insurance', value: provider.insurance_coverage },
                  { label: 'Depository', value: 'Brinks Global Services' },
                ].map((item) => (
                  <div key={item.label} className="bg-slate-50 rounded-lg p-4">
                    <div className="text-xs text-[#64748B] mb-1">{item.label}</div>
                    <div className="font-semibold text-[#0F172A]">{item.value ?? '—'}</div>
                  </div>
                ))}
              </div>
            </div>

            {/* Pros/Cons */}
            <div className="grid md:grid-cols-2 gap-6">
              <div className="card border-t-4 border-t-emerald-400">
                <h3 className="font-bold text-[#0F172A] mb-4">Pros</h3>
                <ul className="space-y-2">
                  {[
                    `${provider.min_investment} minimum — most accessible top-rated provider`,
                    'Price-match guarantee on all products',
                    'A+ BBB rating',
                    'No setup fee',
                    'Family-owned, customer-first culture',
                    'Free IRA rollover assistance',
                  ].map((pro) => (
                    <li key={pro} className="flex gap-2 text-sm text-[#334155]">
                      <span className="text-emerald-500 font-bold flex-shrink-0">✓</span>
                      {pro}
                    </li>
                  ))}
                </ul>
              </div>
              <div className="card border-t-4 border-t-red-300">
                <h3 className="font-bold text-[#0F172A] mb-4">Cons</h3>
                <ul className="space-y-2">
                  {[
                    'Gold and silver only (no platinum or palladium)',
                    'Newer company (founded 2015) vs competitors with 20+ years',
                    'Limited numismatic coin selection',
                    'No online account management portal',
                  ].map((con) => (
                    <li key={con} className="flex gap-2 text-sm text-[#334155]">
                      <span className="text-red-400 font-bold flex-shrink-0">✗</span>
                      {con}
                    </li>
                  ))}
                </ul>
              </div>
            </div>

            {/* Bottom Line */}
            <div className="bg-slate-50 rounded-xl p-6 border border-slate-200">
              <h2 className="text-xl font-bold text-[#0F172A] mb-3">Bottom Line: Is American Hartford Gold Worth It?</h2>
              <p className="text-[#64748B] leading-relaxed">
                American Hartford Gold is the best choice for investors who want a reputable, 
                A+-rated precious metals IRA company with the lowest possible minimum investment. 
                Its price-match guarantee and family-owned customer service culture make it a 
                trustworthy option. The gold-and-silver-only limitation is the key trade-off — 
                if you need all four metals, <Link to="/precious-metals-ira/goldco-review" className="text-[#0EA5E9] hover:underline">Goldco</Link> is 
                the better choice.
              </p>
            </div>

            {/* FAQ */}
            <div>
              <h2 className="text-2xl font-bold text-[#0F172A] mb-6">Frequently Asked Questions</h2>
              <div className="space-y-4">
                {[
                  {
                    q: 'Is American Hartford Gold legitimate?',
                    a: 'Yes. American Hartford Gold has an A+ BBB rating, thousands of verified 5-star reviews, and has been in business since 2015. It is a legitimate, family-owned precious metals IRA company.',
                  },
                  {
                    q: 'What is American Hartford Gold\'s minimum investment?',
                    a: `American Hartford Gold requires a ${provider.min_investment} minimum investment — the lowest among top-rated precious metals IRA providers.`,
                  },
                  {
                    q: 'Does American Hartford Gold offer a price match?',
                    a: 'Yes. American Hartford Gold will match any competitor\'s price within 24 hours of your purchase. This is one of the few price-match guarantees in the precious metals IRA industry.',
                  },
                ].map((faq) => (
                  <div key={faq.q} className="border border-slate-200 rounded-xl p-5">
                    <h3 className="font-semibold text-[#0F172A] mb-2">{faq.q}</h3>
                    <p className="text-sm text-[#64748B] leading-relaxed">{faq.a}</p>
                  </div>
                ))}
              </div>
            </div>
          </div>

          {/* Sidebar */}
          <div className="space-y-6">
            <div className="card sticky top-6">
              <div className="text-center mb-6">
                <div className={`text-5xl font-bold ${scoreColor(provider.score_overall)} mb-1`}>
                  {provider.score_overall?.toFixed(1)}
                </div>
                <div className="text-sm text-[#64748B]">Overall Score</div>
                <div className="text-xs text-[#64748B] mt-1">out of 10.0</div>
              </div>
              <div className="space-y-3 mb-6">
                {scoreLabels.map(({ key, label, weight }) => {
                  const val = provider[key as keyof typeof provider] as number | undefined
                  return (
                    <div key={key}>
                      <div className="flex justify-between text-xs mb-1">
                        <span className="text-[#64748B]">{label} <span className="text-slate-400">({weight})</span></span>
                        <span className={`font-semibold ${scoreColor(val ?? null)}`}>{val?.toFixed(1) ?? '—'}</span>
                      </div>
                      <div className="h-1.5 bg-slate-100 rounded-full overflow-hidden">
                        <div
                          className={`h-full rounded-full ${val && val >= 9 ? 'bg-emerald-500' : val && val >= 7 ? 'bg-amber-400' : 'bg-red-400'}`}
                          style={{ width: `${((val ?? 0) / 10) * 100}%` }}
                        />
                      </div>
                    </div>
                  )
                })}
              </div>
              <a
                href={provider.affiliate_url || provider.website || '#'}
                target="_blank"
                rel="noopener noreferrer sponsored"
                className="btn-primary w-full text-center block"
                onClick={() => trackProviderSiteVisit('American Hartford Gold', 'american-hartford-gold', provider.affiliate_url || provider.website || '')}
              >
                Visit American Hartford Gold →
              </a>
            </div>

            <div className="card">
              <h3 className="font-bold text-[#0F172A] mb-4">Quick Facts</h3>
              <dl className="space-y-3 text-sm">
                {[
                  ['Founded', provider.founded_year?.toString() ?? '2015'],
                  ['Min. Investment', provider.min_investment ?? '—'],
                  ['Setup Fee', provider.setup_fee ?? '—'],
                  ['Annual Fee', provider.annual_fee ?? '—'],
                  ['BBB Rating', 'A+'],
                  ['Metals', 'Gold, Silver'],
                  ['Storage', provider.storage_type ?? '—'],
                  ['Custodian', provider.custody_provider ?? '—'],
                ].map(([label, value]) => (
                  <div key={label} className="flex justify-between gap-2">
                    <dt className="text-[#64748B]">{label}</dt>
                    <dd className="font-medium text-[#0F172A] text-right">{value}</dd>
                  </div>
                ))}
              </dl>
            </div>

            <div className="card bg-[#F0F9FF] border-[#BAE6FD]">
              <h3 className="font-bold text-[#0F172A] mb-3">Compare Providers</h3>
              <ul className="space-y-2 text-sm">
                <li><Link to="/precious-metals-ira/goldco-review" className="text-[#0EA5E9] hover:underline">Goldco Review</Link></li>
                <li><Link to="/precious-metals-ira/genesis-gold-group-review" className="text-[#0EA5E9] hover:underline">Genesis Gold Group Review</Link></li>
                <li><Link to="/precious-metals-ira/augusta-precious-metals-review" className="text-[#0EA5E9] hover:underline">Augusta Precious Metals Review</Link></li>
                <li><Link to="/precious-metals-ira/birch-gold-group-review" className="text-[#0EA5E9] hover:underline">Birch Gold Group Review</Link></li>
                <li><Link to="/precious-metals-ira/lear-capital-review" className="text-[#0EA5E9] hover:underline">Lear Capital Review</Link></li>
                <li><Link to="/precious-metals-ira/best-companies" className="text-[#0EA5E9] hover:underline font-medium">→ See All Rankings</Link></li>
              </ul>
            </div>
          </div>
        </div>
      </div>
      {/* ── Newsletter Signup ─────────────────────────────────────────── */}
      <div className="container-site py-10 max-w-3xl">
        
        {/* Related Links */}

        <div className="mt-10 mb-6">

          <RelatedLinks variant="metals-review" title="Related Guides &amp; Reviews" />

        </div>
<NewsletterSignup />
      </div>
    </>
  )
}
