import StateGuideTemplate from '../components/StateGuideTemplate'

export default function BestCryptoIRAWIPage() {
  return (
    <StateGuideTemplate
      stateName="Wisconsin"
      stateAbbr="WI"
      slug="wisconsin"
    />
  )
}
