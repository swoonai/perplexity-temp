import StateGuideTemplate from '../components/StateGuideTemplate'

export default function BestCryptoIRAMOPage() {
  return (
    <StateGuideTemplate
      stateName="Missouri"
      stateAbbr="MO"
      slug="missouri"
    />
  )
}
