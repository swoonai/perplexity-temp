import React from 'react'
import { Link } from 'react-router-dom'
import SEO from '../components/SEO'
import AdvertiserDisclosure from '../components/AdvertiserDisclosure'
import { trackResearchStart } from '../hooks/useAnalytics'
import NewsletterSignup from '../components/NewsletterSignup';
import RelatedLinks from '../components/RelatedLinks';

const LAST_UPDATED = 'March 31, 2026'

export default function PreciousMetalsInIRAGuidePage() {

  // Funnel tracking: fire research_start when arriving from a paid ad
  React.useEffect(() => {
    const params = new URLSearchParams(window.location.search)
    const utmSource = params.get('utm_source') ?? undefined
    if (utmSource) {
      trackResearchStart(window.location.pathname, document.title, utmSource)
    }
  }, [])

  return (
    <>
      <script type="application/ld+json" dangerouslySetInnerHTML={{ __html: JSON.stringify({"@context":"https://schema.org","@type":"BreadcrumbList","itemListElement":[{"@type":"ListItem","position":1,"name":"Guides","item":"https://iraresearchhub.com/guides"},{"@type":"ListItem","position":2,"name":"Precious Metals in an IRA","item":"https://iraresearchhub.com/guides/precious-metals-in-ira"}]}) }} />
      <SEO
        title="Precious Metals in IRAs: Gold, Silver & Diversification Strategies (2026 Guide)"
        description="Independent educational guide to holding gold, silver, platinum, and palladium in an IRA. Covers IRS purity rules, approved depositories, storage requirements, historical performance, and risks."
        canonical="/guides/precious-metals-in-ira"
        ogType="article"
      />
      <script type="application/ld+json" dangerouslySetInnerHTML={{ __html: JSON.stringify({"@context":"https://schema.org","@type":"Article","headline":"Precious Metals in IRAs: Gold, Silver & Diversification Strategies (2026 Guide)","author":{"@type":"Person","name":"James Mitchell","jobTitle":"CFA"},"publisher":{"@type":"Organization","name":"IRA Research Hub"},"dateModified":"2026-03-31"}) }} />

      {/* Hero */}
      <div className="bg-[#F8FAFC] border-b border-slate-200 py-10">
        <div className="container-site max-w-4xl">
          <div className="flex flex-wrap gap-2 mb-4">
            <span className="inline-flex items-center px-2.5 py-0.5 rounded-full text-xs font-medium bg-yellow-100 text-yellow-700">Educational Guide</span>
            <span className="inline-flex items-center px-2.5 py-0.5 rounded-full text-xs font-medium bg-slate-100 text-slate-600">2026 Update</span>
          </div>
          <h1 className="text-4xl font-bold text-[#0F172A] mb-4 leading-tight">
            Precious Metals in IRAs: Gold, Silver & Diversification Strategies (2026 Guide)
          </h1>
          <p className="text-lg text-[#64748B] mb-4 max-w-3xl">
            The IRS permits gold, silver, platinum, and palladium in self-directed IRAs — but only under specific purity, storage, and custodian requirements. This guide covers what is permitted, how it works, the historical performance data, and the risks investors must understand.
          </p>
          <p className="text-sm text-slate-500">
            By <Link to="/author/james-mitchell" className="text-sky-600 hover:underline font-medium">James Mitchell, CFA</Link>
            {' · '}Last Updated: {LAST_UPDATED}
            {' · '}
            <Link to="/methodology" className="text-sky-600 hover:underline">Editorial Methodology</Link>
          </p>
          <AdvertiserDisclosure />
        </div>
      </div>

      <div className="container-site max-w-4xl py-8">
        {/* TOC */}
        <div className="bg-slate-50 border border-slate-200 rounded-xl p-5 mb-10">
          <p className="text-xs font-semibold text-slate-400 uppercase tracking-wider mb-3">In This Guide</p>
          <ol className="space-y-1.5 text-sm text-sky-700">
            {[
              ['IRS-Approved Precious Metals', '#irs-approved'],
              ['IRS Purity Requirements', '#purity'],
              ['Storage Requirements: Approved Depositories', '#storage'],
              ['How a Precious Metals IRA Works', '#how-it-works'],
              ['Historical Performance vs. Traditional Assets', '#performance'],
              ['Diversification: What the Research Shows', '#diversification'],
              ['Risks You Must Understand', '#risks'],
              ['Fee Structures in Precious Metals IRAs', '#fees'],
              ['How to Research Providers Independently', '#research'],
              ['Primary Sources & References', '#sources'],
            ].map(([label, href]) => (
              <li key={href}><a href={href} className="hover:underline">{label}</a></li>
            ))}
          </ol>
        </div>

        <section id="irs-approved" className="mb-12">
          <h2 className="text-2xl font-bold text-[#0F172A] mb-4">IRS-Approved Precious Metals</h2>
          <p className="text-slate-600 leading-relaxed mb-4">
            Under IRC §408(m), an IRA may hold certain precious metals if they meet specific fineness (purity) requirements. The IRS explicitly permits four metals:
          </p>
          <div className="grid md:grid-cols-2 gap-4 mb-4">
            {[
              { metal: 'Gold', purity: '≥99.5% (0.995 fineness)', examples: 'American Gold Eagle, Canadian Gold Maple Leaf, Austrian Philharmonic, PAMP Suisse bars' },
              { metal: 'Silver', purity: '≥99.9% (0.999 fineness)', examples: 'American Silver Eagle, Canadian Silver Maple Leaf, Austrian Silver Philharmonic' },
              { metal: 'Platinum', purity: '≥99.95% (0.9995 fineness)', examples: 'American Platinum Eagle, Canadian Platinum Maple Leaf' },
              { metal: 'Palladium', purity: '≥99.95% (0.9995 fineness)', examples: 'Canadian Palladium Maple Leaf, Palladium bars from approved refiners' },
            ].map((item) => (
              <div key={item.metal} className="p-4 bg-white border border-slate-200 rounded-xl">
                <p className="font-semibold text-[#0F172A] mb-1">{item.metal}</p>
                <p className="text-xs text-slate-500 mb-1">Minimum purity: <span className="font-medium text-slate-700">{item.purity}</span></p>
                <p className="text-xs text-slate-500">Examples: {item.examples}</p>
              </div>
            ))}
          </div>
          <div className="bg-red-50 border border-red-200 rounded-lg p-4 text-sm text-red-900">
            <p className="font-semibold mb-1">Collectible Coins Are Prohibited (IRC §408(m)(3)):</p>
            <p>Most collectible coins — including many gold and silver coins with numismatic value — are prohibited in IRAs. The American Gold Eagle is a notable exception explicitly permitted by Congress. Holding prohibited collectibles triggers immediate distribution and potential penalties. Always verify coin eligibility with a tax advisor before purchasing.</p>
          </div>
        </section>

        <section id="purity" className="mb-12">
          <h2 className="text-2xl font-bold text-[#0F172A] mb-4">IRS Purity Requirements</h2>
          <div className="overflow-x-auto mb-4">
            <table className="w-full text-sm border-collapse">
              <thead>
                <tr className="bg-slate-100">
                  <th className="text-left p-3 font-semibold text-slate-700 border border-slate-200">Metal</th>
                  <th className="text-left p-3 font-semibold text-slate-700 border border-slate-200">Minimum Fineness</th>
                  <th className="text-left p-3 font-semibold text-slate-700 border border-slate-200">Karat Equivalent</th>
                  <th className="text-left p-3 font-semibold text-slate-700 border border-slate-200">Statutory Reference</th>
                </tr>
              </thead>
              <tbody>
                {[
                  ['Gold', '0.995 (99.5%)', '23.88 karat', 'IRC §408(m)(3)(B)'],
                  ['Silver', '0.999 (99.9%)', 'Fine silver', 'IRC §408(m)(3)(B)'],
                  ['Platinum', '0.9995 (99.95%)', 'Fine platinum', 'IRC §408(m)(3)(B)'],
                  ['Palladium', '0.9995 (99.95%)', 'Fine palladium', 'IRC §408(m)(3)(B)'],
                ].map(([metal, fineness, karat, ref]) => (
                  <tr key={metal} className="border-b border-slate-100">
                    <td className="p-3 font-medium text-slate-700 border border-slate-200">{metal}</td>
                    <td className="p-3 text-slate-600 border border-slate-200">{fineness}</td>
                    <td className="p-3 text-slate-600 border border-slate-200">{karat}</td>
                    <td className="p-3 text-slate-500 text-xs border border-slate-200">{ref}</td>
                  </tr>
                ))}
              </tbody>
            </table>
          </div>
        </section>

        <section id="storage" className="mb-12">
          <h2 className="text-2xl font-bold text-[#0F172A] mb-4">Storage Requirements: Approved Depositories</h2>
          <p className="text-slate-600 leading-relaxed mb-4">
            IRA-owned precious metals must be stored in an <strong>IRS-approved depository</strong> — not at your home, in a personal safe, or in a bank safe deposit box. Home storage of IRA-owned metals is a prohibited transaction under IRC §408(m) and will trigger immediate distribution and penalties.
          </p>
          <p className="text-slate-600 leading-relaxed mb-4">
            Approved depositories are typically large, insured, third-party vaulting facilities. Common examples include Delaware Depository, Brinks Global Services, and International Depository Services. Your custodian will arrange storage — you do not select or manage the depository directly.
          </p>
          <div className="bg-amber-50 border border-amber-200 rounded-lg p-4 text-sm text-amber-900">
            <p className="font-semibold mb-1">Warning: "Home Storage Gold IRA" Marketing</p>
            <p>Some promoters market "home storage gold IRAs" or "checkbook IRAs" that claim to allow home storage of IRA metals. The IRS has explicitly stated that home storage of IRA-owned precious metals is not permitted and constitutes a prohibited transaction. The IRS has pursued enforcement actions against these arrangements. Do not rely on promoter claims — verify directly with a tax attorney.</p>
          </div>
        </section>

        <section id="how-it-works" className="mb-12">
          <h2 className="text-2xl font-bold text-[#0F172A] mb-4">How a Precious Metals IRA Works</h2>
          <div className="space-y-3">
            {[
              { step: '1', title: 'Open a Self-Directed IRA', desc: 'Establish an SDIRA with a custodian that specializes in precious metals. Not all SDIRA custodians handle physical metals.' },
              { step: '2', title: 'Fund the Account', desc: 'Fund via rollover from a 401(k) or existing IRA, direct transfer, or new contribution (subject to annual IRS limits).' },
              { step: '3', title: 'Select IRS-Eligible Metals', desc: 'Direct your custodian to purchase specific IRS-approved coins or bars. The custodian executes the purchase on behalf of the IRA.' },
              { step: '4', title: 'Metals Are Stored at an Approved Depository', desc: 'The custodian arranges storage at an IRS-approved depository. You receive documentation of your holdings but do not take physical possession.' },
              { step: '5', title: 'Ongoing Administration', desc: 'The custodian files required IRS reports, manages the account, and processes any future purchases, sales, or distributions.' },
            ].map((item) => (
              <div key={item.step} className="flex gap-4 p-4 bg-white border border-slate-200 rounded-xl">
                <div className="flex-shrink-0 w-8 h-8 bg-yellow-100 text-yellow-700 rounded-full flex items-center justify-center font-bold text-sm">{item.step}</div>
                <div>
                  <p className="font-semibold text-[#0F172A] text-sm mb-1">{item.title}</p>
                  <p className="text-sm text-slate-600 leading-relaxed">{item.desc}</p>
                </div>
              </div>
            ))}
          </div>
        </section>

        <section id="performance" className="mb-12">
          <h2 className="text-2xl font-bold text-[#0F172A] mb-4">Historical Performance vs. Traditional Assets</h2>
          <p className="text-slate-600 leading-relaxed mb-4">
            Historical performance data provides context but is not predictive of future results. The following data reflects approximate annualized returns over various periods:
          </p>
          <div className="overflow-x-auto mb-4">
            <table className="w-full text-sm border-collapse">
              <thead>
                <tr className="bg-slate-100">
                  <th className="text-left p-3 font-semibold text-slate-700 border border-slate-200">Asset</th>
                  <th className="text-left p-3 font-semibold text-slate-700 border border-slate-200">10-Year Annualized Return (approx.)</th>
                  <th className="text-left p-3 font-semibold text-slate-700 border border-slate-200">Max Drawdown (historical)</th>
                  <th className="text-left p-3 font-semibold text-slate-700 border border-slate-200">Income Generation</th>
                </tr>
              </thead>
              <tbody>
                {[
                  ['Gold', '~7–9%', '−46% (2011–2015)', 'None'],
                  ['Silver', '~3–5%', '−72% (2011–2020)', 'None'],
                  ['S&P 500', '~12–14%', '−57% (2007–2009)', 'Dividends (~1.5%)'],
                  ['US Bonds (Agg)', '~1–3%', '−17% (2022)', 'Interest (~3–5%)'],
                  ['Bitcoin', '~40–60%*', '−83% (2017–2018)', 'None'],
                ].map(([asset, ret, drawdown, income]) => (
                  <tr key={asset} className="border-b border-slate-100">
                    <td className="p-3 font-medium text-slate-700 border border-slate-200">{asset}</td>
                    <td className="p-3 text-slate-600 border border-slate-200">{ret}</td>
                    <td className="p-3 text-red-600 border border-slate-200">{drawdown}</td>
                    <td className="p-3 text-slate-600 border border-slate-200">{income}</td>
                  </tr>
                ))}
              </tbody>
            </table>
          </div>
          <p className="text-xs text-slate-400 italic">*Bitcoin 10-year return is highly sensitive to start/end date selection. Data is approximate and sourced from publicly available market data. Past performance is not indicative of future results.</p>
        </section>

        <section id="diversification" className="mb-12">
          <h2 className="text-2xl font-bold text-[#0F172A] mb-4">Diversification: What the Research Shows</h2>
          <p className="text-slate-600 leading-relaxed mb-4">
            Gold is often cited as a portfolio diversifier due to its historically low or negative correlation with equities during periods of market stress. However, the research on gold as a diversifier is more nuanced than marketing materials suggest:
          </p>
          <ul className="list-disc list-inside text-slate-600 space-y-2 mb-4 ml-2">
            <li>Gold has historically maintained purchasing power over very long time horizons (decades to centuries)</li>
            <li>Gold's correlation with equities is not consistently negative — it has risen alongside stocks during some bull markets</li>
            <li>Gold generates no income (dividends, interest) — all return comes from price appreciation</li>
            <li>Storage and custodian fees create a negative carry that erodes returns in flat markets</li>
            <li>Silver is significantly more volatile than gold and has substantial industrial demand drivers that affect its price independently of its monetary role</li>
          </ul>
          <p className="text-slate-600 leading-relaxed">
            Academic research (including work by Claude Erb and Campbell Harvey) suggests gold's role as an inflation hedge is more reliable over very long periods than shorter investment horizons. For retirement investors with a 10–20 year horizon, the evidence is mixed.
          </p>
        </section>

        <section id="risks" className="mb-12">
          <h2 className="text-2xl font-bold text-[#0F172A] mb-4">Risks You Must Understand</h2>
          <div className="space-y-3">
            {[
              { title: 'Price Volatility', desc: 'Gold declined 46% from its 2011 peak to its 2015 trough. Silver declined 72% over a similar period. These are not stable-value assets.', level: 'High' },
              { title: 'No Income Generation', desc: 'Precious metals produce no dividends or interest. All return is price-based. In a flat or declining price environment, you earn nothing and still pay storage and custodian fees.', level: 'Medium' },
              { title: 'Storage and Custodian Fees', desc: 'Annual storage fees (typically 0.5–1% of asset value), custodian fees, and transaction costs can significantly reduce net returns, especially on smaller balances.', level: 'Medium' },
              { title: 'Liquidity Risk', desc: 'Selling IRA-owned physical metals requires the custodian to arrange a sale. This is not as instant as selling a stock. In rapidly declining markets, execution delays can increase losses.', level: 'Medium' },
              { title: 'Counterparty and Custodian Risk', desc: 'If your custodian or depository fails, recovery of physical metals is not guaranteed. Verify insurance coverage and segregation of assets before opening an account.', level: 'High' },
            ].map((risk) => (
              <div key={risk.title} className={`p-4 rounded-xl border ${risk.level === 'High' ? 'bg-orange-50 border-orange-200' : 'bg-amber-50 border-amber-200'}`}>
                <div className="flex items-center gap-2 mb-1">
                  <span className={`text-xs font-bold px-2 py-0.5 rounded ${risk.level === 'High' ? 'bg-orange-200 text-orange-800' : 'bg-amber-200 text-amber-800'}`}>{risk.level} Risk</span>
                  <span className="font-semibold text-[#0F172A] text-sm">{risk.title}</span>
                </div>
                <p className="text-sm text-slate-600 leading-relaxed">{risk.desc}</p>
              </div>
            ))}
          </div>
        </section>

        <section id="fees" className="mb-12">
          <h2 className="text-2xl font-bold text-[#0F172A] mb-4">Fee Structures in Precious Metals IRAs</h2>
          <div className="overflow-x-auto mb-4">
            <table className="w-full text-sm border-collapse">
              <thead>
                <tr className="bg-slate-100">
                  <th className="text-left p-3 font-semibold text-slate-700 border border-slate-200">Fee Type</th>
                  <th className="text-left p-3 font-semibold text-slate-700 border border-slate-200">Typical Range</th>
                  <th className="text-left p-3 font-semibold text-slate-700 border border-slate-200">Notes</th>
                </tr>
              </thead>
              <tbody>
                {[
                  ['Account Setup Fee', '$50–$300', 'One-time fee to open the SDIRA'],
                  ['Annual Custodian Fee', '$75–$300/yr', 'Charged by the SDIRA custodian for account administration'],
                  ['Storage Fee', '0.5–1.0% of asset value/yr', 'Charged by the depository; may be flat or percentage-based'],
                  ['Transaction/Purchase Fee', '$25–$75 per transaction', 'Charged when buying or selling metals'],
                  ['Wire Transfer Fee', '$25–$50 per wire', 'For funding or distribution'],
                  ['Liquidation Fee', '$50–$150', 'Charged when selling metals from the IRA'],
                ].map(([type, range, notes]) => (
                  <tr key={type} className="border-b border-slate-100">
                    <td className="p-3 font-medium text-slate-700 border border-slate-200">{type}</td>
                    <td className="p-3 text-slate-600 border border-slate-200">{range}</td>
                    <td className="p-3 text-slate-500 text-xs border border-slate-200">{notes}</td>
                  </tr>
                ))}
              </tbody>
            </table>
          </div>
          <p className="text-slate-600 text-sm">
            For a $50,000 precious metals IRA, total annual fees (custodian + storage) could range from $450 to $800+ per year — equivalent to 0.9–1.6% annually. This is substantially higher than a standard IRA investing in index funds (typically 0.03–0.20% annually).{' '}
            <Link to="/research/gold-ira-fees-2026" className="text-sky-600 hover:underline">See our 2026 Gold IRA Fee Research →</Link>
          </p>
        </section>

        <section id="research" className="mb-12">
          <h2 className="text-2xl font-bold text-[#0F172A] mb-4">How to Research Providers Independently</h2>
          <p className="text-slate-600 leading-relaxed mb-4">
            Our independent research covers 14 precious metals IRA providers. Key factors to evaluate:
          </p>
          <div className="p-4 bg-indigo-50 border border-indigo-200 rounded-xl text-sm mb-4">
            <p className="font-semibold text-indigo-800 mb-2">Independent Provider Research</p>
            <p className="text-indigo-700 mb-3">Based on our independent scoring of publicly available data across 2,400+ data points from 22 providers — updated quarterly. Data sourced from IRS filings, BBB records, SEC EDGAR, and direct fee schedule requests.</p>
            <Link to="/precious-metals-ira/best-companies" className="text-indigo-700 font-medium hover:underline">View 2026 Precious Metals IRA Provider Comparison →</Link>
          </div>
        </section>

        {/* Sources */}
        <section id="sources" className="mb-12 pt-6 border-t border-slate-200">
          <h3 className="text-sm font-semibold text-slate-500 uppercase tracking-wider mb-3">Primary Sources & References</h3>
          <ul className="space-y-1.5 text-xs text-slate-500">
            <li><a href="https://www.irs.gov/publications/p590a" target="_blank" rel="noopener noreferrer" className="text-sky-600 hover:underline">IRS Publication 590-A: Contributions to Individual Retirement Arrangements</a></li>
            <li><a href="https://www.irs.gov/publications/p590b" target="_blank" rel="noopener noreferrer" className="text-sky-600 hover:underline">IRS Publication 590-B: Distributions from Individual Retirement Arrangements</a></li>
            <li><a href="https://www.law.cornell.edu/uscode/text/26/408" target="_blank" rel="noopener noreferrer" className="text-sky-600 hover:underline">IRC §408: Individual Retirement Accounts (Cornell Law)</a></li>
            <li><a href="https://www.ftc.gov/tips-advice/business-center/guidance/investing-precious-metals" target="_blank" rel="noopener noreferrer" className="text-sky-600 hover:underline">FTC: Investing in Precious Metals</a></li>
          </ul>
        </section>

        {/* Risk Disclaimer */}
        <div className="mt-8 p-5 bg-amber-50 border border-amber-200 rounded-lg text-sm text-amber-900">
          <p className="font-semibold mb-1">Important Disclaimer</p>
          <p>This page is for informational and educational purposes only and does not constitute financial, investment, tax, or legal advice. Precious metals investments involve significant risks, including price volatility and potential loss of principal. Past performance is not indicative of future results. Always consult a qualified, licensed financial advisor and tax professional before making any investment decisions. <Link to="/editorial-policy" className="underline font-medium">See our Editorial Policy</Link> for full disclosure.</p>
        </div>
      </div>
      {/* ── Newsletter Signup ─────────────────────────────────────────── */}
      <div className="container-site py-10 max-w-3xl">
                {/* Related Links */}
        <div className="mt-10 mb-6">
          <RelatedLinks variant="metals-guide" title="Related Guides &amp; Reviews" />
        </div>
        <NewsletterSignup />
      </div>
    </>
  )
}
