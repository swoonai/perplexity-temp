import React from 'react'
import { Link } from 'react-router-dom'
import SEO from '../components/SEO'
import AdvertiserDisclosure from '../components/AdvertiserDisclosure'
import { trackResearchStart } from '../hooks/useAnalytics'
import NewsletterSignup from '../components/NewsletterSignup';
import RelatedLinks from '../components/RelatedLinks';

const LAST_UPDATED = 'March 31, 2026'

export default function RMDGuide2026Page() {

  // Funnel tracking: fire research_start when arriving from a paid ad
  React.useEffect(() => {
    const params = new URLSearchParams(window.location.search)
    const utmSource = params.get('utm_source') ?? undefined
    if (utmSource) {
      trackResearchStart(window.location.pathname, document.title, utmSource)
    }
  }, [])

  return (
    <>
      <script type="application/ld+json" dangerouslySetInnerHTML={{ __html: JSON.stringify({"@context":"https://schema.org","@type":"BreadcrumbList","itemListElement":[{"@type":"ListItem","position":1,"name":"Guides","item":"https://iraresearchhub.com/guides"},{"@type":"ListItem","position":2,"name":"Required Minimum Distributions 2026","item":"https://iraresearchhub.com/guides/required-minimum-distributions-2026"}]}) }} />
      <SEO
        title="Required Minimum Distributions (RMDs): Complete 2026 Guide"
        description="Independent educational guide to RMD rules for Traditional IRAs, SDIRAs, and inherited IRAs. Covers the SECURE 2.0 Act changes, RMD age, calculation methods, penalties, and how RMDs affect crypto and gold IRA holders."
        canonical="/guides/required-minimum-distributions-2026"
        ogType="article"
      />
      <script type="application/ld+json" dangerouslySetInnerHTML={{ __html: JSON.stringify({"@context":"https://schema.org","@type":"Article","headline":"Required Minimum Distributions (RMDs): Complete 2026 Guide","author":{"@type":"Person","name":"James Mitchell","jobTitle":"CFA"},"publisher":{"@type":"Organization","name":"IRA Research Hub"},"dateModified":"2026-03-31"}) }} />

      <div className="bg-[#F8FAFC] border-b border-slate-200 py-10">
        <div className="container-site max-w-4xl">
          <div className="flex flex-wrap gap-2 mb-4">
            <span className="inline-flex items-center px-2.5 py-0.5 rounded-full text-xs font-medium bg-indigo-100 text-indigo-700">Educational Guide</span>
            <span className="inline-flex items-center px-2.5 py-0.5 rounded-full text-xs font-medium bg-slate-100 text-slate-600">SECURE 2.0 Updated</span>
          </div>
          <h1 className="text-4xl font-bold text-[#0F172A] mb-4 leading-tight">
            Required Minimum Distributions (RMDs): Complete 2026 Guide
          </h1>
          <p className="text-lg text-[#64748B] mb-4 max-w-3xl">
            The SECURE 2.0 Act (2022) changed the RMD starting age and reduced penalties for missed RMDs. This guide covers the current rules, how to calculate your RMD, special considerations for crypto and gold IRA holders, and inherited IRA rules.
          </p>
          <p className="text-sm text-slate-500">
            By <Link to="/author/james-mitchell" className="text-sky-600 hover:underline font-medium">James Mitchell, CFA</Link>
            {' · '}Last Updated: {LAST_UPDATED}
          </p>
          <AdvertiserDisclosure />
        </div>
      </div>

      <div className="container-site max-w-4xl py-8">
        <section className="mb-10">
          <h2 className="text-2xl font-bold text-[#0F172A] mb-4">What Is an RMD?</h2>
          <p className="text-slate-600 leading-relaxed mb-4">
            A Required Minimum Distribution (RMD) is the minimum amount the IRS requires you to withdraw annually from certain retirement accounts once you reach a specified age. RMDs apply to Traditional IRAs, SEP-IRAs, SIMPLE IRAs, and most employer-sponsored plans (401(k), 403(b), 457(b)). Roth IRAs are not subject to RMDs during the original owner's lifetime.
          </p>
          <p className="text-slate-600 leading-relaxed mb-4">
            The purpose of RMDs is to ensure that tax-deferred retirement savings are eventually taxed. The IRS requires distributions so that the government collects income tax on funds that were contributed pre-tax.
          </p>
        </section>

        <section className="mb-10">
          <h2 className="text-2xl font-bold text-[#0F172A] mb-4">RMD Age Under SECURE 2.0 Act</h2>
          <div className="overflow-x-auto mb-4">
            <table className="w-full text-sm border-collapse">
              <thead>
                <tr className="bg-slate-100">
                  <th className="text-left p-3 font-semibold text-slate-700 border border-slate-200">Birth Year</th>
                  <th className="text-left p-3 font-semibold text-slate-700 border border-slate-200">RMD Starting Age</th>
                  <th className="text-left p-3 font-semibold text-slate-700 border border-slate-200">Governing Law</th>
                </tr>
              </thead>
              <tbody>
                {[
                  ["Before 1951", "70½", "Pre-SECURE Act (original law)"],
                  ["1951–1959", "72", "SECURE Act (2019)"],
                  ["1960 and later", "73", "SECURE 2.0 Act (2022)"],
                  ["Note: Starting in 2033", "75 (planned)", "SECURE 2.0 Act — further increase scheduled"],
                ].map(([birth, age, law]) => (
                  <tr key={birth} className="border-b border-slate-100">
                    <td className="p-3 font-medium text-slate-700 border border-slate-200">{birth}</td>
                    <td className="p-3 text-slate-600 border border-slate-200">{age}</td>
                    <td className="p-3 text-slate-500 text-xs border border-slate-200">{law}</td>
                  </tr>
                ))}
              </tbody>
            </table>
          </div>
        </section>

        <section className="mb-10">
          <h2 className="text-2xl font-bold text-[#0F172A] mb-4">How to Calculate Your RMD</h2>
          <p className="text-slate-600 leading-relaxed mb-4">
            Your RMD is calculated by dividing your IRA account balance as of December 31 of the prior year by a life expectancy factor from the IRS Uniform Lifetime Table (IRS Publication 590-B, Appendix B).
          </p>
          <div className="bg-slate-50 border border-slate-200 rounded-xl p-5 mb-4">
            <p className="font-semibold text-[#0F172A] mb-3">RMD Calculation Formula</p>
            <div className="text-sm text-slate-600 space-y-2">
              <p><strong>RMD = Prior Year-End Account Balance ÷ IRS Life Expectancy Factor</strong></p>
              <p className="mt-3 font-medium">Example:</p>
              <p>Account balance on December 31, 2025: $500,000</p>
              <p>Age in 2026: 75 years old</p>
              <p>IRS Uniform Lifetime Table factor for age 75: 24.6</p>
              <p className="font-semibold mt-2">2026 RMD = $500,000 ÷ 24.6 = <span className="text-sky-700">$20,325</span></p>
            </div>
          </div>
          <p className="text-slate-600 text-sm">The IRS Uniform Lifetime Table is available in IRS Publication 590-B. If your sole beneficiary is your spouse who is more than 10 years younger, you use the Joint Life and Last Survivor Expectancy Table, which produces lower RMDs.</p>
        </section>

        <section className="mb-10">
          <h2 className="text-2xl font-bold text-[#0F172A] mb-4">RMDs and Crypto/Gold IRAs: Special Considerations</h2>
          <p className="text-slate-600 leading-relaxed mb-4">
            RMDs from self-directed IRAs holding crypto or precious metals present unique challenges:
          </p>
          <div className="space-y-3 mb-4">
            {[
              { title: "Valuation Complexity", desc: "Your RMD is based on the account's fair market value on December 31 of the prior year. For volatile assets like crypto, the year-end value may be significantly different from the value when you actually take the distribution." },
              { title: "Liquidity Risk", desc: "If your SDIRA holds illiquid assets (physical metals, private equity), you may need to sell assets to fund the RMD. In a declining market, this forces you to sell at potentially unfavorable prices." },
              { title: "In-Kind Distributions", desc: "In some cases, you may be able to take an in-kind distribution (receiving physical metals or transferring crypto to a personal wallet) rather than selling. However, this has tax implications — the fair market value of the distributed assets is taxable income." },
              { title: "Aggregation Rules", desc: "If you have multiple Traditional IRAs, you can aggregate the RMDs and take the total from any one or combination of the accounts. This allows flexibility in which assets you liquidate." },
            ].map((item) => (
              <div key={item.title} className="p-4 bg-white border border-slate-200 rounded-xl">
                <p className="font-semibold text-[#0F172A] text-sm mb-1">{item.title}</p>
                <p className="text-sm text-slate-600 leading-relaxed">{item.desc}</p>
              </div>
            ))}
          </div>
        </section>

        <section className="mb-10">
          <h2 className="text-2xl font-bold text-[#0F172A] mb-4">Penalty for Missing an RMD</h2>
          <p className="text-slate-600 leading-relaxed mb-4">
            Under SECURE 2.0, the penalty for failing to take an RMD was reduced from 50% to <strong>25% of the shortfall</strong> (the amount you should have taken but did not). If you correct the missed RMD within the "correction window" (generally 2 years), the penalty is further reduced to <strong>10%</strong>.
          </p>
          <p className="text-slate-600 leading-relaxed">
            Despite the reduced penalty, missing an RMD is still a significant and avoidable tax event. Set up automatic reminders and consider working with a tax advisor to ensure RMDs are taken correctly each year.
          </p>
        </section>

        <section className="mb-10 pt-6 border-t border-slate-200">
          <h3 className="text-sm font-semibold text-slate-500 uppercase tracking-wider mb-3">Primary Sources & References</h3>
          <ul className="space-y-1.5 text-xs text-slate-500">
            <li><a href="https://www.irs.gov/publications/p590b" target="_blank" rel="noopener noreferrer" className="text-sky-600 hover:underline">IRS Publication 590-B: Distributions from Individual Retirement Arrangements</a></li>
            <li><a href="https://www.irs.gov/retirement-plans/retirement-plans-faqs-regarding-required-minimum-distributions" target="_blank" rel="noopener noreferrer" className="text-sky-600 hover:underline">IRS: RMD FAQs</a></li>
            <li><a href="https://www.congress.gov/bill/117th-congress/house-bill/2954" target="_blank" rel="noopener noreferrer" className="text-sky-600 hover:underline">SECURE 2.0 Act of 2022 (H.R. 2954)</a></li>
          </ul>
        </section>

        <div className="mt-8 p-5 bg-amber-50 border border-amber-200 rounded-lg text-sm text-amber-900">
          <p className="font-semibold mb-1">Important Disclaimer</p>
          <p>This page is for informational and educational purposes only. RMD rules are complex and penalties for non-compliance are significant. Always consult a qualified tax professional. <Link to="/editorial-policy" className="underline font-medium">See our Editorial Policy</Link>.</p>
        </div>
      </div>
      {/* ── Newsletter Signup ─────────────────────────────────────────── */}
      <div className="container-site py-10 max-w-3xl">
        
        {/* Related Links */}

        <div className="mt-10 mb-6">

          <RelatedLinks variant="crypto-guide" title="Related Guides &amp; Reviews" />

        </div>
<NewsletterSignup />
      </div>
    </>
  )
}
