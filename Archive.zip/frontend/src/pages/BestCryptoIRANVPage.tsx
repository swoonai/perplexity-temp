import StateGuideTemplate from '../components/StateGuideTemplate'

export default function BestCryptoIRANVPage() {
  return (
    <StateGuideTemplate
      stateName="Nevada"
      stateAbbr="NV"
      slug="nevada"
    />
  )
}
