import StateGuideTemplate from '../components/StateGuideTemplate'

export default function BestCryptoIRAMEPage() {
  return (
    <StateGuideTemplate
      stateName="Maine"
      stateAbbr="ME"
      slug="maine"
    />
  )
}
