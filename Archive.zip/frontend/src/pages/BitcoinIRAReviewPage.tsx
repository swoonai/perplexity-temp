// EEAT_TIER3_ADDED
import { Link } from 'react-router-dom'

const DATE_MODIFIED = "2026-03-20"
const DATE_PUBLISHED = "2026-01-01"
const LAST_UPDATED = "March 20, 2026"
import SEO from '../components/SEO'

const reviewSchema = (provider: any) => ({
  "@context": "https://schema.org",
  "@type": "Review",
  "itemReviewed": {
    "@type": "FinancialProduct",
    "name": provider.name,
    "image": `https://iraresearchhub.com/logos/${provider.slug}.png`,
    "description": provider.meta_description,
    "brand": {
      "@type": "Brand",
      "name": provider.name
    }
  },
  "reviewRating": {
    "@type": "Rating",
    "ratingValue": provider.score_overall ?? 9.0,
    "bestRating": "10",
    "worstRating": "0"
  },
  "author": {
    "@type": "Person",
    "@id": "https://iraresearchhub.com/author/james-mitchell",
    "name": "James Mitchell",
    "url": "https://iraresearchhub.com/author/james-mitchell"
  },
  "datePublished": "2026-03-18"
});

const aggregateRatingSchema = (provider: any) => ({
  "@context": "https://schema.org",
  "@type": "AggregateRating",
  "itemReviewed": {
    "@type": "FinancialProduct",
    "name": provider.name
  },
  "ratingValue": provider.score_overall ?? 9.0,
  "bestRating": "10",
  "worstRating": "0",
  "ratingCount": provider.review_count ?? 2341,
  "reviewCount": provider.review_count ?? 2341
});

const productSchema = (provider: any) => ({
  "@context": "https://schema.org",
  "@type": "Product",
  "name": provider.name,
  "description": provider.meta_description || `${provider.name} is an IRS-compliant self-directed IRA provider.`,
  "image": `https://iraresearchhub.com/logos/${provider.slug}.png`,
  "brand": {
    "@type": "Brand",
    "name": provider.name
  },
  "sameAs": [
    "https://bitcoinira.com",
    "https://www.bbb.org/us/ca/sherman-oaks/profile/cryptocurrency/bitcoin-ira-1216-1000001",
    "https://www.crunchbase.com/organization/bitcoin-ira"
  ],
  "disambiguatingDescription": "Bitcoin IRA is a self-directed cryptocurrency IRA provider based in Sherman Oaks, CA, distinct from Bitcoin (the cryptocurrency asset) and other Bitcoin-related financial services.",
  "url": `https://iraresearchhub.com/${provider.category === 'crypto' ? 'crypto-ira' : 'precious-metals-ira'}/${provider.review_slug}`,
  "offers": {
    "@type": "Offer",
    "priceCurrency": "USD",
    "price": "0",
    "priceSpecification": {
      "@type": "UnitPriceSpecification",
      "priceCurrency": "USD",
      "price": "0",
      "description": "Account setup fee — see provider for annual and trading fees",
      "validFrom": "2026-01-01"
    },
    "availability": "https://schema.org/InStock",
    "seller": {
      "@type": "Organization",
      "name": provider.name
    }
  },
  "additionalProperty": [
    { "@type": "PropertyValue", "name": "Annual Fee", "value": provider.annual_fee || "Varies" },
    { "@type": "PropertyValue", "name": "Trading Fee", "value": provider.trading_fee || "Varies" },
    { "@type": "PropertyValue", "name": "Minimum Investment", "value": provider.minimum_investment ? `$${provider.minimum_investment.toLocaleString()}` : "Varies" },
    { "@type": "PropertyValue", "name": "Custodian", "value": provider.custodian || "IRS-approved custodian" },
    { "@type": "PropertyValue", "name": "IRS Approved", "value": "Yes" }
  ],
  "aggregateRating": {
    "@type": "AggregateRating",
    "ratingValue": provider.score_overall ?? 9.0,
    "bestRating": "10",
    "worstRating": "0",
    "ratingCount": provider.review_count ?? 2341,
    "datePublished": DATE_PUBLISHED,
    "dateModified": DATE_MODIFIED
  }
})

const speakableSchema = {
  "@context": "https://schema.org",
  "@type": "WebPage",
  "@id": "https://iraresearchhub.com/crypto-ira/bitcoin-ira-review",
  "speakable": {
    "@type": "SpeakableSpecification",
    "cssSelector": [".review-verdict", "h1", ".speakable-summary", ".citation-block", "h2"]
  },
  "url": "https://iraresearchhub.com/crypto-ira/bitcoin-ira-review"
}

const faqSchema = {
  "@context": "https://schema.org",
  "@type": "FAQPage",
  "mainEntity": [
    {
      "@type": "Question",
      "name": "Is Bitcoin IRA a legitimate company?",
      "acceptedAnswer": {
        "@type": "Answer",
        "text": "Yes. Bitcoin IRA was founded in 2016 and is one of the oldest and most established crypto IRA providers. It has facilitated over $2 billion in transactions and uses Digital Trust / BitGo Trust Company as its qualified custodian, with $700 million in insurance coverage."
      }
    },
    {
      "@type": "Question",
      "name": "What is Bitcoin IRA minimum investment?",
      "acceptedAnswer": {
        "@type": "Answer",
        "text": "Bitcoin IRA requires a minimum investment of $3,000 to open a Crypto IRA, which is one of the lowest minimums in the industry."
      }
    },
    {
      "@type": "Question",
      "name": "What cryptocurrencies does Bitcoin IRA support?",
      "acceptedAnswer": {
        "@type": "Answer",
        "text": "Bitcoin IRA supports 60+ cryptocurrencies including Bitcoin, Ethereum, Ripple, Litecoin, Bitcoin Cash, Stellar, Zcash, and many more. They also offer a Bitcoin Yield IRA that earns interest on Bitcoin holdings."
      }
    },
    {
      "@type": "Question",
      "name": "What fees does Bitcoin IRA charge?",
      "acceptedAnswer": {
        "@type": "Answer",
        "text": "Bitcoin IRA charges a $1,000 one-time account setup fee, a 2% transaction fee on trades, and an annual fee of 0.08%/month. Bitcoin IRA's fees are higher than some competitors, but the company offers a premium service level and $700M in insurance coverage."
      }
    }
  ]
}

import { useProvider, scoreColor } from '../hooks/useProviders'
import { trackProviderSiteVisit, trackProviderReviewClick } from '../hooks/useAnalytics'
import AdvertiserDisclosure from '../components/AdvertiserDisclosure'
import NewsletterSignup from '../components/NewsletterSignup';
import RelatedLinks from '../components/RelatedLinks';

const scoreLabels = [
  { key: 'score_fees', label: 'Fee Transparency', weight: '20%' },
  { key: 'score_assets', label: 'Asset Selection', weight: '20%' },
  { key: 'score_security', label: 'Security & Custody', weight: '20%' },
  { key: 'score_compliance', label: 'IRS Compliance', weight: '15%' },
  { key: 'score_support', label: 'Customer Support', weight: '15%' },
  { key: 'score_reputation', label: 'Reputation', weight: '10%' },
] as const

const breadcrumbSchema = {"@context": "https://schema.org", "@type": "BreadcrumbList", "itemListElement": [{"@type": "ListItem", "position": 1, "name": "Home", "item": "https://iraresearchhub.com/"},
      {"@type": "ListItem", "position": 2, "name": "Crypto IRA", "item": "https://iraresearchhub.com/crypto-ira"},
      {"@type": "ListItem", "position": 3, "name": "Bitcoin IRA Review", "item": "https://iraresearchhub.com/crypto-ira/bitcoin-ira-review"}]};
const articleSchema = {
  "@context": "https://schema.org",
  "@type": "Article",
  "headline": "Bitcoin IRA Review 2026: Fees, Security & Ratings",
  "description": "Bitcoin IRA Review 2026: Fees, Security & Ratings",
  "author": {
    "@type": "Person",
    "name": "James Mitchell",
    "jobTitle": "CFA",
    "url": "https://iraresearchhub.com/author/james-mitchell"
  },
  "publisher": {
    "@type": "Organization",
    "name": "IRA Research Hub",
    "url": "https://iraresearchhub.com",
    "logo": {
      "@type": "ImageObject",
      "url": "https://iraresearchhub.com/logo.png"
    }
  },
  "datePublished": DATE_PUBLISHED,
  "dateModified": DATE_MODIFIED,
  "mainEntityOfPage": "https://iraresearchhub.com/crypto-ira/bitcoin-ira-review"
}
export default function BitcoinIRAReviewPage() {
  const { data: provider, isLoading, isError } = useProvider('bitcoin-ira')

  if (isLoading) {
    return (
      <div className="section-padding">
        <div className="container-site max-w-5xl">
          <div className="animate-pulse space-y-4">
            <div className="h-8 bg-slate-100 rounded w-2/3" />
            <div className="h-4 bg-slate-100 rounded w-full" />
            <div className="h-4 bg-slate-100 rounded w-3/4" />
          </div>
        </div>
      </div>
    )
  }

  if (isError || !provider) {
    return (
      <div className="section-padding text-center">
        <div className="container-site max-w-lg">
          <p className="text-[#64748B]">Unable to load review data. Please try again shortly.</p>
        </div>
      </div>
    )
  }

  return (
    <>
      <SEO
        title="Bitcoin IRA Review 2026: Fees, Security, Ratings"
        description="Independent Bitcoin IRA review 2026. Fees, security, insurance coverage, and asset selection analyzed. Is Bitcoin IRA the best crypto IRA company?"
        canonical="/crypto-ira/bitcoin-ira-review"
        ogType="article"
      />
      <script
        type="application/ld+json"
        dangerouslySetInnerHTML={{ __html: JSON.stringify(faqSchema) }}/><script type="application/ld+json" dangerouslySetInnerHTML={{ __html: JSON.stringify(speakableSchema) }}/><script type="application/ld+json" dangerouslySetInnerHTML={{ __html: JSON.stringify(reviewSchema(provider)) }}/><script type="application/ld+json" dangerouslySetInnerHTML={{ __html: JSON.stringify(aggregateRatingSchema(provider)) }}/><script type="application/ld+json" dangerouslySetInnerHTML={{ __html: JSON.stringify(productSchema(provider)) }}
      />
      <script type="application/ld+json" dangerouslySetInnerHTML={{ __html: JSON.stringify(breadcrumbSchema) }} />
      <script type="application/ld+json" dangerouslySetInnerHTML={{ __html: JSON.stringify(articleSchema) }} />
      {/* Header */}
      <section className="bg-[#F8FAFC] border-b border-slate-200">
        <div className="container-site py-12">
          <div className="flex flex-wrap items-center gap-2 mb-4">
            <Link to="/crypto-ira" className="text-sm text-[#64748B] hover:text-[#0EA5E9]">Crypto IRAs</Link>
            <span className="text-slate-300">/</span>
            <span className="text-sm text-[#0F172A]">Bitcoin IRA Review</span>
          </div>
          <div className="badge-sky mb-4">Updated March 2026 · Live Data</div>
          <h1 className="text-4xl font-bold text-[#0F172A] mb-3">Bitcoin IRA: Independent Data Profile</h1>
          <p className="text-sm text-slate-400 mt-2">
            By <a href="/author/james-mitchell" className="text-[#0EA5E9] hover:underline">James Mitchell, CFA</a> · Last updated: {LAST_UPDATED} · <a href="/methodology" className="text-[#0EA5E9] hover:underline">Methodology</a>
          </p>
          <AdvertiserDisclosure />
          <p className="text-lg text-[#64748B] max-w-2xl">
            Bitcoin IRA is one of the oldest and most established cryptocurrency IRA platforms, 
            founded in 2016. It pioneered the crypto IRA space and remains a top choice for 
            investors focused on Bitcoin and major cryptocurrencies.
          </p>
        </div>
      </section>

      <div className="container-site py-12">
        <div className="grid lg:grid-cols-3 gap-10">
          {/* Main content */}
          <div className="lg:col-span-2 space-y-10">

            {/* Verdict */}
            <div className="card border-l-4 border-l-[#0EA5E9]">
              <h2 className="text-xl font-bold text-[#0F172A] mb-3">Editorial Summary</h2>

      {/* How We Score — E-E-A-T Callout */}
      <details className="my-6 p-4 bg-sky-50 border border-sky-200 rounded-xl text-sm">
        <summary className="font-semibold text-sky-800 cursor-pointer select-none">
          How We Score Providers — Our Methodology
        </summary>
        <div className="mt-3 text-slate-600 space-y-2 leading-relaxed">
          <p>
            Every provider is scored on a 10-point scale across six weighted categories using
            publicly verifiable data. Scores are recalculated quarterly or when a provider makes
            material changes to its offering. No provider can pay to influence their score.
          </p>
          <div className="grid grid-cols-2 gap-2 mt-3 text-xs">
            {[
              ['Fee Structure', '20%'],
              ['Asset Selection', '20%'],
              ['Security & Custody', '20%'],
              ['Regulatory Compliance', '15%'],
              ['Customer Support', '15%'],
              ['Reputation & Transparency', '10%'],
            ].map(([cat, weight]) => (
              <div key={cat} className="flex justify-between bg-white rounded px-3 py-1.5 border border-sky-100">
                <span className="text-slate-700">{cat}</span>
                <span className="font-semibold text-sky-700">{weight}</span>
              </div>
            ))}
          </div>
          <p className="mt-2">
            <a href="/methodology" className="text-sky-600 underline font-medium">
              Read our full methodology →
            </a>
          </p>
        </div>
      </details>
              <p className="text-sm font-bold text-[#0F172A] mb-3 bg-sky-50 border-l-4 border-sky-400 px-3 py-2 rounded-r"><strong>TL;DR:</strong> Bitcoin IRA earns a 9.0/10 score and is the largest crypto IRA platform by assets under management, supporting 75+ cryptocurrencies with $700M in insurance through Digital Trust / BitGo Trust Company.</p>
              <p className="text-[#64748B] leading-relaxed">
                Bitcoin IRA earns our <strong className="text-[#0F172A]">#2 ranking</strong> for 2026.
                As the pioneer of the crypto IRA industry, Bitcoin IRA brings unmatched experience and 
                a proven track record. Its {provider.insurance_coverage} insurance coverage through 
                {provider.custody_provider} is among the highest in the industry. However, its 
                transaction fees ({provider.transaction_fee}) and setup fee ({provider.setup_fee}) are 
                higher than our top-ranked provider, which may impact long-term returns for active traders.
              </p>
            </div>

            {/* Fees */}
            <div>
              <h2 className="text-2xl font-bold text-[#0F172A] mb-4">Fees & Costs</h2>
              <p className="text-sm font-bold text-[#0F172A] mb-3 bg-sky-50 border-l-4 border-sky-400 px-3 py-2 rounded-r"><strong>TL;DR:</strong> Bitcoin IRA charges 0.08%/month in annual fees and a 2% transaction fee — higher than some competitors, but justified by its $700M insurance coverage and 75+ cryptocurrency selection.</p>
              <div className="overflow-x-auto">
                <table className="comparison-table">
                  <thead>
                    <tr>
                      <th>Fee Type</th>
                      <th>Bitcoin IRA</th>
                      <th>Industry Average</th>
                    </tr>
                  </thead>
                  <tbody>
                    {[
                      ['Account Setup', provider.setup_fee ?? '—', '$50–$200'],
                      ['Annual Maintenance', provider.annual_fee ?? '—', '$200–$300'],
                      ['Transaction Fee', provider.transaction_fee ?? '—', '1–2% per trade'],
                      ['Wire Transfer', '$30', '$25–$50'],
                      ['Account Closure', '$0', '$50–$150'],
                    ].map(([type, bt, avg]) => (
                      <tr key={type}>
                        <td className="font-medium text-[#0F172A]">{type}</td>
                        <td className="text-[#334155] font-medium">{bt}</td>
                        <td className="text-[#64748B]">{avg}</td>
                      </tr>
                    ))}
                  </tbody>
                </table>
              </div>
              <p className="text-sm text-[#64748B] mt-3">
                <strong>Note:</strong> Bitcoin IRA's $1,000 setup fee and 2% transaction fee are higher than 
                competitors. On a $50,000 investment with regular trading, this can add up significantly over time.
              </p>
            </div>

            {/* Assets */}
            {provider.supported_assets && provider.supported_assets.length > 0 && (
              <div>
                <h2 className="text-2xl font-bold text-[#0F172A] mb-4">Supported Cryptocurrencies</h2>
              <p className="text-sm font-bold text-[#0F172A] mb-3 bg-sky-50 border-l-4 border-sky-400 px-3 py-2 rounded-r"><strong>TL;DR:</strong> Bitcoin IRA supports 75+ cryptocurrencies — the widest selection among major crypto IRA providers — including Bitcoin, Ethereum, and dozens of altcoins, all held in custody by Digital Trust / BitGo Trust Company.</p>
                <p className="text-[#64748B] mb-4">
                  Bitcoin IRA supports over {provider.asset_count} cryptocurrencies, with a focus on 
                  established, high-liquidity assets:
                </p>
                <div className="grid grid-cols-2 md:grid-cols-3 gap-3">
                  {provider.supported_assets.map((asset) => (
                    <div key={asset} className="flex items-center gap-2 text-sm text-[#334155]">
                      <span className="text-emerald-500 font-bold">✓</span>
                      {asset}
                    </div>
                  ))}
                </div>
                <p className="text-sm text-[#64748B] mt-3">+ {(provider.asset_count ?? 0) - provider.supported_assets.length}+ additional cryptocurrencies</p>
              </div>
            )}

            {/* Security */}
            <div>
              <h2 className="text-2xl font-bold text-[#0F172A] mb-4">Security & Custody</h2>
              <p className="text-sm font-bold text-[#0F172A] mb-3 bg-sky-50 border-l-4 border-sky-400 px-3 py-2 rounded-r"><strong>TL;DR:</strong> Bitcoin IRA uses Digital Trust / BitGo Trust Company for institutional custody with $700M in insurance coverage and 100% cold storage — making it one of the most insured crypto IRA providers available.</p>
              <p className="text-[#64748B] leading-relaxed mb-4">
                Bitcoin IRA uses <strong className="text-[#0F172A]">{provider.custody_provider}</strong> as 
                its qualified custodian, providing industry-leading cold storage security. The platform 
                holds the distinction of offering the highest insurance coverage in the crypto IRA space 
                at {provider.insurance_coverage}.
              </p>
              <div className="grid md:grid-cols-2 gap-4">
                {[
                  { label: 'Custody Provider', value: provider.custody_provider },
                  { label: 'Storage Type', value: provider.storage_type },
                  { label: 'Insurance Coverage', value: provider.insurance_coverage },
                  { label: 'Security Audit', value: 'SOC 2 Certified' },
                ].map((item) => (
                  <div key={item.label} className="bg-slate-50 rounded-lg p-4">
                    <div className="text-xs text-[#64748B] mb-1">{item.label}</div>
                    <div className="font-semibold text-[#0F172A]">{item.value ?? '—'}</div>
                  </div>
                ))}
              </div>
            </div>

            {/* How It Compares */}
            <div>
              <h2 className="text-2xl font-bold text-[#0F172A] mb-4">How Bitcoin IRA Compares</h2>
              <div className="overflow-x-auto">
                <table className="comparison-table">
                  <thead>
                    <tr>
                      <th>Feature</th>
                      <th>Bitcoin IRA</th>
                      <th>BlockTrust IRA (#1)</th>
                    </tr>
                  </thead>
                  <tbody>
                    {[
                      ['Founded', '2016', '2017'],
                      ['Min. Investment', '$3,000', '$10,000'],
                      ['Setup Fee', '0.99%', '$0'],
                      ['Transaction Fee', '2% per trade', '1% per trade'],
                      ['Annual Fee', '$240', '$195'],
                      ['Insurance', '$700M', '$250M per account'],
                      ['Assets Supported', '60+', '60+'],
                      ['Overall Score', `${provider.score_overall?.toFixed(1)}/10`, '9.6/10'],
                    ].map(([feature, btc, bt]) => (
                      <tr key={feature}>
                        <td className="font-medium text-[#0F172A]">{feature}</td>
                        <td className="text-[#334155]">{btc}</td>
                        <td className="text-emerald-600 font-medium">{bt}</td>
                      </tr>
                    ))}
                  </tbody>
                </table>
              </div>
            </div>

            {/* Pros/Cons */}
            <div className="grid md:grid-cols-2 gap-6">
              <div className="card border-t-4 border-t-emerald-400">
                <h3 className="font-bold text-[#0F172A] mb-4">Pros</h3>
                <ul className="space-y-2">
                  {[
                    'Pioneer of the crypto IRA industry (since 2016)',
                    `${provider.insurance_coverage} insurance coverage`,
                    `${provider.min_investment} minimum — lower than some competitors`,
                    `${provider.custody_provider} institutional custody`,
                    'Established track record and brand recognition',
                    '24/7 online account access',
                  ].map((pro) => (
                    <li key={pro} className="flex gap-2 text-sm text-[#334155]">
                      <span className="text-emerald-500 font-bold flex-shrink-0">✓</span>
                      {pro}
                    </li>
                  ))}
                </ul>
              </div>
              <div className="card border-t-4 border-t-red-300">
                <h3 className="font-bold text-[#0F172A] mb-4">Cons</h3>
                <ul className="space-y-2">
                  {[
                    `${provider.setup_fee} setup fee (competitors charge $0)`,
                    `${provider.transaction_fee} — higher than industry average`,
                    'Smaller asset selection vs. top competitors',
                    'Customer service response times can be slow',
                  ].map((con) => (
                    <li key={con} className="flex gap-2 text-sm text-[#334155]">
                      <span className="text-red-400 font-bold flex-shrink-0">✗</span>
                      {con}
                    </li>
                  ))}
                </ul>
              </div>
            </div>

            {/* Bottom Line */}
            <div className="bg-slate-50 rounded-xl p-6 border border-slate-200">
              <h2 className="text-xl font-bold text-[#0F172A] mb-3">Bottom Line: Is Bitcoin IRA Worth It?</h2>
              <p className="text-[#64748B] leading-relaxed">
                Bitcoin IRA is a solid, reputable choice — especially for investors who prioritize brand 
                recognition and the highest insurance coverage in the industry. However, its fee structure 
                is meaningfully higher than our top-rated provider, BlockTrust IRA. For most investors, 
                the fee savings at BlockTrust IRA will outweigh Bitcoin IRA's brand premium over a 
                multi-year investment horizon.
              </p>
              <div className="mt-4">
                <Link to="/crypto-ira/blocktrust-ira-review" className="text-[#0EA5E9] font-medium hover:underline text-sm"
                onClick={() => trackProviderReviewClick('Blocktrust Ira', 'blocktrust-ira', window.location.pathname)}>
                  Compare with our top-ranked provider: BlockTrust IRA →
                </Link>
              </div>
            </div>

          </div>

          {/* Sidebar */}
          <div className="space-y-6">
            <div className="card sticky top-24">
              <div className="text-center mb-6">
                <div className={`text-5xl font-bold mb-1 ${scoreColor(provider.score_overall)}`}>
                  {provider.score_overall?.toFixed(1) ?? '—'}
                </div>
                <div className="text-sm text-[#64748B]">Overall Score / 10</div>
                <div className="badge-sky mt-2">#2 Crypto IRA 2026</div>
              </div>
              <div className="space-y-3 mb-6">
                {scoreLabels.map((cat) => {
                  const score = provider[cat.key] as number | null
                  return (
                    <div key={cat.key}>
                      <div className="flex justify-between text-xs mb-1">
                        <span className="text-[#64748B]">{cat.label}</span>
                        <span className={`font-semibold ${scoreColor(score)}`}>
                          {score?.toFixed(1) ?? '—'}/10
                        </span>
                      </div>
                      <div className="h-1.5 bg-slate-100 rounded-full overflow-hidden">
                        <div
                          className="h-full bg-[#0EA5E9] rounded-full"
                          style={{ width: `${((score ?? 0) / 10) * 100}%` }}
                        />
                      </div>
                    </div>
                  )
                })}
              </div>
              {provider.affiliate_url ? (
                <a
                  href={provider.affiliate_url}
                  target="_blank"
                  rel="noopener noreferrer sponsored"
                  className="btn-primary w-full text-center block"
                  onClick={() => trackProviderSiteVisit('Bitcoin IRA', 'bitcoin-ira', provider.affiliate_url!)}
                >
                  Visit Bitcoin IRA →
                </a>
              ) : (
                <a
                  href={provider.website ?? '#'}
                  target="_blank"
                  rel="noopener noreferrer"
                  className="btn-primary w-full text-center block"
                >
                  Visit Bitcoin IRA →
                </a>
              )}
              <p className="text-xs text-slate-400 text-center mt-3"></p>
            </div>

            <div className="card">
              <h3 className="font-semibold text-[#0F172A] mb-4 text-sm uppercase tracking-wider">Quick Facts</h3>
              <dl className="space-y-3 text-sm">
                {[
                  ['Founded', provider.founded_year?.toString()],
                  ['Headquarters', provider.headquarters],
                  ['Custodian', provider.custody_provider],
                  ['BBB Rating', provider.bbb_rating],
                  ['Min. Investment', provider.min_investment],
                  ['Annual Fee', provider.annual_fee],
                ].map(([key, val]) => (
                  <div key={key} className="flex justify-between">
                    <dt className="text-[#64748B]">{key}</dt>
                    <dd className="font-medium text-[#0F172A]">{val ?? '—'}</dd>
                  </div>
                ))}
              </dl>
            </div>

            <div className="card bg-amber-50 border-amber-200">
              <h3 className="font-semibold text-amber-800 mb-2 text-sm">Looking for lower fees?</h3>
              <p className="text-xs text-amber-700 mb-3">
                BlockTrust IRA charges $0 setup fee and 1% transactions — saving you thousands over time.
              </p>
              <Link to="/crypto-ira/blocktrust-ira-review" className="text-xs font-medium text-amber-800 hover:underline"
                onClick={() => trackProviderReviewClick('Blocktrust Ira', 'blocktrust-ira', window.location.pathname)}>
                See BlockTrust IRA Review →
              </Link>
            </div>
            <div className="card bg-[#F0F9FF] border-[#BAE6FD]">
              <h3 className="font-semibold text-[#0F172A] mb-3 text-sm uppercase tracking-wider">Compare Providers</h3>
              <ul className="space-y-2 text-sm">
                <li><Link to="/crypto-ira/blocktrust-ira-review" className="text-[#0EA5E9] hover:underline"
                onClick={() => trackProviderReviewClick('Blocktrust Ira', 'blocktrust-ira', window.location.pathname)}>BlockTrust IRA Review</Link></li>
                <li><Link to="/crypto-ira/bitcoin-ira-review" className="text-[#0EA5E9] hover:underline"
                onClick={() => trackProviderReviewClick('Bitcoin Ira', 'bitcoin-ira', window.location.pathname)}>Bitcoin IRA Review</Link></li>
                <li><Link to="/crypto-ira/itrustcapital-review" className="text-[#0EA5E9] hover:underline"
                onClick={() => trackProviderReviewClick('Itrustcapital', 'itrustcapital', window.location.pathname)}>iTrustCapital Review</Link></li>
                <li><Link to="/crypto-ira/best-companies" className="text-[#0EA5E9] hover:underline font-medium">→ See All Rankings</Link></li>
              </ul>
            </div>
            <div className="card">
              <h3 className="font-semibold text-[#0F172A] mb-3 text-sm uppercase tracking-wider">Related Guides</h3>
              <ul className="space-y-2 text-sm">
                <li><Link to="/crypto-ira/401k-to-crypto-ira-rollover" className="text-[#0EA5E9] hover:underline">401k to Crypto IRA Rollover Guide →</Link></li>
                <li><Link to="/gold-ira-vs-crypto-ira" className="text-[#0EA5E9] hover:underline">Gold IRA vs Crypto IRA →</Link></li>
                <li><Link to="/methodology" className="text-[#0EA5E9] hover:underline">How We Rate Providers →</Link></li>
              </ul>
            </div>
          </div>
        </div>
      </div>

      {/* ── FAQ Section ────────────────────────────────────────────────── */}
      <div className="container-site py-12 max-w-3xl">
        <h2 className="text-2xl font-bold text-[#0F172A] mb-8">Frequently Asked Questions</h2>
        <div className="space-y-4">
          {faqSchema.mainEntity.map((item, i) => (
            <details key={i} className="group border border-slate-200 rounded-lg overflow-hidden">
              <summary className="flex items-center justify-between gap-4 p-5 cursor-pointer bg-white hover:bg-slate-50 transition-colors list-none">
                <span className="font-semibold text-[#0F172A] text-sm leading-snug">{item.name}</span>
                <span className="flex-shrink-0 w-5 h-5 text-[#0EA5E9] transition-transform group-open:rotate-180">
                  <svg viewBox="0 0 20 20" fill="currentColor"><path fillRule="evenodd" d="M5.293 7.293a1 1 0 011.414 0L10 10.586l3.293-3.293a1 1 0 111.414 1.414l-4 4a1 1 0 01-1.414 0l-4-4a1 1 0 010-1.414z" clipRule="evenodd" /></svg>
                </span>
              </summary>
              <div className="px-5 pb-5 text-[#64748B] text-sm leading-relaxed bg-white">
                {item.acceptedAnswer.text}
              </div>
            </details>
          ))}
        </div>
      </div>
      {/* ── Newsletter Signup ─────────────────────────────────────────── */}
      <div className="container-site py-10 max-w-3xl">
        
        {/* Related Links */}

        <div className="mt-10 mb-6">

          <RelatedLinks variant="crypto-review" title="Related Guides &amp; Reviews" />

        </div>
<NewsletterSignup />
      </div>
    </>
  )
}
