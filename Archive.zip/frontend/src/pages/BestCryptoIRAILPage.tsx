import StateGuideTemplate from '../components/StateGuideTemplate'

export default function BestCryptoIRAILPage() {
  return (
    <StateGuideTemplate
      stateName="Illinois"
      stateAbbr="IL"
      slug="illinois"
    />
  )
}
