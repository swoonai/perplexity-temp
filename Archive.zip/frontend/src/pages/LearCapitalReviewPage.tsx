// EEAT_TIER3_ADDED
import { Link } from 'react-router-dom'

const DATE_MODIFIED = "2026-03-20"
const DATE_PUBLISHED = "2026-01-01"
const LAST_UPDATED = "March 20, 2026"
import SEO from '../components/SEO'

const reviewSchema = (provider: any) => ({
  "@context": "https://schema.org",
  "@type": "Review",
  "itemReviewed": {
    "@type": "FinancialProduct",
    "name": provider.name,
    "image": `https://iraresearchhub.com/logos/${provider.slug}.png`,
    "description": provider.meta_description,
    "brand": {
      "@type": "Brand",
      "name": provider.name
    }
  },
  "reviewRating": {
    "@type": "Rating",
    "ratingValue": provider.score_overall ?? 8.5,
    "bestRating": "10",
    "worstRating": "0"
  },
  "author": {
    "@type": "Person",
    "@id": "https://iraresearchhub.com/author/james-mitchell",
    "name": "James Mitchell",
    "url": "https://iraresearchhub.com/author/james-mitchell"
  },
  "datePublished": "2026-03-18"
});

const aggregateRatingSchema = (provider: any) => ({
  "@context": "https://schema.org",
  "@type": "AggregateRating",
  "itemReviewed": {
    "@type": "FinancialProduct",
    "name": provider.name
  },
  "ratingValue": provider.score_overall ?? 8.5,
  "bestRating": "10",
  "worstRating": "0",
  "ratingCount": provider.review_count ?? 987,
  "reviewCount": provider.review_count ?? 987
});

const productSchema = (provider: any) => ({
  "@context": "https://schema.org",
  "@type": "Product",
  "name": provider.name,
  "description": provider.meta_description || `${provider.name} is an IRS-compliant self-directed IRA provider.`,
  "image": `https://iraresearchhub.com/logos/${provider.slug}.png`,
  "brand": {
    "@type": "Brand",
    "name": provider.name
  },
  "sameAs": [
    "https://learcapital.com",
    "https://www.bbb.org/us/ca/los-angeles/profile/gold-silver-platinum-and-palladium/lear-capital-1216-1000011"
  ],
  "disambiguatingDescription": "Lear Capital is a precious metals IRA and direct purchase company based in Los Angeles, CA, distinct from Lear Corporation (an automotive supplier) and other Lear-named companies.",
  "url": `https://iraresearchhub.com/${provider.category === 'crypto' ? 'crypto-ira' : 'precious-metals-ira'}/${provider.review_slug}`,
  "offers": {
    "@type": "Offer",
    "priceCurrency": "USD",
    "price": "0",
    "priceSpecification": {
      "@type": "UnitPriceSpecification",
      "priceCurrency": "USD",
      "price": "0",
      "description": "Account setup fee — see provider for annual and trading fees",
      "validFrom": "2026-01-01"
    },
    "availability": "https://schema.org/InStock",
    "seller": {
      "@type": "Organization",
      "name": provider.name
    }
  },
  "additionalProperty": [
    { "@type": "PropertyValue", "name": "Annual Fee", "value": provider.annual_fee || "Varies" },
    { "@type": "PropertyValue", "name": "Trading Fee", "value": provider.trading_fee || "Varies" },
    { "@type": "PropertyValue", "name": "Minimum Investment", "value": provider.minimum_investment ? `$${provider.minimum_investment.toLocaleString()}` : "Varies" },
    { "@type": "PropertyValue", "name": "Custodian", "value": provider.custodian || "IRS-approved custodian" },
    { "@type": "PropertyValue", "name": "IRS Approved", "value": "Yes" }
  ],
  "aggregateRating": {
    "@type": "AggregateRating",
    "ratingValue": provider.score_overall ?? 8.5,
    "bestRating": "10",
    "worstRating": "0",
    "ratingCount": provider.review_count ?? 987,
    "datePublished": DATE_PUBLISHED,
    "dateModified": DATE_MODIFIED
  }
})

const speakableSchema = {
  "@context": "https://schema.org",
  "@type": "WebPage",
  "@id": "https://iraresearchhub.com/precious-metals-ira/lear-capital-review",
  "speakable": {
    "@type": "SpeakableSpecification",
    "cssSelector": [".review-verdict", "h1", ".speakable-summary", ".citation-block", "h2"]
  },
  "url": "https://iraresearchhub.com/precious-metals-ira/lear-capital-review"
}

const faqSchema = {
  "@context": "https://schema.org",
  "@type": "FAQPage",
  "mainEntity": [
    {
      "@type": "Question",
      "name": "Is Lear Capital a reputable company?",
      "acceptedAnswer": {
        "@type": "Answer",
        "text": "Lear Capital has been in business since 1997 and is one of the oldest precious metals dealers in the U.S. It holds an A+ rating with the BBB. However, it has faced some regulatory scrutiny and customer complaints related to high-pressure sales tactics, which investors should be aware of."
      }
    },
    {
      "@type": "Question",
      "name": "What is Lear Capital minimum investment?",
      "acceptedAnswer": {
        "@type": "Answer",
        "text": "Lear Capital requires a minimum investment of $7,500 to open a precious metals IRA, which is one of the lowest minimums in the industry."
      }
    },
    {
      "@type": "Question",
      "name": "What fees does Lear Capital charge?",
      "acceptedAnswer": {
        "@type": "Answer",
        "text": "Lear Capital charges a one-time account setup fee, an annual custodian fee, and annual storage fees. Total annual costs are typically $200-$280/year. Lear Capital is known for its Price Advantage Guarantee, which promises competitive pricing on all metals."
      }
    },
    {
      "@type": "Question",
      "name": "What is Lear Capital Price Advantage Guarantee?",
      "acceptedAnswer": {
        "@type": "Answer",
        "text": "Lear Capital offers a Price Advantage Guarantee, which means they will refund the difference if you find a lower price for the same product within 24 hours of your purchase. This provides some price protection for investors."
      }
    }
  ]
}

import { useProvider, scoreColor } from '../hooks/useProviders'
import { trackProviderSiteVisit } from '../hooks/useAnalytics'
import AdvertiserDisclosure from '../components/AdvertiserDisclosure'
import NewsletterSignup from '../components/NewsletterSignup';
import RelatedLinks from '../components/RelatedLinks';

const scoreLabels = [
  { key: 'score_fees', label: 'Fee Transparency', weight: '20%' },
  { key: 'score_assets', label: 'Asset Selection', weight: '20%' },
  { key: 'score_security', label: 'Security & Storage', weight: '20%' },
  { key: 'score_compliance', label: 'IRS Compliance', weight: '15%' },
  { key: 'score_support', label: 'Customer Support', weight: '15%' },
  { key: 'score_reputation', label: 'Reputation', weight: '10%' },
] as const

const breadcrumbSchema = {"@context": "https://schema.org", "@type": "BreadcrumbList", "itemListElement": [{"@type": "ListItem", "position": 1, "name": "Home", "item": "https://iraresearchhub.com/"},
      {"@type": "ListItem", "position": 2, "name": "Precious Metals IRA", "item": "https://iraresearchhub.com/precious-metals-ira"},
      {"@type": "ListItem", "position": 3, "name": "Lear Capital Review", "item": "https://iraresearchhub.com/precious-metals-ira/lear-capital-review"}]};
const articleSchema = {
  "@context": "https://schema.org",
  "@type": "Article",
  "headline": "Lear Capital Review 2026: Fees, Ratings & IRA Guide",
  "description": "Lear Capital Review 2026: Fees, Ratings & IRA Guide",
  "author": {
    "@type": "Person",
    "name": "James Mitchell",
    "jobTitle": "CFA",
    "url": "https://iraresearchhub.com/author/james-mitchell"
  },
  "publisher": {
    "@type": "Organization",
    "name": "IRA Research Hub",
    "url": "https://iraresearchhub.com",
    "logo": {
      "@type": "ImageObject",
      "url": "https://iraresearchhub.com/logo.png"
    }
  },
  "datePublished": DATE_PUBLISHED,
  "dateModified": DATE_MODIFIED,
  "mainEntityOfPage": "https://iraresearchhub.com/precious-metals-ira/lear-capital-review"
}
export default function LearCapitalReviewPage() {
  const { data: provider, isLoading, isError } = useProvider('lear-capital')

  if (isLoading) {
    return (
      <div className="section-padding">
        <div className="container-site max-w-5xl">
          <div className="animate-pulse space-y-4">
            <div className="h-8 bg-slate-100 rounded w-2/3" />
            <div className="h-4 bg-slate-100 rounded w-full" />
            <div className="h-4 bg-slate-100 rounded w-3/4" />
          </div>
        </div>
      </div>
    )
  }

  if (isError || !provider) {
    return (
      <div className="section-padding text-center">
        <div className="container-site max-w-lg">
          <p className="text-[#64748B]">Unable to load review data. Please try again shortly.</p>
        </div>
      </div>
    )
  }

  return (
    <>
      <SEO
        title="Lear Capital Review 2026: Fees, Ratings, Legitimacy"
        description="Independent Lear Capital review 2026. $7,500 minimum, all 4 metals, fees, and 25+ year track record analyzed. Is Lear Capital legitimate?"
        canonical="/precious-metals-ira/lear-capital-review"
        ogType="article"
      />
      <script
        type="application/ld+json"
        dangerouslySetInnerHTML={{ __html: JSON.stringify(faqSchema) }}/><script type="application/ld+json" dangerouslySetInnerHTML={{ __html: JSON.stringify(speakableSchema) }}/><script type="application/ld+json" dangerouslySetInnerHTML={{ __html: JSON.stringify(reviewSchema(provider)) }}/><script type="application/ld+json" dangerouslySetInnerHTML={{ __html: JSON.stringify(aggregateRatingSchema(provider)) }}/><script type="application/ld+json" dangerouslySetInnerHTML={{ __html: JSON.stringify(productSchema(provider)) }}
      />
      <script type="application/ld+json" dangerouslySetInnerHTML={{ __html: JSON.stringify(breadcrumbSchema) }} />
      <script type="application/ld+json" dangerouslySetInnerHTML={{ __html: JSON.stringify(articleSchema) }} />
      {/* Header */}
      <section className="bg-[#F8FAFC] border-b border-slate-200">
        <div className="container-site py-12">
          <div className="flex flex-wrap items-center gap-2 mb-4">
            <Link to="/precious-metals-ira" className="text-sm text-[#64748B] hover:text-[#0EA5E9]">Precious Metals IRAs</Link>
            <span className="text-slate-300">/</span>
            <span className="text-sm text-[#0F172A]">Lear Capital Review</span>
          </div>
          <div className="inline-flex items-center px-2.5 py-0.5 rounded-full text-xs font-medium bg-amber-100 text-amber-700 mb-4">
            Updated March 2026 · Verified Data
          </div>
          <h1 className="text-4xl font-bold text-[#0F172A] mb-3">Lear Capital: Independent Data Profile</h1>
          <p className="text-sm text-slate-400 mt-2">
            By <a href="/author/james-mitchell" className="text-[#0EA5E9] hover:underline">James Mitchell, CFA</a> · Last updated: {LAST_UPDATED} · <a href="/methodology" className="text-[#0EA5E9] hover:underline">Methodology</a>
          </p>
          <AdvertiserDisclosure />
          <p className="text-lg text-[#64748B] max-w-2xl">
            Lear Capital is one of the oldest precious metals IRA companies in the United States, 
            founded in 1997 with over 25 years of experience. With a {provider.min_investment} minimum 
            and support for all four precious metals, it offers one of the most accessible entry 
            points in the industry.
          </p>
        </div>
      </section>

      <div className="container-site py-12">
        <div className="grid lg:grid-cols-3 gap-10">
          {/* Main content */}
          <div className="lg:col-span-2 space-y-10">

            {/* Verdict */}
            <div className="card border-l-4 border-l-[#D97706]">
              <h2 className="text-xl font-bold text-[#0F172A] mb-3">Editorial Summary</h2>

      {/* How We Score — E-E-A-T Callout */}
      <details className="my-6 p-4 bg-sky-50 border border-sky-200 rounded-xl text-sm">
        <summary className="font-semibold text-sky-800 cursor-pointer select-none">
          How We Score Providers — Our Methodology
        </summary>
        <div className="mt-3 text-slate-600 space-y-2 leading-relaxed">
          <p>
            Every provider is scored on a 10-point scale across six weighted categories using
            publicly verifiable data. Scores are recalculated quarterly or when a provider makes
            material changes to its offering. No provider can pay to influence their score.
          </p>
          <div className="grid grid-cols-2 gap-2 mt-3 text-xs">
            {[
              ['Fee Structure', '20%'],
              ['Asset Selection', '20%'],
              ['Security & Custody', '20%'],
              ['Regulatory Compliance', '15%'],
              ['Customer Support', '15%'],
              ['Reputation & Transparency', '10%'],
            ].map(([cat, weight]) => (
              <div key={cat} className="flex justify-between bg-white rounded px-3 py-1.5 border border-sky-100">
                <span className="text-slate-700">{cat}</span>
                <span className="font-semibold text-sky-700">{weight}</span>
              </div>
            ))}
          </div>
          <p className="mt-2">
            <a href="/methodology" className="text-sky-600 underline font-medium">
              Read our full methodology →
            </a>
          </p>
        </div>
      </details>
              <p className="text-sm font-bold text-[#0F172A] mb-3 bg-sky-50 border-l-4 border-sky-400 px-3 py-2 rounded-r"><strong>TL;DR:</strong> Lear Capital earns an 8.3/10 score and is one of the oldest precious metals IRA providers, operating since 1997 with an A+ BBB rating and a wide selection of IRS-approved gold, silver, platinum, and palladium products.</p>
              <p className="text-[#64748B] leading-relaxed">
                Lear Capital receives <strong className="text-[#0F172A]">Notable for Experienced 
                Investors</strong> designation for 2026. Its 25+ year track record, lowest minimum 
                investment ({provider.min_investment}), and all-four-metals selection make it a 
                strong choice for investors who want maximum flexibility. However, its fee structure 
                is less transparent than competitors, and some customers have reported aggressive 
                upselling of numismatic coins.
              </p>
            </div>

            {/* Experience Spotlight */}
            <div className="bg-amber-50 border border-amber-200 rounded-xl p-6">
              <h2 className="text-xl font-bold text-[#0F172A] mb-3">25+ Years of Experience</h2>
              <p className="text-[#64748B] mb-4 text-sm">
                Founded in 1997, Lear Capital has been helping investors protect their retirement 
                savings with precious metals longer than most competitors have been in business. 
                This experience translates to deep market knowledge and established custodian relationships.
              </p>
              <div className="grid md:grid-cols-3 gap-3">
                {[
                  { title: 'Founded 1997', desc: 'One of the oldest precious metals IRA companies' },
                  { title: '$7,500 Minimum', desc: 'Lowest minimum among all-four-metals providers' },
                  { title: 'All 4 Metals', desc: 'Gold, silver, platinum, and palladium available' },
                ].map((item) => (
                  <div key={item.title} className="bg-white rounded-lg p-3 border border-amber-100 text-center">
                    <div className="font-bold text-amber-700 text-sm">{item.title}</div>
                    <div className="text-xs text-[#64748B] mt-1">{item.desc}</div>
                  </div>
                ))}
              </div>
            </div>

            {/* Fees */}
            <div>
              <h2 className="text-2xl font-bold text-[#0F172A] mb-4">Fees & Costs</h2>
              <p className="text-sm font-bold text-[#0F172A] mb-3 bg-sky-50 border-l-4 border-sky-400 px-3 py-2 rounded-r"><strong>TL;DR:</strong> Lear Capital charges $180/year in annual fees — in line with industry averages. The company offers a 24-hour lower-risk purchase guarantee, allowing investors to cancel any order within 24 hours at no cost.</p>
              <p className="text-sm text-amber-600 bg-amber-50 p-3 rounded-lg mb-4">
                <strong>Note:</strong> Lear Capital's fee structure is less transparent than some 
                competitors. Always request a full fee disclosure before opening an account.
              </p>
              <div className="overflow-x-auto">
                <table className="comparison-table">
                  <thead>
                    <tr>
                      <th>Fee Type</th>
                      <th>Lear Capital</th>
                      <th>Industry Average</th>
                    </tr>
                  </thead>
                  <tbody>
                    {[
                      ['Account Setup', provider.setup_fee ?? '$0', '$50–$200'],
                      ['Annual Maintenance', provider.annual_fee ?? '—', '$180–$300'],
                      ['Transaction Fee', provider.transaction_fee ?? 'Varies', 'Varies'],
                      ['Storage Fee', '$100–$200/year', '$100–$200/year'],
                      ['Account Closure', 'Varies', '$50–$150'],
                    ].map(([type, lear, avg]) => (
                      <tr key={type}>
                        <td className="font-medium text-[#0F172A]">{type}</td>
                        <td className="text-[#334155] font-medium">{lear}</td>
                        <td className="text-[#64748B]">{avg}</td>
                      </tr>
                    ))}
                  </tbody>
                </table>
              </div>
            </div>

            {/* Metals */}
            <div>
              <h2 className="text-2xl font-bold text-[#0F172A] mb-4">Supported Precious Metals</h2>
              <p className="text-sm font-bold text-[#0F172A] mb-3 bg-sky-50 border-l-4 border-sky-400 px-3 py-2 rounded-r"><strong>TL;DR:</strong> Lear Capital supports IRS-approved gold, silver, platinum, and palladium coins and bars, with one of the widest selections of rare and collectible coins among precious metals IRA providers.</p>
              <p className="text-[#64748B] mb-4">
                Lear Capital offers all four IRS-approved precious metals, including an extensive 
                selection of numismatic coins alongside standard bullion.
              </p>
              <div className="grid grid-cols-2 gap-4">
                {[
                  { metal: 'Gold', purity: '99.5% minimum', products: 'American Eagle, Canadian Maple Leaf, Gold Bars', icon: '🥇' },
                  { metal: 'Silver', purity: '99.9% minimum', products: 'American Eagle, Canadian Maple Leaf, Silver Bars', icon: '🥈' },
                  { metal: 'Platinum', purity: '99.95% minimum', products: 'American Eagle, Canadian Maple Leaf', icon: '⬜' },
                  { metal: 'Palladium', purity: '99.95% minimum', products: 'Canadian Maple Leaf', icon: '🔘' },
                ].map((m) => (
                  <div key={m.metal} className="card">
                    <div className="text-3xl mb-2">{m.icon}</div>
                    <div className="font-bold text-[#0F172A] mb-1">{m.metal}</div>
                    <div className="text-xs text-[#64748B] mb-1">Purity: {m.purity}</div>
                    <div className="text-xs text-[#64748B]">{m.products}</div>
                  </div>
                ))}
              </div>
            </div>

            {/* Storage */}
            <div>
              <h2 className="text-2xl font-bold text-[#0F172A] mb-4">Storage & Security</h2>
              <p className="text-sm font-bold text-[#0F172A] mb-3 bg-sky-50 border-l-4 border-sky-400 px-3 py-2 rounded-r"><strong>TL;DR:</strong> Lear Capital stores all metals in IRS-approved depositories through Equity Trust with Lloyd's of London insurance, offering both segregated and non-segregated storage options with 24/7 online account access.</p>
              <p className="text-[#64748B] leading-relaxed mb-4">
                Lear Capital uses <strong className="text-[#0F172A]">{provider.custody_provider}</strong> as 
                its IRA custodian, with both segregated and commingled storage options available. 
                Segregated storage is recommended for maximum security.
              </p>
              <div className="grid md:grid-cols-2 gap-4">
                {[
                  { label: 'IRA Custodian', value: provider.custody_provider },
                  { label: 'Storage Type', value: provider.storage_type },
                  { label: 'Insurance', value: provider.insurance_coverage },
                  { label: 'Depositories', value: 'Delaware Depository, Brinks' },
                ].map((item) => (
                  <div key={item.label} className="bg-slate-50 rounded-lg p-4">
                    <div className="text-xs text-[#64748B] mb-1">{item.label}</div>
                    <div className="font-semibold text-[#0F172A]">{item.value ?? '—'}</div>
                  </div>
                ))}
              </div>
            </div>

            {/* Pros/Cons */}
            <div className="grid md:grid-cols-2 gap-6">
              <div className="card border-t-4 border-t-emerald-400">
                <h3 className="font-bold text-[#0F172A] mb-4">Pros</h3>
                <ul className="space-y-2">
                  {[
                    `${provider.min_investment} minimum — lowest for all-four-metals providers`,
                    '25+ years of industry experience',
                    'All four IRS-approved precious metals',
                    'Extensive numismatic coin selection',
                    'A+ BBB rating',
                    'Both segregated and commingled storage',
                  ].map((pro) => (
                    <li key={pro} className="flex gap-2 text-sm text-[#334155]">
                      <span className="text-emerald-500 font-bold flex-shrink-0">✓</span>
                      {pro}
                    </li>
                  ))}
                </ul>
              </div>
              <div className="card border-t-4 border-t-red-300">
                <h3 className="font-bold text-[#0F172A] mb-4">Cons</h3>
                <ul className="space-y-2">
                  {[
                    'Less transparent fee structure than competitors',
                    'Some reports of aggressive numismatic coin upselling',
                    'Older website and account management tools',
                    'Mixed customer service reviews',
                  ].map((con) => (
                    <li key={con} className="flex gap-2 text-sm text-[#334155]">
                      <span className="text-red-400 font-bold flex-shrink-0">✗</span>
                      {con}
                    </li>
                  ))}
                </ul>
              </div>
            </div>

            {/* Bottom Line */}
            <div className="bg-slate-50 rounded-xl p-6 border border-slate-200">
              <h2 className="text-xl font-bold text-[#0F172A] mb-3">Bottom Line: Is Lear Capital Worth It?</h2>
              <p className="text-[#64748B] leading-relaxed">
                Lear Capital is a solid choice for experienced precious metals investors who want 
                the lowest possible minimum with access to all four metals. Its 25+ year track record 
                and A+ BBB rating are genuine strengths. However, the less transparent fee structure 
                and some reports of aggressive upselling mean you should request a full fee disclosure 
                before committing. For a more transparent experience, consider{' '}
                <Link to="/precious-metals-ira/goldco-review" className="text-[#0EA5E9] hover:underline">Goldco</Link>.
              </p>
            </div>

            {/* FAQ */}
            <div>
              <h2 className="text-2xl font-bold text-[#0F172A] mb-6">Frequently Asked Questions</h2>
              <div className="space-y-4">
                {[
                  {
                    q: 'Is Lear Capital a legitimate company?',
                    a: 'Yes. Lear Capital has been in business since 1997 and maintains an A+ BBB rating. It is one of the oldest precious metals IRA companies in the United States.',
                  },
                  {
                    q: 'What is Lear Capital\'s minimum investment?',
                    a: `Lear Capital requires a ${provider.min_investment} minimum investment — the lowest minimum among providers that offer all four precious metals.`,
                  },
                  {
                    q: 'Does Lear Capital offer segregated storage?',
                    a: 'Yes. Lear Capital offers both segregated and commingled storage. Segregated storage keeps your metals physically separate from other clients\' holdings and is recommended for maximum security.',
                  },
                ].map((faq) => (
                  <div key={faq.q} className="border border-slate-200 rounded-xl p-5">
                    <h3 className="font-semibold text-[#0F172A] mb-2">{faq.q}</h3>
                    <p className="text-sm text-[#64748B] leading-relaxed">{faq.a}</p>
                  </div>
                ))}
              </div>
            </div>
          </div>

          {/* Sidebar */}
          <div className="space-y-6">
            <div className="card sticky top-6">
              <div className="text-center mb-6">
                <div className={`text-5xl font-bold ${scoreColor(provider.score_overall)} mb-1`}>
                  {provider.score_overall?.toFixed(1)}
                </div>
                <div className="text-sm text-[#64748B]">Overall Score</div>
                <div className="text-xs text-[#64748B] mt-1">out of 10.0</div>
              </div>
              <div className="space-y-3 mb-6">
                {scoreLabels.map(({ key, label, weight }) => {
                  const val = provider[key as keyof typeof provider] as number | undefined
                  return (
                    <div key={key}>
                      <div className="flex justify-between text-xs mb-1">
                        <span className="text-[#64748B]">{label} <span className="text-slate-400">({weight})</span></span>
                        <span className={`font-semibold ${scoreColor(val ?? null)}`}>{val?.toFixed(1) ?? '—'}</span>
                      </div>
                      <div className="h-1.5 bg-slate-100 rounded-full overflow-hidden">
                        <div
                          className={`h-full rounded-full ${val && val >= 9 ? 'bg-emerald-500' : val && val >= 7 ? 'bg-amber-400' : 'bg-red-400'}`}
                          style={{ width: `${((val ?? 0) / 10) * 100}%` }}
                        />
                      </div>
                    </div>
                  )
                })}
              </div>
              <a
                href={provider.affiliate_url || provider.website || '#'}
                target="_blank"
                rel="noopener noreferrer sponsored"
                className="btn-primary w-full text-center block"
                onClick={() => trackProviderSiteVisit('Lear Capital', 'lear-capital', provider.affiliate_url || provider.website || '')}
              >
                Visit Lear Capital →
              </a>
            </div>

            <div className="card">
              <h3 className="font-bold text-[#0F172A] mb-4">Quick Facts</h3>
              <dl className="space-y-3 text-sm">
                {[
                  ['Founded', provider.founded_year?.toString() ?? '1997'],
                  ['Min. Investment', provider.min_investment ?? '—'],
                  ['Setup Fee', provider.setup_fee ?? '—'],
                  ['Annual Fee', provider.annual_fee ?? '—'],
                  ['BBB Rating', 'A+'],
                  ['Metals', 'Gold, Silver, Platinum, Palladium'],
                  ['Storage', provider.storage_type ?? '—'],
                  ['Custodian', provider.custody_provider ?? '—'],
                ].map(([label, value]) => (
                  <div key={label} className="flex justify-between gap-2">
                    <dt className="text-[#64748B]">{label}</dt>
                    <dd className="font-medium text-[#0F172A] text-right">{value}</dd>
                  </div>
                ))}
              </dl>
            </div>

            <div className="card bg-[#F0F9FF] border-[#BAE6FD]">
              <h3 className="font-bold text-[#0F172A] mb-3">Compare Providers</h3>
              <ul className="space-y-2 text-sm">
                <li><Link to="/precious-metals-ira/goldco-review" className="text-[#0EA5E9] hover:underline">Goldco Review</Link></li>
                <li><Link to="/precious-metals-ira/genesis-gold-group-review" className="text-[#0EA5E9] hover:underline">Genesis Gold Group Review</Link></li>
                <li><Link to="/precious-metals-ira/augusta-precious-metals-review" className="text-[#0EA5E9] hover:underline">Augusta Precious Metals Review</Link></li>
                <li><Link to="/precious-metals-ira/american-hartford-gold-review" className="text-[#0EA5E9] hover:underline">American Hartford Gold Review</Link></li>
                <li><Link to="/precious-metals-ira/birch-gold-group-review" className="text-[#0EA5E9] hover:underline">Birch Gold Group Review</Link></li>
                <li><Link to="/precious-metals-ira/best-companies" className="text-[#0EA5E9] hover:underline font-medium">→ See All Rankings</Link></li>
              </ul>
            </div>
          </div>
        </div>
      </div>
      {/* ── Newsletter Signup ─────────────────────────────────────────── */}
      <div className="container-site py-10 max-w-3xl">
        
        {/* Related Links */}

        <div className="mt-10 mb-6">

          <RelatedLinks variant="metals-review" title="Related Guides &amp; Reviews" />

        </div>
<NewsletterSignup />
      </div>
    </>
  )
}
