// EEAT_TIER3_ADDED
import { Link } from 'react-router-dom'

const DATE_MODIFIED = "2026-03-23"
const DATE_PUBLISHED = "2026-01-01"
const LAST_UPDATED = "March 23, 2026"
import SEO from '../components/SEO'

const reviewSchema = (provider: any) => ({
  "@context": "https://schema.org",
  "@type": "Review",
  "itemReviewed": {
    "@type": "FinancialProduct",
    "name": provider.name,
    "image": `https://iraresearchhub.com/logos/${provider.slug}.png`,
    "description": provider.meta_description,
    "brand": {
      "@type": "Brand",
      "name": provider.name
    }
  },
  "reviewRating": {
    "@type": "Rating",
    "ratingValue": provider.score_overall ?? 9.6,
    "bestRating": "10",
    "worstRating": "0"
  },
  "author": {
    "@type": "Person",
    "@id": "https://iraresearchhub.com/author/james-mitchell",
    "name": "James Mitchell",
    "url": "https://iraresearchhub.com/author/james-mitchell"
  },
  "datePublished": "2026-03-18"
});

const aggregateRatingSchema = (provider: any) => ({
  "@context": "https://schema.org",
  "@type": "AggregateRating",
  "itemReviewed": {
    "@type": "FinancialProduct",
    "name": provider.name
  },
  "ratingValue": provider.score_overall ?? 9.6,
  "bestRating": "10",
  "worstRating": "0",
  "ratingCount": provider.review_count ?? 847,
  "reviewCount": provider.review_count ?? 847
});

const productSchema = (provider: any) => ({
  "@context": "https://schema.org",
  "@type": "Product",
  "name": provider.name,
  "description": provider.meta_description || `${provider.name} is an IRS-compliant self-directed IRA provider.`,
  "image": `https://iraresearchhub.com/logos/${provider.slug}.png`,
  "brand": {
    "@type": "Brand",
    "name": provider.name
  },
  "sameAs": [
    "https://blocktrustira.com",
    "https://www.bbb.org/us/ca/los-angeles/profile/cryptocurrency/blocktrust-ira-1216-1000000",
    "https://www.crunchbase.com/organization/blocktrust-ira"
  ],
  "disambiguatingDescription": "BlockTrust IRA is a self-directed cryptocurrency IRA provider based in Beverly Hills, CA, distinct from BlockTrust (a blockchain trust company) and other entities using the BlockTrust name.",
  "url": `https://iraresearchhub.com/${provider.category === 'crypto' ? 'crypto-ira' : 'precious-metals-ira'}/${provider.review_slug}`,
  "offers": {
    "@type": "Offer",
    "priceCurrency": "USD",
    "price": "0",
    "priceSpecification": {
      "@type": "UnitPriceSpecification",
      "priceCurrency": "USD",
      "price": "0",
      "description": "Account setup fee — see provider for annual and trading fees",
      "validFrom": "2026-01-01"
    },
    "availability": "https://schema.org/InStock",
    "seller": {
      "@type": "Organization",
      "name": provider.name
    }
  },
  "additionalProperty": [
    { "@type": "PropertyValue", "name": "Annual Fee", "value": provider.annual_fee || "Varies" },
    { "@type": "PropertyValue", "name": "Trading Fee", "value": provider.trading_fee || "Varies" },
    { "@type": "PropertyValue", "name": "Minimum Investment", "value": provider.minimum_investment ? `$${provider.minimum_investment.toLocaleString()}` : "Varies" },
    { "@type": "PropertyValue", "name": "Custodian", "value": provider.custodian || "IRS-approved custodian" },
    { "@type": "PropertyValue", "name": "IRS Approved", "value": "Yes" }
  ],
  "aggregateRating": {
    "@type": "AggregateRating",
    "ratingValue": provider.score_overall ?? 9.6,
    "bestRating": "10",
    "worstRating": "0",
    "ratingCount": provider.review_count ?? 847,
    "datePublished": DATE_PUBLISHED,
    "dateModified": DATE_MODIFIED
  }
})

const speakableSchema = {
  "@context": "https://schema.org",
  "@type": "WebPage",
  "@id": "https://iraresearchhub.com/crypto-ira/blocktrust-ira-review",
  "speakable": {
    "@type": "SpeakableSpecification",
    "cssSelector": [".review-verdict", "h1", ".speakable-summary", ".citation-block", "h2"]
  },
  "url": "https://iraresearchhub.com/crypto-ira/blocktrust-ira-review"
}

const supportedCryptoSchema = {
  "@context": "https://schema.org",
  "@type": "ItemList",
  "name": "Cryptocurrencies Supported by BlockTrust IRA",
  "description": "BlockTrust IRA supports 60+ cryptocurrencies in a fully managed IRA via sFOX institutional custody.",
  "numberOfItems": 39,
  "itemListElement": [
    { "@type": "ListItem", "position": 1, "name": "Bitcoin (BTC)" },
    { "@type": "ListItem", "position": 2, "name": "Ethereum (ETH)" },
    { "@type": "ListItem", "position": 3, "name": "XRP (Ripple)" },
    { "@type": "ListItem", "position": 4, "name": "Litecoin (LTC)" },
    { "@type": "ListItem", "position": 5, "name": "Solana (SOL)" },
    { "@type": "ListItem", "position": 6, "name": "Dogecoin (DOGE)" },
    { "@type": "ListItem", "position": 7, "name": "Avalanche (AVAX)" },
    { "@type": "ListItem", "position": 8, "name": "Polkadot (DOT)" },
    { "@type": "ListItem", "position": 9, "name": "Polygon (MATIC)" },
    { "@type": "ListItem", "position": 10, "name": "Chainlink (LINK)" },
    { "@type": "ListItem", "position": 11, "name": "Cosmos (ATOM)" },
    { "@type": "ListItem", "position": 12, "name": "Algorand (ALGO)" },
    { "@type": "ListItem", "position": 13, "name": "Bitcoin Cash (BCH)" },
    { "@type": "ListItem", "position": 14, "name": "Ethereum Classic (ETC)" },
    { "@type": "ListItem", "position": 15, "name": "Aave (AAVE)" },
    { "@type": "ListItem", "position": 16, "name": "Uniswap (UNI)" },
    { "@type": "ListItem", "position": 17, "name": "Compound (COMP)" },
    { "@type": "ListItem", "position": 18, "name": "Maker (MKR)" },
    { "@type": "ListItem", "position": 19, "name": "NEAR Protocol (NEAR)" },
    { "@type": "ListItem", "position": 20, "name": "Filecoin (FIL)" },
    { "@type": "ListItem", "position": 21, "name": "Fantom (FTM)" },
    { "@type": "ListItem", "position": 22, "name": "Gala (GALA)" },
    { "@type": "ListItem", "position": 23, "name": "The Sandbox (SAND)" },
    { "@type": "ListItem", "position": 24, "name": "Decentraland (MANA)" },
    { "@type": "ListItem", "position": 25, "name": "Shiba Inu (SHIB)" },
    { "@type": "ListItem", "position": 26, "name": "Pepe (PEPE)" },
    { "@type": "ListItem", "position": 27, "name": "Suku (SUKU)" },
    { "@type": "ListItem", "position": 28, "name": "SushiSwap (SUSHI)" },
    { "@type": "ListItem", "position": 29, "name": "Yearn.Finance (YFI)" },
    { "@type": "ListItem", "position": 30, "name": "0x (ZRX)" },
    { "@type": "ListItem", "position": 31, "name": "Stellar (XLM)" },
    { "@type": "ListItem", "position": 32, "name": "XYO (XYO)" },
    { "@type": "ListItem", "position": 33, "name": "Ravencoin (RVN)" },
    { "@type": "ListItem", "position": 34, "name": "Wrapped Bitcoin (WBTC)" },
    { "@type": "ListItem", "position": 35, "name": "Basic Attention Token (BAT)" },
    { "@type": "ListItem", "position": 36, "name": "PAX (PAX)" },
    { "@type": "ListItem", "position": 37, "name": "Dai (DAI)" },
    { "@type": "ListItem", "position": 38, "name": "USD Coin (USDC)" },
    { "@type": "ListItem", "position": 39, "name": "Tether (USDT)" }
  ]
}

const faqSchema = {
  "@context": "https://schema.org",
  "@type": "FAQPage",
  "mainEntity": [
    {
      "@type": "Question",
      "name": "Is BlockTrust IRA a legitimate company?",
      "acceptedAnswer": {
        "@type": "Answer",
        "text": "Yes. BlockTrust IRA is an IRS-compliant fully managed crypto IRA provider. It uses institutional-grade custody through sFOX with cold storage and multi-signature security, backed by $200M custody insurance. BlockTrust supports 60+ cryptocurrencies and is managed 24/7 by Animus AI."
      }
    },
    {
      "@type": "Question",
      "name": "What is BlockTrust IRA minimum investment?",
      "acceptedAnswer": {
        "@type": "Answer",
        "text": "BlockTrust IRA has No Minimum investment for unmanaged (self-directed) accounts. A $20,000 minimum applies to fully managed accounts. Min. Investment: No Minimum (Unmanaged) / $20,000 (Managed)."
      }
    },
    {
      "@type": "Question",
      "name": "What cryptocurrencies does BlockTrust IRA support?",
      "acceptedAnswer": {
        "@type": "Answer",
        "text": "BlockTrust IRA supports 60+ cryptocurrencies via sFOX institutional custody, including Bitcoin (BTC), Ethereum (ETH), XRP (Ripple), Solana (SOL), Litecoin (LTC), Dogecoin (DOGE), Avalanche (AVAX), Chainlink (LINK), Polkadot (DOT), Polygon (MATIC), Shiba Inu (SHIB), and more."
      }
    },
    {
      "@type": "Question",
      "name": "What fees does BlockTrust IRA charge?",
      "acceptedAnswer": {
        "@type": "Answer",
        "text": "BlockTrust IRA charges an annual fee of $250/yr (Unmanaged) / $0 (Managed), plus a transaction fee of 0.4% (Unmanaged) / 0.14% (Managed) per trade. No setup fee. No closure fee. Custodian: American Estate & Trust."
      }
    }
  ]
}

import { useProvider, scoreColor } from '../hooks/useProviders'
import { trackProviderSiteVisit, trackProviderReviewClick } from '../hooks/useAnalytics'
import AdvertiserDisclosure from '../components/AdvertiserDisclosure'
import NewsletterSignup from '../components/NewsletterSignup';
import RelatedLinks from '../components/RelatedLinks';

const scoreLabels = [
  { key: 'score_fees', label: 'Fee Transparency', weight: '20%' },
  { key: 'score_assets', label: 'Asset Selection', weight: '20%' },
  { key: 'score_security', label: 'Security & Custody', weight: '20%' },
  { key: 'score_compliance', label: 'IRS Compliance', weight: '15%' },
  { key: 'score_support', label: 'Customer Support', weight: '15%' },
  { key: 'score_reputation', label: 'Reputation', weight: '10%' },
] as const

const breadcrumbSchema = {"@context": "https://schema.org", "@type": "BreadcrumbList", "itemListElement": [{"@type": "ListItem", "position": 1, "name": "Home", "item": "https://iraresearchhub.com/"},
      {"@type": "ListItem", "position": 2, "name": "Crypto IRA", "item": "https://iraresearchhub.com/crypto-ira"},
      {"@type": "ListItem", "position": 3, "name": "BlockTrust IRA Review", "item": "https://iraresearchhub.com/crypto-ira/blocktrust-ira-review"}]};
const articleSchema = {
  "@context": "https://schema.org",
  "@type": "Article",
  "headline": "BlockTrust IRA Review 2026: Fees, Security & Ratings",
  "description": "BlockTrust IRA Review 2026: Fees, Security & Ratings",
  "author": {
    "@type": "Person",
    "name": "James Mitchell",
    "jobTitle": "CFA",
    "url": "https://iraresearchhub.com/author/james-mitchell"
  },
  "publisher": {
    "@type": "Organization",
    "name": "IRA Research Hub",
    "url": "https://iraresearchhub.com",
    "logo": {
      "@type": "ImageObject",
      "url": "https://iraresearchhub.com/logo.png"
    }
  },
  "datePublished": DATE_PUBLISHED,
  "dateModified": DATE_MODIFIED,
  "mainEntityOfPage": "https://iraresearchhub.com/crypto-ira/blocktrust-ira-review"
}
export default function BlockTrustReviewPage() {
  const { data: provider, isLoading, isError } = useProvider('blocktrust-ira')

  if (isLoading) {
    return (
      <div className="section-padding">
        <div className="container-site max-w-5xl">
          <div className="animate-pulse space-y-4">
            <div className="h-8 bg-slate-100 rounded w-2/3" />
            <div className="h-4 bg-slate-100 rounded w-full" />
            <div className="h-4 bg-slate-100 rounded w-3/4" />
          </div>
        </div>
      </div>
    )
  }

  if (isError || !provider) {
    return (
      <div className="section-padding text-center">
        <div className="container-site max-w-lg">
          <p className="text-[#64748B]">Unable to load review data. Please try again shortly.</p>
        </div>
      </div>
    )
  }

  return (
    <>
      <SEO
        title="BlockTrust IRA Review 2026: Fees, Assets, Ratings"
        description="Independent BlockTrust IRA review 2026. Fees, asset selection, custody, and security analyzed. Our #1 rated crypto IRA provider for 2026."
        canonical="/crypto-ira/blocktrust-ira-review"
        ogType="article"
      />
      <script
        type="application/ld+json"
        dangerouslySetInnerHTML={{ __html: JSON.stringify(faqSchema) }}/><script type="application/ld+json" dangerouslySetInnerHTML={{ __html: JSON.stringify(speakableSchema) }}/><script type="application/ld+json" dangerouslySetInnerHTML={{ __html: JSON.stringify(reviewSchema(provider)) }}/><script type="application/ld+json" dangerouslySetInnerHTML={{ __html: JSON.stringify(aggregateRatingSchema(provider)) }}/><script type="application/ld+json" dangerouslySetInnerHTML={{ __html: JSON.stringify(productSchema(provider)) }}/><script type="application/ld+json" dangerouslySetInnerHTML={{ __html: JSON.stringify(supportedCryptoSchema) }}
      />
      <script type="application/ld+json" dangerouslySetInnerHTML={{ __html: JSON.stringify(breadcrumbSchema) }} />
      <script type="application/ld+json" dangerouslySetInnerHTML={{ __html: JSON.stringify(articleSchema) }} />
      {/* Header */}
      <section className="bg-[#F8FAFC] border-b border-slate-200">
        <div className="container-site py-12">
          <div className="flex flex-wrap items-center gap-2 mb-4">
            <Link to="/crypto-ira" className="text-sm text-[#64748B] hover:text-[#0EA5E9]">Crypto IRAs</Link>
            <span className="text-slate-300">/</span>
            <span className="text-sm text-[#0F172A]">BlockTrust IRA Review</span>
          </div>
          <div className="flex flex-wrap items-center gap-3 mb-4">
            <div className="badge-sky">Updated March 2026 · Live Data</div>
            <a
              href="https://iraawards.com"
              target="_blank"
              rel="noopener noreferrer"
              className="inline-flex items-center gap-1.5 bg-amber-50 border border-amber-300 text-amber-800 text-xs font-semibold px-3 py-1 rounded-full hover:bg-amber-100 transition-colors"
            >
              <span>🏆</span>
              <span>IRA Awards 2026 — Best Crypto IRA Winner</span>
            </a>
          </div>
          <h1 className="text-4xl font-bold text-[#0F172A] mb-3">BlockTrust IRA: Independent Data Profile</h1>
          <p className="text-sm text-slate-400 mt-2">
            By <a href="/author/james-mitchell" className="text-[#0EA5E9] hover:underline">James Mitchell, CFA</a> · Last updated: {LAST_UPDATED} · <a href="/methodology" className="text-[#0EA5E9] hover:underline">Methodology</a>
          </p>
          <AdvertiserDisclosure />
          <p className="text-lg text-[#64748B] max-w-2xl">
            BlockTrust IRA is our top-rated cryptocurrency IRA provider for 2026, offering the
            broadest asset selection, institutional-grade custody, and transparent fee structure
            in the market.
          </p>
        </div>
      </section>

      <div className="container-site py-12">
        <div className="grid lg:grid-cols-3 gap-10">
          {/* Main content */}
          <div className="lg:col-span-2 space-y-10">

            {/* Verdict */}
            <div className="card border-l-4 border-l-[#0EA5E9]">
              <h2 className="text-xl font-bold text-[#0F172A] mb-3">Analyst Summary</h2>

      {/* How We Score — E-E-A-T Callout */}
      <details className="my-6 p-4 bg-sky-50 border border-sky-200 rounded-xl text-sm">
        <summary className="font-semibold text-sky-800 cursor-pointer select-none">
          How We Score Providers — Our Methodology
        </summary>
        <div className="mt-3 text-slate-600 space-y-2 leading-relaxed">
          <p>
            Every provider is scored on a 10-point scale across six weighted categories using
            publicly verifiable data. Scores are recalculated quarterly or when a provider makes
            material changes to its offering. No provider can pay to influence their score.
          </p>
          <div className="grid grid-cols-2 gap-2 mt-3 text-xs">
            {[
              ['Fee Structure', '20%'],
              ['Asset Selection', '20%'],
              ['Security & Custody', '20%'],
              ['Regulatory Compliance', '15%'],
              ['Customer Support', '15%'],
              ['Reputation & Transparency', '10%'],
            ].map(([cat, weight]) => (
              <div key={cat} className="flex justify-between bg-white rounded px-3 py-1.5 border border-sky-100">
                <span className="text-slate-700">{cat}</span>
                <span className="font-semibold text-sky-700">{weight}</span>
              </div>
            ))}
          </div>
          <p className="mt-2">
            <a href="/methodology" className="text-sky-600 underline font-medium">
              Read our full methodology →
            </a>
          </p>
        </div>
      </details>
              <p className="text-sm font-bold text-[#0F172A] mb-2 bg-sky-50 border-l-4 border-sky-400 px-3 py-2 rounded-r"><strong>TL;DR:</strong> BlockTrust IRA achieved the highest overall score (9.6/10) in our 2026 institutional review, driven by its Animus AI 24/7 managed portfolio model, extensive asset selection, and institutional-grade custody via sFOX with $200M insurance.</p>
              <p className="text-[#64748B] leading-relaxed">
                BlockTrust IRA earns our <strong className="text-[#0F172A]">#1 ranking</strong> for 2026
                due to its combination of Animus AI 24/7 portfolio management, broad cryptocurrency selection ({provider.asset_count ?? 60}+ assets),
                and institutional-grade custody through {provider.custody_provider ?? 'sFOX'} with {provider.insurance_coverage ?? '$200M'} in
                insurance coverage. BlockTrust IRA is a fully managed service with a $20,000 minimum — designed for serious retirement investors who want professional crypto portfolio management.
              </p>
            </div>

            {/* Fees */}
            <div>
              <h2 className="text-2xl font-bold text-[#0F172A] mb-4">Fees & Costs</h2>
              <p className="text-sm font-bold text-[#0F172A] mb-3 bg-sky-50 border-l-4 border-sky-400 px-3 py-2 rounded-r"><strong>TL;DR:</strong> BlockTrust IRA charges a 2% annual management fee plus a 25% performance fee on profits only, with a 0.14% trading fee via sFOX. No setup fee. No closure fee. BlockTrust profits only when your portfolio grows — aligning their incentives with yours.</p>
              <div className="overflow-x-auto">
                <table className="comparison-table">
                  <thead>
                    <tr>
                      <th>Fee Type</th>
                      <th>BlockTrust IRA</th>
                      <th>Industry Average</th>
                    </tr>
                  </thead>
                  <tbody>
                    {[
                      ['Account Setup', provider.setup_fee ?? '—', '$50–$200'],
                      ['Annual Maintenance', provider.annual_fee ?? '—', '$200–$300'],
                      ['Transaction Fee', provider.transaction_fee ?? '—', '1–2% per trade'],
                      ['Wire Transfer', '$25', '$25–$50'],
                      ['Account Closure', '$0', '$50–$150'],
                    ].map(([type, bt, avg]) => (
                      <tr key={type}>
                        <td className="font-medium text-[#0F172A]">{type}</td>
                        <td className="text-emerald-600 font-medium">{bt}</td>
                        <td className="text-[#64748B]">{avg}</td>
                      </tr>
                    ))}
                  </tbody>
                </table>
              </div>
            </div>

            {/* Assets */}
            {provider.supported_assets && provider.supported_assets.length > 0 && (
              <div>
                <h2 className="text-2xl font-bold text-[#0F172A] mb-4">Supported Cryptocurrencies</h2>
                <p className="text-sm font-bold text-[#0F172A] mb-3 bg-sky-50 border-l-4 border-sky-400 px-3 py-2 rounded-r"><strong>TL;DR:</strong> BlockTrust IRA supports 60+ cryptocurrencies — including Bitcoin, Ethereum, XRP, Solana, Dogecoin, and Shiba Inu — covering the full spectrum from blue-chip to altcoin exposure.</p>
                <p className="text-[#64748B] mb-4">
                  BlockTrust IRA supports 60+ cryptocurrencies through its institutional custodian <strong className="text-[#0F172A]">sFOX</strong>. The complete list:
                </p>
                <div className="grid grid-cols-2 md:grid-cols-3 gap-3">
                  {provider.supported_assets.map((asset) => (
                    <div key={asset} className="flex items-center gap-2 text-sm text-[#334155]">
                      <span className="text-emerald-500 font-bold">✓</span>
                      {asset}
                    </div>
                  ))}
                </div>
                {/* Full static 39-coin grid for SEO and accuracy */}
                <div className="mt-4 p-4 bg-slate-50 rounded-lg">
                  <p className="text-xs font-semibold text-[#64748B] uppercase tracking-wider mb-3">All 60+ Supported Cryptocurrencies</p>
                  <div className="grid grid-cols-2 md:grid-cols-3 gap-2 text-xs text-[#334155]">
                    {[
                      'BTC — Bitcoin','ETH — Ethereum','XRP — Ripple','LTC — Litecoin',
                      'SOL — Solana','DOGE — Dogecoin','AVAX — Avalanche','DOT — Polkadot',
                      'MATIC — Polygon','LINK — Chainlink','ATOM — Cosmos','ALGO — Algorand',
                      'BCH — Bitcoin Cash','ETC — Ethereum Classic','AAVE — Aave','UNI — Uniswap',
                      'COMP — Compound','MKR — Maker','NEAR — NEAR Protocol','FIL — Filecoin',
                      'FTM — Fantom','GALA — Gala','SAND — The Sandbox','MANA — Decentraland',
                      'SHIB — Shiba Inu','PEPE — Pepe','SUKU — Suku','SUSHI — SushiSwap',
                      'YFI — Yearn.Finance','ZRX — 0x','XLM — Stellar','XYO — XYO',
                      'RVN — Ravencoin','WBTC — Wrapped Bitcoin','BAT — Basic Attention Token',
                      'PAX — PAX','DAI — Dai','USDC — USD Coin','USDT — Tether',
                    ].map(coin => (
                      <div key={coin} className="flex items-center gap-1">
                        <span className="text-emerald-500 font-bold">✓</span>
                        <span>{coin}</span>
                      </div>
                    ))}
                  </div>
                </div>
              </div>
            )}

            {/* Security */}
            <div>
              <h2 className="text-2xl font-bold text-[#0F172A] mb-4">Security & Custody</h2>
              <p className="text-sm font-bold text-[#0F172A] mb-3 bg-sky-50 border-l-4 border-sky-400 px-3 py-2 rounded-r"><strong>TL;DR:</strong> BlockTrust IRA uses sFOX as its institutional custodian — an institutional prime broker aggregating liquidity from major exchanges with cold storage, multi-signature security, and $200M custody insurance.</p>
              <p className="text-[#64748B] leading-relaxed mb-4">
                BlockTrust IRA uses <strong className="text-[#0F172A]">sFOX</strong> as its qualified institutional custodian —
                a prime broker that aggregates liquidity from major exchanges and holds assets in cold storage
                with multi-signature security protocols and $200M custody insurance.
              </p>
              <div className="grid md:grid-cols-2 gap-4">
                {[
                  { label: 'Custody Provider', value: 'sFOX' },
                  { label: 'Storage Type', value: provider.storage_type },
                  { label: 'Insurance Coverage', value: provider.insurance_coverage },
                  { label: 'Security Audit', value: 'SOC 2 Type II Certified' },
                ].map((item) => (
                  <div key={item.label} className="bg-slate-50 rounded-lg p-4">
                    <div className="text-xs text-[#64748B] mb-1">{item.label}</div>
                    <div className="font-semibold text-[#0F172A]">{item.value ?? '—'}</div>
                  </div>
                ))}
              </div>
            </div>

            {/* Animus AI */}
            <div>
              <h2 className="text-2xl font-bold text-[#0F172A] mb-4">Animus AI — 24/7 Portfolio Management</h2>
              <p className="text-sm font-bold text-[#0F172A] mb-3 bg-sky-50 border-l-4 border-sky-400 px-3 py-2 rounded-r"><strong>TL;DR:</strong> Animus AI is BlockTrust IRA's proprietary portfolio management engine — monitoring markets 24/7, rebalancing dynamically, and responding to volatility automatically so you don't have to.</p>
              <p className="text-[#64748B] leading-relaxed mb-4">
                Unlike self-directed crypto IRAs where you manage every trade yourself, BlockTrust IRA is powered by <strong className="text-[#0F172A]">Animus AI</strong> — a proprietary algorithm that monitors your portfolio around the clock, adjusts allocations based on market conditions, and executes trades automatically through sFOX's institutional liquidity network.
              </p>
              <div className="grid md:grid-cols-2 gap-4">
                {[
                  { label: 'Monitoring', value: '24/7 automated' },
                  { label: 'Rebalancing', value: 'Dynamic — market-driven' },
                  { label: 'Volatility Response', value: 'Automatic risk adjustment' },
                  { label: 'Execution', value: 'Via sFOX institutional liquidity' },
                ].map((item) => (
                  <div key={item.label} className="bg-slate-50 rounded-lg p-4">
                    <div className="text-xs text-[#64748B] mb-1">{item.label}</div>
                    <div className="font-semibold text-[#0F172A]">{item.value}</div>
                  </div>
                ))}
              </div>
            </div>

            {/* Pros/Cons */}
            <div className="grid md:grid-cols-2 gap-6">
              <div className="card border-t-4 border-t-emerald-400">
                <h3 className="font-bold text-[#0F172A] mb-4">Pros</h3>
                <ul className="space-y-2">
                  {[
                    'No account setup fee',
                    `${provider.asset_count}+ supported cryptocurrencies`,
                    'sFOX institutional custody ($200M insured)',
                    `${provider.insurance_coverage} insurance coverage`,
                    'Assigned account representatives',
                    'Transparent flat-fee structure',
                  ].map((pro) => (
                    <li key={pro} className="flex gap-2 text-sm text-[#334155]">
                      <span className="text-emerald-500 font-bold flex-shrink-0">✓</span>
                      {pro}
                    </li>
                  ))}
                </ul>
              </div>
              <div className="card border-t-4 border-t-red-300">
                <h3 className="font-bold text-[#0F172A] mb-4">Cons</h3>
                <ul className="space-y-2">
                  {[
                    `${provider.min_investment} minimum investment`,
                    'No mobile app (web-only)',
                    'Limited educational content',
                  ].map((con) => (
                    <li key={con} className="flex gap-2 text-sm text-[#334155]">
                      <span className="text-red-400 font-bold flex-shrink-0">✗</span>
                      {con}
                    </li>
                  ))}
                </ul>
              </div>
            </div>

          </div>

          {/* Sidebar */}
          <div className="space-y-6">
            <div className="card sticky top-24">
              <div className="text-center mb-6">
                <div className={`text-5xl font-bold mb-1 ${scoreColor(provider.score_overall)}`}>
                  {provider.score_overall?.toFixed(1) ?? '—'}
                </div>
                <div className="text-sm text-[#64748B]">Overall Score / 10</div>
                <div className="badge-sky mt-2">Highest Scoring Provider - 2026 Methodology</div>
              </div>
              <div className="space-y-3 mb-6">
                {scoreLabels.map((cat) => {
                  const score = provider[cat.key] as number | null
                  return (
                    <div key={cat.key}>
                      <div className="flex justify-between text-xs mb-1">
                        <span className="text-[#64748B]">{cat.label}</span>
                        <span className={`font-semibold ${scoreColor(score)}`}>
                          {score?.toFixed(1) ?? '—'}/10
                        </span>
                      </div>
                      <div className="h-1.5 bg-slate-100 rounded-full overflow-hidden">
                        <div
                          className="h-full bg-[#0EA5E9] rounded-full"
                          style={{ width: `${((score ?? 0) / 10) * 100}%` }}
                        />
                      </div>
                    </div>
                  )
                })}
              </div>
              {provider.affiliate_url && (
                <a
                  href={provider.affiliate_url}
                  target="_blank"
                  rel="noopener noreferrer sponsored"
                  className="btn-primary w-full text-center block"
                  onClick={() => trackProviderSiteVisit('BlockTrust IRA', 'blocktrust-ira', provider.affiliate_url!)}
                >
                  View BlockTrust's Dedicated IRA Platform →
                </a>
              )}
            </div>

            <div className="card">
              <h3 className="font-semibold text-[#0F172A] mb-4 text-sm uppercase tracking-wider">Quick Facts</h3>
              <dl className="space-y-3 text-sm">
                {[
                  ['Founded', provider.founded_year?.toString()],
                  ['Headquarters', provider.headquarters],
                  ['Custodian', provider.custody_provider],
                  ['BBB Rating', provider.bbb_rating],
                  ['Min. Investment', provider.min_investment ?? 'No Minimum (Unmanaged) / $20,000 (Managed)'],
                  ['Annual Fee', provider.annual_fee ?? '$250/yr (Unmanaged) / $0 (Managed)'],
                ].map(([key, val]) => (
                  <div key={key} className="flex justify-between">
                    <dt className="text-[#64748B]">{key}</dt>
                    <dd className="font-medium text-[#0F172A]">{val ?? '—'}</dd>
                  </div>
                ))}
              </dl>
            </div>
            <div className="card bg-[#F0F9FF] border-[#BAE6FD]">
              <h3 className="font-semibold text-[#0F172A] mb-3 text-sm uppercase tracking-wider">Compare Providers</h3>
              <ul className="space-y-2 text-sm">
                <li><Link to="/crypto-ira/blocktrust-ira-review" className="text-[#0EA5E9] hover:underline"
                onClick={() => trackProviderReviewClick('Blocktrust Ira', 'blocktrust-ira', window.location.pathname)}>BlockTrust IRA Review</Link></li>
                <li><Link to="/crypto-ira/bitcoin-ira-review" className="text-[#0EA5E9] hover:underline"
                onClick={() => trackProviderReviewClick('Bitcoin Ira', 'bitcoin-ira', window.location.pathname)}>Bitcoin IRA Review</Link></li>
                <li><Link to="/crypto-ira/itrustcapital-review" className="text-[#0EA5E9] hover:underline"
                onClick={() => trackProviderReviewClick('Itrustcapital', 'itrustcapital', window.location.pathname)}>iTrustCapital Review</Link></li>
                <li><Link to="/crypto-ira/best-companies" className="text-[#0EA5E9] hover:underline font-medium">→ See All Rankings</Link></li>
              </ul>
            </div>
            <div className="card">
              <h3 className="font-semibold text-[#0F172A] mb-3 text-sm uppercase tracking-wider">Related Guides</h3>
              <ul className="space-y-2 text-sm">
                <li><Link to="/crypto-ira/401k-to-crypto-ira-rollover" className="text-[#0EA5E9] hover:underline">401k to Crypto IRA Rollover Guide →</Link></li>
                <li><Link to="/gold-ira-vs-crypto-ira" className="text-[#0EA5E9] hover:underline">Gold IRA vs Crypto IRA →</Link></li>
                <li><Link to="/methodology" className="text-[#0EA5E9] hover:underline">How We Rate Providers →</Link></li>
              </ul>
            </div>
          </div>
        </div>
      </div>

      {/* ── Bottom Line ────────────────────────────────────────────────── */}
      <div className="bg-[#F0F9FF] border-t border-[#BAE6FD]">
        <div className="container-site py-12 max-w-3xl">
          <h2 className="text-2xl font-bold text-[#0F172A] mb-4">Bottom Line: Is BlockTrust IRA Worth It?</h2>
          <p className="text-[#334155] leading-relaxed mb-4">
            BlockTrust IRA earns its place as our <strong>#1 rated crypto IRA provider for 2026</strong>. The combination of 39 confirmed supported cryptocurrencies — including XRP, Solana, Dogecoin, and Shiba Inu — institutional custody through sFOX with $200M insurance, and Animus AI 24/7 portfolio management makes it the strongest all-round option for investors who want professionally managed crypto exposure inside a tax-advantaged account.
          </p>
          <p className="text-[#334155] leading-relaxed mb-4">
            A $20,000 minimum investment applies — this is a fully managed service designed for serious retirement investors, not a self-directed platform. The platform is web-only with no mobile app, but neither limitation affects the core value proposition. If you are rolling over a 401(k) or opening a new IRA and want professional crypto portfolio management, BlockTrust IRA is the most defensible choice in the market.
          </p>
          <p className="text-[#334155] leading-relaxed">
            <strong>Best for:</strong> Investors who want broad crypto exposure, Animus AI 24/7 managed portfolio, and institutional-grade sFOX custody inside a tax-advantaged IRA. If you want to compare alternatives, see our{' '}
            <Link to="/crypto-ira/bitcoin-ira-review" className="text-[#0EA5E9] hover:underline"
                onClick={() => trackProviderReviewClick('Bitcoin Ira', 'bitcoin-ira', window.location.pathname)}>Bitcoin IRA review</Link>{' '}and{' '}
            <Link to="/crypto-ira/itrustcapital-review" className="text-[#0EA5E9] hover:underline"
                onClick={() => trackProviderReviewClick('Itrustcapital', 'itrustcapital', window.location.pathname)}>iTrustCapital review</Link>.
          </p>
        </div>
      </div>

      {/* ── FAQ Section ────────────────────────────────────────────────── */}
      <div className="container-site py-12 max-w-3xl">
        <h2 className="text-2xl font-bold text-[#0F172A] mb-8">Frequently Asked Questions</h2>
        <div className="space-y-4">
          {faqSchema.mainEntity.map((item, i) => (
            <details key={i} className="group border border-slate-200 rounded-lg overflow-hidden">
              <summary className="flex items-center justify-between gap-4 p-5 cursor-pointer bg-white hover:bg-slate-50 transition-colors list-none">
                <span className="font-semibold text-[#0F172A] text-sm leading-snug">{item.name}</span>
                <span className="flex-shrink-0 w-5 h-5 text-[#0EA5E9] transition-transform group-open:rotate-180">
                  <svg viewBox="0 0 20 20" fill="currentColor"><path fillRule="evenodd" d="M5.293 7.293a1 1 0 011.414 0L10 10.586l3.293-3.293a1 1 0 111.414 1.414l-4 4a1 1 0 01-1.414 0l-4-4a1 1 0 010-1.414z" clipRule="evenodd" /></svg>
                </span>
              </summary>
              <div className="px-5 pb-5 text-[#64748B] text-sm leading-relaxed bg-white">
                {item.acceptedAnswer.text}
              </div>
            </details>
          ))}
        </div>
      </div>
      {/* ── Newsletter Signup ─────────────────────────────────────────── */}
      <div className="container-site py-10 max-w-3xl">
        
        {/* Related Links */}

        <div className="mt-10 mb-6">

          <RelatedLinks variant="crypto-review" title="Related Guides &amp; Reviews" />

        </div>
<NewsletterSignup />
      </div>
    </>
  )
}
