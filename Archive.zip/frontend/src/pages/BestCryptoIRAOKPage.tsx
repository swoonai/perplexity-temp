import StateGuideTemplate from '../components/StateGuideTemplate'

export default function BestCryptoIRAOKPage() {
  return (
    <StateGuideTemplate
      stateName="Oklahoma"
      stateAbbr="OK"
      slug="oklahoma"
    />
  )
}
