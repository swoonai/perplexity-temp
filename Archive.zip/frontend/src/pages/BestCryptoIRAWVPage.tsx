import StateGuideTemplate from '../components/StateGuideTemplate'

export default function BestCryptoIRAWVPage() {
  return (
    <StateGuideTemplate
      stateName="West Virginia"
      stateAbbr="WV"
      slug="west-virginia"
    />
  )
}
