import StateGuideTemplate from '../components/StateGuideTemplate'

export default function BestCryptoIRAFLPage() {
  return (
    <StateGuideTemplate
      stateName="Florida"
      stateAbbr="FL"
      slug="florida"
    />
  )
}
