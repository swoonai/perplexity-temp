import SEO from '../components/SEO'
export default function TermsPage() {
  return (
    <div className="section-padding">
      <SEO
        title="Terms of Service"
        description="IRA Research Hub terms of service. Read the terms and conditions for using iraresearchhub.com."
        canonical="/terms"
      />
      <div className="container-site max-w-3xl">
        <h1 className="text-4xl font-bold text-[#0F172A] mb-6">Terms of Service</h1>
        <p className="text-[#64748B] mb-4">Last updated: March 2026</p>
        <div className="space-y-6 text-[#64748B] leading-relaxed">
          <p>By accessing iraresearchhub.com, you agree to be bound by these Terms of Service. If you disagree with any part of the terms, you may not access the website.</p>
          <h2 className="text-xl font-bold text-[#0F172A]">Intellectual Property</h2>
          <p>The content on this site, including text, graphics, and logos, is the property of IRA Research Hub and protected by copyright laws.</p>
          <h2 className="text-xl font-bold text-[#0F172A]">Disclaimer</h2>
          <p>The information provided on this site is for informational purposes only and does not constitute financial, investment, or tax advice. We are not a financial advisor. You should consult with a qualified professional before making any investment decisions.</p>
          <h2 className="text-xl font-bold text-[#0F172A]">Limitation of Liability</h2>
          <p>In no event shall IRA Research Hub be liable for any damages arising out of the use or inability to use the materials on this website.</p>
          <h2 className="text-xl font-bold text-[#0F172A]">Links to Third-Party Sites</h2>
          <p>Our website may contain links to third-party websites. These links are provided for your convenience only. We have no control over the content of those sites and accept no responsibility for them.</p>
          <h2 className="text-xl font-bold text-[#0F172A]">Changes to Terms</h2>
          <p>We reserve the right to modify these terms at any time. By continuing to use the site after changes are posted, you agree to the revised terms.</p>
          <h2 className="text-xl font-bold text-[#0F172A]">Contact</h2>
          <p>If you have any questions about these Terms, please contact us through the information provided on our About page.</p>
        </div>
      </div>
    </div>
  )
}
