import { Link } from 'react-router-dom'
import SEO from '../components/SEO'
import AdvertiserDisclosure from '../components/AdvertiserDisclosure'
import NewsletterSignup from '../components/NewsletterSignup'
import RelatedLinks from '../components/RelatedLinks';

const DATE_MODIFIED = "2026-04-10"
const DATE_PUBLISHED = "2026-04-10"
const LAST_UPDATED = "April 10, 2026"

const articleSchema = {
  "@context": "https://schema.org",
  "@type": "Article",
  "headline": "Precious Metals IRA Fees 2026: Complete Cost Breakdown",
  "description": "A comprehensive guide to all fees associated with a Precious Metals IRA in 2026, including setup, storage, custodian, and hidden spread costs.",
  "author": { "@type": "Person", "name": "James Mitchell, CFA", "url": "https://iraresearchhub.com/author/james-mitchell" },
  "publisher": { "@type": "Organization", "name": "IRA Research Hub", "url": "https://iraresearchhub.com" },
  "datePublished": DATE_PUBLISHED,
  "dateModified": DATE_MODIFIED,
  "url": "https://iraresearchhub.com/research/precious-metals-ira-fees-2026"
}

const breadcrumbSchema = {
  "@context": "https://schema.org", 
  "@type": "BreadcrumbList", 
  "itemListElement": [
    {"@type": "ListItem", "position": 1, "name": "Home", "item": "https://iraresearchhub.com/"},
    {"@type": "ListItem", "position": 2, "name": "Research", "item": "https://iraresearchhub.com/research"},
    {"@type": "ListItem", "position": 3, "name": "Precious Metals IRA Fees 2026", "item": "https://iraresearchhub.com/research/precious-metals-ira-fees-2026"}
  ]
};

export default function PreciousMetalsIRAFeesPage() {
  return (
    <>
      <SEO
        title="Precious Metals IRA Fees 2026: Complete Cost Breakdown"
        description="A comprehensive guide to all fees associated with a Precious Metals IRA in 2026, including setup, storage, custodian, and hidden spread costs."
        canonical="/research/precious-metals-ira-fees-2026"
        ogType="article"
      />
      <script type="application/ld+json" dangerouslySetInnerHTML={{ __html: JSON.stringify(articleSchema) }} />
      <script type="application/ld+json" dangerouslySetInnerHTML={{ __html: JSON.stringify(breadcrumbSchema) }} />

      <div className="container-site section-padding">
        <nav className="text-sm text-slate-500 mb-6" aria-label="Breadcrumb">
          <ol className="flex flex-wrap gap-1 items-center">
            <li><Link to="/" className="hover:text-amber-600">Home</Link></li>
            <li className="text-slate-300">/</li>
            <li><Link to="/research" className="hover:text-amber-600">Research</Link></li>
            <li className="text-slate-300">/</li>
            <li className="text-slate-700 font-medium">Precious Metals IRA Fees 2026</li>
          </ol>
        </nav>

        <div className="grid lg:grid-cols-[1fr_320px] gap-10">
          <main>
            <div className="mb-8">
              <div className="flex items-center gap-3 mb-3">
                <span className="text-xs font-semibold uppercase tracking-wider text-amber-600 bg-amber-50 border border-amber-200 px-2 py-1 rounded">Research Report</span>
                <span className="text-xs text-slate-500">Updated {LAST_UPDATED}</span>
              </div>
              <h1 className="text-3xl md:text-4xl font-bold text-[#0F172A] mb-4">
                Precious Metals IRA Fees 2026: Complete Cost Breakdown
              </h1>
              <AdvertiserDisclosure />
              
              <div className="prose prose-slate max-w-none mt-8">
                <p className="text-lg text-slate-600 leading-relaxed speakable-summary">
                  Understanding the true cost of a Precious Metals IRA is critical before investing. Unlike traditional IRAs which often have zero fees, physical gold and silver IRAs involve multiple parties—the dealer, the custodian, and the depository—each charging their own fees. In 2026, expect to pay between $150 and $300 annually in fixed fees, plus a one-time setup fee and the dealer's markup (spread) on the metals themselves.
                </p>

                <h2>The 4 Types of Precious Metals IRA Fees</h2>
                
                <h3>1. Account Setup Fees (One-Time)</h3>
                <p>Most custodians charge a one-time fee to establish your self-directed IRA and process the rollover paperwork from your existing retirement account. This typically ranges from <strong>$50 to $150</strong>. Many top-tier dealers will waive this fee for initial deposits over a certain threshold (usually $50,000).</p>

                <h3>2. Annual Custodian Maintenance Fees</h3>
                <p>The IRS requires a qualified custodian to administer your self-directed IRA, handle reporting, and ensure compliance. Custodian fees are usually billed annually and range from <strong>$75 to $300</strong>. Some custodians charge a flat fee regardless of account size, while others charge a scaled fee based on the total value of your assets.</p>

                <h3>3. Annual Storage Fees</h3>
                <p>Physical metals must be stored in an IRS-approved depository (like Delaware Depository or Brink's). Storage fees cover insurance and secure vaulting. Expect to pay <strong>$100 to $150 annually</strong>. There are two types of storage:</p>
                <ul>
                  <li><strong>Commingled (Non-Segregated):</strong> Your metals are stored alongside others. When you take a distribution, you receive the exact same type and purity of metal, but not necessarily the exact specific coins/bars you deposited. This is usually cheaper.</li>
                  <li><strong>Segregated:</strong> Your specific metals are kept in a separate, dedicated space. You receive the exact items you deposited. This typically costs $50-$100 more per year.</li>
                </ul>

                <h3>4. The Dealer Spread (The "Hidden" Cost)</h3>
                <p>The most significant cost in a Precious Metals IRA isn't an explicit fee—it's the dealer spread. This is the difference between the spot price of the metal and the retail price the dealer charges you. Spreads vary wildly by dealer and by the type of metal (coins usually have higher premiums than bars). A competitive spread is typically <strong>5% to 15%</strong> above spot price. Always ask your dealer to disclose their exact premium over spot before purchasing.</p>

                <h2>Fee Comparison: Top Providers in 2026</h2>
                <div className="overflow-x-auto my-6">
                  <table className="min-w-full text-sm text-left border-collapse">
                    <thead>
                      <tr className="bg-slate-100 border-b border-slate-200">
                        <th className="p-3 font-semibold text-slate-700">Provider</th>
                        <th className="p-3 font-semibold text-slate-700">Setup Fee</th>
                        <th className="p-3 font-semibold text-slate-700">Annual Custodian Fee</th>
                        <th className="p-3 font-semibold text-slate-700">Annual Storage Fee</th>
                        <th className="p-3 font-semibold text-slate-700">Fee Waivers</th>
                      </tr>
                    </thead>
                    <tbody className="divide-y divide-slate-200">
                      <tr>
                        <td className="p-3 font-medium">Genesis Gold Group</td>
                        <td className="p-3">$50</td>
                        <td className="p-3">$100</td>
                        <td className="p-3">$100</td>
                        <td className="p-3">Waived first year for qualifying accounts</td>
                      </tr>
                      <tr className="bg-slate-50">
                        <td className="p-3 font-medium">Augusta Precious Metals</td>
                        <td className="p-3">$50</td>
                        <td className="p-3">$100</td>
                        <td className="p-3">$100</td>
                        <td className="p-3">Up to 10 years fees waived for premium accounts</td>
                      </tr>
                      <tr>
                        <td className="p-3 font-medium">Goldco</td>
                        <td className="p-3">$50</td>
                        <td className="p-3">$80</td>
                        <td className="p-3">$100</td>
                        <td className="p-3">First year waived for accounts over $50k</td>
                      </tr>
                    </tbody>
                  </table>
                </div>

                <h2>How to Minimise Your Fees</h2>
                <p>To keep your costs down, look for providers that offer flat-rate fee structures rather than scaled fees (which penalise you as your account grows). Additionally, many top providers run promotions where they will cover your first year (or even multiple years) of custodian and storage fees if you meet their minimum investment threshold.</p>
              </div>
            </div>
                        {/* Related Links */}
            <div className="mt-10 mb-6">
              <RelatedLinks variant="metals-guide" title="Related Guides &amp; Reviews" />
            </div>
            <NewsletterSignup />
          </main>
          
          <aside className="hidden lg:block space-y-8">
            <div className="bg-slate-50 rounded-xl p-6 border border-slate-200 sticky top-8">
              <h3 className="font-bold text-slate-900 mb-4">Related Research</h3>
              <ul className="space-y-3 text-sm">
                <li><Link to="/research/gold-ira-vs-crypto-ira-2026" className="text-amber-600 hover:underline">Gold IRA vs Crypto IRA 2026</Link></li>
                <li><Link to="/education/gold-ira-guide" className="text-amber-600 hover:underline">Gold IRA Guide</Link></li>
                <li><Link to="/precious-metals-ira" className="text-amber-600 hover:underline">Best Precious Metals IRAs</Link></li>
              </ul>
            </div>
          </aside>
        </div>
      </div>
    </>
  )
}
