import AwardDetailPage from './AwardDetailPage'

export default function BestCustomerService2026AwardPage() {
  return <AwardDetailPage awardSlug="best-customer-service-2026" />
}
