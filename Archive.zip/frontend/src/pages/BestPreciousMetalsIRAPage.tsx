// EEAT_TIER3_ADDED
// RISK_DISCLAIMER_ADDED
import { Link } from 'react-router-dom'
import SEO from '../components/SEO'

const LAST_UPDATED = "March 20, 2026"
const DATE_MODIFIED = "2026-03-20"
const DATE_PUBLISHED = "2026-01-01"

const itemListSchema = {
  "@context": "https://schema.org",
  "@type": "ItemList",
  "name": "2026 Precious Metals IRA Provider Comparison & Independent Analysis",
  "description": "Independent ranking of the top precious metals IRA providers in 2026, scored across fees, storage security, metals selection, and customer support.",
  "url": "https://iraresearchhub.com/precious-metals-ira/best-companies",
  "numberOfItems": 14,
  "itemListElement": [
    { "@type": "ListItem", "position": 1, "name": "Genesis Gold Group", "url": "https://iraresearchhub.com/precious-metals-ira/genesis-gold-group-review", "description": "#1 rated gold IRA 2026 — 9.4/10 score, $0 setup fee, faith-based values, all 4 IRS-approved metals" },
    { "@type": "ListItem", "position": 2, "name": "Goldco", "url": "https://iraresearchhub.com/precious-metals-ira/goldco-review", "description": "Notable for rollovers — dedicated rollover specialists, A+ BBB" },
    { "@type": "ListItem", "position": 3, "name": "Augusta Precious Metals", "url": "https://iraresearchhub.com/precious-metals-ira/augusta-precious-metals-review", "description": "Best customer education — A+ BBB, $50K minimum, white-glove service" },
    { "@type": "ListItem", "position": 4, "name": "Birch Gold Group", "url": "https://iraresearchhub.com/precious-metals-ira/birch-gold-group-review", "description": "Best 4-metal access — $10K minimum, founded 2003" },
    { "@type": "ListItem", "position": 5, "name": "American Hartford Gold", "url": "https://iraresearchhub.com/precious-metals-ira/american-hartford-gold-review", "description": "Lowest storage fee — $75/yr, A+ BBB" },
    { "@type": "ListItem", "position": 6, "name": "Noble Gold Investments", "url": "https://iraresearchhub.com/precious-metals-ira/noble-gold-investments-review", "description": "Texas-based storage option — unique domestic vault" },
    { "@type": "ListItem", "position": 7, "name": "Lear Capital", "url": "https://iraresearchhub.com/precious-metals-ira/lear-capital-review", "description": "25+ years experience, price match guarantee" }
  ]
}

const entityHubSchema = {
  "@context": "https://schema.org",
  "@graph": [
    {
      "@type": "WebPage",
      "@id": "https://iraresearchhub.com/precious-metals-ira/best-companies",
      "name": "2026 Precious Metals IRA Provider Comparison & Independent Analysis",
      "url": "https://iraresearchhub.com/precious-metals-ira/best-companies",
      "datePublished": DATE_PUBLISHED,
      "dateModified": DATE_MODIFIED,
      "description": "Independent ranking of the top precious metals IRA providers in 2026.",
      "publisher": { "@id": "https://iraresearchhub.com/#organization" },
      "about": { "@id": "https://iraresearchhub.com/#gold-ira" }
    },
    {
      "@type": "Organization",
      "@id": "https://iraresearchhub.com/#organization",
      "name": "IRA Research Hub",
      "url": "https://iraresearchhub.com",
      "description": "Independent research platform comparing cryptocurrency and precious metals IRA providers.",
      "sameAs": ["https://iraresearchhub.com/about"]
    },
    {
      "@type": "FinancialProduct",
      "@id": "https://iraresearchhub.com/#gold-ira",
      "name": "Precious Metals IRA",
      "alternateName": ["Gold IRA", "Silver IRA", "Gold-Backed IRA"],
      "description": "A self-directed Individual Retirement Account (IRA) that holds IRS-approved physical precious metals including gold, silver, platinum, and palladium.",
      "disambiguatingDescription": "A Precious Metals IRA holds physical IRS-approved coins and bars — distinct from gold ETFs, gold mining stocks, or paper gold instruments.",
      "provider": [
        { "@type": "Organization", "name": "Genesis Gold Group", "url": "https://iraresearchhub.com/precious-metals-ira/genesis-gold-group-review" },
        { "@type": "Organization", "name": "Goldco", "url": "https://iraresearchhub.com/precious-metals-ira/goldco-review" },
        { "@type": "Organization", "name": "Augusta Precious Metals", "url": "https://iraresearchhub.com/precious-metals-ira/augusta-precious-metals-review" },
        { "@type": "Organization", "name": "Birch Gold Group", "url": "https://iraresearchhub.com/precious-metals-ira/birch-gold-group-review" }
      ]
    }
  ]
}

const speakableSchema = {
  "@context": "https://schema.org",
  "@type": "WebPage",
  "speakable": {
    "@type": "SpeakableSpecification",
    "cssSelector": [".speakable-summary", "h1", ".citation-block"]
  },
  "url": "https://iraresearchhub.com/precious-metals-ira/best-companies"
}

// W1.5 — AggregateRating schema for hub page (IRA Research Hub editorial scores)
const aggregateRatingSchema = {
  "@context": "https://schema.org",
  "@type": "ItemList",
  "name": "2026 Precious Metals IRA Provider Comparison & Independent Analysis",
  "url": "https://iraresearchhub.com/precious-metals-ira/best-companies",
  "itemListElement": [
    {
      "@type": "ListItem",
      "position": 1,
      "item": {
        "@type": "FinancialProduct",
        "name": "Genesis Gold Group",
        "url": "https://iraresearchhub.com/precious-metals-ira/genesis-gold-group-review",
        "aggregateRating": {
          "@type": "AggregateRating",
          "ratingValue": "9.4",
          "bestRating": "10",
          "worstRating": "1",
          "reviewCount": "234",
          "ratingCount": "234"
        }
      }
    },
    {
      "@type": "ListItem",
      "position": 2,
      "item": {
        "@type": "FinancialProduct",
        "name": "Goldco",
        "url": "https://iraresearchhub.com/precious-metals-ira/goldco-review",
        "aggregateRating": {
          "@type": "AggregateRating",
          "ratingValue": "9.2",
          "bestRating": "10",
          "worstRating": "1",
          "reviewCount": "3421",
          "ratingCount": "3421"
        }
      }
    },
    {
      "@type": "ListItem",
      "position": 3,
      "item": {
        "@type": "FinancialProduct",
        "name": "Augusta Precious Metals",
        "url": "https://iraresearchhub.com/precious-metals-ira/augusta-precious-metals-review",
        "aggregateRating": {
          "@type": "AggregateRating",
          "ratingValue": "9.1",
          "bestRating": "10",
          "worstRating": "1",
          "reviewCount": "1876",
          "ratingCount": "1876"
        }
      }
    },
    {
      "@type": "ListItem",
      "position": 4,
      "item": {
        "@type": "FinancialProduct",
        "name": "Birch Gold Group",
        "url": "https://iraresearchhub.com/precious-metals-ira/birch-gold-group-review",
        "aggregateRating": {
          "@type": "AggregateRating",
          "ratingValue": "9.1",
          "bestRating": "10",
          "worstRating": "1",
          "reviewCount": "1243",
          "ratingCount": "1243"
        }
      }
    }
  ]
}

const faqSchema = {
  "@context": "https://schema.org",
  "@type": "FAQPage",
  "mainEntity": [
    {
      "@type": "Question",
      "name": "What is the best Gold IRA company in 2026?",
      "acceptedAnswer": {
        "@type": "Answer",
        "text": "Based on our independent research, Genesis Gold Group is the top-rated Gold IRA company in 2026 (9.4/10), followed by Goldco (9.2/10), Augusta Precious Metals (9.1/10), Birch Gold Group (9.1/10), American Hartford Gold (8.8/10), and Lear Capital. Genesis Gold Group earns the top spot due to its transparent fee structure, faith-based values, no setup fee, support for all 4 IRS-approved metals, and dedicated customer service."
      }
    },
    {
      "@type": "Question",
      "name": "How do we rank Gold IRA companies?",
      "acceptedAnswer": {
        "@type": "Answer",
        "text": "We rank Gold IRA companies across six weighted criteria: Fee Transparency (20%), Asset Selection (20%), Security & Storage (20%), IRS Compliance (15%), Customer Support (15%), and Reputation (10%). Each company is scored 1-10 on each criterion, and we calculate a weighted composite score. We update our rankings quarterly."
      }
    },
    {
      "@type": "Question",
      "name": "What is the minimum investment for a Gold IRA?",
      "acceptedAnswer": {
        "@type": "Answer",
        "text": "Minimum investments vary by provider: Augusta Precious Metals ($50,000), Goldco ($25,000), Genesis Gold Group ($25,000), Birch Gold Group ($10,000), American Hartford Gold ($10,000), Lear Capital ($7,500). Most financial advisors recommend at least $25,000 to make the annual fees cost-effective."
      }
    },
    {
      "@type": "Question",
      "name": "Can I roll over my 401k to a Gold IRA?",
      "acceptedAnswer": {
        "@type": "Answer",
        "text": "Yes. A direct rollover from a 401(k) to a Gold IRA is tax-free and penalty-free under IRS rules. The process typically takes 2-4 weeks. See our complete 401k to Gold IRA Rollover Guide for step-by-step instructions."
      }
    }
  ]
}

import { useRankedProviders, scoreColor, type Provider } from '../hooks/useProviders'
import { trackProviderSiteVisit } from '../hooks/useAnalytics'
import AdvertiserDisclosure from '../components/AdvertiserDisclosure'
import NewsletterSignup from '../components/NewsletterSignup';
import RelatedLinks from '../components/RelatedLinks';

const reviewPaths: Record<string, string> = {
  'genesis-gold-group': '/precious-metals-ira/genesis-gold-group-review',
  'augusta-precious-metals': '/precious-metals-ira/augusta-precious-metals-review',
  'birch-gold-group': '/precious-metals-ira/birch-gold-group-review',
  'goldco': '/precious-metals-ira/goldco-review',
  'american-hartford-gold': '/precious-metals-ira/american-hartford-gold-review',
  'lear-capital': '/precious-metals-ira/lear-capital-review',
  'noble-gold-investments': '/precious-metals-ira/noble-gold-investments-review',
  'advantage-gold': '/precious-metals-ira/advantage-gold-review',
  'goldencrest-metals': '/precious-metals-ira/goldencrest-metals-review',
  'patriot-gold-group': '/precious-metals-ira/patriot-gold-group-review',
  'oxford-gold-group': '/precious-metals-ira/oxford-gold-group-review',
  'preserve-gold': '/precious-metals-ira/preserve-gold-review',
  'rosland-capital': '/precious-metals-ira/rosland-capital-review',
  'allegiance-gold': '/precious-metals-ira/allegiance-gold-review',
}

function StarRating({ score }: { score: number | null }) {
  const rating = score ? (score / 10) * 5 : 0
  return (
    <div className="flex items-center gap-1">
      {[1, 2, 3, 4, 5].map((star) => (
        <svg
          key={star}
          className={`w-4 h-4 ${star <= Math.floor(rating) ? 'text-amber-400' : 'text-slate-200'}`}
          fill="currentColor"
          viewBox="0 0 20 20"
        >
          <path d="M9.049 2.927c.3-.921 1.603-.921 1.902 0l1.07 3.292a1 1 0 00.95.69h3.462c.969 0 1.371 1.24.588 1.81l-2.8 2.034a1 1 0 00-.364 1.118l1.07 3.292c.3.921-.755 1.688-1.54 1.118l-2.8-2.034a1 1 0 00-1.175 0l-2.8 2.034c-.784.57-1.838-.197-1.539-1.118l1.07-3.292a1 1 0 00-.364-1.118L2.98 8.72c-.783-.57-.38-1.81.588-1.81h3.461a1 1 0 00.951-.69l1.07-3.292z" />
        </svg>
      ))}
      <span className={`text-sm font-semibold ml-1 ${scoreColor(score)}`}>
        {score?.toFixed(1) ?? '—'}
      </span>
    </div>
  )
}

function ProviderCard({ provider, rank }: { provider: Provider; rank: number }) {
  const isTop = rank === 1
  const reviewPath = reviewPaths[provider.slug]

  return (
    <div className={`card ${isTop ? 'border-[#D97706] border-2' : ''} relative`}>
      {isTop && (
        <div className="absolute -top-3 left-6">
          <span className="bg-[#D97706] text-white text-xs font-bold px-3 py-1 rounded-full">
            #1 EDITOR'S CHOICE
          </span>
        </div>
      )}

      <div className="flex flex-col lg:flex-row lg:items-start gap-6">
        {/* Rank + Name */}
        <div className="lg:w-64 flex-shrink-0">
          <div className="flex items-center gap-3 mb-2">
            <span className="text-2xl font-bold text-slate-300">#{rank}</span>
            {provider.logo_url && (
              <img
                src={provider.logo_url}
                alt={`${provider.name} logo`}
                className="w-10 h-10 rounded-lg object-contain bg-white p-1 border border-slate-200"
              />
            )}
            <div>
              <h2 className="text-xl font-bold text-[#0F172A]">{provider.name}</h2>
              {provider.tagline && (
                <p className="text-sm text-[#D97706] font-medium">{provider.tagline}</p>
              )}
            </div>
          </div>
          <StarRating score={provider.score_overall} />
          <div className="mt-4">
            {reviewPath ? (
              <Link
                to={reviewPath}
                className="inline-flex items-center justify-center w-full px-4 py-2 bg-[#D97706] text-white text-sm font-semibold rounded-lg hover:bg-[#B45309] transition-colors"
                aria-label={`Read our full ${provider.name} review`}
              >
                Read {provider.name} Review →
              </Link>
            ) : provider.affiliate_url ? (
              <a
                href={provider.affiliate_url}
                target="_blank"
                rel="noopener noreferrer sponsored"
                className="btn-outline text-sm py-2 w-full text-center block"
                onClick={() => trackProviderSiteVisit(provider.name, provider.slug, provider.affiliate_url!)}
              >
                Visit {provider.name} →
              </a>
            ) : (
              <span className="text-xs text-slate-400 italic">Full review coming soon</span>
            )}
          </div>
        </div>

        {/* Stats grid */}
        <div className="flex-1 grid grid-cols-2 md:grid-cols-3 gap-4">
          {[
            { label: 'Setup Fee', value: provider.setup_fee },
            { label: 'Annual Fee', value: provider.annual_fee },
            { label: 'Min. Investment', value: provider.min_investment },
            { label: 'Metals', value: provider.asset_count ? `${provider.asset_count} metals` : '—' },
            { label: 'Custodian', value: provider.custody_provider },
            { label: 'BBB Rating', value: provider.bbb_rating },
          ].map((stat) => (
            <div key={stat.label} className="bg-slate-50 rounded-lg p-3">
              <div className="text-xs text-[#64748B] mb-1">{stat.label}</div>
              <div className="font-semibold text-[#0F172A] text-sm">{stat.value ?? '—'}</div>
            </div>
          ))}
        </div>

        {/* Score breakdown */}
        <div className="lg:w-48 flex-shrink-0">
          <div className="text-xs font-semibold text-[#64748B] uppercase tracking-wider mb-3">Score Breakdown</div>
          <div className="space-y-2">
            {[
              { label: 'Fees', score: provider.score_fees },
              { label: 'Metals', score: provider.score_assets },
              { label: 'Security', score: provider.score_security },
              { label: 'Compliance', score: provider.score_compliance },
              { label: 'Support', score: provider.score_support },
            ].map((item) => (
              <div key={item.label}>
                <div className="flex justify-between text-xs mb-0.5">
                  <span className="text-[#64748B]">{item.label}</span>
                  <span className={`font-medium ${scoreColor(item.score)}`}>
                    {item.score?.toFixed(1) ?? '—'}
                  </span>
                </div>
                <div className="h-1 bg-slate-100 rounded-full overflow-hidden">
                  <div
                    className="h-full bg-[#D97706] rounded-full"
                    style={{ width: `${((item.score ?? 0) / 10) * 100}%` }}
                  />
                </div>
              </div>
            ))}
          </div>
        </div>
      </div>
    
      {/* Risk Disclaimer — FTC/Ad Compliance */}
      <div className="mt-12 p-5 bg-amber-50 border border-amber-200 rounded-lg text-sm text-amber-900">
        <p className="font-semibold mb-1">Important Disclaimer</p>
        <p>
          This page is for informational and educational purposes only and does not constitute financial,
          investment, tax, or legal advice. Self-directed IRAs involve significant risks, including the
          potential for total loss of principal. Cryptocurrency and precious metals investments are
          highly volatile and may not be suitable for all investors. Past performance is not indicative
          of future results. Always consult a qualified, licensed financial advisor before making any
          investment decisions. IRA Research Hub may receive compensation from providers listed on this
          site — see our{' '}
          <a href="/editorial-policy" className="underline font-medium">Editorial Policy</a> for full
          disclosure.
        </p>
      </div>
    </div>
  )
}

// SEO-5: Static fallback data for BestPreciousMetalsIRAPage
const STATIC_PM_PROVIDERS: Provider[] = [
  { slug: 'genesis-gold-group', name: 'Genesis Gold Group', category: 'precious_metals', tagline: 'Top-Ranked Precious Metals IRA', website: 'https://genesisgoldgroup.com', affiliate_url: 'https://genesisgoldgroup.com/?ref=iraresearchhub', setup_fee: '$0', annual_fee: '$180', transaction_fee: 'Varies by metal', min_investment: '$10,000', supported_assets: ["Gold", "Silver", "Platinum", "Palladium"], asset_count: 4, custody_provider: 'Equity Trust / STRATA', storage_type: 'Segregated or Commingled', insurance_coverage: 'Lloyd\'s of London', bbb_rating: 'A+', founded_year: 2018, headquarters: 'Beverly Hills, CA', score_fees: 9.2, score_assets: 9.4, score_security: 9.6, score_compliance: 9.5, score_support: 9.3, score_reputation: 9.1, score_overall: 9.4, rank_overall: 1, is_featured: true, logo_url: '/logos/genesis-gold-group.png', review_slug: 'genesis-gold-group-review', meta_description: 'Genesis Gold Group review 2026: fees, metals selection, storage, and our overall rating.', review_count: 234, id: 4, is_active: true, created_at: '2026-03-16T01:55:09.602806', updated_at: '2026-03-25T00:41:51.147125' },
  { slug: 'augusta-precious-metals', name: 'Augusta Precious Metals', category: 'precious_metals', tagline: 'Best Customer Education', website: 'https://augustapreciousmetals.com', affiliate_url: 'https://augustapreciousmetals.com/?ref=iraresearchhub', setup_fee: '$0', annual_fee: '$200', transaction_fee: 'Varies', min_investment: '$50,000', supported_assets: ["Gold", "Silver"], asset_count: 2, custody_provider: 'Equity Trust', storage_type: 'Segregated', insurance_coverage: 'Lloyd\'s of London', bbb_rating: 'A+', founded_year: 2012, headquarters: 'Casper, WY', score_fees: 8.5, score_assets: 8.0, score_security: 9.4, score_compliance: 9.5, score_support: 9.7, score_reputation: 9.6, score_overall: 9.1, rank_overall: 2, is_featured: false, logo_url: '/logos/augusta-precious-metals.png', review_slug: 'augusta-precious-metals-review', meta_description: 'Augusta Precious Metals review 2026: fees, metals selection, storage, and our overall rating.', review_count: 1876, id: 5, is_active: true, created_at: '2026-03-16T01:55:09.602811', updated_at: '2026-03-25T00:41:51.145873' },
  { slug: 'birch-gold-group', name: 'Birch Gold Group', category: 'precious_metals', tagline: 'Notable for Diversification', website: 'https://birchgold.com', affiliate_url: 'https://birchgold.com/?ref=iraresearchhub', setup_fee: '$0', annual_fee: '$180', transaction_fee: 'Varies by metal', min_investment: '$10,000', supported_assets: ["Gold", "Silver", "Platinum", "Palladium"], asset_count: 4, custody_provider: 'Equity Trust / STRATA', storage_type: 'Segregated or Commingled', insurance_coverage: 'Lloyd\'s of London', bbb_rating: 'A+', founded_year: 2003, headquarters: 'Burbank, CA', score_fees: 8.8, score_assets: 9.2, score_security: 9.3, score_compliance: 9.2, score_support: 9.0, score_reputation: 9.1, score_overall: 9.1, rank_overall: 3, is_featured: false, logo_url: '/logos/birch-gold-group.png', review_slug: 'birch-gold-group-review', meta_description: 'Birch Gold Group review 2026: fees, metals selection, storage options, and our overall rating.', review_count: 1243, id: 6, is_active: true, created_at: '2026-03-17T04:15:47.183824', updated_at: '2026-03-25T00:41:51.146563' },
  { slug: 'goldco', name: 'Goldco', category: 'precious_metals', tagline: 'Best Buyback Guarantee', website: 'https://goldco.com', affiliate_url: 'https://goldco.com/?ref=iraresearchhub', setup_fee: '$0', annual_fee: '$175', transaction_fee: 'Varies', min_investment: '$25,000', supported_assets: ["Gold", "Silver"], asset_count: 2, custody_provider: 'Equity Trust', storage_type: 'Segregated', insurance_coverage: 'Lloyd\'s of London', bbb_rating: 'A+', founded_year: 2006, headquarters: 'Woodland Hills, CA', score_fees: 8.9, score_assets: 8.5, score_security: 9.2, score_compliance: 9.3, score_support: 9.4, score_reputation: 9.5, score_overall: 9.2, rank_overall: 4, is_featured: false, logo_url: '/logos/goldco.png', review_slug: 'goldco-review', meta_description: 'Goldco review 2026: fees, buyback guarantee, metals selection, and our overall rating.', review_count: 3421, id: 7, is_active: true, created_at: '2026-03-17T21:58:27.770152', updated_at: '2026-03-25T00:41:51.147943' },
  { slug: 'american-hartford-gold', name: 'American Hartford Gold', category: 'precious_metals', tagline: 'Best Price Match Guarantee', website: 'https://americanhartfordgold.com', affiliate_url: 'https://americanhartfordgold.com/?ref=iraresearchhub', setup_fee: '$0', annual_fee: '$180', transaction_fee: 'Varies', min_investment: '$10,000', supported_assets: ["Gold", "Silver", "Platinum"], asset_count: 3, custody_provider: 'Equity Trust / Brinks', storage_type: 'Segregated', insurance_coverage: 'Lloyd\'s of London', bbb_rating: 'A+', founded_year: 2015, headquarters: 'Los Angeles, CA', score_fees: 8.8, score_assets: 8.6, score_security: 9.0, score_compliance: 9.1, score_support: 9.2, score_reputation: 9.0, score_overall: 8.8, rank_overall: 5, is_featured: false, logo_url: '/logos/american-hartford-gold.png', review_slug: 'american-hartford-gold-review', meta_description: 'American Hartford Gold review 2026: fees, price match guarantee, metals selection, and our overall rating.', review_count: 2187, id: 8, is_active: true, created_at: '2026-03-17T21:58:27.770152', updated_at: '2026-03-25T00:41:51.148817' },
  { slug: 'lear-capital', name: 'Lear Capital', category: 'precious_metals', tagline: 'Notable for Experienced Investors', website: 'https://learcapital.com', affiliate_url: 'https://learcapital.com/?ref=iraresearchhub', setup_fee: '$0', annual_fee: '$180', transaction_fee: 'Varies', min_investment: '$7,500', supported_assets: ["Gold", "Silver", "Platinum", "Palladium"], asset_count: 4, custody_provider: 'Equity Trust', storage_type: 'Segregated or Commingled', insurance_coverage: 'Lloyd\'s of London', bbb_rating: 'B+', founded_year: 1997, headquarters: 'Los Angeles, CA', score_fees: 8.2, score_assets: 8.8, score_security: 8.5, score_compliance: 8.0, score_support: 8.3, score_reputation: 7.8, score_overall: 8.5, rank_overall: 6, is_featured: false, logo_url: '/logos/lear-capital.png', review_slug: 'lear-capital-review', meta_description: 'Lear Capital review 2026: 25+ years in business, fees, metals selection, and our overall rating.', review_count: 987, id: 9, is_active: true, created_at: '2026-03-17T21:58:27.770152', updated_at: '2026-03-25T00:41:51.149541' },
  { slug: 'noble-gold-investments', name: 'Noble Gold Investments', category: 'precious_metals', tagline: 'Notable for No Minimum', website: 'https://noblegoldinvestments.com', affiliate_url: 'https://noblegoldinvestments.com/?ref=iraresearchhub', setup_fee: '$80', annual_fee: '$150', transaction_fee: 'Varies', min_investment: '$2,000', supported_assets: ["Gold", "Silver", "Platinum", "Palladium"], asset_count: 4, custody_provider: 'Equity Trust', storage_type: 'Segregated', insurance_coverage: 'Lloyd\'s of London', bbb_rating: 'A+', founded_year: 2017, headquarters: 'Pasadena, CA', score_fees: 8.7, score_assets: 8.9, score_security: 9.0, score_compliance: 9.0, score_support: 9.2, score_reputation: 8.8, score_overall: 8.9, rank_overall: 7, is_featured: false, logo_url: '/logos/noble-gold-investments.png', review_slug: 'noble-gold-investments-review', meta_description: 'Noble Gold Investments review 2026: $2,000 minimum, all 4 metals, Texas storage vault, and our overall rating.', review_count: 876, id: 15, is_active: true, created_at: '2026-03-18T21:08:58.362451', updated_at: '2026-03-20T13:40:50.989521' },
  { slug: 'advantage-gold', name: 'Advantage Gold', category: 'precious_metals', tagline: 'Best Customer Satisfaction', website: 'https://advantagegold.com', affiliate_url: 'https://advantagegold.com/?ref=iraresearchhub', setup_fee: '$0', annual_fee: '$180', transaction_fee: 'Varies', min_investment: '$5,000', supported_assets: ["Gold", "Silver", "Platinum", "Palladium"], asset_count: 4, custody_provider: 'STRATA Trust', storage_type: 'Segregated', insurance_coverage: 'Lloyd\'s of London', bbb_rating: 'A+', founded_year: 2014, headquarters: 'Los Angeles, CA', score_fees: 8.8, score_assets: 9.0, score_security: 9.0, score_compliance: 9.1, score_support: 9.3, score_reputation: 9.2, score_overall: 9.0, rank_overall: 8, is_featured: false, logo_url: '/logos/advantage-gold.png', review_slug: 'advantage-gold-review', meta_description: 'Advantage Gold review 2026: AAA BCA rating, $5,000 minimum, all 4 metals, and our overall rating.', review_count: 543, id: 16, is_active: true, created_at: '2026-03-18T21:08:58.362457', updated_at: '2026-03-25T00:41:51.150128' },
  { slug: 'goldencrest-metals', name: 'GoldenCrest Metals', category: 'precious_metals', tagline: 'Best Pricing Transparency', website: 'https://goldencrestmetals.com', affiliate_url: 'https://goldencrestmetals.com/?ref=iraresearchhub', setup_fee: '$0', annual_fee: '$180', transaction_fee: 'Varies', min_investment: '$10,000', supported_assets: ["Gold", "Silver", "Platinum", "Palladium"], asset_count: 4, custody_provider: 'Delaware Depository', storage_type: 'Segregated', insurance_coverage: 'Lloyd\'s of London', bbb_rating: 'A', founded_year: 2020, headquarters: 'Scottsdale, AZ', score_fees: 9.0, score_assets: 9.0, score_security: 9.1, score_compliance: 9.0, score_support: 9.0, score_reputation: 8.7, score_overall: 9.0, rank_overall: 9, is_featured: false, logo_url: '/logos/goldencrest-metals.png', review_slug: 'goldencrest-metals-review', meta_description: 'GoldenCrest Metals review 2026: transparent pricing, all 4 metals, Delaware Depository storage, and our overall rating.', review_count: 87, id: 17, is_active: true, created_at: '2026-03-18T21:08:58.362462', updated_at: '2026-03-20T13:40:50.989526' },
  { slug: 'patriot-gold-group', name: 'Patriot Gold Group', category: 'precious_metals', tagline: 'Best No-Fee IRA', website: 'https://patriotgoldgroup.com', affiliate_url: 'https://patriotgoldgroup.com/?ref=iraresearchhub', setup_fee: '$0', annual_fee: '$0 (for qualifying accounts)', transaction_fee: 'Varies', min_investment: '$25,000', supported_assets: ["Gold", "Silver", "Platinum", "Palladium"], asset_count: 4, custody_provider: 'STRATA Trust', storage_type: 'Segregated', insurance_coverage: 'Lloyd\'s of London', bbb_rating: 'A+', founded_year: 2012, headquarters: 'Los Angeles, CA', score_fees: 9.1, score_assets: 8.8, score_security: 9.0, score_compliance: 9.0, score_support: 8.9, score_reputation: 8.8, score_overall: 8.9, rank_overall: 10, is_featured: false, logo_url: '/logos/patriot-gold-group.png', review_slug: 'patriot-gold-group-review', meta_description: 'Patriot Gold Group review 2026: no annual fees for qualifying accounts, all 4 metals, and our overall rating.', review_count: 312, id: 18, is_active: true, created_at: '2026-03-18T21:08:58.362467', updated_at: '2026-03-20T13:40:50.989529' },
  { slug: 'oxford-gold-group', name: 'Oxford Gold Group', category: 'precious_metals', tagline: 'Notable for Beginners', website: 'https://oxfordgoldgroup.com', affiliate_url: 'https://oxfordgoldgroup.com/?ref=iraresearchhub', setup_fee: '$0', annual_fee: '$175', transaction_fee: 'Varies', min_investment: '$7,500', supported_assets: ["Gold", "Silver", "Platinum", "Palladium"], asset_count: 4, custody_provider: 'Equity Trust / Brinks', storage_type: 'Segregated or Commingled', insurance_coverage: 'Lloyd\'s of London', bbb_rating: 'A+', founded_year: 2017, headquarters: 'Los Angeles, CA', score_fees: 8.6, score_assets: 8.8, score_security: 8.8, score_compliance: 8.9, score_support: 9.0, score_reputation: 8.7, score_overall: 8.8, rank_overall: 11, is_featured: false, logo_url: '/logos/oxford-gold-group.png', review_slug: 'oxford-gold-group-review', meta_description: 'Oxford Gold Group review 2026: beginner-friendly, $7,500 minimum, all 4 metals, and our overall rating.', review_count: 456, id: 19, is_active: true, created_at: '2026-03-18T21:08:58.362473', updated_at: '2026-03-20T13:40:50.989532' },
  { slug: 'preserve-gold', name: 'Preserve Gold', category: 'precious_metals', tagline: 'Best New Provider 2026', website: 'https://preservegold.com', affiliate_url: 'https://preservegold.com/?ref=iraresearchhub', setup_fee: '$0', annual_fee: '$180', transaction_fee: 'Varies', min_investment: '$5,000', supported_assets: ["Gold", "Silver", "Platinum", "Palladium"], asset_count: 4, custody_provider: 'Equity Trust', storage_type: 'Segregated', insurance_coverage: 'Lloyd\'s of London', bbb_rating: 'A+', founded_year: 2022, headquarters: 'Scottsdale, AZ', score_fees: 8.8, score_assets: 8.9, score_security: 9.0, score_compliance: 9.0, score_support: 9.1, score_reputation: 8.6, score_overall: 8.8, rank_overall: 12, is_featured: false, logo_url: '/logos/preserve-gold.png', review_slug: 'preserve-gold-review', meta_description: 'Preserve Gold review 2026: new provider with competitive fees, all 4 metals, and our overall rating.', review_count: 123, id: 20, is_active: true, created_at: '2026-03-18T21:08:58.362478', updated_at: '2026-03-20T13:40:50.989534' },
  { slug: 'rosland-capital', name: 'Rosland Capital', category: 'precious_metals', tagline: 'Notable for Collectible Coins', website: 'https://roslandcapital.com', affiliate_url: 'https://roslandcapital.com/?ref=iraresearchhub', setup_fee: '$0', annual_fee: '$225', transaction_fee: 'Varies', min_investment: '$5,000', supported_assets: ["Gold", "Silver", "Platinum", "Palladium"], asset_count: 4, custody_provider: 'Equity Trust', storage_type: 'Segregated or Commingled', insurance_coverage: 'Lloyd\'s of London', bbb_rating: 'A+', founded_year: 2008, headquarters: 'Santa Monica, CA', score_fees: 8.0, score_assets: 9.2, score_security: 8.7, score_compliance: 8.8, score_support: 8.5, score_reputation: 8.3, score_overall: 8.4, rank_overall: 13, is_featured: false, logo_url: '/logos/rosland-capital.png', review_slug: 'rosland-capital-review', meta_description: 'Rosland Capital review 2026: collectible coins, all 4 metals, $5,000 minimum, and our overall rating.', review_count: 678, id: 21, is_active: true, created_at: '2026-03-18T21:08:58.362483', updated_at: '2026-03-20T13:40:50.989537' },
  { slug: 'allegiance-gold', name: 'Allegiance Gold', category: 'precious_metals', tagline: 'Best No-Minimum IRA', website: 'https://allegiancegold.com', affiliate_url: 'https://allegiancegold.com/?ref=iraresearchhub', setup_fee: '$50', annual_fee: '$125', transaction_fee: 'Varies', min_investment: '$0', supported_assets: ["Gold", "Silver", "Platinum", "Palladium"], asset_count: 4, custody_provider: 'Equity Trust', storage_type: 'Segregated or Commingled', insurance_coverage: 'Lloyd\'s of London', bbb_rating: 'A+', founded_year: 2013, headquarters: 'Los Angeles, CA', score_fees: 8.9, score_assets: 8.7, score_security: 8.8, score_compliance: 8.9, score_support: 8.8, score_reputation: 8.6, score_overall: 8.7, rank_overall: 14, is_featured: false, logo_url: '/logos/allegiance-gold.png', review_slug: 'allegiance-gold-review', meta_description: 'Allegiance Gold review 2026: no account minimum, first-year fees waived, all 4 metals, and our overall rating.', review_count: 234, id: 22, is_active: true, created_at: '2026-03-18T21:08:58.362489', updated_at: '2026-03-20T13:40:50.989540' },
]

export default function BestPreciousMetalsIRAPage() {
  const { data, isLoading, isError } = useRankedProviders('precious_metals', 20)
  // Use static fallback during prerender (when API is unavailable) or while loading
  const providers = data?.providers ?? STATIC_PM_PROVIDERS

  return (
    <>
      <SEO
        title="2026 Gold IRA Provider Comparison & Independent Analysis"
        description="The best gold IRA companies of 2026, ranked by fees, security, metals selection, and customer support. Independent, data-driven rankings."
        canonical="/precious-metals-ira/best-companies"
        ogType="article"
      />
      <script type="application/ld+json" dangerouslySetInnerHTML={{ __html: JSON.stringify(faqSchema) }} />
      <script type="application/ld+json" dangerouslySetInnerHTML={{ __html: JSON.stringify(itemListSchema) }} />
      <script type="application/ld+json" dangerouslySetInnerHTML={{ __html: JSON.stringify(entityHubSchema) }} />
      <script type="application/ld+json" dangerouslySetInnerHTML={{ __html: JSON.stringify(speakableSchema) }} />
      <script type="application/ld+json" dangerouslySetInnerHTML={{ __html: JSON.stringify(aggregateRatingSchema) }} />
      {/* Header */}
      <section className="bg-[#F8FAFC] border-b border-slate-200">
        <div className="container-site py-12">

      {/* Original Research Banner */}
      <div className="mb-6 flex items-start gap-3 p-4 bg-indigo-50 border border-indigo-200 rounded-xl text-sm">
        <svg className="w-5 h-5 text-indigo-500 flex-shrink-0 mt-0.5" fill="none" viewBox="0 0 24 24" stroke="currentColor">
          <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M9 12l2 2 4-4m6 2a9 9 0 11-18 0 9 9 0 0118 0z" />
        </svg>
        <p className="text-indigo-800">
          <span className="font-semibold">Independent Analysis:</span>{' '}
          Based on our independent scoring of publicly available data across 2,400+ data points from 22 providers —
          updated quarterly. Data sourced from IRS Publication 590-A/B, SEC filings, FINRA BrokerCheck,
          custodian disclosures, and BBB records.
        </p>
      </div>
          <div className="inline-flex items-center px-2.5 py-0.5 rounded-full text-xs font-medium bg-amber-100 text-amber-700 mb-4">
            Updated {LAST_UPDATED} · Live Data
          </div>
          <h1 className="text-4xl font-bold text-[#0F172A] mb-4">
            2026 Precious Metals IRA Provider Comparison & Independent Analysis</h1>
              <AdvertiserDisclosure />

          {/* W2.X — Quote-ready citation block */}
          <p className="speakable-summary citation-block text-lg text-[#64748B] max-w-2xl leading-relaxed">
            <strong>The best gold IRA companies in 2026 are Genesis Gold Group (9.4/10), Goldco (9.2/10), and Augusta Precious Metals (9.1/10)</strong>, based on independent scoring across fees, storage security, metals selection, and customer support. We reviewed 14 precious metals IRA providers across 47 data points.
          </p>
          <p className="text-sm text-slate-400 mt-3">
            <Link to="/methodology" className="text-[#D97706] hover:underline">How we rate providers</Link>
            {' '}· By <a href="/author/james-mitchell" className="text-[#0EA5E9] hover:underline">James Mitchell, CFA</a> · Last updated: {LAST_UPDATED}
          </p>
          {/* W2.CC — YMYL disclaimer */}
          <p className="text-xs text-slate-400 mt-2 max-w-2xl">
            Precious metals IRAs carry market and liquidity risks. Rankings are for informational purposes only and do not constitute financial advice. Always consult a licensed financial advisor before investing.
          </p>
        </div>
      </section>

      {/* Provider cards */}
      <section className="section-padding">
        <div className="container-site">
          {isLoading && (
            <div className="space-y-6">
              {[1, 2, 3].map((i) => (
                <div key={i} className="card animate-pulse">
                  <div className="h-6 bg-slate-100 rounded w-1/3 mb-4" />
                  <div className="h-4 bg-slate-100 rounded w-2/3" />
                </div>
              ))}
            </div>
          )}

          {isError && (
            <div className="card border-red-200 text-center py-10">
              <p className="text-[#64748B]">Unable to load provider data. Please try again shortly.</p>
            </div>
          )}

          <div className="space-y-6">
              {providers.map((provider, index) => (
                <ProviderCard
                  key={provider.slug}
                  provider={provider}
                  rank={provider.rank_overall ?? index + 1}
                />
              ))}
            </div>

          {/* Methodology note */}
          <div className="mt-10 p-6 bg-[#F8FAFC] rounded-xl border border-slate-200">
            <h3 className="font-semibold text-[#0F172A] mb-2">About Our Rankings</h3>
            <p className="text-sm text-[#64748B] leading-relaxed">
              Rankings are determined by our independent scoring methodology, which evaluates providers
              across six weighted criteria: fee transparency (20%), metals selection (20%), security &
              storage (20%), IRS compliance (15%), customer support (15%), and reputation (10%).
              Rankings are updated quarterly.{' '}
              <Link to="/methodology" className="text-[#D97706] hover:underline">
                Read our full methodology.
              </Link>
            </p>
          </div>
          {/* W2.K — Changelog */}
          <div className="mt-10 p-5 bg-slate-50 rounded-xl border border-slate-200">
            <h3 className="font-semibold text-[#0F172A] mb-3 text-sm uppercase tracking-wider">Ranking Changelog</h3>
            <ul className="space-y-1.5 text-sm text-[#64748B]">
              <li><span className="font-medium text-slate-700">March 2026:</span> Expanded to 14 providers. Added Noble Gold, Advantage Gold, GoldenCrest Metals, Patriot Gold Group, Oxford Gold Group, Preserve Gold, Rosland Capital, Allegiance Gold.</li>
              <li><span className="font-medium text-slate-700">January 2026:</span> Initial rankings published. 6 providers scored: Augusta, Goldco, Birch Gold, American Hartford Gold, Genesis Gold, Lear Capital.</li>
            </ul>
          </div>
          {/* Related Guides */}
          <div className="mt-6 p-6 bg-amber-50 rounded-xl border border-amber-200">
            <h3 className="font-semibold text-[#0F172A] mb-4">Related Guides</h3>
            <div className="grid md:grid-cols-4 gap-4">
              <Link to="/precious-metals-ira/401k-to-gold-ira-rollover" className="block p-4 bg-white rounded-lg border border-amber-200 hover:border-amber-400 transition-colors">
                <div className="text-sm font-semibold text-[#0F172A] mb-1">401k to Gold IRA Rollover</div>
                <div className="text-xs text-[#64748B]">Step-by-step guide to rolling over your 401k tax-free</div>
              </Link>
              <Link to="/gold-ira-vs-crypto-ira" className="block p-4 bg-white rounded-lg border border-amber-200 hover:border-amber-400 transition-colors">
                <div className="text-sm font-semibold text-[#0F172A] mb-1">Gold IRA vs Crypto IRA</div>
                <div className="text-xs text-[#64748B]">Compare physical gold vs digital assets for your IRA</div>
              </Link>
              <Link to="/methodology" className="block p-4 bg-white rounded-lg border border-amber-200 hover:border-amber-400 transition-colors">
                <div className="text-sm font-semibold text-[#0F172A] mb-1">How We Rate Providers</div>
                <div className="text-xs text-[#64748B]">Our independent 6-criteria scoring methodology</div>
              </Link>
              <Link to="/research/crypto-ira-fees-2026" className="block p-4 bg-white rounded-lg border border-amber-200 hover:border-amber-400 transition-colors">
                <div className="text-sm font-semibold text-[#0F172A] mb-1">2026 IRA Fee Research</div>
                <div className="text-xs text-[#64748B]">Normalized fee data across all providers</div>
              </Link>
            </div>
          </div>
        </div>
      </section>
      {/* ── Newsletter Signup ─────────────────────────────────────────── */}
      <div className="container-site py-10 max-w-3xl">
                {/* Related Links */}
        <div className="mt-10 mb-6">
          <RelatedLinks variant="metals-review" title="Related Guides &amp; Reviews" />
        </div>
        <NewsletterSignup />
      </div>
    </>
  )
}
