import StateGuideTemplate from '../components/StateGuideTemplate'

export default function BestCryptoIRANDPage() {
  return (
    <StateGuideTemplate
      stateName="North Dakota"
      stateAbbr="ND"
      slug="north-dakota"
    />
  )
}
