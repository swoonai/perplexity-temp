import StateGuideTemplate from '../components/StateGuideTemplate'

export default function BestCryptoIRADEPage() {
  return (
    <StateGuideTemplate
      stateName="Delaware"
      stateAbbr="DE"
      slug="delaware"
    />
  )
}
