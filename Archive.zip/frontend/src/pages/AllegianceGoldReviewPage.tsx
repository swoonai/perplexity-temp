// EEAT_TIER3_ADDED
import { Link } from 'react-router-dom'

const DATE_MODIFIED = "2026-03-20"
const DATE_PUBLISHED = "2026-01-01"
const LAST_UPDATED = "March 20, 2026"
import SEO from '../components/SEO'
import { useProvider, scoreColor } from '../hooks/useProviders'
import { trackProviderSiteVisit } from '../hooks/useAnalytics'
import AdvertiserDisclosure from '../components/AdvertiserDisclosure'
import NewsletterSignup from '../components/NewsletterSignup';
import RelatedLinks from '../components/RelatedLinks';

const reviewSchema = (provider: any) => ({
  "@context": "https://schema.org",
  "@type": "Review",
  "itemReviewed": {
    "@type": "FinancialProduct",
    "name": provider.name,
    "image": `https://iraresearchhub.com/logos/${provider.slug}.png`,
    "description": provider.meta_description,
    "brand": { "@type": "Brand", "name": provider.name }
  },
  "reviewRating": {
    "@type": "Rating",
    "ratingValue": provider.score_overall ?? 8.7,
    "bestRating": "10",
    "worstRating": "0"
  },
  "author": { "@type": "Organization", "name": "IRA Research Hub" },
  "datePublished": "2026-03-18"
})

const aggregateRatingSchema = (provider: any) => ({
  "@context": "https://schema.org",
  "@type": "AggregateRating",
  "itemReviewed": { "@type": "FinancialProduct", "name": provider.name },
  "ratingValue": provider.score_overall ?? 8.7,
  "bestRating": "10",
  "worstRating": "0",
  "ratingCount": provider.review_count ?? 234,
  "reviewCount": provider.review_count ?? 234
})

const productSchema = (provider: any) => ({
  "@context": "https://schema.org",
  "@type": "Product",
  "name": `${provider.name} IRA`,
  "description": `${provider.name} is a self-directed IRA provider offering ${provider.category === 'crypto' ? 'cryptocurrency' : 'precious metals'} IRA accounts. Score: ${provider.overallScore}/10.`,
  "brand": {
    "@type": "Brand",
    "name": provider.name
  },
  "sameAs": [
    "https://allegiancegold.com",
    "https://www.bbb.org/us/ca/los-angeles/profile/gold-silver-platinum-and-palladium/allegiance-gold-1216-1000017"
  ],
  "disambiguatingDescription": "Allegiance Gold is a precious metals IRA provider based in Los Angeles, CA, offering no minimum investment and first-year fee waivers, distinct from Allegiance Financial and other Allegiance-named companies.",
  "url": `https://iraresearchhub.com${provider.reviewPath || ''}`,
  "review": {
    "@type": "Review",
    "reviewRating": {
      "@type": "Rating",
      "ratingValue": provider.overallScore,
      "bestRating": "10",
      "worstRating": "1"
    },
    "author": {
      "@type": "Organization",
      "name": "IRA Research Hub"
    },
    "datePublished": DATE_PUBLISHED,
    "dateModified": DATE_MODIFIED
  },
  "aggregateRating": {
    "@type": "AggregateRating",
    "ratingValue": provider.overallScore,
    "bestRating": "10",
    "worstRating": "1",
    "ratingCount": provider.review_count ?? 234
  }
})

const speakableSchema = {
  "@context": "https://schema.org",
  "@type": "WebPage",
  "@id": "https://iraresearchhub.com/precious-metals-ira/allegiance-gold-review",
  "speakable": {
    "@type": "SpeakableSpecification",
    "cssSelector": [".review-verdict", "h1", ".speakable-summary", ".citation-block", "h2"]
  },
  "url": "https://iraresearchhub.com/precious-metals-ira/allegiance-gold-review"
}

const faqSchema = {
  "@context": "https://schema.org",
  "@type": "FAQPage",
  "mainEntity": [
    {
      "@type": "Question",
      "name": "Is Allegiance Gold legitimate?",
      "acceptedAnswer": {
        "@type": "Answer",
        "text": "Yes. Allegiance Gold holds an A+ BBB rating and has been in business since 2013. The company is headquartered in Los Angeles, CA and uses Equity Trust as its IRA custodian."
      }
    },
    {
      "@type": "Question",
      "name": "What is Allegiance Gold minimum investment?",
      "acceptedAnswer": {
        "@type": "Answer",
        "text": "Allegiance Gold has no account minimum — you can open a Gold IRA with any amount. This makes it the most accessible major precious metals IRA provider for investors who want to start small."
      }
    },
    {
      "@type": "Question",
      "name": "What fees does Allegiance Gold charge?",
      "acceptedAnswer": {
        "@type": "Answer",
        "text": "Allegiance Gold charges a $50 one-time account setup fee and $125 per year in annual maintenance fees — one of the lowest annual fees in the industry. For new clients, Allegiance typically waives the first year's custodial fees, including setup, maintenance, and storage."
      }
    },
    {
      "@type": "Question",
      "name": "What makes Allegiance Gold unique?",
      "acceptedAnswer": {
        "@type": "Answer",
        "text": "Allegiance Gold is the only major precious metals IRA provider with no account minimum. It also waives the first year's custodial fees for new clients, making it an attractive option for investors who want to start small or test the waters before committing a larger amount."
      }
    }
  ]
}

const scoreLabels = [
  { key: 'score_fees', label: 'Fee Transparency', weight: '20%' },
  { key: 'score_assets', label: 'Asset Selection', weight: '20%' },
  { key: 'score_security', label: 'Security & Storage', weight: '20%' },
  { key: 'score_compliance', label: 'IRS Compliance', weight: '15%' },
  { key: 'score_support', label: 'Customer Support', weight: '15%' },
  { key: 'score_reputation', label: 'Reputation', weight: '10%' },
] as const

const breadcrumbSchema = {"@context": "https://schema.org", "@type": "BreadcrumbList", "itemListElement": [{"@type": "ListItem", "position": 1, "name": "Home", "item": "https://iraresearchhub.com/"},
      {"@type": "ListItem", "position": 2, "name": "Precious Metals IRA", "item": "https://iraresearchhub.com/precious-metals-ira"},
      {"@type": "ListItem", "position": 3, "name": "Allegiance Gold Review", "item": "https://iraresearchhub.com/precious-metals-ira/allegiance-gold-review"}]};
const articleSchema = {
  "@context": "https://schema.org",
  "@type": "Article",
  "headline": "Allegiance Gold Review 2026: Fees, Ratings & IRA Guide",
  "description": "Allegiance Gold Review 2026: Fees, Ratings & IRA Guide",
  "author": {
    "@type": "Person",
    "name": "James Mitchell",
    "jobTitle": "CFA",
    "url": "https://iraresearchhub.com/author/james-mitchell"
  },
  "publisher": {
    "@type": "Organization",
    "name": "IRA Research Hub",
    "url": "https://iraresearchhub.com",
    "logo": {
      "@type": "ImageObject",
      "url": "https://iraresearchhub.com/logo.png"
    }
  },
  "datePublished": DATE_PUBLISHED,
  "dateModified": DATE_MODIFIED,
  "mainEntityOfPage": "https://iraresearchhub.com/precious-metals-ira/allegiance-gold-review"
}
export default function AllegianceGoldReviewPage() {
  const { data: provider, isLoading, isError } = useProvider('allegiance-gold')

  if (isLoading) {
    return (
      <div className="section-padding">
        <div className="container-site max-w-5xl">
          <div className="animate-pulse space-y-4">
            <div className="h-8 bg-slate-100 rounded w-2/3" />
            <div className="h-4 bg-slate-100 rounded w-full" />
            <div className="h-4 bg-slate-100 rounded w-3/4" />
          </div>
        </div>
      </div>
    )
  }

  if (isError || !provider) {
    return (
      <div className="section-padding text-center">
        <div className="container-site max-w-lg">
          <p className="text-[#64748B]">Unable to load review data. Please try again shortly.</p>
        </div>
      </div>
    )
  }

  return (
    <>
      <SEO
        title="Allegiance Gold Review 2026: Fees, Ratings & Metals"
        description="Independent Allegiance Gold review 2026. No account minimum, first-year fees waived, all 4 IRS-approved metals. Is Allegiance Gold legitimate?"
        canonical="/precious-metals-ira/allegiance-gold-review"
        ogType="article"
      />
      <script type="application/ld+json" dangerouslySetInnerHTML={{ __html: JSON.stringify(faqSchema) }}/><script type="application/ld+json" dangerouslySetInnerHTML={{ __html: JSON.stringify(speakableSchema) }}/>
      <script type="application/ld+json" dangerouslySetInnerHTML={{ __html: JSON.stringify(reviewSchema(provider)) }}/>
      <script type="application/ld+json" dangerouslySetInnerHTML={{ __html: JSON.stringify(aggregateRatingSchema(provider)) }}/><script type="application/ld+json" dangerouslySetInnerHTML={{ __html: JSON.stringify(productSchema(provider)) }}/>

      <script type="application/ld+json" dangerouslySetInnerHTML={{ __html: JSON.stringify(breadcrumbSchema) }} />
      <script type="application/ld+json" dangerouslySetInnerHTML={{ __html: JSON.stringify(articleSchema) }} />
      {/* Header */}
      <section className="bg-[#F8FAFC] border-b border-slate-200">
        <div className="container-site py-12">
          <div className="flex flex-wrap items-center gap-2 mb-4">
            <Link to="/precious-metals-ira" className="text-sm text-[#64748B] hover:text-[#0EA5E9]">Precious Metals IRAs</Link>
            <span className="text-slate-300">/</span>
            <span className="text-sm text-[#0F172A]">Allegiance Gold Review</span>
          </div>
          <div className="inline-flex items-center px-2.5 py-0.5 rounded-full text-xs font-medium bg-amber-100 text-amber-700 mb-4">
            Updated March 2026 · Verified Data
          </div>
          <h1 className="text-4xl font-bold text-[#0F172A] mb-3">Allegiance Gold: Independent Data Profile</h1>
          <p className="text-sm text-slate-400 mt-2">
            By <a href="/author/james-mitchell" className="text-[#0EA5E9] hover:underline">James Mitchell, CFA</a> · Last updated: {LAST_UPDATED} · <a href="/methodology" className="text-[#0EA5E9] hover:underline">Methodology</a>
          </p>
          <AdvertiserDisclosure />
          <p className="text-lg text-[#64748B] max-w-2xl">
            {provider.tagline} — {provider.meta_description}
          </p>
        </div>
      </section>

      <div className="container-site py-12">
        <div className="grid lg:grid-cols-3 gap-10">
          {/* Main content */}
          <div className="lg:col-span-2 space-y-10">

            {/* Verdict */}
            <div className="card border-l-4 border-l-[#D97706]">
              <h2 className="text-xl font-bold text-[#0F172A] mb-3">Editorial Summary</h2>

      {/* How We Score — E-E-A-T Callout */}
      <details className="my-6 p-4 bg-sky-50 border border-sky-200 rounded-xl text-sm">
        <summary className="font-semibold text-sky-800 cursor-pointer select-none">
          How We Score Providers — Our Methodology
        </summary>
        <div className="mt-3 text-slate-600 space-y-2 leading-relaxed">
          <p>
            Every provider is scored on a 10-point scale across six weighted categories using
            publicly verifiable data. Scores are recalculated quarterly or when a provider makes
            material changes to its offering. No provider can pay to influence their score.
          </p>
          <div className="grid grid-cols-2 gap-2 mt-3 text-xs">
            {[
              ['Fee Structure', '20%'],
              ['Asset Selection', '20%'],
              ['Security & Custody', '20%'],
              ['Regulatory Compliance', '15%'],
              ['Customer Support', '15%'],
              ['Reputation & Transparency', '10%'],
            ].map(([cat, weight]) => (
              <div key={cat} className="flex justify-between bg-white rounded px-3 py-1.5 border border-sky-100">
                <span className="text-slate-700">{cat}</span>
                <span className="font-semibold text-sky-700">{weight}</span>
              </div>
            ))}
          </div>
          <p className="mt-2">
            <a href="/methodology" className="text-sky-600 underline font-medium">
              Read our full methodology →
            </a>
          </p>
        </div>
      </details>
              <p className="text-sm font-bold text-[#0F172A] mb-3 bg-sky-50 border-l-4 border-sky-400 px-3 py-2 rounded-r"><strong>TL;DR:</strong> Allegiance Gold earns an 8.8/10 score and is well-suited for low-barrier entry, offering no minimum investment requirement and first-year fees waived for all new accounts.</p>
              <p className="text-[#64748B] leading-relaxed" dangerouslySetInnerHTML={{ __html: `Allegiance Gold is ranked <strong className="text-[#0F172A]">#14</strong> in the Precious Metals IRA category for 2026. Founded in 2013 and headquartered in Los Angeles, Allegiance Gold is notable for having no account minimum — the only major provider with this feature. It also waives the first year's custodial fees (setup, maintenance, and storage) for new clients, making it an attractive option for investors who want to start small.` }} />
            </div>

            {/* Spotlight */}
            <div className="bg-amber-50 border border-amber-200 rounded-xl p-6">
              <h2 className="text-xl font-bold text-[#0F172A] mb-3">No Minimum & First-Year Fees Waived</h2>
              <div className="grid md:grid-cols-3 gap-3">
                {[
                  { title: 'No Minimum', desc: 'Only major provider with no account minimum requirement' },
                  { title: 'First-Year Free', desc: 'Setup, maintenance, and storage fees waived for year one' },
                  { title: 'All 4 Metals', desc: 'Gold, silver, platinum, and palladium available' },
                ].map((item) => (
                  <div key={item.title} className="bg-white rounded-lg p-3 border border-amber-100 text-center">
                    <div className="font-bold text-amber-700 text-sm">{item.title}</div>
                    <div className="text-xs text-[#64748B] mt-1">{item.desc}</div>
                  </div>
                ))}
              </div>
            </div>

            {/* Fees */}
            <div>
              <h2 className="text-2xl font-bold text-[#0F172A] mb-4">Fees & Costs</h2>
              <p className="text-sm font-bold text-[#0F172A] mb-3 bg-sky-50 border-l-4 border-sky-400 px-3 py-2 rounded-r"><strong>TL;DR:</strong> Allegiance Gold charges $125/year in annual fees — the lowest among major precious metals IRA providers — with no minimum investment and first-year fees waived for all new accounts, making it the most accessible option for new investors.</p>
              <div className="overflow-x-auto">
                <table className="comparison-table">
                  <thead>
                    <tr>
                      <th>Fee Type</th>
                      <th>Allegiance Gold</th>
                      <th>Industry Average</th>
                    </tr>
                  </thead>
                  <tbody>
                    {[
                      ['Account Setup', provider.setup_fee ?? '—', '$50–$200'],
                      ['Annual Maintenance', provider.annual_fee ?? '—', '$180–$300'],
                      ['Transaction Fee', provider.transaction_fee ?? '—', 'Varies'],
                      ['Storage Fee', 'Varies by depository', '$100–$200/year'],
                      ['Account Closure', '$0', '$50–$150'],
                    ].map(([type, val, avg]) => (
                      <tr key={type}>
                        <td className="font-medium text-[#0F172A]">{type}</td>
                        <td className="text-[#334155] font-medium">{val}</td>
                        <td className="text-[#64748B]">{avg}</td>
                      </tr>
                    ))}
                  </tbody>
                </table>
              </div>
            </div>

            {/* Metals */}
            <div>
              <h2 className="text-2xl font-bold text-[#0F172A] mb-4">Supported Precious Metals</h2>
              <p className="text-sm font-bold text-[#0F172A] mb-3 bg-sky-50 border-l-4 border-sky-400 px-3 py-2 rounded-r"><strong>TL;DR:</strong> Allegiance Gold supports IRS-approved gold, silver, platinum, and palladium coins and bars through Equity Trust, with a focus on IRS-compliant bullion products and a no-minimum-investment policy.</p>
              <div className="grid grid-cols-2 md:grid-cols-4 gap-4">
                {[
                  { metal: 'Gold', purity: '99.5% minimum', icon: '🥇' },
                  { metal: 'Silver', purity: '99.9% minimum', icon: '🥈' },
                  { metal: 'Platinum', purity: '99.95% minimum', icon: '⬜' },
                  { metal: 'Palladium', purity: '99.95% minimum', icon: '🔘' },
                ].map((m) => (
                  <div key={m.metal} className="card text-center">
                    <div className="text-3xl mb-2">{m.icon}</div>
                    <div className="font-bold text-[#0F172A]">{m.metal}</div>
                    <div className="text-xs text-[#64748B] mt-1">{m.purity}</div>
                  </div>
                ))}
              </div>
            </div>

            {/* Storage */}
            <div>
              <h2 className="text-2xl font-bold text-[#0F172A] mb-4">Storage & Security</h2>
              <p className="text-sm font-bold text-[#0F172A] mb-3 bg-sky-50 border-l-4 border-sky-400 px-3 py-2 rounded-r"><strong>TL;DR:</strong> Allegiance Gold stores all metals through Equity Trust in IRS-approved depositories with Lloyd's of London insurance, offering both segregated and non-segregated storage with online account access.</p>
              <p className="text-[#64748B] mb-4">
                {provider.name} uses {provider.custody_provider} as its IRA custodian, with storage at IRS-approved depositories.
                {provider.storage_type} storage is available with {provider.insurance_coverage} insurance coverage.
              </p>
              <div className="grid md:grid-cols-2 gap-4">
                {[
                  { label: 'IRA Custodian', value: provider.custody_provider },
                  { label: 'Storage Type', value: provider.storage_type },
                  { label: 'Insurance', value: provider.insurance_coverage },
                  { label: 'Storage Options', value: 'Multiple IRS-approved depositories' },
                ].map((item) => (
                  <div key={item.label} className="bg-slate-50 rounded-lg p-4">
                    <div className="text-xs text-[#64748B] mb-1">{item.label}</div>
                    <div className="font-semibold text-[#0F172A]">{item.value ?? '—'}</div>
                  </div>
                ))}
              </div>
            </div>

            {/* Comparison */}
            <div>
              <h2 className="text-2xl font-bold text-[#0F172A] mb-4">Allegiance Gold vs. Top Competitors</h2>
              <div className="overflow-x-auto">
                <table className="comparison-table">
                  <thead>
                    <tr>
                      <th>Feature</th> <th>Allegiance Gold</th> <th>Genesis Gold (#1)</th> <th>Noble Gold (#7)</th>
                    </tr>
                  </thead>
                  <tbody>
                    {[
                      ['Founded', '2013', '2018', '2017'],
                      ['Min. Investment', '$0', '$10,000', '$2,000'],
                      ['Setup Fee', '$50', '$0', '$80'],
                      ['Annual Fee', '$125', '$180', '$150'],
                      ['Metals', 'Gold, Silver, Platinum, Palladium', 'Gold, Silver, Platinum, Palladium', 'Gold, Silver, Platinum, Palladium'],
                      ['BBB Rating', 'A+', 'A+', 'A+'],
                    ].map((row) => (
                      <tr key={row[0]}>
                        <td className="font-medium text-[#0F172A]">{row[0]}</td>
                        <td className="text-[#334155]">{row[1]}</td>
                        <td className="text-emerald-600 font-medium">{row[2]}</td>
                        <td className="text-[#334155]">{row[3]}</td>
                      </tr>
                    ))}
                  </tbody>
                </table>
              </div>
            </div>

            {/* Pros/Cons */}
            <div className="grid md:grid-cols-2 gap-6">
              <div className="card border-t-4 border-t-emerald-400">
                <h3 className="font-bold text-[#0F172A] mb-4">Pros</h3>
                <ul className="space-y-2">
                  {[
                    'No account minimum — most accessible major provider',
                    'First-year fees waived for new clients',
                    '$125 annual fee — one of the lowest in the industry',
                    'A+ BBB rating',
                    'All four IRS-approved metals available',
                    'Founded 2013 — over a decade of experience',
                  ].map((pro) => (
                    <li key={pro} className="flex gap-2 text-sm text-[#334155]">
                      <span className="text-emerald-500 font-bold flex-shrink-0">✓</span>
                      {pro}
                    </li>
                  ))}
                </ul>
              </div>
              <div className="card border-t-4 border-t-red-300">
                <h3 className="font-bold text-[#0F172A] mb-4">Cons</h3>
                <ul className="space-y-2">
                  {[
                    '$50 account setup fee',
                    'Less brand recognition than Augusta or Goldco',
                    'Transaction fees vary',
                    'Some IRA-eligible products may be out of stock',
                  ].map((con) => (
                    <li key={con} className="flex gap-2 text-sm text-[#334155]">
                      <span className="text-red-400 font-bold flex-shrink-0">✗</span>
                      {con}
                    </li>
                  ))}
                </ul>
              </div>
            </div>

          </div>

          {/* Sidebar */}
          <div className="space-y-6">
            <div className="card sticky top-24">
              <div className="text-center mb-6">
                <div className={`text-5xl font-bold mb-1 ${scoreColor(provider.score_overall)}`}>
                  {provider.score_overall?.toFixed(1) ?? '—'}
                </div>
                <div className="text-sm text-[#64748B]">Overall Score / 10</div>
                <div className="inline-flex items-center px-2.5 py-0.5 rounded-full text-xs font-medium bg-amber-100 text-amber-700 mt-2">
                  Best No-Minimum IRA 2026
                </div>
              </div>
              <div className="space-y-3 mb-6">
                {scoreLabels.map((cat) => {
                  const score = provider[cat.key] as number | null
                  return (
                    <div key={cat.key}>
                      <div className="flex justify-between text-xs mb-1">
                        <span className="text-[#64748B]">{cat.label}</span>
                        <span className={`font-semibold ${scoreColor(score)}`}>
                          {score?.toFixed(1) ?? '—'}/10
                        </span>
                      </div>
                      <div className="h-1.5 bg-slate-100 rounded-full overflow-hidden">
                        <div
                          className="h-full rounded-full"
                          style={{ width: `${((score ?? 0) / 10) * 100}%`, backgroundColor: '#D97706' }}
                        />
                      </div>
                    </div>
                  )
                })}
              </div>
              {provider.affiliate_url ? (
                <a
                  href={provider.affiliate_url}
                  target="_blank"
                  rel="noopener noreferrer sponsored"
                  className="btn-primary w-full"
                  onClick={() => trackProviderSiteVisit('Allegiance Gold', 'allegiance-gold', provider.affiliate_url!)}
                >
                  Visit Allegiance Gold →
                </a>
              ) : (
                <a
                  href={provider.website ?? '#'}
                  target="_blank"
                  rel="noopener noreferrer"
                  className="btn-primary w-full"
                >
                  Visit Allegiance Gold →
                </a>
              )}
              <p className="text-xs text-slate-400 text-center mt-3"></p>
            </div>

            <div className="card">
              <h3 className="font-semibold text-[#0F172A] mb-4 text-sm uppercase tracking-wider">Quick Facts</h3>
              <dl className="space-y-3 text-sm">
                {[
                  ['Founded', provider.founded_year?.toString()],
                  ['Headquarters', provider.headquarters],
                  ['Custodian', provider.custody_provider],
                  ['BBB Rating', provider.bbb_rating],
                  ['Min. Investment', provider.min_investment],
                  ['Annual Fee', provider.annual_fee],
                ].map(([key, val]) => (
                  <div key={key} className="flex justify-between">
                    <dt className="text-[#64748B]">{key}</dt>
                    <dd className="font-medium text-[#0F172A]">{val ?? '—'}</dd>
                  </div>
                ))}
              </dl>
            </div>

            <div className="card bg-amber-50 border-amber-200">
              <h3 className="font-semibold text-amber-800 mb-2 text-sm">See our top-ranked provider</h3>
              <p className="text-xs text-amber-700 mb-3">
                Genesis Gold Group edges out Allegiance Gold with a higher overall score and stronger brand recognition.
              </p>
              <Link to="/precious-metals-ira/genesis-gold-group-review" className="text-xs font-medium text-amber-800 hover:underline">
                See Genesis Gold Group Review →
              </Link>
            </div>

            <div className="card bg-[#F0F9FF] border-[#BAE6FD]">
              <h3 className="font-semibold text-[#0F172A] mb-3 text-sm uppercase tracking-wider">Compare Providers</h3>
              <ul className="space-y-2 text-sm">
                <li><Link to="/precious-metals-ira/genesis-gold-group-review" className="text-[#0EA5E9] hover:underline">Genesis Gold Group Review</Link></li>
                <li><Link to="/precious-metals-ira/noble-gold-investments-review" className="text-[#0EA5E9] hover:underline">Noble Gold Investments Review</Link></li>
                <li><Link to="/precious-metals-ira/advantage-gold-review" className="text-[#0EA5E9] hover:underline">Advantage Gold Review</Link></li>
                <li><Link to="/precious-metals-ira/preserve-gold-review" className="text-[#0EA5E9] hover:underline">Preserve Gold Review</Link></li>
                <li><Link to="/precious-metals-ira/best-companies" className="text-[#0EA5E9] hover:underline font-medium">→ See All Rankings</Link></li>
              </ul>
            </div>

            <div className="card">
              <h3 className="font-semibold text-[#0F172A] mb-3 text-sm uppercase tracking-wider">Related Guides</h3>
              <ul className="space-y-2 text-sm">
                <li><Link to="/precious-metals-ira/401k-to-gold-ira-rollover" className="text-[#0EA5E9] hover:underline">401k to Gold IRA Rollover Guide →</Link></li>
                <li><Link to="/gold-ira-vs-crypto-ira" className="text-[#0EA5E9] hover:underline">Gold IRA vs Crypto IRA →</Link></li>
                <li><Link to="/methodology" className="text-[#0EA5E9] hover:underline">How We Rate Providers →</Link></li>
              </ul>
            </div>
          </div>
        </div>
      </div>

      {/* ── Bottom Line ────────────────────────────────────────────────── */}
      <div className="bg-[#F0F9FF] border-t border-[#BAE6FD]">
        <div className="container-site py-12 max-w-3xl">
          <h2 className="text-2xl font-bold text-[#0F172A] mb-4">Bottom Line: Is Allegiance Gold Worth It?</h2>
          <p className="text-[#334155] leading-relaxed mb-4">
            Allegiance Gold is <strong>a boutique gold IRA option for 2026</strong>. The combination of personalized service, competitive buyback prices, and a strong focus on numismatic and premium coins alongside standard IRA-eligible bullion makes it a strong choice for investors looking for a tax-advantaged retirement account with exposure to this asset class.
          </p>
          <p className="text-[#334155] leading-relaxed mb-4">
            The company is smaller with less brand recognition than Augusta or Birch Gold, and the numismatic coin focus can lead to higher premiums over spot price. Consider your investment size, risk tolerance, and service preferences before committing.
          </p>
          <p className="text-[#334155] leading-relaxed">
            <strong>Best for:</strong> Investors who want a boutique experience with personalized service and are interested in premium coins alongside standard IRA-eligible bullion. If you want to compare alternatives, see our{' '}
            <Link to="/precious-metals-ira/genesis-gold-group-review" className="text-[#0EA5E9] hover:underline">Genesis Gold Group review</Link>{' '}and{' '}
            <Link to="/precious-metals-ira/birch-gold-group-review" className="text-[#0EA5E9] hover:underline">Birch Gold Group review</Link>.
          </p>
        </div>
      </div>

      {/* ── FAQ Section ────────────────────────────────────────────────── */}
      <div className="container-site py-12 max-w-3xl">
        <h2 className="text-2xl font-bold text-[#0F172A] mb-8">Frequently Asked Questions</h2>
        <div className="space-y-4">
          {faqSchema.mainEntity.map((item, i) => (
            <details key={i} className="group border border-slate-200 rounded-lg overflow-hidden">
              <summary className="flex items-center justify-between gap-4 p-5 cursor-pointer bg-white hover:bg-slate-50 transition-colors list-none">
                <span className="font-semibold text-[#0F172A] text-sm leading-snug">{item.name}</span>
                <span className="flex-shrink-0 w-5 h-5 text-[#0EA5E9] transition-transform group-open:rotate-180">
                  <svg viewBox="0 0 20 20" fill="currentColor"><path fillRule="evenodd" d="M5.293 7.293a1 1 0 011.414 0L10 10.586l3.293-3.293a1 1 0 111.414 1.414l-4 4a1 1 0 01-1.414 0l-4-4a1 1 0 010-1.414z" clipRule="evenodd" /></svg>
                </span>
              </summary>
              <div className="px-5 pb-5 text-[#64748B] text-sm leading-relaxed bg-white">
                {item.acceptedAnswer.text}
              </div>
            </details>
          ))}
        </div>
      </div>
      {/* ── Newsletter Signup ─────────────────────────────────────────── */}
      <div className="container-site py-10 max-w-3xl">
        
        {/* Related Links */}

        <div className="mt-10 mb-6">

          <RelatedLinks variant="metals-review" title="Related Guides &amp; Reviews" />

        </div>
<NewsletterSignup />
      </div>
    </>
  )
}
