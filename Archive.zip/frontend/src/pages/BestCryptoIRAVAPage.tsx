import StateGuideTemplate from '../components/StateGuideTemplate'

export default function BestCryptoIRAVAPage() {
  return (
    <StateGuideTemplate
      stateName="Virginia"
      stateAbbr="VA"
      slug="virginia"
    />
  )
}
