import StateGuideTemplate from '../components/StateGuideTemplate'

export default function BestCryptoIRAAKPage() {
  return (
    <StateGuideTemplate
      stateName="Alaska"
      stateAbbr="AK"
      slug="alaska"
    />
  )
}
