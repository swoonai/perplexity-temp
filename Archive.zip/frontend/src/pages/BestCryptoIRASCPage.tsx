import StateGuideTemplate from '../components/StateGuideTemplate'

export default function BestCryptoIRASCPage() {
  return (
    <StateGuideTemplate
      stateName="South Carolina"
      stateAbbr="SC"
      slug="south-carolina"
    />
  )
}
