import { Link } from 'react-router-dom'
export default function NotFoundPage() {
  return (
    <div className="section-padding text-center">
      <div className="container-site max-w-lg">
        <h1 className="text-6xl font-bold text-[#0F172A] mb-4">404</h1>
        <p className="text-xl text-[#64748B] mb-8">Page not found.</p>
        <Link to="/" className="btn-primary">Return to Home</Link>
      </div>
    </div>
  )
}
