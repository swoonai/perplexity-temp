import StateGuideTemplate from '../components/StateGuideTemplate'

export default function BestCryptoIRAINPage() {
  return (
    <StateGuideTemplate
      stateName="Indiana"
      stateAbbr="IN"
      slug="indiana"
    />
  )
}
