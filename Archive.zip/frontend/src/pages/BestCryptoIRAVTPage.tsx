import StateGuideTemplate from '../components/StateGuideTemplate'

export default function BestCryptoIRAVTPage() {
  return (
    <StateGuideTemplate
      stateName="Vermont"
      stateAbbr="VT"
      slug="vermont"
    />
  )
}
