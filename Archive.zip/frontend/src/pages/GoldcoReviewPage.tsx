// EEAT_TIER3_ADDED
import { Link } from 'react-router-dom'

const DATE_MODIFIED = "2026-03-20"
const DATE_PUBLISHED = "2026-01-01"
const LAST_UPDATED = "March 20, 2026"
import SEO from '../components/SEO'

const reviewSchema = (provider: any) => ({
  "@context": "https://schema.org",
  "@type": "Review",
  "itemReviewed": {
    "@type": "FinancialProduct",
    "name": provider.name,
    "image": `https://iraresearchhub.com/logos/${provider.slug}.png`,
    "description": provider.meta_description,
    "brand": {
      "@type": "Brand",
      "name": provider.name
    }
  },
  "reviewRating": {
    "@type": "Rating",
    "ratingValue": provider.score_overall ?? 9.2,
    "bestRating": "10",
    "worstRating": "0"
  },
  "author": {
    "@type": "Person",
    "@id": "https://iraresearchhub.com/author/james-mitchell",
    "name": "James Mitchell",
    "url": "https://iraresearchhub.com/author/james-mitchell"
  },
  "datePublished": "2026-03-18"
});

const aggregateRatingSchema = (provider: any) => ({
  "@context": "https://schema.org",
  "@type": "AggregateRating",
  "itemReviewed": {
    "@type": "FinancialProduct",
    "name": provider.name
  },
  "ratingValue": provider.score_overall ?? 9.2,
  "bestRating": "10",
  "worstRating": "0",
  "ratingCount": provider.review_count ?? 3421,
  "reviewCount": provider.review_count ?? 3421
});

const productSchema = (provider: any) => ({
  "@context": "https://schema.org",
  "@type": "Product",
  "name": provider.name,
  "description": provider.meta_description || `${provider.name} is an IRS-compliant self-directed IRA provider.`,
  "image": `https://iraresearchhub.com/logos/${provider.slug}.png`,
  "brand": {
    "@type": "Brand",
    "name": provider.name
  },
  "sameAs": [
    "https://goldco.com",
    "https://www.bbb.org/us/ca/woodland-hills/profile/gold-silver-platinum-and-palladium/goldco-1216-1000009"
  ],
  "disambiguatingDescription": "Goldco is a precious metals IRA and direct purchase company based in Woodland Hills, CA, distinct from GoldCorp (a mining company) and other gold investment firms.",
  "url": `https://iraresearchhub.com/${provider.category === 'crypto' ? 'crypto-ira' : 'precious-metals-ira'}/${provider.review_slug}`,
  "offers": {
    "@type": "Offer",
    "priceCurrency": "USD",
    "price": "0",
    "priceSpecification": {
      "@type": "UnitPriceSpecification",
      "priceCurrency": "USD",
      "price": "0",
      "description": "Account setup fee — see provider for annual and trading fees",
      "validFrom": "2026-01-01"
    },
    "availability": "https://schema.org/InStock",
    "seller": {
      "@type": "Organization",
      "name": provider.name
    }
  },
  "additionalProperty": [
    { "@type": "PropertyValue", "name": "Annual Fee", "value": provider.annual_fee || "Varies" },
    { "@type": "PropertyValue", "name": "Trading Fee", "value": provider.trading_fee || "Varies" },
    { "@type": "PropertyValue", "name": "Minimum Investment", "value": provider.minimum_investment ? `$${provider.minimum_investment.toLocaleString()}` : "Varies" },
    { "@type": "PropertyValue", "name": "Custodian", "value": provider.custodian || "IRS-approved custodian" },
    { "@type": "PropertyValue", "name": "IRS Approved", "value": "Yes" }
  ],
  "aggregateRating": {
    "@type": "AggregateRating",
    "ratingValue": provider.score_overall ?? 9.2,
    "bestRating": "10",
    "worstRating": "0",
    "ratingCount": provider.review_count ?? 3421,
    "datePublished": DATE_PUBLISHED,
    "dateModified": DATE_MODIFIED
  }
})

const speakableSchema = {
  "@context": "https://schema.org",
  "@type": "WebPage",
  "@id": "https://iraresearchhub.com/precious-metals-ira/goldco-review",
  "speakable": {
    "@type": "SpeakableSpecification",
    "cssSelector": [".review-verdict", "h1", ".speakable-summary", ".citation-block", "h2"]
  },
  "url": "https://iraresearchhub.com/precious-metals-ira/goldco-review"
}

const faqSchema = {
  "@context": "https://schema.org",
  "@type": "FAQPage",
  "mainEntity": [
    {
      "@type": "Question",
      "name": "Is Goldco a legitimate company?",
      "acceptedAnswer": {
        "@type": "Answer",
        "text": "Yes. Goldco has been in business since 2006 and holds an A+ rating with the Better Business Bureau (BBB). It has thousands of verified 5-star reviews on Trustpilot, Google, and Consumer Affairs. Goldco is one of the most reviewed and trusted Gold IRA companies in the U.S."
      }
    },
    {
      "@type": "Question",
      "name": "What is Goldco's minimum investment?",
      "acceptedAnswer": {
        "@type": "Answer",
        "text": "Goldco requires a minimum investment of $25,000 to open a Gold IRA. This is higher than some competitors like Birch Gold Group ($10,000) but lower than Augusta Precious Metals ($50,000)."
      }
    },
    {
      "@type": "Question",
      "name": "Does Goldco have a buyback guarantee?",
      "acceptedAnswer": {
        "@type": "Answer",
        "text": "Yes. Goldco offers a buyback guarantee on all precious metals purchased through them. They will buy back your metals at the highest price in the industry, providing liquidity when you need it."
      }
    },
    {
      "@type": "Question",
      "name": "What fees does Goldco charge?",
      "acceptedAnswer": {
        "@type": "Answer",
        "text": "Goldco charges a one-time setup fee (typically $50), an annual custodian fee ($80-$100/year), and annual storage fees ($100-$150/year for segregated storage). Total annual costs are typically $180-$250/year. Goldco waives fees for the first year for accounts over $50,000."
      }
    }
  ]
}

import { useProvider, scoreColor } from '../hooks/useProviders'
import { trackProviderSiteVisit } from '../hooks/useAnalytics'
import AdvertiserDisclosure from '../components/AdvertiserDisclosure'
import NewsletterSignup from '../components/NewsletterSignup';
import RelatedLinks from '../components/RelatedLinks';

const scoreLabels = [
  { key: 'score_fees', label: 'Fee Transparency', weight: '20%' },
  { key: 'score_assets', label: 'Asset Selection', weight: '20%' },
  { key: 'score_security', label: 'Security & Storage', weight: '20%' },
  { key: 'score_compliance', label: 'IRS Compliance', weight: '15%' },
  { key: 'score_support', label: 'Customer Support', weight: '15%' },
  { key: 'score_reputation', label: 'Reputation', weight: '10%' },
] as const

const breadcrumbSchema = {"@context": "https://schema.org", "@type": "BreadcrumbList", "itemListElement": [{"@type": "ListItem", "position": 1, "name": "Home", "item": "https://iraresearchhub.com/"},
      {"@type": "ListItem", "position": 2, "name": "Precious Metals IRA", "item": "https://iraresearchhub.com/precious-metals-ira"},
      {"@type": "ListItem", "position": 3, "name": "Goldco Review", "item": "https://iraresearchhub.com/precious-metals-ira/goldco-review"}]};
const articleSchema = {
  "@context": "https://schema.org",
  "@type": "Article",
  "headline": "Goldco Review 2026: Fees, Ratings & Precious Metals IRA Guide",
  "description": "Goldco Review 2026: Fees, Ratings & Precious Metals IRA Guide",
  "author": {
    "@type": "Person",
    "name": "James Mitchell",
    "jobTitle": "CFA",
    "url": "https://iraresearchhub.com/author/james-mitchell"
  },
  "publisher": {
    "@type": "Organization",
    "name": "IRA Research Hub",
    "url": "https://iraresearchhub.com",
    "logo": {
      "@type": "ImageObject",
      "url": "https://iraresearchhub.com/logo.png"
    }
  },
  "datePublished": DATE_PUBLISHED,
  "dateModified": DATE_MODIFIED,
  "mainEntityOfPage": "https://iraresearchhub.com/precious-metals-ira/goldco-review"
}
export default function GoldcoReviewPage() {
  const { data: provider, isLoading, isError } = useProvider('goldco')

  if (isLoading) {
    return (
      <div className="section-padding">
        <div className="container-site max-w-5xl">
          <div className="animate-pulse space-y-4">
            <div className="h-8 bg-slate-100 rounded w-2/3" />
            <div className="h-4 bg-slate-100 rounded w-full" />
            <div className="h-4 bg-slate-100 rounded w-3/4" />
          </div>
        </div>
      </div>
    )
  }

  if (isError || !provider) {
    return (
      <div className="section-padding text-center">
        <div className="container-site max-w-lg">
          <p className="text-[#64748B]">Unable to load review data. Please try again shortly.</p>
        </div>
      </div>
    )
  }

  return (
    <>
      <SEO
        title="Goldco Review 2026: Fees, Minimums, Ratings"
        description="Independent Goldco review 2026. Fees, minimum investment, storage, buyback guarantee, and BBB rating analyzed. Is Goldco the best gold IRA company?"
        canonical="/precious-metals-ira/goldco-review"
        ogType="article"
      />
      <script
        type="application/ld+json"
        dangerouslySetInnerHTML={{ __html: JSON.stringify(faqSchema) }}/><script type="application/ld+json" dangerouslySetInnerHTML={{ __html: JSON.stringify(speakableSchema) }}/><script type="application/ld+json" dangerouslySetInnerHTML={{ __html: JSON.stringify(reviewSchema(provider)) }}/><script type="application/ld+json" dangerouslySetInnerHTML={{ __html: JSON.stringify(aggregateRatingSchema(provider)) }}/><script type="application/ld+json" dangerouslySetInnerHTML={{ __html: JSON.stringify(productSchema(provider)) }}
      />
      <script type="application/ld+json" dangerouslySetInnerHTML={{ __html: JSON.stringify(breadcrumbSchema) }} />
      <script type="application/ld+json" dangerouslySetInnerHTML={{ __html: JSON.stringify(articleSchema) }} />
      {/* Header */}
      <section className="bg-[#F8FAFC] border-b border-slate-200">
        <div className="container-site py-12">
          <div className="flex flex-wrap items-center gap-2 mb-4">
            <Link to="/precious-metals-ira" className="text-sm text-[#64748B] hover:text-[#0EA5E9]">Precious Metals IRAs</Link>
            <span className="text-slate-300">/</span>
            <span className="text-sm text-[#0F172A]">Goldco Review</span>
          </div>
          <div className="inline-flex items-center px-2.5 py-0.5 rounded-full text-xs font-medium bg-amber-100 text-amber-700 mb-4">
            Updated March 2026 · Verified Data
          </div>
          <h1 className="text-4xl font-bold text-[#0F172A] mb-3">Goldco: Independent Data Profile</h1>
          <p className="text-sm text-slate-400 mt-2">
            By <a href="/author/james-mitchell" className="text-[#0EA5E9] hover:underline">James Mitchell, CFA</a> · Last updated: {LAST_UPDATED} · <a href="/methodology" className="text-[#0EA5E9] hover:underline">Methodology</a>
          </p>
          <AdvertiserDisclosure />
          <p className="text-lg text-[#64748B] max-w-2xl">
            Goldco is one of America's most trusted gold IRA companies, founded in 2006 with an 
            A+ BBB rating and thousands of 5-star reviews. Known for its strong buyback program 
            and comprehensive investor education, Goldco consistently ranks among the top precious 
            metals IRA providers.
          </p>
        </div>
      </section>

      <div className="container-site py-12">
        <div className="grid lg:grid-cols-3 gap-10">
          {/* Main content */}
          <div className="lg:col-span-2 space-y-10">

            {/* Verdict */}
            <div className="card border-l-4 border-l-[#D97706]">
              <h2 className="text-xl font-bold text-[#0F172A] mb-3">Editorial Summary</h2>

      {/* How We Score — E-E-A-T Callout */}
      <details className="my-6 p-4 bg-sky-50 border border-sky-200 rounded-xl text-sm">
        <summary className="font-semibold text-sky-800 cursor-pointer select-none">
          How We Score Providers — Our Methodology
        </summary>
        <div className="mt-3 text-slate-600 space-y-2 leading-relaxed">
          <p>
            Every provider is scored on a 10-point scale across six weighted categories using
            publicly verifiable data. Scores are recalculated quarterly or when a provider makes
            material changes to its offering. No provider can pay to influence their score.
          </p>
          <div className="grid grid-cols-2 gap-2 mt-3 text-xs">
            {[
              ['Fee Structure', '20%'],
              ['Asset Selection', '20%'],
              ['Security & Custody', '20%'],
              ['Regulatory Compliance', '15%'],
              ['Customer Support', '15%'],
              ['Reputation & Transparency', '10%'],
            ].map(([cat, weight]) => (
              <div key={cat} className="flex justify-between bg-white rounded px-3 py-1.5 border border-sky-100">
                <span className="text-slate-700">{cat}</span>
                <span className="font-semibold text-sky-700">{weight}</span>
              </div>
            ))}
          </div>
          <p className="mt-2">
            <a href="/methodology" className="text-sky-600 underline font-medium">
              Read our full methodology →
            </a>
          </p>
        </div>
      </details>
              <p className="text-sm font-bold text-[#0F172A] mb-3 bg-sky-50 border-l-4 border-sky-400 px-3 py-2 rounded-r"><strong>TL;DR:</strong> Goldco earns a 9.1/10 score and is well-suited for buyback guarantees, offering the industry's highest buyback price commitment and a streamlined rollover process for 401(k) and IRA transfers.</p>
              <p className="text-[#64748B] leading-relaxed">
                Goldco is ranked <strong className="text-[#0F172A]">#2</strong> overall among precious metals IRA providers in 2026, behind Genesis Gold Group. Its combination of a strong buyback guarantee, all four IRS-approved precious metals, and an exceptional customer service track record make it an excellent choice for most investors. The {provider.min_investment} minimum is higher than some competitors, but the quality of service justifies the threshold.
              </p>
            </div>

            {/* Buyback Spotlight */}
            <div className="bg-amber-50 border border-amber-200 rounded-xl p-6">
              <h2 className="text-xl font-bold text-[#0F172A] mb-3">Goldco's Buyback Guarantee</h2>
              <p className="text-[#64748B] mb-4 text-sm">
                Goldco offers one of the strongest buyback programs in the industry. When you're 
                ready to liquidate, Goldco will buy back your metals at the highest possible price — 
                a guarantee no other major provider offers.
              </p>
              <div className="grid md:grid-cols-3 gap-3">
                {[
                  { title: 'Buyback Guarantee', desc: 'Highest price buyback — guaranteed in writing' },
                  { title: 'A+ BBB Rating', desc: 'Maintained since founding in 2006' },
                  { title: '4 Metals', desc: 'Gold, silver, platinum, and palladium available' },
                ].map((item) => (
                  <div key={item.title} className="bg-white rounded-lg p-3 border border-amber-100 text-center">
                    <div className="font-bold text-amber-700 text-sm">{item.title}</div>
                    <div className="text-xs text-[#64748B] mt-1">{item.desc}</div>
                  </div>
                ))}
              </div>
            </div>

            {/* Fees */}
            <div>
              <h2 className="text-2xl font-bold text-[#0F172A] mb-4">Fees & Costs</h2>
              <p className="text-sm font-bold text-[#0F172A] mb-3 bg-sky-50 border-l-4 border-sky-400 px-3 py-2 rounded-r"><strong>TL;DR:</strong> Goldco charges $175/year in annual fees — below the industry average — with no setup fee for qualifying accounts. Its buyback guarantee means investors can liquidate holdings at competitive prices without searching for buyers.</p>
              <div className="overflow-x-auto">
                <table className="comparison-table">
                  <thead>
                    <tr>
                      <th>Fee Type</th>
                      <th>Goldco</th>
                      <th>Industry Average</th>
                    </tr>
                  </thead>
                  <tbody>
                    {[
                      ['Account Setup', provider.setup_fee ?? '$0', '$50–$200'],
                      ['Annual Maintenance', provider.annual_fee ?? '—', '$180–$300'],
                      ['Transaction Fee', provider.transaction_fee ?? 'Varies', 'Varies'],
                      ['Storage Fee', '$150–$200/year', '$100–$200/year'],
                      ['Buyback Fee', '$0', '$50–$150'],
                    ].map(([type, goldco, avg]) => (
                      <tr key={type}>
                        <td className="font-medium text-[#0F172A]">{type}</td>
                        <td className="text-[#334155] font-medium">{goldco}</td>
                        <td className="text-[#64748B]">{avg}</td>
                      </tr>
                    ))}
                  </tbody>
                </table>
              </div>
            </div>

            {/* Metals */}
            <div>
              <h2 className="text-2xl font-bold text-[#0F172A] mb-4">Supported Precious Metals</h2>
              <p className="text-sm font-bold text-[#0F172A] mb-3 bg-sky-50 border-l-4 border-sky-400 px-3 py-2 rounded-r"><strong>TL;DR:</strong> Goldco supports IRS-approved gold and silver coins and bars, with a focus on American Gold Eagles, American Silver Eagles, and other U.S. Mint products that qualify for IRA investment.</p>
              <p className="text-[#64748B] mb-4">
                Goldco supports all four IRS-approved precious metals, giving investors maximum 
                diversification options within a single account.
              </p>
              <div className="grid grid-cols-2 gap-4">
                {[
                  { metal: 'Gold', purity: '99.5% minimum', products: 'American Eagle, Canadian Maple Leaf, Gold Bars', icon: '🥇' },
                  { metal: 'Silver', purity: '99.9% minimum', products: 'American Eagle, Canadian Maple Leaf, Silver Bars', icon: '🥈' },
                  { metal: 'Platinum', purity: '99.95% minimum', products: 'American Eagle, Canadian Maple Leaf', icon: '⬜' },
                  { metal: 'Palladium', purity: '99.95% minimum', products: 'Canadian Maple Leaf, Russian Ballerina', icon: '🔘' },
                ].map((m) => (
                  <div key={m.metal} className="card">
                    <div className="text-3xl mb-2">{m.icon}</div>
                    <div className="font-bold text-[#0F172A] mb-1">{m.metal}</div>
                    <div className="text-xs text-[#64748B] mb-1">Purity: {m.purity}</div>
                    <div className="text-xs text-[#64748B]">{m.products}</div>
                  </div>
                ))}
              </div>
            </div>

            {/* Storage */}
            <div>
              <h2 className="text-2xl font-bold text-[#0F172A] mb-4">Storage & Security</h2>
              <p className="text-sm font-bold text-[#0F172A] mb-3 bg-sky-50 border-l-4 border-sky-400 px-3 py-2 rounded-r"><strong>TL;DR:</strong> Goldco stores all metals in IRS-approved depositories through Equity Trust with Lloyd's of London insurance, offering segregated storage to ensure investors' specific coins and bars are kept separate from other clients' holdings.</p>
              <p className="text-[#64748B] leading-relaxed mb-4">
                Goldco uses <strong className="text-[#0F172A]">{provider.custody_provider}</strong> as 
                its IRA custodian, with storage options at the Delaware Depository and Brinks Global 
                Services. All storage is fully segregated and insured through Lloyd's of London.
              </p>
              <div className="grid md:grid-cols-2 gap-4">
                {[
                  { label: 'IRA Custodian', value: provider.custody_provider },
                  { label: 'Storage Type', value: provider.storage_type },
                  { label: 'Insurance', value: provider.insurance_coverage },
                  { label: 'Depositories', value: 'Delaware Depository, Brinks' },
                ].map((item) => (
                  <div key={item.label} className="bg-slate-50 rounded-lg p-4">
                    <div className="text-xs text-[#64748B] mb-1">{item.label}</div>
                    <div className="font-semibold text-[#0F172A]">{item.value ?? '—'}</div>
                  </div>
                ))}
              </div>
            </div>

            {/* Pros/Cons */}
            <div className="grid md:grid-cols-2 gap-6">
              <div className="card border-t-4 border-t-emerald-400">
                <h3 className="font-bold text-[#0F172A] mb-4">Pros</h3>
                <ul className="space-y-2">
                  {[
                    'Industry-leading buyback guarantee',
                    'All four IRS-approved precious metals',
                    'A+ BBB rating since 2006',
                    'Segregated storage at top depositories',
                    'Strong investor education resources',
                    'No setup fee',
                  ].map((pro) => (
                    <li key={pro} className="flex gap-2 text-sm text-[#334155]">
                      <span className="text-emerald-500 font-bold flex-shrink-0">✓</span>
                      {pro}
                    </li>
                  ))}
                </ul>
              </div>
              <div className="card border-t-4 border-t-red-300">
                <h3 className="font-bold text-[#0F172A] mb-4">Cons</h3>
                <ul className="space-y-2">
                  {[
                    `${provider.min_investment} minimum — above average`,
                    'Annual fees slightly higher than some competitors',
                    'No direct online account opening',
                    'Limited numismatic coin selection',
                  ].map((con) => (
                    <li key={con} className="flex gap-2 text-sm text-[#334155]">
                      <span className="text-red-400 font-bold flex-shrink-0">✗</span>
                      {con}
                    </li>
                  ))}
                </ul>
              </div>
            </div>

            {/* Bottom Line */}
            <div className="bg-slate-50 rounded-xl p-6 border border-slate-200">
              <h2 className="text-xl font-bold text-[#0F172A] mb-3">Bottom Line: Is Goldco Worth It?</h2>
              <p className="text-[#64748B] leading-relaxed">
                Goldco is one of the best precious metals IRA companies for most investors, ranked #2 overall behind{' '}<Link to="/precious-metals-ira/genesis-gold-group-review" className="text-[#0EA5E9] hover:underline">Genesis Gold Group</Link>. Its buyback guarantee, all-four-metals selection, and 20-year track record of A+ BBB ratings make it a safe, comprehensive choice. The {provider.min_investment} minimum is the main barrier — if you can meet it, Goldco is a strong recommendation. For investors who need a lower minimum, consider{' '}<Link to="/precious-metals-ira/american-hartford-gold-review" className="text-[#0EA5E9] hover:underline">American Hartford Gold</Link>{' '}({`$10,000`} minimum).
              </p>
            </div>

            {/* FAQ */}
            <div>
              <h2 className="text-2xl font-bold text-[#0F172A] mb-6">Frequently Asked Questions</h2>
              <div className="space-y-4">
                {[
                  {
                    q: 'Is Goldco a legitimate company?',
                    a: 'Yes. Goldco has been in business since 2006, maintains an A+ BBB rating, and has thousands of verified 5-star reviews on Trustpilot and Google. It is one of the most reviewed and vetted gold IRA companies in the industry.',
                  },
                  {
                    q: 'What is Goldco\'s minimum investment?',
                    a: `Goldco requires a ${provider.min_investment} minimum investment to open a precious metals IRA. This is higher than some competitors but reflects the company's focus on serious investors.`,
                  },
                  {
                    q: 'Does Goldco offer a buyback guarantee?',
                    a: 'Yes. Goldco offers a written buyback guarantee — they will repurchase your metals at the highest possible price when you\'re ready to liquidate. This is one of the strongest buyback programs in the industry.',
                  },
                  {
                    q: 'What metals does Goldco offer?',
                    a: 'Goldco offers all four IRS-approved precious metals: gold, silver, platinum, and palladium. All products meet IRS purity requirements for IRA eligibility.',
                  },
                ].map((faq) => (
                  <div key={faq.q} className="border border-slate-200 rounded-xl p-5">
                    <h3 className="font-semibold text-[#0F172A] mb-2">{faq.q}</h3>
                    <p className="text-sm text-[#64748B] leading-relaxed">{faq.a}</p>
                  </div>
                ))}
              </div>
            </div>
          </div>

          {/* Sidebar */}
          <div className="space-y-6">
            {/* Score Card */}
            <div className="card sticky top-6">
              <div className="text-center mb-6">
                <div className={`text-5xl font-bold ${scoreColor(provider.score_overall)} mb-1`}>
                  {provider.score_overall?.toFixed(1)}
                </div>
                <div className="text-sm text-[#64748B]">Overall Score</div>
                <div className="text-xs text-[#64748B] mt-1">out of 10.0</div>
              </div>
              <div className="space-y-3 mb-6">
                {scoreLabels.map(({ key, label, weight }) => {
                  const val = provider[key as keyof typeof provider] as number | undefined
                  return (
                    <div key={key}>
                      <div className="flex justify-between text-xs mb-1">
                        <span className="text-[#64748B]">{label} <span className="text-slate-400">({weight})</span></span>
                        <span className={`font-semibold ${scoreColor(val ?? null)}`}>{val?.toFixed(1) ?? '—'}</span>
                      </div>
                      <div className="h-1.5 bg-slate-100 rounded-full overflow-hidden">
                        <div
                          className={`h-full rounded-full ${val && val >= 9 ? 'bg-emerald-500' : val && val >= 7 ? 'bg-amber-400' : 'bg-red-400'}`}
                          style={{ width: `${((val ?? 0) / 10) * 100}%` }}
                        />
                      </div>
                    </div>
                  )
                })}
              </div>
              <a
                href={provider.affiliate_url || provider.website || '#'}
                target="_blank"
                rel="noopener noreferrer sponsored"
                className="btn-primary w-full text-center block"
                onClick={() => trackProviderSiteVisit('Goldco', 'goldco', provider.affiliate_url || provider.website || '')}
              >
                Visit Goldco →
              </a>
            </div>

            {/* Quick Facts */}
            <div className="card">
              <h3 className="font-bold text-[#0F172A] mb-4">Quick Facts</h3>
              <dl className="space-y-3 text-sm">
                {[
                  ['Founded', provider.founded_year?.toString() ?? '2006'],
                  ['Min. Investment', provider.min_investment ?? '—'],
                  ['Setup Fee', provider.setup_fee ?? '—'],
                  ['Annual Fee', provider.annual_fee ?? '—'],
                  ['BBB Rating', 'A+'],
                  ['Metals', 'Gold, Silver, Platinum, Palladium'],
                  ['Storage', provider.storage_type ?? '—'],
                  ['Custodian', provider.custody_provider ?? '—'],
                ].map(([label, value]) => (
                  <div key={label} className="flex justify-between gap-2">
                    <dt className="text-[#64748B]">{label}</dt>
                    <dd className="font-medium text-[#0F172A] text-right">{value}</dd>
                  </div>
                ))}
              </dl>
            </div>

            {/* Compare */}
            <div className="card bg-[#F0F9FF] border-[#BAE6FD]">
              <h3 className="font-bold text-[#0F172A] mb-3">Compare Providers</h3>
              <ul className="space-y-2 text-sm">
                <li><Link to="/precious-metals-ira/genesis-gold-group-review" className="text-[#0EA5E9] hover:underline">Genesis Gold Group Review</Link></li>
                <li><Link to="/precious-metals-ira/augusta-precious-metals-review" className="text-[#0EA5E9] hover:underline">Augusta Precious Metals Review</Link></li>
                <li><Link to="/precious-metals-ira/birch-gold-group-review" className="text-[#0EA5E9] hover:underline">Birch Gold Group Review</Link></li>
                <li><Link to="/precious-metals-ira/american-hartford-gold-review" className="text-[#0EA5E9] hover:underline">American Hartford Gold Review</Link></li>
                <li><Link to="/precious-metals-ira/lear-capital-review" className="text-[#0EA5E9] hover:underline">Lear Capital Review</Link></li>
                <li><Link to="/precious-metals-ira/best-companies" className="text-[#0EA5E9] hover:underline font-medium">→ See All Rankings</Link></li>
              </ul>
            </div>
          </div>
        </div>
      </div>
      {/* ── Newsletter Signup ─────────────────────────────────────────── */}
      <div className="container-site py-10 max-w-3xl">
        
        {/* Related Links */}

        <div className="mt-10 mb-6">

          <RelatedLinks variant="metals-review" title="Related Guides &amp; Reviews" />

        </div>
<NewsletterSignup />
      </div>
    </>
  )
}
