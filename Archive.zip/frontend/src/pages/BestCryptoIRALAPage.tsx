import StateGuideTemplate from '../components/StateGuideTemplate'

export default function BestCryptoIRALAPage() {
  return (
    <StateGuideTemplate
      stateName="Louisiana"
      stateAbbr="LA"
      slug="louisiana"
    />
  )
}
