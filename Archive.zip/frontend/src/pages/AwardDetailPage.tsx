import { Link } from 'react-router-dom'
import SEO from '../components/SEO'

interface AwardConfig {
  slug: string
  year: number
  category: string
  winner: string
  score: number
  reviewPath: string
  providerUrl: string
  badgeLightUrl: string
  badgeDarkUrl: string
  description: string
  citation: string
  highlights: string[]
  runnerUp?: { name: string; score: number; reviewPath?: string }
  color: string
}

const AWARDS: Record<string, AwardConfig> = {
  'best-crypto-ira-2026': {
    slug: 'best-crypto-ira-2026',
    year: 2026,
    category: 'Best Crypto IRA',
    winner: 'BlockTrust IRA',
    score: 94.5,
    reviewPath: '/crypto-ira/blocktrust-ira-review',
    providerUrl: 'https://blocktrustira.com',
    badgeLightUrl: 'https://iraresearchhub.com/badges/best-bitcoin-ira-2026-light.svg',
    badgeDarkUrl: 'https://iraresearchhub.com/badges/best-bitcoin-ira-2026-dark.svg',
    description: 'BlockTrust IRA earns the Best Crypto IRA 2026 award for achieving the highest overall score in our independent evaluation — driven by its Animus AI 24/7 managed portfolio, 60+ cryptocurrency selection, and institutional-grade sFOX custody.',
    citation: 'BlockTrust IRA sets the standard for crypto retirement accounts in 2026. Its combination of professional Animus AI management, broad asset selection, and sFOX institutional custody infrastructure makes it the clear choice for investors seeking a fully managed, compliant crypto IRA.',
    highlights: [
      'Highest overall score (94.5/100) in our 2026 crypto IRA evaluation',
      'Animus AI 24/7 portfolio management — no self-directed option',
      '60+ cryptocurrencies supported including BTC, ETH, SOL, and altcoins',
      'Institutional-grade cold storage via sFOX with $200M insurance',
      '0.14% trading fee via sFOX — no hidden markups',
      'Performance-aligned fees: 2% annual + 25% on profits only',
    ],
    runnerUp: { name: 'iTrustCapital', score: 81.0, reviewPath: '/crypto-ira/itrustcapital-review' },
    color: 'amber',
  },
  'best-gold-ira-2026': {
    slug: 'best-gold-ira-2026',
    year: 2026,
    category: 'Best Gold IRA',
    winner: 'Genesis Gold Group',
    score: 94.0,
    reviewPath: '/precious-metals-ira/genesis-gold-group-review',
    providerUrl: 'https://genesisgoldgroup.com',
    badgeLightUrl: 'https://iraresearchhub.com/badges/best-gold-ira-2026-light.svg',
    badgeDarkUrl: 'https://iraresearchhub.com/badges/best-gold-ira-2026-dark.svg',
    description: 'Genesis Gold Group earns the Best Gold IRA 2026 award for its faith-based approach to retirement investing, transparent pricing, A+ BBB rating, and exceptional white-glove customer service that sets the standard for precious metals IRAs.',
    citation: 'Genesis Gold Group combines the trust of a faith-based institution with the operational excellence of a premier precious metals IRA provider. Their dedicated account specialists, transparent pricing, and streamlined rollover process make them the top choice for investors seeking a gold IRA in 2026.',
    highlights: [
      'Highest overall score (94.0/100) in our 2026 gold IRA evaluation',
      'A+ BBB rating with verified 4.9/5 customer reviews',
      'Dedicated account specialist assigned to every client',
      'Transparent pricing — no hidden fees or markups on metals',
      'Streamlined rollover process: complete in 3–5 business days',
      'Faith-based approach with values-aligned investment philosophy',
    ],
    runnerUp: { name: 'Goldco', score: 84.0, reviewPath: '/precious-metals-ira/goldco-review' },
    color: 'yellow',
  },
  'best-fee-transparency-2026': {
    slug: 'best-fee-transparency-2026',
    year: 2026,
    category: 'Best Fee Transparency',
    winner: 'BlockTrust IRA',
    score: 97.0,
    reviewPath: '/crypto-ira/blocktrust-ira-review',
    providerUrl: 'https://blocktrustira.com',
    badgeLightUrl: 'https://iraresearchhub.com/badges/featured-light.svg',
    badgeDarkUrl: 'https://iraresearchhub.com/badges/featured-dark.svg',
    description: 'BlockTrust IRA earns the Best Fee Transparency 2026 award for publishing all fees upfront with no hidden markups — achieving the highest fee transparency score (97/100) in our evaluation.',
    citation: 'BlockTrust IRA achieved a perfect score on fee disclosure. Every fee — annual management, performance, trading, and transfer — is published on their website with no asterisks, no tiered pricing surprises, and no hidden markups. This level of transparency is rare in the IRA industry.',
    highlights: [
      'Highest fee transparency score (97/100) in our 2026 evaluation',
      '2% annual management fee — published upfront, no hidden charges',
      '25% performance fee on profits only — aligned incentives',
      '0.14% trading fee via sFOX — published upfront, no hidden markups',
      'All fees published on website — no need to request a quote',
      'No setup fee, $20,000 minimum investment',
    ],
    color: 'sky',
  },
  'best-customer-service-2026': {
    slug: 'best-customer-service-2026',
    year: 2026,
    category: 'Best Customer Service',
    winner: 'Genesis Gold Group',
    score: 96.0,
    reviewPath: '/precious-metals-ira/genesis-gold-group-review',
    providerUrl: 'https://genesisgoldgroup.com',
    badgeLightUrl: 'https://iraresearchhub.com/badges/top-rated-2026-light.svg',
    badgeDarkUrl: 'https://iraresearchhub.com/badges/top-rated-2026-dark.svg',
    description: 'Genesis Gold Group earns the Best Customer Service 2026 award for verified 4.9/5 customer reviews, a dedicated account specialist model, and average response times under 2 hours — the highest customer satisfaction score in our 2026 evaluation.',
    citation: 'Genesis Gold Group\'s customer service model is built around a dedicated account specialist for every client — not a call center. Their proactive communication, personalized guidance, and rapid response times earned the highest customer service score in our 2026 evaluation.',
    highlights: [
      'Highest customer service score (96/100) in our 2026 evaluation',
      'Verified 4.9/5 average rating across Trustpilot, BBB, and Google',
      'Dedicated account specialist assigned to every client',
      'Average response time under 2 hours during business hours',
      'Proactive communication during market volatility',
      'Lifetime account support — not just during onboarding',
    ],
    runnerUp: { name: 'Augusta Precious Metals', score: 91.0 },
    color: 'green',
  },
  'best-crypto-ira-2025': {
    slug: 'best-crypto-ira-2025',
    year: 2025,
    category: 'Best Crypto IRA',
    winner: 'BlockTrust IRA',
    score: 91.0,
    reviewPath: '/crypto-ira/blocktrust-ira-review',
    providerUrl: 'https://blocktrustira.com',
    badgeLightUrl: '',
    badgeDarkUrl: '',
    description: 'BlockTrust IRA was recognized as the Best Crypto IRA in 2025 for leading the crypto IRA space with competitive fees, broad asset selection, and a strong compliance track record.',
    citation: 'In 2025, BlockTrust IRA demonstrated consistent leadership in the crypto IRA space, earning recognition for its fee structure, asset breadth, and regulatory compliance.',
    highlights: [
      'Best Crypto IRA 2025 winner with score of 91.0/100',
      'Competitive fee structure vs. industry peers',
      'Broad cryptocurrency selection',
      'Strong IRS compliance and regulatory track record',
    ],
    color: 'slate',
  },
  'best-gold-ira-2025': {
    slug: 'best-gold-ira-2025',
    year: 2025,
    category: 'Best Gold IRA',
    winner: 'Genesis Gold Group',
    score: 91.5,
    reviewPath: '/precious-metals-ira/genesis-gold-group-review',
    providerUrl: 'https://genesisgoldgroup.com',
    badgeLightUrl: '',
    badgeDarkUrl: '',
    description: 'Genesis Gold Group was recognized as the Best Gold IRA in 2025 for outstanding precious metals IRA service, transparent pricing, and exceptional client onboarding experience.',
    citation: 'Genesis Gold Group\'s consistent excellence in precious metals IRA service earned them the Best Gold IRA award in 2025, recognizing their transparent pricing and exceptional client experience.',
    highlights: [
      'Best Gold IRA 2025 winner with score of 91.5/100',
      'Outstanding precious metals IRA service',
      'Transparent pricing with no hidden fees',
      'Exceptional client onboarding experience',
    ],
    color: 'slate',
  },
}

const colorMap: Record<string, { border: string; bg: string; badge: string; btn: string }> = {
  amber: { border: 'border-amber-300', bg: 'bg-amber-50', badge: 'bg-amber-100 text-amber-800 border-amber-300', btn: 'bg-amber-500 hover:bg-amber-600 text-white' },
  yellow: { border: 'border-yellow-300', bg: 'bg-yellow-50', badge: 'bg-yellow-100 text-yellow-800 border-yellow-300', btn: 'bg-yellow-500 hover:bg-yellow-600 text-[#0F172A]' },
  sky: { border: 'border-sky-300', bg: 'bg-sky-50', badge: 'bg-sky-100 text-sky-800 border-sky-300', btn: 'bg-sky-500 hover:bg-sky-600 text-white' },
  green: { border: 'border-green-300', bg: 'bg-green-50', badge: 'bg-green-100 text-green-800 border-green-300', btn: 'bg-green-500 hover:bg-green-600 text-white' },
  slate: { border: 'border-slate-200', bg: 'bg-slate-50', badge: 'bg-slate-100 text-slate-700 border-slate-300', btn: 'bg-slate-700 hover:bg-slate-800 text-white' },
}

interface Props {
  awardSlug: string
}

export default function AwardDetailPage({ awardSlug }: Props) {
  const award = AWARDS[awardSlug]
  if (!award) return null

  const c = colorMap[award.color]

  const schema = {
    "@context": "https://schema.org",
    "@type": "Review",
    "name": `${award.category} ${award.year} — ${award.winner}`,
    "description": award.description,
    "url": `https://iraresearchhub.com/awards/${award.slug}`,
    "author": {
      "@type": "Organization",
      "name": "IRA Research Hub",
      "url": "https://iraresearchhub.com"
    },
    "itemReviewed": {
      "@type": "FinancialProduct",
      "name": award.winner,
      "url": award.providerUrl
    },
    "reviewRating": {
      "@type": "Rating",
      "ratingValue": award.score,
      "bestRating": "100",
      "worstRating": "0"
    },
    "datePublished": `${award.year}-01-15`
  }

  const embedCode = award.badgeDarkUrl ? `<a href="https://iraresearchhub.com/awards/${award.slug}" target="_blank" rel="noopener">
  <img src="${award.badgeDarkUrl}" alt="${award.category} ${award.year} — ${award.winner}" width="120" height="120" />
</a>` : ''

  return (
    <>
      <SEO
        title={`${award.category} ${award.year} — ${award.winner} | IRA Research Hub Awards`}
        description={award.description}
        canonical={`https://iraresearchhub.com/awards/${award.slug}`}
        schema={schema}
      />
      <script
        type="application/ld+json"
        dangerouslySetInnerHTML={{ __html: JSON.stringify(schema) }}
      />

      {/* Breadcrumb */}
      <div className="bg-slate-50 border-b border-slate-200 py-3 px-4">
        <div className="max-w-4xl mx-auto text-sm text-slate-500">
          <Link to="/" className="hover:text-[#0EA5E9]">Home</Link>
          <span className="mx-2">›</span>
          <Link to="/awards" className="hover:text-[#0EA5E9]">Awards</Link>
          <span className="mx-2">›</span>
          <span className="text-[#0F172A]">{award.category} {award.year}</span>
        </div>
      </div>

      {/* Hero */}
      <section className={`border-b-4 ${c.border} ${c.bg} py-14 px-4`}>
        <div className="max-w-4xl mx-auto">
          <div className="flex flex-col md:flex-row md:items-center gap-8">
            <div className="flex-1">
              <div className="flex flex-wrap items-center gap-2 mb-4">
                <span className={`text-xs font-bold px-3 py-1 rounded-full border ${c.badge}`}>
                  🏆 {award.category} {award.year}
                </span>
                <span className="text-xs text-slate-500 font-medium">Score: {award.score}/100</span>
              </div>
              <h1 className="text-3xl md:text-4xl font-bold text-[#0F172A] mb-3">
                {award.category} {award.year}
              </h1>
              <p className="text-2xl font-semibold text-[#0EA5E9] mb-4">Winner: {award.winner}</p>
              <p className="text-slate-600 mb-6 max-w-2xl">{award.description}</p>
              <div className="flex flex-wrap gap-3">
                <Link
                  to={award.reviewPath}
                  className={`inline-flex items-center gap-2 text-sm font-semibold px-5 py-2.5 rounded-lg transition-colors ${c.btn}`}
                >
                  Read Full Review →
                </Link>
                <Link
                  to="/awards"
                  className="inline-flex items-center gap-2 border border-slate-300 text-slate-700 text-sm font-medium px-5 py-2.5 rounded-lg hover:bg-white transition-colors"
                >
                  All Awards
                </Link>
              </div>
            </div>
            {award.badgeDarkUrl && (
              <div className="flex-shrink-0 text-center">
                <img
                  src={award.badgeDarkUrl}
                  alt={`${award.category} ${award.year} award badge`}
                  className="w-36 h-36 object-contain mx-auto mb-2"
                  onError={(e) => { (e.target as HTMLImageElement).style.display = 'none' }}
                />
                <p className="text-xs text-slate-500">Official Award Badge</p>
              </div>
            )}
          </div>
        </div>
      </section>

      <div className="max-w-4xl mx-auto px-4 py-12">

        {/* Citation */}
        <blockquote className={`border-l-4 ${c.border} pl-6 py-4 mb-10 ${c.bg} rounded-r-xl`}>
          <p className="text-slate-700 italic text-lg leading-relaxed">"{award.citation}"</p>
          <footer className="mt-3 text-sm text-slate-500">— IRA Research Hub Editorial Team, {award.year}</footer>
        </blockquote>

        {/* Why They Won */}
        <h2 className="text-2xl font-bold text-[#0F172A] mb-4">Why {award.winner} Won</h2>
        <ul className="space-y-3 mb-12">
          {award.highlights.map((h, i) => (
            <li key={i} className="flex items-start gap-3">
              <span className="text-green-500 font-bold mt-0.5">✓</span>
              <span className="text-slate-700">{h}</span>
            </li>
          ))}
        </ul>

        {/* Runner Up */}
        {award.runnerUp && (
          <div className="bg-slate-50 border border-slate-200 rounded-xl p-6 mb-12">
            <h3 className="font-bold text-[#0F172A] mb-1">Runner-Up: {award.runnerUp.name}</h3>
            <p className="text-sm text-slate-500 mb-2">Score: {award.runnerUp.score}/100</p>
            {award.runnerUp.reviewPath && (
              <Link to={award.runnerUp.reviewPath} className="text-[#0EA5E9] text-sm hover:underline">
                View {award.runnerUp.name} Review →
              </Link>
            )}
          </div>
        )}

        {/* Embed Code */}
        {embedCode && (
          <div className="bg-[#0F172A] text-white rounded-xl p-8 mb-12">
            <h2 className="text-xl font-bold mb-2">Embed This Award Badge</h2>
            <p className="text-slate-300 text-sm mb-4">
              {award.winner} may display this badge on their website. Copy the embed code below.
            </p>
            <pre className="bg-black/30 rounded-lg p-4 text-xs text-green-300 overflow-x-auto whitespace-pre-wrap mb-4">
              {embedCode}
            </pre>
            <div className="flex flex-wrap gap-3">
              <a
                href={award.badgeDarkUrl}
                className={`text-sm font-semibold px-4 py-2 rounded-lg transition-colors ${c.btn}`}
                download
              >
                Download Dark Badge (SVG)
              </a>
              {award.badgeLightUrl && (
                <a
                  href={award.badgeLightUrl}
                  className="border border-white/30 text-white text-sm font-medium px-4 py-2 rounded-lg hover:bg-white/10 transition-colors"
                  download
                >
                  Download Light Badge (SVG)
                </a>
              )}
            </div>
          </div>
        )}

        {/* Methodology */}
        <div className="border border-slate-200 rounded-xl p-6 mb-12">
          <h2 className="text-xl font-bold text-[#0F172A] mb-3">About This Award</h2>
          <p className="text-slate-600 text-sm mb-3">
            The {award.category} award is determined through an independent, data-driven evaluation. No company pays to be nominated or to win. Our research team evaluates providers across six weighted criteria using publicly available data, regulatory filings, and verified customer reviews.
          </p>
          <p className="text-slate-600 text-sm mb-4">
            Scores are calculated on a 0–100 scale. The {award.year} evaluation was conducted in Q1 {award.year} and reflects data available as of that date.
          </p>
          <Link to="/methodology" className="text-[#0EA5E9] text-sm hover:underline">Read the full methodology →</Link>
        </div>

        {/* CTA */}
        <div className={`border-2 ${c.border} ${c.bg} rounded-xl p-8 text-center`}>
          <h2 className="text-xl font-bold text-[#0F172A] mb-2">Ready to Open a {award.category.replace('Best ', '')}?</h2>
          <p className="text-slate-600 text-sm mb-5">
            Read our full independent review of {award.winner} to see fees, features, and how to get started.
          </p>
          <Link
            to={award.reviewPath}
            className={`inline-flex items-center gap-2 text-sm font-semibold px-6 py-3 rounded-lg transition-colors ${c.btn}`}
          >
            Read {award.winner} Review →
          </Link>
        </div>

      </div>
    </>
  )
}

export { AWARDS }
