import React from 'react'
import { Link } from 'react-router-dom'
import SEO from '../components/SEO'
import AdvertiserDisclosure from '../components/AdvertiserDisclosure'
import { trackResearchStart } from '../hooks/useAnalytics'
import NewsletterSignup from '../components/NewsletterSignup';
import RelatedLinks from '../components/RelatedLinks';

const LAST_UPDATED = 'March 31, 2026'

export default function IRAContributionLimitsPage() {

  // Funnel tracking: fire research_start when arriving from a paid ad
  React.useEffect(() => {
    const params = new URLSearchParams(window.location.search)
    const utmSource = params.get('utm_source') ?? undefined
    if (utmSource) {
      trackResearchStart(window.location.pathname, document.title, utmSource)
    }
  }, [])

  return (
    <>
      <script type="application/ld+json" dangerouslySetInnerHTML={{ __html: JSON.stringify({"@context":"https://schema.org","@type":"BreadcrumbList","itemListElement":[{"@type":"ListItem","position":1,"name":"Guides","item":"https://iraresearchhub.com/guides"},{"@type":"ListItem","position":2,"name":"IRA Contribution Limits 2026","item":"https://iraresearchhub.com/guides/ira-contribution-limits-2026"}]}) }} />
      <SEO
        title="IRA Contribution Limits & Rules 2026 — Traditional, Roth, SEP, SIMPLE"
        description="Complete 2026 IRA contribution limits for Traditional, Roth, SEP-IRA, and SIMPLE IRA. Covers income limits, catch-up contributions, deductibility rules, and excess contribution penalties."
        canonical="/guides/ira-contribution-limits-2026"
        ogType="article"
      />
      <script type="application/ld+json" dangerouslySetInnerHTML={{ __html: JSON.stringify({"@context":"https://schema.org","@type":"Article","headline":"IRA Contribution Limits & Rules 2026","author":{"@type":"Person","name":"James Mitchell","jobTitle":"CFA"},"publisher":{"@type":"Organization","name":"IRA Research Hub"},"dateModified":"2026-03-31"}) }} />

      <div className="bg-[#F8FAFC] border-b border-slate-200 py-10">
        <div className="container-site max-w-4xl">
          <div className="flex flex-wrap gap-2 mb-4">
            <span className="inline-flex items-center px-2.5 py-0.5 rounded-full text-xs font-medium bg-indigo-100 text-indigo-700">Educational Guide</span>
            <span className="inline-flex items-center px-2.5 py-0.5 rounded-full text-xs font-medium bg-emerald-100 text-emerald-700">2026 Limits</span>
          </div>
          <h1 className="text-4xl font-bold text-[#0F172A] mb-4 leading-tight">
            IRA Contribution Limits & Rules 2026
          </h1>
          <p className="text-lg text-[#64748B] mb-4 max-w-3xl">
            The IRS adjusts IRA contribution limits annually for inflation. This guide covers the 2026 limits for all IRA types, income-based restrictions, catch-up contribution rules, deductibility rules, and the penalties for excess contributions.
          </p>
          <p className="text-sm text-slate-500">
            By <Link to="/author/james-mitchell" className="text-sky-600 hover:underline font-medium">James Mitchell, CFA</Link>
            {' · '}Last Updated: {LAST_UPDATED}
          </p>
          <AdvertiserDisclosure />
        </div>
      </div>

      <div className="container-site max-w-4xl py-8">
        <div className="bg-sky-50 border border-sky-200 rounded-xl p-5 mb-8">
          <p className="font-semibold text-sky-800 mb-3">2026 IRA Contribution Limits at a Glance</p>
          <div className="overflow-x-auto">
            <table className="w-full text-sm border-collapse">
              <thead>
                <tr className="bg-sky-100">
                  <th className="text-left p-3 font-semibold text-sky-800 border border-sky-200">Account Type</th>
                  <th className="text-left p-3 font-semibold text-sky-800 border border-sky-200">2026 Limit</th>
                  <th className="text-left p-3 font-semibold text-sky-800 border border-sky-200">Catch-Up (Age 50+)</th>
                  <th className="text-left p-3 font-semibold text-sky-800 border border-sky-200">Income Limit?</th>
                </tr>
              </thead>
              <tbody>
                {[
                  ["Traditional IRA", "$7,000", "+$1,000 = $8,000", "No (deductibility has limits)"],
                  ["Roth IRA", "$7,000", "+$1,000 = $8,000", "Yes — phases out at $150K–$165K (single)"],
                  ["SEP-IRA", "25% of compensation or $70,000", "N/A", "No"],
                  ["SIMPLE IRA", "$16,500", "+$3,500 = $20,000", "No"],
                ].map(([type, limit, catchup, income]) => (
                  <tr key={type} className="border-b border-sky-100">
                    <td className="p-3 font-medium text-slate-700 border border-sky-200">{type}</td>
                    <td className="p-3 text-slate-600 border border-sky-200">{limit}</td>
                    <td className="p-3 text-slate-600 border border-sky-200">{catchup}</td>
                    <td className="p-3 text-slate-600 border border-sky-200">{income}</td>
                  </tr>
                ))}
              </tbody>
            </table>
          </div>
          <p className="text-xs text-slate-500 mt-2 italic">Source: IRS Publication 590-A (2025). 2026 limits subject to IRS inflation adjustments.</p>
        </div>

        <section className="mb-10">
          <h2 className="text-2xl font-bold text-[#0F172A] mb-4">Traditional IRA Contribution Rules</h2>
          <p className="text-slate-600 leading-relaxed mb-4">
            Anyone with earned income (wages, self-employment income) can contribute to a Traditional IRA, regardless of income level. However, the deductibility of contributions depends on whether you (or your spouse) are covered by a workplace retirement plan and your modified adjusted gross income (MAGI).
          </p>
          <div className="overflow-x-auto mb-4">
            <table className="w-full text-sm border-collapse">
              <thead>
                <tr className="bg-slate-100">
                  <th className="text-left p-3 font-semibold text-slate-700 border border-slate-200">Filing Status</th>
                  <th className="text-left p-3 font-semibold text-slate-700 border border-slate-200">Covered by Workplace Plan?</th>
                  <th className="text-left p-3 font-semibold text-slate-700 border border-slate-200">2026 Deduction Phase-Out Range</th>
                </tr>
              </thead>
              <tbody>
                {[
                  ["Single / Head of Household", "Yes", "$79,000 – $89,000"],
                  ["Married Filing Jointly", "Yes (contributor)", "$126,000 – $146,000"],
                  ["Married Filing Jointly", "No (spouse covered)", "$236,000 – $246,000"],
                  ["Married Filing Separately", "Yes", "$0 – $10,000"],
                  ["Any filing status", "No", "No phase-out — full deduction"],
                ].map(([status, covered, range], i) => (
                  <tr key={i} className="border-b border-slate-100">
                    <td className="p-3 text-slate-700 border border-slate-200">{status}</td>
                    <td className="p-3 text-slate-600 border border-slate-200">{covered}</td>
                    <td className="p-3 text-slate-600 border border-slate-200">{range}</td>
                  </tr>
                ))}
              </tbody>
            </table>
          </div>
        </section>

        <section className="mb-10">
          <h2 className="text-2xl font-bold text-[#0F172A] mb-4">Roth IRA Income Limits</h2>
          <p className="text-slate-600 leading-relaxed mb-4">
            Unlike Traditional IRAs, Roth IRA contributions are subject to income limits. If your MAGI exceeds the phase-out range, your contribution limit is reduced. Above the upper limit, you cannot contribute directly to a Roth IRA.
          </p>
          <div className="overflow-x-auto mb-4">
            <table className="w-full text-sm border-collapse">
              <thead>
                <tr className="bg-slate-100">
                  <th className="text-left p-3 font-semibold text-slate-700 border border-slate-200">Filing Status</th>
                  <th className="text-left p-3 font-semibold text-slate-700 border border-slate-200">2026 Phase-Out Range</th>
                  <th className="text-left p-3 font-semibold text-slate-700 border border-slate-200">Above Limit</th>
                </tr>
              </thead>
              <tbody>
                {[
                  ["Single / Head of Household", "$150,000 – $165,000", "No direct Roth contribution"],
                  ["Married Filing Jointly", "$236,000 – $246,000", "No direct Roth contribution"],
                  ["Married Filing Separately", "$0 – $10,000", "No direct Roth contribution"],
                ].map(([status, range, above]) => (
                  <tr key={status} className="border-b border-slate-100">
                    <td className="p-3 font-medium text-slate-700 border border-slate-200">{status}</td>
                    <td className="p-3 text-slate-600 border border-slate-200">{range}</td>
                    <td className="p-3 text-slate-600 border border-slate-200">{above}</td>
                  </tr>
                ))}
              </tbody>
            </table>
          </div>
          <div className="bg-sky-50 border border-sky-200 rounded-lg p-4 text-sm text-sky-900">
            <p className="font-semibold mb-1">Backdoor Roth IRA:</p>
            <p>High-income earners who exceed the Roth IRA income limits may be able to use a "backdoor Roth" strategy — making a non-deductible Traditional IRA contribution and then converting it to a Roth IRA. This strategy has tax implications and should be evaluated with a tax advisor, particularly if you have other pre-tax IRA balances (the "pro-rata rule").</p>
          </div>
        </section>

        <section className="mb-10">
          <h2 className="text-2xl font-bold text-[#0F172A] mb-4">Excess Contribution Penalties</h2>
          <p className="text-slate-600 leading-relaxed mb-4">
            Contributing more than the allowed limit to an IRA results in an <strong>excess contribution</strong>, subject to a <strong>6% excise tax per year</strong> on the excess amount for each year it remains in the account.
          </p>
          <p className="text-slate-600 leading-relaxed mb-4">
            To avoid the penalty, you must withdraw the excess contribution (plus any earnings on it) by the tax filing deadline (including extensions) for the year in which the excess was made. Consult a tax advisor if you have made an excess contribution.
          </p>
        </section>

        <section className="mb-10 pt-6 border-t border-slate-200">
          <h3 className="text-sm font-semibold text-slate-500 uppercase tracking-wider mb-3">Primary Sources & References</h3>
          <ul className="space-y-1.5 text-xs text-slate-500">
            <li><a href="https://www.irs.gov/publications/p590a" target="_blank" rel="noopener noreferrer" className="text-sky-600 hover:underline">IRS Publication 590-A: Contributions to Individual Retirement Arrangements</a></li>
            <li><a href="https://www.irs.gov/retirement-plans/ira-deduction-limits" target="_blank" rel="noopener noreferrer" className="text-sky-600 hover:underline">IRS: IRA Deduction Limits</a></li>
            <li><a href="https://www.irs.gov/retirement-plans/roth-iras" target="_blank" rel="noopener noreferrer" className="text-sky-600 hover:underline">IRS: Roth IRAs</a></li>
          </ul>
        </section>

        <div className="mt-8 p-5 bg-amber-50 border border-amber-200 rounded-lg text-sm text-amber-900">
          <p className="font-semibold mb-1">Important Disclaimer</p>
          <p>This page is for informational and educational purposes only. IRA contribution rules are complex and subject to annual IRS adjustments. Always consult a qualified tax professional for advice specific to your situation. <Link to="/editorial-policy" className="underline font-medium">See our Editorial Policy</Link>.</p>
        </div>
      </div>
      {/* ── Newsletter Signup ─────────────────────────────────────────── */}
      <div className="container-site py-10 max-w-3xl">
        
        {/* Related Links */}

        <div className="mt-10 mb-6">

          <RelatedLinks variant="crypto-guide" title="Related Guides &amp; Reviews" />

        </div>
<NewsletterSignup />
      </div>
    </>
  )
}
