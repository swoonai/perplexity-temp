import { Link } from 'react-router-dom'

import SEO from '../components/SEO'
import NewsletterSignup from '../components/NewsletterSignup';
export default function AboutPage() {
  return (
    <div className="section-padding">
      <SEO
        title="About IRA Research Hub — Independent IRA Reviews"
        description="IRA Research Hub is an independent financial research publication helping investors navigate Crypto IRA and Precious Metals IRA providers with data-driven, unbiased reviews."
        canonical="/about"
      />
      <div className="container-site max-w-3xl">

        {/* Hero */}
        <div className="mb-12">
          <div className="badge-sky mb-4">Independent Research Since 2022</div>
          <h1 className="text-4xl font-bold text-[#0F172A] mb-4">About IRA Research Hub</h1>
          <p className="text-lg text-[#64748B] leading-relaxed">
            IRA Research Hub is an independent financial research publication dedicated to helping
            everyday investors navigate the complex and often opaque landscape of self-directed
            Individual Retirement Accounts (IRAs) — from cryptocurrency IRAs to precious metals IRAs.
          </p>
        </div>

        {/* Mission */}
        <section className="mb-12">
          <h2 className="text-2xl font-bold text-[#0F172A] mb-4">Our Mission</h2>
          <div className="card border-l-4 border-l-[#0EA5E9] mb-6">
            <p className="text-[#334155] leading-relaxed italic">
              "To provide retail investors with the same quality of research and analysis that
              institutional investors take for granted — clear, objective, and data-driven — so
              that every American can make an informed decision about their retirement savings."
            </p>
          </div>
          <p className="text-[#64748B] leading-relaxed mb-4">
            The self-directed IRA market is worth over $2 trillion, yet most retail investors
            receive their information from providers with a direct financial interest in the
            outcome. We exist to change that. Our editorial team conducts independent research,
            analysis, and testing of providers across both the Crypto IRA and Precious Metals IRA
            markets, publishing findings that are grounded in data — not commissions.
          </p>
          <p className="text-[#64748B] leading-relaxed">
            We are not affiliated with any IRA provider, custodian, or financial institution.
            Where we do earn affiliate compensation, it is clearly disclosed and does not influence
            our editorial ratings or rankings.
          </p>
        </section>

        {/* Editorial Guidelines */}
        <section className="mb-12">
          <h2 className="text-2xl font-bold text-[#0F172A] mb-4">Editorial Guidelines</h2>
          <p className="text-[#64748B] leading-relaxed mb-6">
            Our editorial process is built on four principles that govern every review, ranking,
            and piece of analysis we publish:
          </p>
          <div className="grid sm:grid-cols-2 gap-4">
            {[
              {
                title: 'Independence',
                body: 'Our editorial team operates independently of our commercial team. Affiliate relationships are disclosed but never influence scores, rankings, or editorial copy.',
              },
              {
                title: 'Transparency',
                body: 'Every score we publish is derived from a documented, weighted methodology. We publish our scoring framework openly so readers can evaluate our reasoning.',
              },
              {
                title: 'Accuracy',
                body: 'Fee data, regulatory status, and custody details are verified directly against provider websites, SEC filings, and BBB records. We update reviews when data changes.',
              },
              {
                title: 'Fairness',
                body: 'All providers are evaluated against the same criteria. We do not accept payment for positive reviews, and we publish negative findings when the data supports them.',
              },
            ].map((item) => (
              <div key={item.title} className="card">
                <h3 className="font-bold text-[#0F172A] mb-2">{item.title}</h3>
                <p className="text-sm text-[#64748B] leading-relaxed">{item.body}</p>
              </div>
            ))}
          </div>
        </section>

        {/* How We Score */}
        <section className="mb-12">
          <h2 className="text-2xl font-bold text-[#0F172A] mb-4">How We Score Providers</h2>
          <p className="text-[#64748B] leading-relaxed mb-6">
            Each provider is evaluated across six weighted dimensions. Scores are assigned on a
            0–10 scale and combined into a single overall rating using the weights below. The full
            methodology is documented on our{' '}
            <Link to="/methodology" className="text-[#0EA5E9] hover:underline">Methodology page</Link>.
          </p>
          <div className="overflow-x-auto">
            <table className="comparison-table">
              <thead>
                <tr>
                  <th>Dimension</th>
                  <th>Weight</th>
                  <th>What We Measure</th>
                </tr>
              </thead>
              <tbody>
                {[
                  ['Fee Transparency', '20%', 'Setup, annual, and transaction fees vs. industry benchmarks'],
                  ['Asset Selection', '20%', 'Breadth and quality of supported assets'],
                  ['Security & Custody', '20%', 'Custodian quality, insurance coverage, cold storage'],
                  ['IRS Compliance', '15%', 'Regulatory standing, audit history, IRS-approved structures'],
                  ['Customer Support', '15%', 'Response times, dedicated specialists, dispute resolution'],
                  ['Reputation', '10%', 'BBB rating, Trustpilot score, complaint history'],
                ].map(([dim, weight, desc]) => (
                  <tr key={dim}>
                    <td className="font-medium text-[#0F172A]">{dim}</td>
                    <td className="text-[#0EA5E9] font-semibold">{weight}</td>
                    <td className="text-[#64748B]">{desc}</td>
                  </tr>
                ))}
              </tbody>
            </table>
          </div>
        </section>

        {/* Disclosure */}
        <section className="mb-8">
          <h2 className="text-2xl font-bold text-[#0F172A] mb-4">Affiliate Disclosure</h2>
          <p className="text-[#64748B] leading-relaxed mb-4">
            IRA Research Hub may receive compensation when a reader opens an account with a
            provider featured on this site. This compensation helps fund our independent research
            operation. However, it does not affect our editorial ratings, rankings, or the
            objectivity of our analysis. Providers that offer affiliate compensation are not
            guaranteed positive reviews, and providers without affiliate arrangements are evaluated
            on exactly the same criteria.
          </p>
          <p className="text-[#64748B] leading-relaxed">
            All affiliate relationships are clearly marked with an "Affiliate link" disclosure
            wherever they appear. For a full explanation of our compensation model, please read
            our{' '}
            <Link to="/privacy" className="text-[#0EA5E9] hover:underline">Privacy Policy</Link>.
          </p>
        </section>

        {/* CTA */}
        <div className="card bg-[#F0F9FF] border border-[#BAE6FD] text-center">
          <h3 className="font-bold text-[#0F172A] mb-2">Have a question or correction?</h3>
          <p className="text-sm text-[#64748B] mb-4">
            We take accuracy seriously. If you spot an error in any of our reviews or data,
            please reach out and we will investigate promptly.
          </p>
          <a
            href="mailto:editorial@iraresearchhub.com"
            className="btn-primary inline-block"
          >
            Contact the Editorial Team
          </a>
        </div>

      </div>
      {/* ── Newsletter Signup ─────────────────────────────────────────── */}
      <div className="container-site py-10 max-w-3xl">
        <NewsletterSignup />
      </div>
    </div>
  )
}
