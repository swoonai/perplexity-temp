import StateGuideTemplate from '../components/StateGuideTemplate'

export default function BestCryptoIRANEPage() {
  return (
    <StateGuideTemplate
      stateName="Nebraska"
      stateAbbr="NE"
      slug="nebraska"
    />
  )
}
