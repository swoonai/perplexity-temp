import { Link } from 'react-router-dom'
import SEO from '../components/SEO'
import { useProvider, scoreColor } from '../hooks/useProviders'
import AdvertiserDisclosure from '../components/AdvertiserDisclosure'
import { trackProviderReviewClick, trackProviderSiteVisit } from '../hooks/useAnalytics'
import NewsletterSignup from '../components/NewsletterSignup';
import RelatedLinks from '../components/RelatedLinks';

const DATE_MODIFIED = "2026-03-21"
const DATE_PUBLISHED = "2026-03-21"
const LAST_UPDATED = "March 21, 2026"

const comparisonSchema = {
  "@context": "https://schema.org",
  "@type": "Article",
  "@id": "https://iraresearchhub.com/crypto-ira/blocktrust-ira-vs-itrustcapital",
  "headline": "BlockTrust IRA vs iTrustCapital: 2026 Comparison",
  "description": "BlockTrust IRA vs iTrustCapital: detailed comparison of fees, asset selection, security, and scores. iTrustCapital has $0 annual fee; BlockTrust scores higher overall. See which is right for you.",
  "author": {
    "@type": "Person",
    "@id": "https://iraresearchhub.com/author/james-mitchell",
    "name": "James Mitchell",
    "url": "https://iraresearchhub.com/author/james-mitchell"
  },
  "publisher": {
    "@type": "Organization",
    "@id": "https://iraresearchhub.com",
    "name": "IRA Research Hub",
    "url": "https://iraresearchhub.com"
  },
  "datePublished": DATE_PUBLISHED,
  "dateModified": DATE_MODIFIED,
  "url": "https://iraresearchhub.com/crypto-ira/blocktrust-ira-vs-itrustcapital"
}

export default function BlockTrustVsITrustCapitalPage() {
  const { data: blockTrust } = useProvider('blocktrust-ira')
  const { data: iTrust } = useProvider('itrustcapital')

  const bt = blockTrust ?? {
    name: "BlockTrust IRA", score_overall: 9.6, score_fees: 9.5, score_assets: 9.8,
    score_security: 9.7, score_compliance: 9.5, score_support: 9.4, score_reputation: 9.2,
    annual_fee: "2% annual + 25% performance", transaction_fee: "0.14% via sFOX", min_investment: "$20,000",
    asset_count: 60, custody_provider: "sFOX", storage_type: "100% Cold Storage",
    insurance_coverage: "$200M", bbb_rating: null, founded_year: 2024,
    affiliate_url: null
  }
  const it = iTrust ?? {
    name: "iTrustCapital", score_overall: 8.8, score_fees: 9.8, score_assets: 8.0,
    score_security: 8.8, score_compliance: 9.0, score_support: 8.5, score_reputation: 8.7,
    annual_fee: "$0", transaction_fee: "1% per trade", min_investment: "$1,000",
    asset_count: 40, custody_provider: "Coinbase Custody", storage_type: "Cold Storage",
    insurance_coverage: "FDIC on cash", bbb_rating: "A", founded_year: 2018,
    affiliate_url: null
  }

  return (
    <>
      <SEO
        title="BlockTrust IRA vs iTrustCapital (2026): Which Is Better?"
        description="BlockTrust IRA vs iTrustCapital: iTrustCapital has $0 annual fee and $1,000 minimum. BlockTrust scores 9.6/10 vs iTrustCapital's 8.8/10. Full comparison of fees, assets, and security."
        canonical="/crypto-ira/blocktrust-ira-vs-itrustcapital"
        ogType="article"
      />
      <script
        type="application/ld+json"
        dangerouslySetInnerHTML={{ __html: JSON.stringify(comparisonSchema) }}
      />

      <section className="bg-[#F8FAFC] border-b border-slate-200">
        <div className="container-site py-12">
          <div className="flex flex-wrap items-center gap-2 mb-4">
            <Link to="/crypto-ira" className="text-sm text-[#64748B] hover:text-[#0EA5E9]">Crypto IRAs</Link>
            <span className="text-slate-300">/</span>
            <span className="text-sm text-[#0F172A]">BlockTrust IRA vs iTrustCapital</span>
          </div>
          <div className="badge-sky mb-4">Updated March 2026 · Live Data</div>
          <h1 className="text-4xl font-bold text-[#0F172A] mb-3">BlockTrust IRA vs iTrustCapital (2026)</h1>
          <p className="text-sm text-slate-400 mt-2">
            By <a href="/author/james-mitchell" className="text-[#0EA5E9] hover:underline">James Mitchell, CFA</a> · Last updated: {LAST_UPDATED} · <a href="/methodology" className="text-[#0EA5E9] hover:underline">Methodology</a>
          </p>
          <AdvertiserDisclosure />
          <p className="text-lg text-[#64748B] max-w-2xl mt-3">
            BlockTrust IRA and iTrustCapital are both top-rated crypto IRA providers — but iTrustCapital's $0 annual fee and $1,000 minimum make it the most accessible option, while BlockTrust leads on overall score and asset breadth.
          </p>
        </div>
      </section>

      <div className="container-site py-12">
        <div className="space-y-12">

          <div className="grid md:grid-cols-2 gap-6">
            <div className="card border-t-4 border-t-[#0EA5E9]">
              <div className="flex items-center justify-between mb-3">
                <h2 className="text-lg font-bold text-[#0F172A]">BlockTrust IRA</h2>
                <span className={`text-3xl font-bold ${scoreColor(bt.score_overall)}`}>{bt.score_overall}/10</span>
              </div>
              <p className="text-sm text-[#64748B] mb-3">🏆 Our #1 Rated Crypto IRA — Top-Ranked</p>
              <ul className="space-y-1 text-sm text-[#64748B]">
                <li className="flex gap-2"><span className="text-sky-500">✓</span> Higher overall score (9.6 vs 8.8)</li>
                <li className="flex gap-2"><span className="text-sky-500">✓</span> More cryptocurrencies (60 vs 40)</li>
                <li className="flex gap-2"><span className="text-sky-500">✓</span> sFOX institutional custody with $200M insurance</li>
                <li className="flex gap-2"><span className="text-sky-500">✓</span> 100% cold storage</li>
                <li className="flex gap-2"><span className="text-sky-500">✓</span> Animus AI 24/7 portfolio management</li>
              </ul>
              {bt.affiliate_url && (
                <a href={bt.affiliate_url} target="_blank" rel="noopener noreferrer sponsored"
                  className="btn-primary w-full text-center block mt-4 text-sm"
                  onClick={() => trackProviderSiteVisit('BlockTrust IRA', 'blocktrust-ira', bt.affiliate_url!)}>
                  Open BlockTrust IRA Account
                </a>
              )}
              <Link to="/crypto-ira/blocktrust-ira-review" className="btn-secondary w-full text-center block mt-2 text-sm"
                onClick={() => trackProviderReviewClick('Blocktrust Ira', 'blocktrust-ira', window.location.pathname)}>
                Read Full Review
              </Link>
            </div>
            <div className="card border-t-4 border-t-emerald-400">
              <div className="flex items-center justify-between mb-3">
                <h2 className="text-lg font-bold text-[#0F172A]">iTrustCapital</h2>
                <span className={`text-3xl font-bold ${scoreColor(it.score_overall)}`}>{it.score_overall}/10</span>
              </div>
              <p className="text-sm text-[#64748B] mb-3">Notable for Low Fees &amp; Low Minimum</p>
              <ul className="space-y-1 text-sm text-[#64748B]">
                <li className="flex gap-2"><span className="text-emerald-500">✓</span> $0 annual fee (vs 2% managed fee)</li>
                <li className="flex gap-2"><span className="text-emerald-500">✓</span> $1,000 minimum (vs $20,000)</li>
                <li className="flex gap-2"><span className="text-emerald-500">✓</span> Simple flat 1% trading fee</li>
                <li className="flex gap-2"><span className="text-emerald-500">✓</span> Gold &amp; silver IRA option</li>
                <li className="flex gap-2"><span className="text-slate-400">✗</span> Fewer cryptocurrencies (40 vs 60)</li>
              </ul>
              {it.affiliate_url && (
                <a href={it.affiliate_url} target="_blank" rel="noopener noreferrer sponsored"
                  className="btn-primary w-full text-center block mt-4 text-sm"
                  onClick={() => trackProviderSiteVisit('iTrustCapital', 'itrustcapital', it.affiliate_url!)}>
                  Open iTrustCapital Account
                </a>
              )}
              <Link to="/crypto-ira/itrustcapital-review" className="btn-secondary w-full text-center block mt-2 text-sm"
                onClick={() => trackProviderReviewClick('Itrustcapital', 'itrustcapital', window.location.pathname)}>
                Read Full Review
              </Link>
            </div>
          </div>

          <div>
            <h2 className="text-2xl font-bold text-[#0F172A] mb-6">Head-to-Head Comparison</h2>
            <div className="overflow-x-auto">
              <table className="comparison-table" aria-label="BlockTrust IRA vs iTrustCapital comparison table">
                <thead>
                  <tr>
                    <th scope="col">Feature</th>
                    <th scope="col">BlockTrust IRA</th>
                    <th scope="col">iTrustCapital</th>
                    <th scope="col">Winner</th>
                  </tr>
                </thead>
                <tbody>
                  {[
                    ['Overall Score', `${bt.score_overall}/10`, `${it.score_overall}/10`, '🏆 BlockTrust IRA'],
                    ['Annual Fee', bt.annual_fee ?? '—', it.annual_fee ?? '—', '🏆 iTrustCapital ($0 vs 2%)'],
                    ['Trading Fee', bt.transaction_fee ?? '—', it.transaction_fee ?? '—', '🏆 BlockTrust IRA (0.14% vs 1%)'],
                    ['Minimum Investment', bt.min_investment ?? '—', it.min_investment ?? '—', '🏆 iTrustCapital ($1,000 vs $20,000)'],
                    ['Cryptocurrencies', `${bt.asset_count ?? '—'}+`, `${it.asset_count ?? '—'}+`, '🏆 BlockTrust IRA (60 vs 40)'],
                    ['Custodian', bt.custody_provider ?? '—', it.custody_provider ?? '—', '🏆 BlockTrust (sFOX)'],
                    ['Storage', bt.storage_type ?? '—', it.storage_type ?? '—', '🏆 BlockTrust (100% cold)'],
                    ['Insurance', bt.insurance_coverage ?? '—', it.insurance_coverage ?? '—', '🏆 BlockTrust ($200M)'],
                    ['BBB Rating', bt.bbb_rating ?? 'None', it.bbb_rating ?? '—', '🏆 iTrustCapital (A vs none)'],
                    ['Fee Score', `${bt.score_fees}/10`, `${it.score_fees}/10`, '🏆 iTrustCapital (9.8 vs 9.5)'],
                    ['Asset Score', `${bt.score_assets}/10`, `${it.score_assets}/10`, '🏆 BlockTrust IRA'],
                    ['Security Score', `${bt.score_security}/10`, `${it.score_security}/10`, '🏆 BlockTrust IRA'],
                  ].map(([feature, btVal, itVal, winner]) => (
                    <tr key={feature}>
                      <td className="font-medium text-[#0F172A]" scope="row">{feature}</td>
                      <td className="text-[#64748B]">{btVal}</td>
                      <td className="text-[#64748B]">{itVal}</td>
                      <td className="font-medium text-[#334155] text-sm">{winner}</td>
                    </tr>
                  ))}
                </tbody>
              </table>
            </div>
          </div>

          <div>
            <h2 className="text-2xl font-bold text-[#0F172A] mb-6">Who Should Choose Each Provider?</h2>
            <div className="grid md:grid-cols-2 gap-6">
              <div className="card border-l-4 border-l-[#0EA5E9]">
                <h3 className="font-bold text-[#0F172A] mb-3">Choose BlockTrust IRA if you:</h3>
                <ul className="space-y-2 text-sm text-[#64748B]">
                  <li className="flex gap-2"><span className="text-sky-500 flex-shrink-0">✓</span> Want Animus AI 24/7 managed portfolio</li>
                  <li className="flex gap-2"><span className="text-sky-500 flex-shrink-0">✓</span> Want the highest-rated platform (9.6/10)</li>
                  <li className="flex gap-2"><span className="text-sky-500 flex-shrink-0">✓</span> Want access to 60+ cryptocurrencies</li>
                  <li className="flex gap-2"><span className="text-sky-500 flex-shrink-0">✓</span> Prioritise sFOX custody and $200M insurance</li>
                  <li className="flex gap-2"><span className="text-sky-500 flex-shrink-0">✓</span> Want 100% cold storage guarantee</li>
                </ul>
              </div>
              <div className="card border-l-4 border-l-emerald-400">
                <h3 className="font-bold text-[#0F172A] mb-3">Choose iTrustCapital if you:</h3>
                <ul className="space-y-2 text-sm text-[#64748B]">
                  <li className="flex gap-2"><span className="text-emerald-500 flex-shrink-0">✓</span> Want to start with as little as $1,000</li>
                  <li className="flex gap-2"><span className="text-emerald-500 flex-shrink-0">✓</span> Prioritise eliminating the annual fee</li>
                  <li className="flex gap-2"><span className="text-emerald-500 flex-shrink-0">✓</span> Want gold and silver IRA alongside crypto</li>
                  <li className="flex gap-2"><span className="text-emerald-500 flex-shrink-0">✓</span> Are a first-time crypto IRA investor</li>
                  <li className="flex gap-2"><span className="text-emerald-500 flex-shrink-0">✓</span> Trade infrequently (annual fee savings matter most)</li>
                </ul>
              </div>
            </div>
          </div>

          <div className="card bg-blue-50 border-blue-200">
            <h2 className="text-xl font-bold text-[#0F172A] mb-4">The Key Tradeoff: Fees vs Capability</h2>
            <div className="space-y-3 text-sm text-[#64748B]">
              <p>
                <strong className="text-[#0F172A]">Annual Fee:</strong> BlockTrust IRA charges a 2% annual management fee plus a 25% performance fee on profits only. iTrustCapital charges $0/year for all accounts. BlockTrust's fee structure is performance-aligned — they profit only when you profit. iTrustCapital wins on pure cost for passive investors.
              </p>
              <p>
                <strong className="text-[#0F172A]">Trading Fee:</strong> BlockTrust IRA charges 0.14% per trade via sFOX institutional liquidity. iTrustCapital charges 1% per trade. For active traders, BlockTrust's lower trading fee is a significant advantage.
              </p>
              <p>
                <strong className="text-[#0F172A]">Minimum Investment:</strong> BlockTrust IRA requires a $20,000 minimum — it is a fully managed service designed for serious retirement investors. iTrustCapital requires $1,000, making it more accessible for smaller accounts.
              </p>
              <p>
                <strong className="text-[#0F172A]">Security:</strong> BlockTrust uses sFOX as custodian with $200M insurance coverage and 100% cold storage. iTrustCapital uses Coinbase Custody with FDIC coverage on cash holdings. Both are institutional-grade.
              </p>
            </div>
          </div>

          <div>
            <h2 className="text-xl font-bold text-[#0F172A] mb-4">Related Comparisons</h2>
            <div className="grid sm:grid-cols-2 gap-3">
              <Link to="/crypto-ira/blocktrust-ira-vs-bitcoin-ira" className="block p-4 rounded-lg border border-slate-200 hover:border-[#0EA5E9] hover:bg-blue-50 transition-colors">
                <p className="font-medium text-[#0F172A] text-sm">BlockTrust IRA vs Bitcoin IRA</p>
                <p className="text-xs text-slate-500 mt-1">Compare fees, assets, and scores</p>
              </Link>
              <Link to="/crypto-ira/bitcoin-ira-vs-itrustcapital" className="block p-4 rounded-lg border border-slate-200 hover:border-[#0EA5E9] hover:bg-blue-50 transition-colors">
                <p className="font-medium text-[#0F172A] text-sm">Bitcoin IRA vs iTrustCapital</p>
                <p className="text-xs text-slate-500 mt-1">Compare fees, assets, and scores</p>
              </Link>
              <Link to="/crypto-ira/blocktrust-ira-review" className="block p-4 rounded-lg border border-slate-200 hover:border-[#0EA5E9] hover:bg-blue-50 transition-colors"
                onClick={() => trackProviderReviewClick('Blocktrust Ira', 'blocktrust-ira', window.location.pathname)}>
                <p className="font-medium text-[#0F172A] text-sm">BlockTrust IRA Full Review</p>
                <p className="text-xs text-slate-500 mt-1">In-depth analysis, 9.6/10</p>
              </Link>
              <Link to="/crypto-ira/itrustcapital-review" className="block p-4 rounded-lg border border-slate-200 hover:border-[#0EA5E9] hover:bg-blue-50 transition-colors"
                onClick={() => trackProviderReviewClick('Itrustcapital', 'itrustcapital', window.location.pathname)}>
                <p className="font-medium text-[#0F172A] text-sm">iTrustCapital Full Review</p>
                <p className="text-xs text-slate-500 mt-1">In-depth analysis, 8.8/10</p>
              </Link>
            </div>
          </div>

        </div>
      </div>
      {/* ── Newsletter Signup ─────────────────────────────────────────── */}
      <div className="container-site py-10 max-w-3xl">
        
        {/* Related Links */}

        <div className="mt-10 mb-6">

          <RelatedLinks variant="comparison-crypto" title="Related Guides &amp; Reviews" />

        </div>
<NewsletterSignup />
      </div>
    </>
  )
}
