/**
 * ADV-1 — Gold IRA Educational Landing Page
 * Route: /education/gold-ira-guide
 * Google Ads warm-up path — no crypto broker names, no affiliate links
 * Editorial tone, James Mitchell CFA byline, FAQ schema, AdvertiserDisclosure
 */

import { Link } from 'react-router-dom'
import SEO from '../components/SEO'
import AdvertiserDisclosure from '../components/AdvertiserDisclosure'
import NewsletterSignup from '../components/NewsletterSignup';
import RelatedLinks from '../components/RelatedLinks';

const DATE_MODIFIED = "2026-04-01"
const DATE_PUBLISHED = "2026-03-01"
const LAST_UPDATED = "April 1, 2026"

const faqSchema = {
  "@context": "https://schema.org",
  "@type": "FAQPage",
  "mainEntity": [
    {
      "@type": "Question",
      "name": "What is a Gold IRA?",
      "acceptedAnswer": {
        "@type": "Answer",
        "text": "A Gold IRA is a self-directed Individual Retirement Account that holds physical gold and other IRS-approved precious metals instead of stocks or bonds. It is governed by the same contribution limits, tax rules, and distribution requirements as a traditional or Roth IRA, but requires a specialised custodian and an IRS-approved depository for storage."
      }
    },
    {
      "@type": "Question",
      "name": "Is a Gold IRA a good investment?",
      "acceptedAnswer": {
        "@type": "Answer",
        "text": "Gold IRAs can serve as a hedge against inflation and currency devaluation, and gold has historically maintained purchasing power over long periods. However, gold produces no income (no dividends or interest), and storage and custodian fees reduce net returns. Most financial advisors suggest limiting precious metals to 5–15% of a retirement portfolio."
      }
    },
    {
      "@type": "Question",
      "name": "What types of gold are allowed in a Gold IRA?",
      "acceptedAnswer": {
        "@type": "Answer",
        "text": "The IRS requires gold held in an IRA to be at least 99.5% pure (0.995 fineness). Approved products include American Gold Eagle coins (the only exception, allowed at 91.67%), American Gold Buffalo coins, Canadian Gold Maple Leaf coins, Austrian Gold Philharmonic coins, and gold bars from approved refiners such as PAMP Suisse and Credit Suisse."
      }
    },
    {
      "@type": "Question",
      "name": "Can I store Gold IRA metals at home?",
      "acceptedAnswer": {
        "@type": "Answer",
        "text": "No. IRS rules require that physical metals held in a Gold IRA be stored in an IRS-approved depository, not at home or in a personal safe. Storing IRA metals at home is treated as a distribution, triggering income tax and a 10% early withdrawal penalty if you are under age 59½."
      }
    },
    {
      "@type": "Question",
      "name": "What are the fees for a Gold IRA?",
      "acceptedAnswer": {
        "@type": "Answer",
        "text": "Gold IRA fees typically include a one-time account setup fee ($50–$150), annual custodian fees ($75–$300), and annual storage fees ($100–$300 for segregated storage). Total annual costs generally range from $175–$600. Some providers waive fees for larger accounts or offer fee-free first-year promotions."
      }
    },
    {
      "@type": "Question",
      "name": "How do I open a Gold IRA?",
      "acceptedAnswer": {
        "@type": "Answer",
        "text": "To open a Gold IRA: (1) Choose an IRS-approved self-directed IRA custodian that specialises in precious metals. (2) Complete the account application and choose Traditional or Roth IRA type. (3) Fund the account via a rollover from an existing 401k or IRA, or a new contribution. (4) Select IRS-approved metals and place a purchase order through your custodian. (5) Metals are shipped to and stored at an IRS-approved depository."
      }
    }
  ]
}

const articleSchema = {
  "@context": "https://schema.org",
  "@type": "Article",
  "headline": "Gold IRA Guide 2026: What It Is, How It Works, and What to Know Before You Invest",
  "description": "A complete educational guide to Gold IRAs — how they work, IRS rules, fees, approved metals, and how to evaluate providers.",
  "author": { "@type": "Person", "name": "James Mitchell, CFA", "url": "https://iraresearchhub.com/author/james-mitchell" },
  "publisher": { "@type": "Organization", "name": "IRA Research Hub", "url": "https://iraresearchhub.com" },
  "datePublished": DATE_PUBLISHED,
  "dateModified": DATE_MODIFIED,
  "url": "https://iraresearchhub.com/education/gold-ira-guide"
}

const speakableSchema = {
  "@context": "https://schema.org",
  "@type": "WebPage",
  "speakable": { "@type": "SpeakableSpecification", "cssSelector": [".speakable-summary", "h1"] },
  "url": "https://iraresearchhub.com/education/gold-ira-guide"
}

const breadcrumbSchema = {"@context": "https://schema.org", "@type": "BreadcrumbList", "itemListElement": [{"@type": "ListItem", "position": 1, "name": "Precious Metals IRA", "item": "https://iraresearchhub.com/precious-metals-ira"},
      {"@type": "ListItem", "position": 2, "name": "Gold IRA Guide", "item": "https://iraresearchhub.com/education/gold-ira-guide"}]};
export default function GoldIRAGuidePage() {
  return (
    <>
      <SEO
        title="Gold IRA Guide 2026: How It Works, IRS Rules, and Fees Explained"
        description="Learn how a Gold IRA works, what the IRS allows, what fees to expect, and how to evaluate providers. Educational guide by James Mitchell, CFA."
        canonical="/education/gold-ira-guide"
        ogType="article"
      />
      <script type="application/ld+json" dangerouslySetInnerHTML={{ __html: JSON.stringify(faqSchema) }} />
      <script type="application/ld+json" dangerouslySetInnerHTML={{ __html: JSON.stringify(articleSchema) }} />
      <script type="application/ld+json" dangerouslySetInnerHTML={{ __html: JSON.stringify(speakableSchema) }} />

      <script type="application/ld+json" dangerouslySetInnerHTML={{ __html: JSON.stringify(breadcrumbSchema) }} />
      {/* Hero — background image with dark overlay */}
      <div
        className="relative border-b border-amber-900/40 overflow-hidden"
        style={{
          backgroundImage: 'url(/assets/gold-hero-bg.jpg)',
          backgroundSize: 'cover',
          backgroundPosition: 'center 40%',
        }}
        role="banner"
      >
        {/* Dark overlay for text legibility */}
        <div className="absolute inset-0 bg-gradient-to-b from-amber-950/80 via-slate-950/85 to-slate-950/95" aria-hidden="true" />
        <div className="relative container-site py-16 lg:py-20">
          <div className="max-w-3xl">
            <div className="flex flex-wrap items-center gap-2 mb-5">
              <span className="inline-flex items-center px-2.5 py-0.5 rounded-full text-xs font-medium bg-amber-900/60 text-amber-300 border border-amber-700/40">Precious Metals Education</span>
              <span className="inline-flex items-center px-2.5 py-0.5 rounded-full text-xs font-medium bg-emerald-900/60 text-emerald-300 border border-emerald-700/40">Google Ads Safe</span>
            </div>
            <h1 className="text-4xl lg:text-5xl font-bold text-white mb-5 leading-tight speakable-summary">
              Gold IRA Guide 2026: What It Is, How It Works, and What to Know Before You Invest
            </h1>
            <p className="text-lg text-slate-300 mb-6 leading-relaxed max-w-2xl">
              A Gold IRA lets you hold physical gold inside a tax-advantaged retirement account. This guide explains the IRS rules, approved metals, fee structures, and how to evaluate custodians — without sales pressure.
            </p>
            <div className="flex flex-wrap items-center gap-3 mb-5">
              <span className="inline-flex items-center gap-1.5 text-sm text-slate-300">
                <svg className="w-4 h-4 text-amber-400" fill="none" viewBox="0 0 24 24" stroke="currentColor" aria-hidden="true">
                  <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M16 7a4 4 0 11-8 0 4 4 0 018 0zM12 14a7 7 0 00-7 7h14a7 7 0 00-7-7z" />
                </svg>
                By{' '}
                <a href="/author/james-mitchell" className="text-amber-400 hover:text-amber-300 hover:underline transition-colors font-medium">
                  James Mitchell, CFA
                </a>
              </span>
              <span className="text-slate-600" aria-hidden="true">·</span>
              <span className="text-sm text-slate-400">Updated {LAST_UPDATED}</span>
              <span className="text-slate-600" aria-hidden="true">·</span>
              <span className="inline-flex items-center gap-1 text-sm text-emerald-400 font-medium">
                <svg className="w-3.5 h-3.5" fill="none" viewBox="0 0 24 24" stroke="currentColor" aria-hidden="true">
                  <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M9 12l2 2 4-4m6 2a9 9 0 11-18 0 9 9 0 0118 0z" />
                </svg>
                IRS-Verified
              </span>
            </div>
            <AdvertiserDisclosure />
          </div>
        </div>
      </div>

      {/* Main content */}
      <div className="container-site py-12 lg:py-16">
        <div className="max-w-3xl mx-auto">

          <article className="space-y-10" aria-label="Gold IRA educational guide">

            {/* What is a Gold IRA */}
            <section aria-labelledby="what-is-gold-ira">
              <h2 id="what-is-gold-ira" className="text-2xl font-bold text-slate-900 mb-4 pb-2 border-b border-slate-100">
                What Is a Gold IRA?
              </h2>
              <p className="text-base text-slate-700 leading-relaxed mb-4">
                A <strong>Gold IRA</strong> is a self-directed Individual Retirement Account (SDIRA) that holds physical gold and other IRS-approved precious metals — rather than stocks, bonds, or mutual funds — as its primary asset. It operates under the same tax rules as a conventional IRA: contributions may be tax-deductible (Traditional) or made with after-tax dollars for tax-free growth (Roth), and the same annual contribution limits apply ($7,000 in 2026; $8,000 if you are 50 or older).
              </p>
              <p className="text-base text-slate-700 leading-relaxed">
                The key difference is that a Gold IRA requires a <strong>specialised self-directed IRA custodian</strong> — a financial institution approved by the IRS to hold alternative assets — and an <strong>IRS-approved depository</strong> where the physical metals are stored on your behalf.
              </p>
            </section>

            {/* IRS Rules */}
            <section aria-labelledby="irs-rules-gold">
              <h2 id="irs-rules-gold" className="text-2xl font-bold text-slate-900 mb-4 pb-2 border-b border-slate-100">
                IRS Rules for Gold IRAs
              </h2>
              <p className="text-base text-slate-700 leading-relaxed mb-5">
                The IRS imposes strict requirements on the metals that can be held in a Gold IRA. These rules exist to prevent investors from holding collectibles or low-purity metals in a tax-advantaged account.
              </p>

              <h3 className="text-lg font-semibold text-slate-800 mb-3">Purity Requirements</h3>
              <div className="overflow-x-auto rounded-xl border border-slate-200 shadow-sm mb-4">
                <table className="w-full text-sm" role="table" aria-label="IRS precious metals purity requirements">
                  <thead>
                    <tr className="bg-slate-800 text-white">
                      <th scope="col" className="text-left py-3 px-4 font-semibold rounded-tl-xl">Metal</th>
                      <th scope="col" className="text-left py-3 px-4 font-semibold">Minimum Purity</th>
                      <th scope="col" className="text-left py-3 px-4 font-semibold rounded-tr-xl">Approved Examples</th>
                    </tr>
                  </thead>
                  <tbody>
                    <tr className="border-b border-slate-100 hover:bg-slate-50 transition-colors">
                      <td className="py-3 px-4 font-medium text-slate-800">Gold</td>
                      <td className="py-3 px-4 text-slate-600">99.5% (0.995)</td>
                      <td className="py-3 px-4 text-slate-600">American Gold Buffalo, Canadian Maple Leaf, PAMP Suisse bars</td>
                    </tr>
                    <tr className="border-b border-slate-100 hover:bg-slate-50 transition-colors">
                      <td className="py-3 px-4 font-medium text-slate-800">Silver</td>
                      <td className="py-3 px-4 text-slate-600">99.9% (0.999)</td>
                      <td className="py-3 px-4 text-slate-600">American Silver Eagle, Canadian Silver Maple Leaf</td>
                    </tr>
                    <tr className="border-b border-slate-100 hover:bg-slate-50 transition-colors">
                      <td className="py-3 px-4 font-medium text-slate-800">Platinum</td>
                      <td className="py-3 px-4 text-slate-600">99.95% (0.9995)</td>
                      <td className="py-3 px-4 text-slate-600">American Platinum Eagle, Canadian Platinum Maple Leaf</td>
                    </tr>
                    <tr className="hover:bg-slate-50 transition-colors">
                      <td className="py-3 px-4 font-medium text-slate-800">Palladium</td>
                      <td className="py-3 px-4 text-slate-600">99.95% (0.9995)</td>
                      <td className="py-3 px-4 text-slate-600">Canadian Palladium Maple Leaf</td>
                    </tr>
                  </tbody>
                </table>
              </div>
              <p className="text-sm text-slate-500 bg-amber-50 border border-amber-100 rounded-lg px-4 py-3">
                <strong className="text-amber-700">Exception:</strong> American Gold Eagle coins are allowed despite being only 91.67% pure — the IRS made a specific statutory exception for these coins.
              </p>

              <h3 className="text-lg font-semibold text-slate-800 mb-3 mt-6">Storage Rules</h3>
              <p className="text-base text-slate-700 leading-relaxed">
                Physical metals in a Gold IRA must be stored at an <strong>IRS-approved depository</strong>, not at home, in a personal safe, or in a bank safe deposit box. Approved depositories include Brinks, Delaware Depository, and IDS of Delaware. Storing metals at home is treated as a taxable distribution.
              </p>
            </section>

            {/* Fees */}
            <section aria-labelledby="fee-structure">
              <h2 id="fee-structure" className="text-2xl font-bold text-slate-900 mb-4 pb-2 border-b border-slate-100">
                Gold IRA Fee Structure
              </h2>
              <p className="text-base text-slate-700 leading-relaxed mb-5">
                Gold IRAs carry fees that conventional IRAs do not. Understanding the full fee picture is essential before opening an account.
              </p>
              <div className="overflow-x-auto rounded-xl border border-slate-200 shadow-sm">
                <table className="w-full text-sm" role="table" aria-label="Gold IRA fee structure">
                  <thead>
                    <tr className="bg-slate-800 text-white">
                      <th scope="col" className="text-left py-3 px-4 font-semibold rounded-tl-xl">Fee Type</th>
                      <th scope="col" className="text-left py-3 px-4 font-semibold">Typical Range</th>
                      <th scope="col" className="text-left py-3 px-4 font-semibold rounded-tr-xl">Notes</th>
                    </tr>
                  </thead>
                  <tbody>
                    <tr className="border-b border-slate-100 hover:bg-slate-50 transition-colors">
                      <td className="py-3 px-4 font-medium text-slate-800">Account setup</td>
                      <td className="py-3 px-4 text-slate-600">$50–$150 (one-time)</td>
                      <td className="py-3 px-4 text-slate-500">Often waived by larger providers</td>
                    </tr>
                    <tr className="border-b border-slate-100 hover:bg-slate-50 transition-colors">
                      <td className="py-3 px-4 font-medium text-slate-800">Annual custodian fee</td>
                      <td className="py-3 px-4 text-slate-600">$75–$300/year</td>
                      <td className="py-3 px-4 text-slate-500">Covers account administration</td>
                    </tr>
                    <tr className="border-b border-slate-100 hover:bg-slate-50 transition-colors">
                      <td className="py-3 px-4 font-medium text-slate-800">Storage fee (commingled)</td>
                      <td className="py-3 px-4 text-slate-600">$100–$150/year</td>
                      <td className="py-3 px-4 text-slate-500">Metals stored with other clients' metals</td>
                    </tr>
                    <tr className="border-b border-slate-100 hover:bg-slate-50 transition-colors">
                      <td className="py-3 px-4 font-medium text-slate-800">Storage fee (segregated)</td>
                      <td className="py-3 px-4 text-slate-600">$150–$300/year</td>
                      <td className="py-3 px-4 text-slate-500">Your metals stored separately</td>
                    </tr>
                    <tr className="hover:bg-slate-50 transition-colors">
                      <td className="py-3 px-4 font-medium text-slate-800">Dealer spread</td>
                      <td className="py-3 px-4 text-amber-600 font-medium">2–10% over spot</td>
                      <td className="py-3 px-4 text-slate-500">The markup on metal purchases</td>
                    </tr>
                  </tbody>
                </table>
              </div>
            </section>

            {/* How to evaluate */}
            <section aria-labelledby="how-to-evaluate">
              <h2 id="how-to-evaluate" className="text-2xl font-bold text-slate-900 mb-4 pb-2 border-b border-slate-100">
                How to Evaluate a Gold IRA Provider
              </h2>
              <p className="text-base text-slate-700 leading-relaxed mb-5">
                When comparing Gold IRA custodians, the following factors matter most:
              </p>
              <ul className="space-y-3" role="list">
                {[
                  { title: 'Fee transparency', desc: 'All fees should be disclosed upfront in writing. Avoid providers who are vague about storage or custodian fees.' },
                  { title: 'Custodian independence', desc: 'The custodian (who holds the account) should be separate from the dealer (who sells the metals). Some providers bundle both, which creates a conflict of interest.' },
                  { title: 'Depository options', desc: 'Confirm which depositories are available and whether segregated storage is offered.' },
                  { title: 'IRS compliance history', desc: 'Look for providers with a clean regulatory record and no FINRA or SEC enforcement actions.' },
                  { title: 'Buyback policy', desc: 'Understand the terms under which the provider will repurchase your metals when you want to liquidate.' },
                  { title: 'Minimum investment', desc: 'Most reputable providers require $10,000–$50,000 minimum. Be cautious of providers with no minimums, as they may compensate with higher spreads.' },
                ].map((item) => (
                  <li key={item.title} className="flex gap-3 p-4 bg-amber-50 border border-amber-100 rounded-lg">
                    <span className="flex-shrink-0 w-5 h-5 mt-0.5 text-amber-500" aria-hidden="true">
                      <svg viewBox="0 0 20 20" fill="currentColor">
                        <path fillRule="evenodd" d="M10 18a8 8 0 100-16 8 8 0 000 16zm3.707-9.293a1 1 0 00-1.414-1.414L9 10.586 7.707 9.293a1 1 0 00-1.414 1.414l2 2a1 1 0 001.414 0l4-4z" clipRule="evenodd" />
                      </svg>
                    </span>
                    <div>
                      <span className="font-semibold text-slate-800">{item.title}</span>
                      <span className="text-slate-600"> — {item.desc}</span>
                    </div>
                  </li>
                ))}
              </ul>
            </section>

            {/* CTA — internal only, no affiliate links */}
            <div
              className="rounded-xl p-6 lg:p-8 text-white"
              style={{
                backgroundImage: 'url(/assets/gold-hero-bg.jpg)',
                backgroundSize: 'cover',
                backgroundPosition: 'center',
              }}
            >
              <div className="relative">
                <div className="absolute inset-0 -m-6 lg:-m-8 rounded-xl bg-amber-950/80" aria-hidden="true" />
                <div className="relative">
                  <h3 className="text-xl font-bold text-white mb-3">Ready to Compare Gold IRA Providers?</h3>
                  <p className="text-slate-300 text-base leading-relaxed mb-5">
                    Our research team has independently evaluated the leading Gold IRA custodians on fees, storage options, IRS compliance, and customer service. Genesis Gold Group ranks #1 for 2026. No affiliate commissions influence our rankings.
                  </p>
                  <Link
                    to="/precious-metals-ira/best-companies"
                    className="inline-flex items-center gap-2 bg-amber-500 hover:bg-amber-400 text-white font-semibold px-6 py-3 rounded-lg transition-colors duration-200 focus:outline-none focus:ring-2 focus:ring-amber-400 focus:ring-offset-2 focus:ring-offset-amber-950"
                    aria-label="View our independent Gold IRA provider rankings"
                  >
                    View Gold IRA Provider Rankings
                    <svg className="w-4 h-4" fill="none" viewBox="0 0 24 24" stroke="currentColor" aria-hidden="true">
                      <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M17 8l4 4m0 0l-4 4m4-4H3" />
                    </svg>
                  </Link>
                </div>
              </div>
            </div>

            {/* FAQ */}
            <section aria-labelledby="faq-heading-gold">
              <h2 id="faq-heading-gold" className="text-2xl font-bold text-slate-900 mb-6 pb-2 border-b border-slate-100">
                Frequently Asked Questions
              </h2>
              <div className="space-y-4">
                {[
                  {
                    q: 'Is a Gold IRA a good investment?',
                    a: 'Gold IRAs can serve as a hedge against inflation and currency devaluation. Gold has historically maintained purchasing power over long periods. However, gold produces no income (no dividends or interest), and storage and custodian fees reduce net returns. Most financial advisors suggest limiting precious metals to 5–15% of a retirement portfolio, not using them as a primary retirement vehicle.'
                  },
                  {
                    q: 'Can I store Gold IRA metals at home?',
                    a: 'No. IRS rules require physical metals held in a Gold IRA to be stored at an IRS-approved depository. Storing metals at home is treated as a taxable distribution, triggering income tax and a 10% early withdrawal penalty if you are under age 59½. This rule has been consistently upheld in Tax Court.'
                  },
                  {
                    q: 'What happens to my Gold IRA when I retire?',
                    a: 'When you reach retirement age (59½ or older), you can take distributions from your Gold IRA in two ways: (1) In-kind distribution — the physical metals are shipped to you; (2) Cash distribution — the custodian sells the metals and sends you the proceeds. Required Minimum Distributions (RMDs) begin at age 73 for Traditional Gold IRAs, the same as conventional IRAs.'
                  },
                  {
                    q: 'Can I roll over my 401(k) to a Gold IRA?',
                    a: <>
                      Yes. A direct rollover from a 401(k) to a Gold IRA is tax-free and penalty-free under IRS rules, provided the funds go directly from your 401(k) custodian to your Gold IRA custodian. See our{' '}
                      <Link to="/precious-metals-ira/401k-to-gold-ira-rollover" className="text-amber-600 hover:text-amber-700 hover:underline font-medium">
                        401(k) to Gold IRA Rollover Guide
                      </Link>{' '}
                      for the step-by-step process.
                    </>
                  },
                ].map((item, i) => (
                  <details key={i} className="group border border-slate-200 rounded-xl overflow-hidden">
                    <summary className="flex items-center justify-between gap-4 px-5 py-4 cursor-pointer bg-white hover:bg-slate-50 transition-colors list-none select-none">
                      <span className="font-semibold text-slate-800 text-base leading-snug">{item.q}</span>
                      <span className="flex-shrink-0 w-5 h-5 text-amber-500 transition-transform duration-200 group-open:rotate-180" aria-hidden="true">
                        <svg viewBox="0 0 20 20" fill="currentColor">
                          <path fillRule="evenodd" d="M5.293 7.293a1 1 0 011.414 0L10 10.586l3.293-3.293a1 1 0 111.414 1.414l-4 4a1 1 0 01-1.414 0l-4-4a1 1 0 010-1.414z" clipRule="evenodd" />
                        </svg>
                      </span>
                    </summary>
                    <div className="px-5 pb-5 pt-2 text-slate-600 text-base leading-relaxed bg-white border-t border-slate-100">
                      {item.a}
                    </div>
                  </details>
                ))}
              </div>
            </section>

            {/* Disclaimer */}
            <div
              className="bg-slate-50 border border-slate-200 rounded-xl p-5 text-sm text-slate-500"
              role="note"
              aria-label="Educational disclaimer"
            >
              <strong className="text-slate-700">Educational Disclaimer:</strong> This article is for informational purposes only and does not constitute investment, tax, or legal advice. Gold IRA investments involve risk, including the possible loss of principal. Past performance of gold prices does not guarantee future results. Consult a qualified financial advisor before making investment decisions. IRA Research Hub is not a registered investment advisor.
            </div>

          </article>

        </div>
      </div>
      {/* ── Newsletter Signup ─────────────────────────────────────────── */}
      <div className="container-site py-10 max-w-3xl">
        
        {/* Related Links */}

        <div className="mt-10 mb-6">

          <RelatedLinks variant="metals-guide" title="Related Guides &amp; Reviews" />

        </div>
<NewsletterSignup />
      </div>
    </>
  )
}
