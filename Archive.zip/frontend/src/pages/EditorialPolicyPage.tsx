import { Link } from 'react-router-dom'
import SEO from '../components/SEO'
import NewsletterSignup from '../components/NewsletterSignup';

const editorialSchema = {
  "@context": "https://schema.org",
  "@graph": [
    {
      "@type": "WebPage",
      "@id": "https://iraresearchhub.com/editorial-policy",
      "name": "Editorial Policy — IRA Research Hub",
      "url": "https://iraresearchhub.com/editorial-policy",
      "datePublished": "2026-01-01",
      "dateModified": "2026-03-20",
      "description": "IRA Research Hub's editorial independence policy, conflict-of-interest disclosures, scoring methodology, and correction procedures.",
      "publisher": { "@id": "https://iraresearchhub.com/#organization" },
      "about": { "@id": "https://iraresearchhub.com/#organization" }
    },
    {
      "@type": "Organization",
      "@id": "https://iraresearchhub.com/#organization",
      "name": "IRA Research Hub",
      "url": "https://iraresearchhub.com",
      "description": "Independent research platform comparing cryptocurrency and precious metals IRA providers across fees, security, compliance, and customer service.",
      "foundingDate": "2022",
      "sameAs": [
        "https://iraresearchhub.com/about",
        "https://iraresearchhub.com/methodology"
      ],
      "contactPoint": {
        "@type": "ContactPoint",
        "contactType": "editorial",
        "email": "editorial@iraresearchhub.com"
      },
      "publishingPrinciples": "https://iraresearchhub.com/editorial-policy"
    }
  ]
}

export default function EditorialPolicyPage() {
  return (
    <>
      <SEO
        title="Editorial Policy — IRA Research Hub"
        description="IRA Research Hub's editorial independence policy, conflict-of-interest disclosures, scoring methodology, and correction procedures."
        canonical="/editorial-policy"
        ogType="article"
      />
      <script
        type="application/ld+json"
        dangerouslySetInnerHTML={{ __html: JSON.stringify(editorialSchema) }}
      />

      <div className="section-padding">
        <div className="container-site max-w-3xl">

          {/* Hero */}
          <div className="mb-10">
            <div className="badge-sky mb-4">Transparency & Independence</div>
            <h1 className="text-4xl font-bold text-[#0F172A] mb-4">Editorial Policy</h1>
            <p className="text-lg text-[#64748B] leading-relaxed">
              IRA Research Hub is committed to providing independent, unbiased research on
              self-directed IRA providers. This page explains how we produce our content,
              how we earn revenue, and how we handle corrections and conflicts of interest.
            </p>
            <p className="text-sm text-slate-400 mt-3">
              Last updated: March 20, 2026 ·{' '}
              <Link to="/methodology" className="text-[#0EA5E9] hover:underline">
                View scoring methodology
              </Link>
            </p>
          </div>

          {/* Editorial Independence */}
          <section className="mb-10">
            <h2 className="text-2xl font-bold text-[#0F172A] mb-4">Editorial Independence</h2>
            <div className="card border-l-4 border-l-[#0EA5E9] mb-5">
              <p className="text-[#334155] leading-relaxed">
                <strong>Our rankings and reviews are never for sale.</strong> No provider can pay
                to improve their score, alter their ranking, or influence the content of their
                review. Affiliate relationships do not affect editorial decisions.
              </p>
            </div>
            <p className="text-[#64748B] leading-relaxed mb-4">
              All provider scores are calculated algorithmically from verified data points using
              our published six-criteria methodology. Score changes occur only when underlying
              data changes — not in response to commercial relationships.
            </p>
            <p className="text-[#64748B] leading-relaxed">
              Our editorial team operates independently from our business development function.
              No member of the editorial team is compensated based on affiliate revenue generated
              by any specific provider.
            </p>
          </section>

          {/* How We Make Money */}
          <section className="mb-10">
            <h2 className="text-2xl font-bold text-[#0F172A] mb-4">How We Make Money</h2>
            <p className="text-[#64748B] leading-relaxed mb-4">
              IRA Research Hub earns revenue through affiliate marketing. When a reader clicks
              a "Visit Provider" or "Get Started" link and opens an account, we may receive a
              referral fee from the provider. This fee does not change the cost to the reader
              in any way.
            </p>
            <div className="bg-amber-50 border border-amber-200 rounded-xl p-5 mb-4">
              <p className="text-sm text-amber-800 font-medium mb-1">Affiliate Disclosure</p>
              <p className="text-sm text-amber-700">
                This site contains affiliate links. We may receive compensation when you click
                links to partner providers. This compensation does not influence our editorial
                content, rankings, or reviews. We only recommend providers we have independently
                evaluated and believe offer genuine value to investors.
              </p>
            </div>
            <p className="text-[#64748B] leading-relaxed">
              We have affiliate relationships with some, but not all, of the providers we review.
              Providers without affiliate relationships are reviewed and ranked using the same
              methodology as those with affiliate relationships.
            </p>
          </section>

          {/* Scoring Methodology Summary */}
          <section className="mb-10">
            <h2 className="text-2xl font-bold text-[#0F172A] mb-4">How We Score Providers</h2>
            <p className="text-[#64748B] leading-relaxed mb-5">
              Every provider is scored on a 1–10 scale across six weighted criteria. Scores are
              calculated from verified data collected through direct provider research, regulatory
              filings, customer service testing, and fee schedule analysis.
            </p>
            <div className="overflow-x-auto">
              <table className="w-full text-sm border-collapse">
                <thead>
                  <tr className="bg-slate-50 border-b border-slate-200">
                    <th className="text-left py-3 px-4 font-semibold text-[#0F172A]">Criterion</th>
                    <th className="text-left py-3 px-4 font-semibold text-[#0F172A]">Weight</th>
                    <th className="text-left py-3 px-4 font-semibold text-[#0F172A]">What We Measure</th>
                  </tr>
                </thead>
                <tbody>
                  {[
                    { criterion: "Fee Transparency", weight: "20%", measures: "Setup fees, annual fees, trading fees, hidden charges, fee disclosure quality" },
                    { criterion: "Asset Selection", weight: "20%", measures: "Number of supported assets, IRS-approved metals/coins, asset diversity" },
                    { criterion: "Security & Custody", weight: "20%", measures: "Custodian quality, storage type, insurance coverage, audit history" },
                    { criterion: "IRS Compliance", weight: "15%", measures: "IRS-approved custodian, eligible assets, proper reporting, regulatory standing" },
                    { criterion: "Customer Support", weight: "15%", measures: "Response time, support channels, specialist availability, complaint resolution" },
                    { criterion: "Reputation", weight: "10%", measures: "BBB rating, complaint history, years in business, industry recognition" },
                  ].map((row) => (
                    <tr key={row.criterion} className="border-b border-slate-100 hover:bg-slate-50">
                      <td className="py-3 px-4 font-medium text-[#0F172A]">{row.criterion}</td>
                      <td className="py-3 px-4 text-[#0EA5E9] font-semibold">{row.weight}</td>
                      <td className="py-3 px-4 text-[#64748B]">{row.measures}</td>
                    </tr>
                  ))}
                </tbody>
              </table>
            </div>
            <p className="text-sm text-slate-400 mt-3">
              <Link to="/methodology" className="text-[#0EA5E9] hover:underline">
                Read the full scoring methodology →
              </Link>
            </p>
          </section>

          {/* Data Sources */}
          <section className="mb-10">
            <h2 className="text-2xl font-bold text-[#0F172A] mb-4">Data Sources & Verification</h2>
            <p className="text-[#64748B] leading-relaxed mb-4">
              Provider data is collected from the following primary sources:
            </p>
            <ul className="space-y-2 text-[#64748B] text-sm pl-5 list-disc">
              <li>Direct provider websites and published fee schedules</li>
              <li>IRS Publication 590-A (Contributions to Individual Retirement Arrangements)</li>
              <li>Better Business Bureau (BBB) ratings and complaint data</li>
              <li>FINRA BrokerCheck and SEC EDGAR filings where applicable</li>
              <li>Direct customer service testing (anonymous inquiries)</li>
              <li>Third-party custody and insurance documentation</li>
              <li>User-submitted reviews (verified, not anonymous)</li>
            </ul>
            <p className="text-[#64748B] leading-relaxed mt-4">
              Data is reviewed and updated quarterly, or immediately upon notification of a
              material change (fee increase, regulatory action, ownership change, etc.).
            </p>
          </section>

          {/* YMYL Disclaimer */}
          <section className="mb-10">
            <h2 className="text-2xl font-bold text-[#0F172A] mb-4">Investment Risk Disclaimer</h2>
            <div className="bg-red-50 border border-red-200 rounded-xl p-5">
              <p className="text-sm text-red-800 font-medium mb-2">Important: Not Financial Advice</p>
              <p className="text-sm text-red-700 leading-relaxed">
                All content on IRA Research Hub is for informational and educational purposes only.
                Nothing on this site constitutes financial, investment, legal, or tax advice.
                Self-directed IRAs — including cryptocurrency IRAs and precious metals IRAs — carry
                significant risks including market volatility, liquidity risk, regulatory risk, and
                the risk of total loss. Past performance is not indicative of future results.
                Always consult a licensed financial advisor, tax professional, or attorney before
                making investment decisions.
              </p>
            </div>
          </section>

          {/* Corrections Policy */}
          <section className="mb-10">
            <h2 className="text-2xl font-bold text-[#0F172A] mb-4">Corrections Policy</h2>
            <p className="text-[#64748B] leading-relaxed mb-4">
              We are committed to accuracy. If you identify a factual error in any of our content,
              please contact us at{' '}
              <a href="mailto:editorial@iraresearchhub.com" className="text-[#0EA5E9] hover:underline">
                editorial@iraresearchhub.com
              </a>
              . We will investigate and, if warranted, issue a correction within 48 hours.
            </p>
            <p className="text-[#64748B] leading-relaxed">
              Material corrections are noted inline in the affected article with a correction notice
              including the date of the correction and a description of what was changed.
            </p>
          </section>

          {/* Related Links */}
          <div className="mt-10 p-6 bg-[#F0F9FF] rounded-xl border border-[#BAE6FD]">
            <h3 className="font-semibold text-[#0F172A] mb-4">Related Pages</h3>
            <div className="grid md:grid-cols-3 gap-4">
              <Link to="/methodology" className="block p-4 bg-white rounded-lg border border-[#BAE6FD] hover:border-[#0EA5E9] transition-colors">
                <div className="text-sm font-semibold text-[#0F172A] mb-1">Scoring Methodology</div>
                <div className="text-xs text-[#64748B]">Full details on our 6-criteria scoring system</div>
              </Link>
              <Link to="/about" className="block p-4 bg-white rounded-lg border border-[#BAE6FD] hover:border-[#0EA5E9] transition-colors">
                <div className="text-sm font-semibold text-[#0F172A] mb-1">About Us</div>
                <div className="text-xs text-[#64748B]">Our mission, team, and research approach</div>
              </Link>
              <Link to="/privacy" className="block p-4 bg-white rounded-lg border border-[#BAE6FD] hover:border-[#0EA5E9] transition-colors">
                <div className="text-sm font-semibold text-[#0F172A] mb-1">Privacy Policy</div>
                <div className="text-xs text-[#64748B]">How we collect and use your data</div>
              </Link>
            </div>
          </div>

        </div>
      </div>
      {/* ── Newsletter Signup ─────────────────────────────────────────── */}
      <div className="container-site py-10 max-w-3xl">
        <NewsletterSignup />
      </div>
    </>
  )
}
