import StateGuideTemplate from '../components/StateGuideTemplate'

export default function BestCryptoIRAHIPage() {
  return (
    <StateGuideTemplate
      stateName="Hawaii"
      stateAbbr="HI"
      slug="hawaii"
    />
  )
}
