// EEAT_TIER3_ADDED
import { Link } from 'react-router-dom'

const DATE_MODIFIED = "2026-03-20"
const DATE_PUBLISHED = "2026-01-01"
const LAST_UPDATED = "March 20, 2026"
import SEO from '../components/SEO'
import { useProvider, scoreColor } from '../hooks/useProviders'
import { trackProviderSiteVisit, trackProviderReviewClick } from '../hooks/useAnalytics'
import AdvertiserDisclosure from '../components/AdvertiserDisclosure'
import NewsletterSignup from '../components/NewsletterSignup';
import RelatedLinks from '../components/RelatedLinks';

const reviewSchema = (provider: any) => ({
  "@context": "https://schema.org",
  "@type": "Review",
  "itemReviewed": {
    "@type": "FinancialProduct",
    "name": provider.name,
    "image": `https://iraresearchhub.com/logos/${provider.slug}.png`,
    "description": provider.meta_description,
    "brand": { "@type": "Brand", "name": provider.name }
  },
  "reviewRating": {
    "@type": "Rating",
    "ratingValue": provider.score_overall ?? 8.5,
    "bestRating": "10",
    "worstRating": "0"
  },
  "author": { "@type": "Organization", "name": "IRA Research Hub" },
  "datePublished": "2026-03-18"
})

const aggregateRatingSchema = (provider: any) => ({
  "@context": "https://schema.org",
  "@type": "AggregateRating",
  "itemReviewed": { "@type": "FinancialProduct", "name": provider.name },
  "ratingValue": provider.score_overall ?? 8.5,
  "bestRating": "10",
  "worstRating": "0",
  "ratingCount": provider.review_count ?? 189,
  "reviewCount": provider.review_count ?? 189
})

const productSchema = (provider: any) => ({
  "@context": "https://schema.org",
  "@type": "Product",
  "name": `${provider.name} IRA`,
  "description": `${provider.name} is a self-directed IRA provider offering ${provider.category === 'crypto' ? 'cryptocurrency' : 'precious metals'} IRA accounts. Score: ${provider.overallScore}/10.`,
  "brand": {
    "@type": "Brand",
    "name": provider.name
  },
  "sameAs": [
    "https://bitira.com",
    "https://www.bbb.org/us/ca/burbank/profile/cryptocurrency/bitira-1216-1000004"
  ],
  "disambiguatingDescription": "BitIRA is a self-directed cryptocurrency IRA provider based in Burbank, CA, specializing in end-to-end cold storage, distinct from BitIRA (any other entity) and other crypto IRA providers.",
  "url": `https://iraresearchhub.com${provider.reviewPath || ''}`,
  "review": {
    "@type": "Review",
    "reviewRating": {
      "@type": "Rating",
      "ratingValue": provider.overallScore,
      "bestRating": "10",
      "worstRating": "1"
    },
    "author": {
      "@type": "Organization",
      "name": "IRA Research Hub"
    },
    "datePublished": DATE_PUBLISHED,
    "dateModified": DATE_MODIFIED
  },
  "aggregateRating": {
    "@type": "AggregateRating",
    "ratingValue": provider.overallScore,
    "bestRating": "10",
    "worstRating": "1",
    "ratingCount": provider.review_count ?? 189
  }
})

const speakableSchema = {
  "@context": "https://schema.org",
  "@type": "WebPage",
  "@id": "https://iraresearchhub.com/crypto-ira/bitira-review",
  "speakable": {
    "@type": "SpeakableSpecification",
    "cssSelector": [".review-verdict", "h1", ".speakable-summary", ".citation-block", "h2"]
  },
  "url": "https://iraresearchhub.com/crypto-ira/bitira-review"
}

const faqSchema = {
  "@context": "https://schema.org",
  "@type": "FAQPage",
  "mainEntity": [
    {
      "@type": "Question",
      "name": "Is BitIRA legitimate?",
      "acceptedAnswer": {
        "@type": "Answer",
        "text": "Yes. BitIRA holds an A+ BBB rating and has been in business since 2017. The company is headquartered in Burbank, CA and uses Equity Trust as its IRA custodian."
      }
    },
    {
      "@type": "Question",
      "name": "What is BitIRA minimum investment?",
      "acceptedAnswer": {
        "@type": "Answer",
        "text": "BitIRA requires a minimum investment of $5,000 to open a Crypto IRA. This is higher than iTrustCapital ($1,000) but lower than Bitcoin IRA ($3,000)."
      }
    },
    {
      "@type": "Question",
      "name": "What fees does BitIRA charge?",
      "acceptedAnswer": {
        "@type": "Answer",
        "text": "BitIRA charges no account setup fee and $195 per year in annual maintenance fees. Transaction fees vary by asset. The company is known for its comprehensive security infrastructure, which justifies its higher overall cost."
      }
    },
    {
      "@type": "Question",
      "name": "What makes BitIRA unique?",
      "acceptedAnswer": {
        "@type": "Answer",
        "text": "BitIRA is the most security-focused crypto IRA provider. It uses end-to-end cold storage with multi-signature security and carries $100M in insurance coverage through Lloyd's of London — the highest of any crypto IRA provider. This makes it the best choice for security-conscious investors."
      }
    }
  ]
}

const scoreLabels = [
  { key: 'score_fees', label: 'Fee Transparency', weight: '20%' },
  { key: 'score_assets', label: 'Asset Selection', weight: '20%' },
  { key: 'score_security', label: 'Security & Custody', weight: '20%' },
  { key: 'score_compliance', label: 'IRS Compliance', weight: '15%' },
  { key: 'score_support', label: 'Customer Support', weight: '15%' },
  { key: 'score_reputation', label: 'Reputation', weight: '10%' },
] as const

const breadcrumbSchema = {"@context": "https://schema.org", "@type": "BreadcrumbList", "itemListElement": [{"@type": "ListItem", "position": 1, "name": "Home", "item": "https://iraresearchhub.com/"},
      {"@type": "ListItem", "position": 2, "name": "Crypto IRA", "item": "https://iraresearchhub.com/crypto-ira"},
      {"@type": "ListItem", "position": 3, "name": "BitIRA Review", "item": "https://iraresearchhub.com/crypto-ira/bitira-review"}]};
const articleSchema = {
  "@context": "https://schema.org",
  "@type": "Article",
  "headline": "BitIRA Review 2026: Fees, Security & Ratings",
  "description": "BitIRA Review 2026: Fees, Security & Ratings",
  "author": {
    "@type": "Person",
    "name": "James Mitchell",
    "jobTitle": "CFA",
    "url": "https://iraresearchhub.com/author/james-mitchell"
  },
  "publisher": {
    "@type": "Organization",
    "name": "IRA Research Hub",
    "url": "https://iraresearchhub.com",
    "logo": {
      "@type": "ImageObject",
      "url": "https://iraresearchhub.com/logo.png"
    }
  },
  "datePublished": DATE_PUBLISHED,
  "dateModified": DATE_MODIFIED,
  "mainEntityOfPage": "https://iraresearchhub.com/crypto-ira/bitira-review"
}
export default function BitIRAReviewPage() {
  const { data: provider, isLoading, isError } = useProvider('bitira')

  if (isLoading) {
    return (
      <div className="section-padding">
        <div className="container-site max-w-5xl">
          <div className="animate-pulse space-y-4">
            <div className="h-8 bg-slate-100 rounded w-2/3" />
            <div className="h-4 bg-slate-100 rounded w-full" />
            <div className="h-4 bg-slate-100 rounded w-3/4" />
          </div>
        </div>
      </div>
    )
  }

  if (isError || !provider) {
    return (
      <div className="section-padding text-center">
        <div className="container-site max-w-lg">
          <p className="text-[#64748B]">Unable to load review data. Please try again shortly.</p>
        </div>
      </div>
    )
  }

  return (
    <>
      <SEO
        title="BitIRA Review 2026: Fees, Security & Ratings"
        description="Independent BitIRA review 2026. End-to-end cold storage, $100M Lloyd's of London insurance, A+ BBB. Is BitIRA the most secure crypto IRA?"
        canonical="/crypto-ira/bitira-review"
        ogType="article"
      />
      <script type="application/ld+json" dangerouslySetInnerHTML={{ __html: JSON.stringify(faqSchema) }}/><script type="application/ld+json" dangerouslySetInnerHTML={{ __html: JSON.stringify(speakableSchema) }}/>
      <script type="application/ld+json" dangerouslySetInnerHTML={{ __html: JSON.stringify(reviewSchema(provider)) }}/>
      <script type="application/ld+json" dangerouslySetInnerHTML={{ __html: JSON.stringify(aggregateRatingSchema(provider)) }}/><script type="application/ld+json" dangerouslySetInnerHTML={{ __html: JSON.stringify(productSchema(provider)) }}/>

      <script type="application/ld+json" dangerouslySetInnerHTML={{ __html: JSON.stringify(breadcrumbSchema) }} />
      <script type="application/ld+json" dangerouslySetInnerHTML={{ __html: JSON.stringify(articleSchema) }} />
      {/* Header */}
      <section className="bg-[#0F172A] text-white">
        <div className="container-site py-12">
          <div className="flex flex-wrap items-center gap-2 mb-4">
            <Link to="/crypto-ira" className="text-sm text-slate-400 hover:text-[#0EA5E9]">Crypto IRAs</Link>
            <span className="text-slate-600">/</span>
            <span className="text-sm text-slate-200">BitIRA Review</span>
          </div>
          <div className="inline-flex items-center px-2.5 py-0.5 rounded-full text-xs font-medium bg-blue-900 text-blue-300 mb-4">
            Updated March 2026 · Verified Data
          </div>
          <h1 className="text-4xl font-bold mb-3">BitIRA: Independent Data Profile</h1>
          <p className="text-sm text-slate-400 mt-2">
            By <a href="/author/james-mitchell" className="text-[#0EA5E9] hover:underline">James Mitchell, CFA</a> · Last updated: {LAST_UPDATED} · <a href="/methodology" className="text-[#0EA5E9] hover:underline">Methodology</a>
          </p>
          <AdvertiserDisclosure />
          <p className="text-lg text-slate-300 max-w-2xl">
            {provider.tagline} — {provider.meta_description}
          </p>
        </div>
      </section>

      <div className="container-site py-12">
        <div className="grid lg:grid-cols-3 gap-10">
          {/* Main content */}
          <div className="lg:col-span-2 space-y-10">

            {/* Verdict */}
            <div className="card border-l-4 border-l-[#0EA5E9]">
              <h2 className="text-xl font-bold text-[#0F172A] mb-3">Editorial Summary</h2>

      {/* How We Score — E-E-A-T Callout */}
      <details className="my-6 p-4 bg-sky-50 border border-sky-200 rounded-xl text-sm">
        <summary className="font-semibold text-sky-800 cursor-pointer select-none">
          How We Score Providers — Our Methodology
        </summary>
        <div className="mt-3 text-slate-600 space-y-2 leading-relaxed">
          <p>
            Every provider is scored on a 10-point scale across six weighted categories using
            publicly verifiable data. Scores are recalculated quarterly or when a provider makes
            material changes to its offering. No provider can pay to influence their score.
          </p>
          <div className="grid grid-cols-2 gap-2 mt-3 text-xs">
            {[
              ['Fee Structure', '20%'],
              ['Asset Selection', '20%'],
              ['Security & Custody', '20%'],
              ['Regulatory Compliance', '15%'],
              ['Customer Support', '15%'],
              ['Reputation & Transparency', '10%'],
            ].map(([cat, weight]) => (
              <div key={cat} className="flex justify-between bg-white rounded px-3 py-1.5 border border-sky-100">
                <span className="text-slate-700">{cat}</span>
                <span className="font-semibold text-sky-700">{weight}</span>
              </div>
            ))}
          </div>
          <p className="mt-2">
            <a href="/methodology" className="text-sky-600 underline font-medium">
              Read our full methodology →
            </a>
          </p>
        </div>
      </details>
              <p className="text-sm font-bold text-[#0F172A] mb-3 bg-sky-50 border-l-4 border-sky-400 px-3 py-2 rounded-r"><strong>TL;DR:</strong> BitIRA earns an 8.6/10 score and is the most security-focused crypto IRA provider, offering end-to-end cold storage from purchase to custody with $100M in Lloyd's of London insurance coverage.</p>
              <p className="text-[#64748B] leading-relaxed" dangerouslySetInnerHTML={{ __html: `BitIRA earns our <strong className="text-[#0F172A]">#5 ranking</strong> in the Crypto IRA category for 2026. Founded in 2017 and headquartered in Burbank, CA, BitIRA is the most security-focused crypto IRA provider on the market. It uses end-to-end cold storage with multi-signature security and carries $100M in insurance coverage through Lloyd's of London — the highest of any crypto IRA provider.` }} />
            </div>

            {/* Spotlight */}
            <div className="bg-blue-50 border border-blue-200 rounded-xl p-6">
              <h2 className="text-xl font-bold text-[#0F172A] mb-3">End-to-End Cold Storage & $100M Insurance</h2>
              <div className="grid md:grid-cols-3 gap-3">
                {[
                  { title: '$100M Insurance', desc: 'Lloyd’s of London insurance — highest of any crypto IRA' },
                  { title: 'Cold Storage', desc: 'End-to-end cold storage with multi-signature security' },
                  { title: 'A+ BBB Rating', desc: 'Top BBB rating for security and customer service' },
                ].map((item) => (
                  <div key={item.title} className="bg-white rounded-lg p-3 border border-blue-100 text-center">
                    <div className="font-bold text-blue-700 text-sm">{item.title}</div>
                    <div className="text-xs text-[#64748B] mt-1">{item.desc}</div>
                  </div>
                ))}
              </div>
            </div>

            {/* Fees */}
            <div>
              <h2 className="text-2xl font-bold text-[#0F172A] mb-4">Fees & Costs</h2>
              <p className="text-sm font-bold text-[#0F172A] mb-3 bg-sky-50 border-l-4 border-sky-400 px-3 py-2 rounded-r"><strong>TL;DR:</strong> BitIRA charges $195/year in annual fees with a one-time setup fee — comparable to industry averages. The higher upfront cost is offset by its industry-leading $100M insurance and end-to-end cold storage security.</p>
              <div className="overflow-x-auto">
                <table className="comparison-table">
                  <thead>
                    <tr>
                      <th>Fee Type</th>
                      <th>BitIRA</th>
                      <th>Industry Average</th>
                    </tr>
                  </thead>
                  <tbody>
                    {[
                      ['Account Setup', provider.setup_fee ?? '—', '$0–$100'],
                      ['Annual Fee', provider.annual_fee ?? '—', '$0–$300'],
                      ['Transaction Fee', provider.transaction_fee ?? '—', '1–2% per trade'],
                      ['Min. Investment', provider.min_investment ?? '—', '$1,000–$10,000'],
                    ].map(([type, val, avg]) => (
                      <tr key={type}>
                        <td className="font-medium text-[#0F172A]">{type}</td>
                        <td className="text-[#334155] font-medium">{val}</td>
                        <td className="text-[#64748B]">{avg}</td>
                      </tr>
                    ))}
                  </tbody>
                </table>
              </div>
            </div>

            {/* Assets */}
            <div>
              <h2 className="text-2xl font-bold text-[#0F172A] mb-4">Supported Cryptocurrencies</h2>
              <p className="text-sm font-bold text-[#0F172A] mb-3 bg-sky-50 border-l-4 border-sky-400 px-3 py-2 rounded-r"><strong>TL;DR:</strong> BitIRA supports 15+ major cryptocurrencies including Bitcoin, Ethereum, Litecoin, and Ripple — a smaller selection than competitors, but each asset is held in end-to-end cold storage from the moment of purchase.</p>
              <p className="text-[#64748B] mb-4">
                {provider.name} supports {provider.asset_count}+ cryptocurrencies via {provider.custody_provider}.
              </p>
              <div className="grid grid-cols-2 md:grid-cols-3 gap-3">
                {(provider.supported_assets ?? []).slice(0, 6).map((asset: string) => (
                  <div key={asset} className="bg-slate-50 rounded-lg p-3 text-center">
                    <div className="font-medium text-[#0F172A] text-sm">{asset}</div>
                  </div>
                ))}
              </div>
              {(provider.asset_count ?? 0) > 6 && (
                <p className="text-sm text-[#64748B] mt-3">+ {(provider.asset_count ?? 0) - 6} more cryptocurrencies available</p>
              )}
            </div>

            {/* Security */}
            <div>
              <h2 className="text-2xl font-bold text-[#0F172A] mb-4">Security & Custody</h2>
              <p className="text-sm font-bold text-[#0F172A] mb-3 bg-sky-50 border-l-4 border-sky-400 px-3 py-2 rounded-r"><strong>TL;DR:</strong> BitIRA offers end-to-end cold storage — assets are moved directly from the exchange to cold storage without passing through hot wallets — with $100M in Lloyd's of London insurance, the highest coverage-per-asset ratio in the industry.</p>
              <div className="grid md:grid-cols-2 gap-4">
                {[
                  { label: 'Custody Provider', value: provider.custody_provider },
                  { label: 'Storage Type', value: provider.storage_type },
                  { label: 'Insurance', value: provider.insurance_coverage },
                  { label: 'BBB Rating', value: provider.bbb_rating },
                ].map((item) => (
                  <div key={item.label} className="bg-slate-50 rounded-lg p-4">
                    <div className="text-xs text-[#64748B] mb-1">{item.label}</div>
                    <div className="font-semibold text-[#0F172A]">{item.value ?? '—'}</div>
                  </div>
                ))}
              </div>
            </div>

            {/* Comparison */}
            <div>
              <h2 className="text-2xl font-bold text-[#0F172A] mb-4">BitIRA vs. Top Competitors</h2>
              <div className="overflow-x-auto">
                <table className="comparison-table">
                  <thead>
                    <tr>
                      <th>Feature</th> <th>BitIRA</th> <th>BlockTrust (#1)</th> <th>iTrustCapital (#3)</th>
                    </tr>
                  </thead>
                  <tbody>
                    {[
                      ['Founded', '2017', '2017', '2018'],
                      ['Min. Investment', '$5,000', '$10,000', '$1,000'],
                      ['Setup Fee', '$0', '$0', '$0'],
                      ['Annual Fee', '$195', '$195', '$0'],
                      ['Trade Fee', 'Varies', '1%', '1%'],
                      ['Asset Count', '15–20', '60+', '40+'],
                    ].map((row) => (
                      <tr key={row[0]}>
                        <td className="font-medium text-[#0F172A]">{row[0]}</td>
                        <td className="text-[#334155]">{row[1]}</td>
                        <td className="text-emerald-600 font-medium">{row[2]}</td>
                        <td className="text-[#334155]">{row[3]}</td>
                      </tr>
                    ))}
                  </tbody>
                </table>
              </div>
            </div>

            {/* Pros/Cons */}
            <div className="grid md:grid-cols-2 gap-6">
              <div className="card border-t-4 border-t-emerald-400">
                <h3 className="font-bold text-[#0F172A] mb-4">Pros</h3>
                <ul className="space-y-2">
                  {[
                    '$100M Lloyd’s of London insurance — highest of any crypto IRA',
                    'End-to-end cold storage with multi-signature security',
                    'A+ BBB rating',
                    'Founded 2017 — established track record',
                    'No account setup fee',
                    'Guided onboarding process',
                  ].map((pro) => (
                    <li key={pro} className="flex gap-2 text-sm text-[#334155]">
                      <span className="text-emerald-500 font-bold flex-shrink-0">✓</span>
                      {pro}
                    </li>
                  ))}
                </ul>
              </div>
              <div className="card border-t-4 border-t-red-300">
                <h3 className="font-bold text-[#0F172A] mb-4">Cons</h3>
                <ul className="space-y-2">
                  {[
                    'Only 15–20 cryptocurrencies supported',
                    'Higher fees than iTrustCapital or Swan Bitcoin',
                    'Rep-assisted onboarding is slower than self-service platforms',
                    'No mobile app',
                  ].map((con) => (
                    <li key={con} className="flex gap-2 text-sm text-[#334155]">
                      <span className="text-red-400 font-bold flex-shrink-0">✗</span>
                      {con}
                    </li>
                  ))}
                </ul>
              </div>
            </div>

          </div>

          {/* Sidebar */}
          <div className="space-y-6">
            <div className="card sticky top-24">
              <div className="text-center mb-6">
                <div className={`text-5xl font-bold mb-1 ${scoreColor(provider.score_overall)}`}>
                  {provider.score_overall?.toFixed(1) ?? '—'}
                </div>
                <div className="text-sm text-[#64748B]">Overall Score / 10</div>
                <div className="inline-flex items-center px-2.5 py-0.5 rounded-full text-xs font-medium bg-blue-100 text-blue-700 mt-2">
                  Best Security & Cold Storage 2026
                </div>
              </div>
              <div className="space-y-3 mb-6">
                {scoreLabels.map((cat) => {
                  const score = provider[cat.key] as number | null
                  return (
                    <div key={cat.key}>
                      <div className="flex justify-between text-xs mb-1">
                        <span className="text-[#64748B]">{cat.label}</span>
                        <span className={`font-semibold ${scoreColor(score)}`}>
                          {score?.toFixed(1) ?? '—'}/10
                        </span>
                      </div>
                      <div className="h-1.5 bg-slate-100 rounded-full overflow-hidden">
                        <div
                          className="h-full rounded-full"
                          style={{ width: `${((score ?? 0) / 10) * 100}%`, backgroundColor: '#0EA5E9' }}
                        />
                      </div>
                    </div>
                  )
                })}
              </div>
              {provider.affiliate_url ? (
                <a
                  href={provider.affiliate_url}
                  target="_blank"
                  rel="noopener noreferrer sponsored"
                  className="btn-primary w-full"
                  onClick={() => trackProviderSiteVisit('BitIRA', 'bitira', provider.affiliate_url!)}
                >
                  Visit BitIRA →
                </a>
              ) : (
                <a
                  href={provider.website ?? '#'}
                  target="_blank"
                  rel="noopener noreferrer"
                  className="btn-primary w-full"
                >
                  Visit BitIRA →
                </a>
              )}
              <p className="text-xs text-slate-400 text-center mt-3"></p>
            </div>

            <div className="card">
              <h3 className="font-semibold text-[#0F172A] mb-4 text-sm uppercase tracking-wider">Quick Facts</h3>
              <dl className="space-y-3 text-sm">
                {[
                  ['Founded', provider.founded_year?.toString()],
                  ['Headquarters', provider.headquarters],
                  ['Custodian', provider.custody_provider],
                  ['BBB Rating', provider.bbb_rating],
                  ['Min. Investment', provider.min_investment],
                  ['Annual Fee', provider.annual_fee],
                ].map(([key, val]) => (
                  <div key={key} className="flex justify-between">
                    <dt className="text-[#64748B]">{key}</dt>
                    <dd className="font-medium text-[#0F172A]">{val ?? '—'}</dd>
                  </div>
                ))}
              </dl>
            </div>

            <div className="card bg-blue-50 border-blue-200">
              <h3 className="font-semibold text-blue-800 mb-2 text-sm">See our top-ranked provider</h3>
              <p className="text-xs text-blue-700 mb-3">
                BlockTrust IRA edges out BitIRA with a wider asset selection, lower fees, and comparable security infrastructure.
              </p>
              <Link to="/crypto-ira/blocktrust-ira-review" className="text-xs font-medium text-blue-800 hover:underline"
                onClick={() => trackProviderReviewClick('Blocktrust Ira', 'blocktrust-ira', window.location.pathname)}>
                See BlockTrust IRA Review →
              </Link>
            </div>

            <div className="card bg-[#F0F9FF] border-[#BAE6FD]">
              <h3 className="font-semibold text-[#0F172A] mb-3 text-sm uppercase tracking-wider">Compare Providers</h3>
              <ul className="space-y-2 text-sm">
                <li><Link to="/crypto-ira/blocktrust-ira-review" className="text-[#0EA5E9] hover:underline"
                onClick={() => trackProviderReviewClick('Blocktrust Ira', 'blocktrust-ira', window.location.pathname)}>BlockTrust IRA Review</Link></li>
                <li><Link to="/crypto-ira/bitcoin-ira-review" className="text-[#0EA5E9] hover:underline"
                onClick={() => trackProviderReviewClick('Bitcoin Ira', 'bitcoin-ira', window.location.pathname)}>Bitcoin IRA Review</Link></li>
                <li><Link to="/crypto-ira/itrustcapital-review" className="text-[#0EA5E9] hover:underline"
                onClick={() => trackProviderReviewClick('Itrustcapital', 'itrustcapital', window.location.pathname)}>iTrustCapital Review</Link></li>
                <li><Link to="/crypto-ira/alto-crypto-ira-review" className="text-[#0EA5E9] hover:underline"
                onClick={() => trackProviderReviewClick('Alto Crypto Ira', 'alto-crypto-ira', window.location.pathname)}>Alto CryptoIRA Review</Link></li>
                <li><Link to="/crypto-ira/best-companies" className="text-[#0EA5E9] hover:underline font-medium">→ See All Rankings</Link></li>
              </ul>
            </div>

            <div className="card">
              <h3 className="font-semibold text-[#0F172A] mb-3 text-sm uppercase tracking-wider">Related Guides</h3>
              <ul className="space-y-2 text-sm">
                <li><Link to="/crypto-ira/how-to-open-a-crypto-ira" className="text-[#0EA5E9] hover:underline">How to Open a Crypto IRA →</Link></li>
                <li><Link to="/gold-ira-vs-crypto-ira" className="text-[#0EA5E9] hover:underline">Gold IRA vs Crypto IRA →</Link></li>
                <li><Link to="/methodology" className="text-[#0EA5E9] hover:underline">How We Rate Providers →</Link></li>
              </ul>
            </div>
          </div>
        </div>
      </div>

      {/* ── Bottom Line ────────────────────────────────────────────────── */}
      <div className="bg-[#F0F9FF] border-t border-[#BAE6FD]">
        <div className="container-site py-12 max-w-3xl">
          <h2 className="text-2xl font-bold text-[#0F172A] mb-4">Bottom Line: Is BitIRA Worth It?</h2>
          <p className="text-[#334155] leading-relaxed mb-4">
            BitIRA is <strong>a premium cold-storage crypto IRA option for 2026</strong>. The combination of the most secure custody solution in the market — 100% offline cold storage in Class III nuclear bunkers — and $100M in insurance coverage makes it a strong choice for investors looking for a tax-advantaged retirement account with exposure to this asset class.
          </p>
          <p className="text-[#334155] leading-relaxed mb-4">
            The $5,000 minimum investment and higher fee structure make it less accessible than competitors, and the asset selection is limited to major cryptocurrencies. Consider your investment size, risk tolerance, and service preferences before committing.
          </p>
          <p className="text-[#334155] leading-relaxed">
            <strong>Best for:</strong> Security-focused investors who want the absolute highest level of custody protection for their crypto IRA, regardless of cost. If you want to compare alternatives, see our{' '}
            <Link to="/crypto-ira/blocktrust-ira-review" className="text-[#0EA5E9] hover:underline"
                onClick={() => trackProviderReviewClick('Blocktrust Ira', 'blocktrust-ira', window.location.pathname)}>BlockTrust IRA review</Link>{' '}and{' '}
            <Link to="/crypto-ira/bitcoin-ira-review" className="text-[#0EA5E9] hover:underline"
                onClick={() => trackProviderReviewClick('Bitcoin Ira', 'bitcoin-ira', window.location.pathname)}>Bitcoin IRA review</Link>.
          </p>
        </div>
      </div>

      {/* ── FAQ Section ────────────────────────────────────────────────── */}
      <div className="container-site py-12 max-w-3xl">
        <h2 className="text-2xl font-bold text-[#0F172A] mb-8">Frequently Asked Questions</h2>
        <div className="space-y-4">
          {faqSchema.mainEntity.map((item, i) => (
            <details key={i} className="group border border-slate-200 rounded-lg overflow-hidden">
              <summary className="flex items-center justify-between gap-4 p-5 cursor-pointer bg-white hover:bg-slate-50 transition-colors list-none">
                <span className="font-semibold text-[#0F172A] text-sm leading-snug">{item.name}</span>
                <span className="flex-shrink-0 w-5 h-5 text-[#0EA5E9] transition-transform group-open:rotate-180">
                  <svg viewBox="0 0 20 20" fill="currentColor"><path fillRule="evenodd" d="M5.293 7.293a1 1 0 011.414 0L10 10.586l3.293-3.293a1 1 0 111.414 1.414l-4 4a1 1 0 01-1.414 0l-4-4a1 1 0 010-1.414z" clipRule="evenodd" /></svg>
                </span>
              </summary>
              <div className="px-5 pb-5 text-[#64748B] text-sm leading-relaxed bg-white">
                {item.acceptedAnswer.text}
              </div>
            </details>
          ))}
        </div>
      </div>
      {/* ── Newsletter Signup ─────────────────────────────────────────── */}
      <div className="container-site py-10 max-w-3xl">
        
        {/* Related Links */}

        <div className="mt-10 mb-6">

          <RelatedLinks variant="crypto-review" title="Related Guides &amp; Reviews" />

        </div>
<NewsletterSignup />
      </div>
    </>
  )
}
