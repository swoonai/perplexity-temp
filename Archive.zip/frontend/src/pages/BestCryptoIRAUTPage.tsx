import StateGuideTemplate from '../components/StateGuideTemplate'

export default function BestCryptoIRAUTPage() {
  return (
    <StateGuideTemplate
      stateName="Utah"
      stateAbbr="UT"
      slug="utah"
    />
  )
}
