import { Link } from 'react-router-dom'
import SEO from '../components/SEO'
import AdvertiserDisclosure from '../components/AdvertiserDisclosure'
import NewsletterSignup from '../components/NewsletterSignup';
import RelatedLinks from '../components/RelatedLinks';

const DATE_MODIFIED = "2026-03-23"
const DATE_PUBLISHED = "2026-03-23"
const LAST_UPDATED = "March 23, 2026"

const articleSchema = {
  "@context": "https://schema.org",
  "@type": "HowTo",
  "@id": "https://iraresearchhub.com/precious-metals-ira/how-to-open-gold-ira",
  "name": "How to Open a Gold IRA in 2026",
  "description": "Step-by-step guide to opening a gold IRA in 2026. Learn how to choose a custodian, fund your account, select IRS-approved gold, and arrange storage.",
  "totalTime": "PT30M",
  "supply": [
    { "@type": "HowToSupply", "name": "Government-issued ID" },
    { "@type": "HowToSupply", "name": "Social Security Number" },
    { "@type": "HowToSupply", "name": "Existing IRA or 401(k) account information (for rollovers)" },
    { "@type": "HowToSupply", "name": "Bank account information (for new contributions)" }
  ],
  "step": [
    {
      "@type": "HowToStep",
      "name": "Choose a Gold IRA Provider",
      "text": "Select an IRS-approved self-directed IRA provider that specializes in precious metals. Compare fees, minimums, storage options, and customer reviews. Top providers include Genesis Gold Group ($10,000 minimum), Augusta Precious Metals ($50,000 minimum), and Birch Gold Group ($10,000 minimum).",
      "url": "https://iraresearchhub.com/precious-metals-ira/how-to-open-gold-ira#step-1"
    },
    {
      "@type": "HowToStep",
      "name": "Open Your Self-Directed IRA Account",
      "text": "Complete the account application with your chosen provider. You will need a government-issued ID, Social Security Number, and beneficiary information. Most providers can open your account in 24–48 hours.",
      "url": "https://iraresearchhub.com/precious-metals-ira/how-to-open-gold-ira#step-2"
    },
    {
      "@type": "HowToStep",
      "name": "Fund Your Gold IRA",
      "text": "Fund your account via a 401(k) rollover, IRA transfer, or new cash contribution. A direct rollover from a 401(k) is the most common method and avoids tax penalties. The IRS allows up to $7,000/year in new contributions ($8,000 if age 50+) for 2026.",
      "url": "https://iraresearchhub.com/precious-metals-ira/how-to-open-gold-ira#step-3"
    },
    {
      "@type": "HowToStep",
      "name": "Select IRS-Approved Gold",
      "text": "Choose IRS-approved gold products: gold must be at least 99.5% pure (0.995 fineness), except American Gold Eagles which are specifically exempted. Popular choices include American Gold Eagles, American Gold Buffalos, and Canadian Gold Maple Leafs.",
      "url": "https://iraresearchhub.com/precious-metals-ira/how-to-open-gold-ira#step-4"
    },
    {
      "@type": "HowToStep",
      "name": "Arrange IRS-Compliant Storage",
      "text": "Your gold must be stored with an IRS-approved depository — you cannot store IRA gold at home. Your provider will arrange storage at an approved facility such as Brinks, Delaware Depository, or International Depository Services. Annual storage fees typically range from $100–$300/year.",
      "url": "https://iraresearchhub.com/precious-metals-ira/how-to-open-gold-ira#step-5"
    }
  ],
  "author": {
    "@type": "Person",
    "@id": "https://iraresearchhub.com/author/james-mitchell",
    "name": "James Mitchell",
    "url": "https://iraresearchhub.com/author/james-mitchell"
  },
  "publisher": {
    "@type": "Organization",
    "@id": "https://iraresearchhub.com",
    "name": "IRA Research Hub",
    "url": "https://iraresearchhub.com"
  },
  "datePublished": DATE_PUBLISHED,
  "dateModified": DATE_MODIFIED
}

const faqSchema = {
  "@context": "https://schema.org",
  "@type": "FAQPage",
  "mainEntity": [
    {
      "@type": "Question",
      "name": "How long does it take to open a gold IRA?",
      "acceptedAnswer": {
        "@type": "Answer",
        "text": "Most gold IRA providers can open your account within 24–48 hours of receiving your completed application. The full process — including funding via a 401(k) rollover — typically takes 2–4 weeks. Direct IRA-to-IRA transfers are faster, usually completing in 1–2 weeks."
      }
    },
    {
      "@type": "Question",
      "name": "What is the minimum investment to open a gold IRA?",
      "acceptedAnswer": {
        "@type": "Answer",
        "text": "Gold IRA minimums vary by provider. Genesis Gold Group and Birch Gold Group both have $10,000 minimums. Augusta Precious Metals requires $50,000. Most providers require at least $5,000–$10,000 to make the economics of physical storage worthwhile."
      }
    },
    {
      "@type": "Question",
      "name": "Can I roll over my 401(k) to a gold IRA without penalty?",
      "acceptedAnswer": {
        "@type": "Answer",
        "text": "Yes. A direct rollover from a 401(k) to a gold IRA is tax-free and penalty-free. The key is to use a direct rollover (funds go directly from your 401(k) to your new IRA custodian) rather than an indirect rollover (where you receive the funds and have 60 days to redeposit them). Most gold IRA providers will handle the rollover paperwork for you."
      }
    },
    {
      "@type": "Question",
      "name": "Can I store gold IRA gold at home?",
      "acceptedAnswer": {
        "@type": "Answer",
        "text": "No. IRS rules require that gold held in an IRA be stored with an IRS-approved custodian at an approved depository. Storing IRA gold at home is considered a distribution and is subject to income tax and a 10% early withdrawal penalty if you are under 59½. Some companies advertise 'home storage gold IRAs' but these are not IRS-compliant and carry significant legal risk."
      }
    },
    {
      "@type": "Question",
      "name": "What types of gold are allowed in a gold IRA?",
      "acceptedAnswer": {
        "@type": "Answer",
        "text": "IRS-approved gold must be at least 99.5% pure (0.995 fineness). Approved coins include American Gold Eagles (specifically exempted despite being 91.67% pure), American Gold Buffalos (99.99%), Canadian Gold Maple Leafs (99.99%), and Austrian Gold Philharmonics (99.99%). Gold bars and rounds from approved refiners are also allowed. Collectible coins and numismatic coins are generally not IRS-approved for IRAs."
      }
    }
  ]
}

const STEPS = [
  {
    id: 'step-1',
    number: '01',
    title: 'Choose a Gold IRA Provider',
    time: '1–2 days',
    content: (
      <>
        <p className="text-[#64748B] leading-relaxed mb-4">
          The most important decision in opening a gold IRA is choosing the right provider. Your provider will serve as the intermediary between you and the IRS-approved custodian who holds your gold. Look for these key factors:
        </p>
        <div className="grid md:grid-cols-2 gap-4 mb-4">
          <div className="bg-slate-50 rounded-lg p-4">
            <div className="font-semibold text-[#0F172A] mb-2 text-sm">What to Look For</div>
            <ul className="text-sm text-[#64748B] space-y-1">
              <li>• IRS-approved custodian partnership</li>
              <li>• Transparent fee structure (published online)</li>
              <li>• A+ BBB rating and strong Trustpilot reviews</li>
              <li>• Dedicated IRA specialist or support team</li>
              <li>• Minimum investment you can meet</li>
            </ul>
          </div>
          <div className="bg-slate-50 rounded-lg p-4">
            <div className="font-semibold text-[#0F172A] mb-2 text-sm">Red Flags to Avoid</div>
            <ul className="text-sm text-[#64748B] space-y-1">
              <li>• Promises of "home storage" gold IRAs</li>
              <li>• Guaranteed returns or "lower-risk" claims</li>
              <li>• Fees not disclosed until after account opening</li>
              <li>• High-pressure sales tactics</li>
              <li>• No physical address or verifiable history</li>
            </ul>
          </div>
        </div>
        <p className="text-[#64748B] leading-relaxed">
          Our top-rated providers for 2026 are <Link to="/precious-metals-ira/genesis-gold-group-review" className="text-[#0EA5E9] hover:underline">Genesis Gold Group</Link> (best overall), <Link to="/precious-metals-ira/augusta-precious-metals-review" className="text-[#0EA5E9] hover:underline">Augusta Precious Metals</Link> (best education), and <Link to="/precious-metals-ira/birch-gold-group-review" className="text-[#0EA5E9] hover:underline">Birch Gold Group</Link> (best for lower minimums).
        </p>
      </>
    ),
  },
  {
    id: 'step-2',
    number: '02',
    title: 'Open Your Self-Directed IRA Account',
    time: '24–48 hours',
    content: (
      <>
        <p className="text-[#64748B] leading-relaxed mb-4">
          Once you have chosen a provider, you will complete an account application. Most providers offer online applications that take 15–30 minutes. You will need:
        </p>
        <ul className="text-sm text-[#64748B] space-y-2 mb-4">
          <li className="flex items-start gap-2"><span className="text-emerald-500 font-bold flex-shrink-0 mt-0.5">✓</span><span><strong className="text-[#0F172A]">Government-issued ID</strong> — driver's license or passport</span></li>
          <li className="flex items-start gap-2"><span className="text-emerald-500 font-bold flex-shrink-0 mt-0.5">✓</span><span><strong className="text-[#0F172A]">Social Security Number</strong> — required for IRS reporting</span></li>
          <li className="flex items-start gap-2"><span className="text-emerald-500 font-bold flex-shrink-0 mt-0.5">✓</span><span><strong className="text-[#0F172A]">Beneficiary information</strong> — name, date of birth, SSN of your beneficiary</span></li>
          <li className="flex items-start gap-2"><span className="text-emerald-500 font-bold flex-shrink-0 mt-0.5">✓</span><span><strong className="text-[#0F172A]">Existing account details</strong> — if rolling over from a 401(k) or existing IRA</span></li>
        </ul>
        <p className="text-[#64748B] leading-relaxed">
          Your provider will set up the account with an IRS-approved custodian (typically Equity Trust, Kingdom Trust, or Strata Trust). The custodian is the entity that legally holds your gold and files the required IRS forms (Form 5498 and Form 1099-R).
        </p>
      </>
    ),
  },
  {
    id: 'step-3',
    number: '03',
    title: 'Fund Your Gold IRA',
    time: '1–4 weeks',
    content: (
      <>
        <p className="text-[#64748B] leading-relaxed mb-4">
          There are three ways to fund a gold IRA:
        </p>
        <div className="space-y-4 mb-4">
          <div className="border border-slate-200 rounded-lg p-4">
            <div className="font-semibold text-[#0F172A] mb-1">Option 1: 401(k) Rollover (Most Common)</div>
            <p className="text-sm text-[#64748B]">Transfer funds from an existing 401(k) or 403(b) to your new gold IRA. Use a <strong>direct rollover</strong> — funds go directly from your 401(k) custodian to your gold IRA custodian, bypassing you entirely. This avoids the 20% mandatory withholding and 60-day rule. Takes 2–4 weeks. Tax-free and penalty-free.</p>
          </div>
          <div className="border border-slate-200 rounded-lg p-4">
            <div className="font-semibold text-[#0F172A] mb-1">Option 2: IRA Transfer</div>
            <p className="text-sm text-[#64748B]">Transfer funds from an existing Traditional IRA or Roth IRA. Like a 401(k) rollover, use a direct transfer where funds move custodian-to-custodian. Faster than a 401(k) rollover — typically 1–2 weeks. Tax-free and penalty-free with no annual limit.</p>
          </div>
          <div className="border border-slate-200 rounded-lg p-4">
            <div className="font-semibold text-[#0F172A] mb-1">Option 3: New Cash Contribution</div>
            <p className="text-sm text-[#64748B]">Contribute new money directly to your gold IRA. Subject to annual IRS contribution limits: $7,000/year for 2026 ($8,000 if age 50+). Traditional IRA contributions may be tax-deductible depending on your income and employer plan participation.</p>
          </div>
        </div>
        <p className="text-[#64748B] leading-relaxed">
          For larger balances, the 401(k) rollover is typically the best option. See our detailed <Link to="/precious-metals-ira/401k-to-gold-ira-rollover" className="text-[#0EA5E9] hover:underline">401k to Gold IRA Rollover Guide</Link> for step-by-step instructions.
        </p>
      </>
    ),
  },
  {
    id: 'step-4',
    number: '04',
    title: 'Select IRS-Approved Gold',
    time: '1–2 days',
    content: (
      <>
        <p className="text-[#64748B] leading-relaxed mb-4">
          Not all gold is IRS-approved for IRA accounts. The IRS requires gold to be at least 99.5% pure (0.995 fineness), with one exception: American Gold Eagle coins are specifically exempted despite being 91.67% pure.
        </p>
        <div className="grid md:grid-cols-2 gap-4 mb-4">
          <div className="bg-emerald-50 rounded-lg p-4">
            <div className="font-semibold text-[#0F172A] mb-2 text-sm">IRS-Approved Gold Coins</div>
            <ul className="text-sm text-[#64748B] space-y-1">
              <li>• American Gold Eagle (1 oz, ½ oz, ¼ oz, 1/10 oz)</li>
              <li>• American Gold Buffalo (99.99%)</li>
              <li>• Canadian Gold Maple Leaf (99.99%)</li>
              <li>• Austrian Gold Philharmonic (99.99%)</li>
              <li>• Australian Gold Kangaroo (99.99%)</li>
            </ul>
          </div>
          <div className="bg-emerald-50 rounded-lg p-4">
            <div className="font-semibold text-[#0F172A] mb-2 text-sm">IRS-Approved Gold Bars</div>
            <ul className="text-sm text-[#64748B] space-y-1">
              <li>• PAMP Suisse bars (99.99%)</li>
              <li>• Credit Suisse bars (99.99%)</li>
              <li>• Valcambi bars (99.99%)</li>
              <li>• Perth Mint bars (99.99%)</li>
              <li>• Any LBMA-approved refiner bar (99.5%+)</li>
            </ul>
          </div>
        </div>
        <div className="bg-red-50 border border-red-200 rounded-lg p-4">
          <div className="font-semibold text-red-700 mb-1 text-sm">Not IRS-Approved for IRAs</div>
          <p className="text-sm text-red-600">Collectible coins, numismatic coins, South African Krugerrands (pre-1986), and any gold below 99.5% purity (except American Gold Eagles). Including non-approved gold in your IRA is treated as a distribution and triggers taxes and penalties.</p>
        </div>
      </>
    ),
  },
  {
    id: 'step-5',
    number: '05',
    title: 'Arrange IRS-Compliant Storage',
    time: 'Handled by your provider',
    content: (
      <>
        <p className="text-[#64748B] leading-relaxed mb-4">
          IRS rules require that gold held in an IRA be stored with an IRS-approved custodian at an approved depository. You cannot store IRA gold at home — doing so is treated as a distribution and triggers taxes and penalties.
        </p>
        <p className="text-[#64748B] leading-relaxed mb-4">
          Your gold IRA provider will arrange storage at an approved depository. The most common depositories include:
        </p>
        <div className="overflow-x-auto mb-4">
          <table className="w-full text-sm">
            <thead>
              <tr className="bg-slate-100">
                <th className="text-left p-3">Depository</th>
                <th className="text-left p-3">Location</th>
                <th className="text-left p-3">Storage Type</th>
              </tr>
            </thead>
            <tbody>
              {[
                ['Delaware Depository', 'Wilmington, DE', 'Segregated & Commingled'],
                ['Brinks Global Services', 'Multiple US locations', 'Segregated & Commingled'],
                ['International Depository Services', 'Multiple US locations', 'Segregated & Commingled'],
                ['CNT Depository', 'Bridgewater, MA', 'Segregated & Commingled'],
              ].map(([name, loc, type], i) => (
                <tr key={name} className={i % 2 === 0 ? 'bg-white' : 'bg-slate-50'}>
                  <td className="p-3 font-medium text-[#0F172A]">{name}</td>
                  <td className="p-3 text-[#64748B]">{loc}</td>
                  <td className="p-3 text-[#64748B]">{type}</td>
                </tr>
              ))}
            </tbody>
          </table>
        </div>
        <p className="text-[#64748B] leading-relaxed">
          <strong className="text-[#0F172A]">Segregated vs. commingled storage:</strong> Segregated storage keeps your gold physically separate from other customers' gold — your specific coins and bars are yours alone. Commingled storage pools gold of the same type together. Segregated storage typically costs $50–$100/year more but provides greater peace of mind.
        </p>
      </>
    ),
  },
]

const breadcrumbSchema = {"@context": "https://schema.org", "@type": "BreadcrumbList", "itemListElement": [{"@type": "ListItem", "position": 1, "name": "Precious Metals IRA", "item": "https://iraresearchhub.com/precious-metals-ira"},
      {"@type": "ListItem", "position": 2, "name": "How to Open a Gold IRA", "item": "https://iraresearchhub.com/precious-metals-ira/how-to-open-gold-ira"}]};
export default function HowToOpenGoldIRAPage() {
  return (
    <>
      <SEO
        title="How to Open a Gold IRA in 2026: Step-by-Step Guide"
        description="Step-by-step guide to opening a gold IRA in 2026. Learn how to choose a custodian, fund your account via 401(k) rollover, select IRS-approved gold, and arrange storage."
        canonical="/precious-metals-ira/how-to-open-gold-ira"
        ogType="article"
      />
      <script type="application/ld+json" dangerouslySetInnerHTML={{ __html: JSON.stringify(articleSchema) }} />
      <script type="application/ld+json" dangerouslySetInnerHTML={{ __html: JSON.stringify(faqSchema) }} />

      <script type="application/ld+json" dangerouslySetInnerHTML={{ __html: JSON.stringify(breadcrumbSchema) }} />
      {/* Header */}
      <section className="bg-[#F8FAFC] border-b border-slate-200">
        <div className="container-site py-12 max-w-4xl">
          <div className="flex flex-wrap items-center gap-2 mb-4">
            <Link to="/precious-metals-ira" className="text-sm text-[#64748B] hover:text-[#0EA5E9]">Precious Metals IRAs</Link>
            <span className="text-slate-300">/</span>
            <span className="text-sm text-[#0F172A]">How to Open a Gold IRA</span>
          </div>
          <div className="inline-flex items-center px-2.5 py-0.5 rounded-full text-xs font-medium bg-amber-100 text-amber-700 mb-4">
            Updated March 2026 · 5-Step Guide
          </div>
          <h1 className="text-4xl font-bold text-[#0F172A] mb-3">
            How to Open a Gold IRA in 2026: A Step-by-Step Guide
          </h1>
          <p className="text-sm text-slate-400 mt-2">
            By <a href="/author/james-mitchell" className="text-[#0EA5E9] hover:underline">James Mitchell, CFA</a> · Last updated: {LAST_UPDATED} · <a href="/methodology" className="text-[#0EA5E9] hover:underline">Methodology</a>
          </p>
          <AdvertiserDisclosure />
          <p className="text-lg text-[#64748B] max-w-2xl mt-3">
            Opening a gold IRA takes about 30 minutes of paperwork and 2–4 weeks to fund. This guide walks you through every step — from choosing a provider to selecting IRS-approved gold and arranging compliant storage.
          </p>
        </div>
      </section>

      <section className="container-site py-12 max-w-4xl">

        {/* Quick Summary */}
        <div className="card border-l-4 border-l-[#D97706] mb-10">
          <h2 className="text-lg font-bold text-[#0F172A] mb-2">Quick Summary: 5 Steps to Open a Gold IRA</h2>
          <ol className="text-sm text-[#64748B] space-y-1">
            <li><strong className="text-[#0F172A]">1.</strong> Choose an IRS-approved gold IRA provider (1–2 days)</li>
            <li><strong className="text-[#0F172A]">2.</strong> Complete the account application (24–48 hours)</li>
            <li><strong className="text-[#0F172A]">3.</strong> Fund your account via 401(k) rollover, IRA transfer, or new contribution (1–4 weeks)</li>
            <li><strong className="text-[#0F172A]">4.</strong> Select IRS-approved gold products (1–2 days)</li>
            <li><strong className="text-[#0F172A]">5.</strong> Your provider arranges IRS-compliant storage (handled automatically)</li>
          </ol>
        </div>

        {/* Step-by-Step */}
        <div className="space-y-10 mb-12">
          {STEPS.map((step) => (
            <div key={step.id} id={step.id} className="scroll-mt-20">
              <div className="flex items-start gap-4 mb-4">
                <div className="flex-shrink-0 w-12 h-12 bg-[#D97706] text-white rounded-full flex items-center justify-center font-bold text-lg">
                  {step.number}
                </div>
                <div>
                  <h2 className="text-2xl font-bold text-[#0F172A]">{step.title}</h2>
                  <div className="text-xs text-[#64748B] mt-0.5">Estimated time: {step.time}</div>
                </div>
              </div>
              <div className="ml-16">
                {step.content}
              </div>
            </div>
          ))}
        </div>

        {/* Cost Summary */}
        <div className="mb-10">
          <h2 className="text-2xl font-bold text-[#0F172A] mb-4">Gold IRA Costs: What to Expect</h2>
          <div className="overflow-x-auto">
            <table className="w-full text-sm">
              <thead>
                <tr className="bg-[#0F172A] text-white">
                  <th className="text-left p-3 rounded-tl-lg">Fee Type</th>
                  <th className="text-center p-3">Typical Range</th>
                  <th className="text-left p-3 rounded-tr-lg">Notes</th>
                </tr>
              </thead>
              <tbody>
                {[
                  ['Account Setup Fee', '$0–$100', 'Many providers waive this fee'],
                  ['Annual Custodian Fee', '$75–$150/year', 'Paid to the IRS-approved custodian'],
                  ['Annual Storage Fee', '$100–$300/year', 'Segregated storage costs more'],
                  ['Precious Metals Markup', '2–10% over spot', 'Varies by product and provider'],
                  ['Wire Transfer Fee', '$25–$50 (one-time)', 'For funding via bank wire'],
                  ['Liquidation Fee', '$0–$150', 'Some providers charge to sell'],
                ].map(([type, range, notes], i) => (
                  <tr key={type} className={i % 2 === 0 ? 'bg-white' : 'bg-slate-50'}>
                    <td className="p-3 font-medium text-[#0F172A]">{type}</td>
                    <td className="p-3 text-center text-[#64748B]">{range}</td>
                    <td className="p-3 text-[#64748B]">{notes}</td>
                  </tr>
                ))}
              </tbody>
            </table>
          </div>
          <p className="text-xs text-slate-400 mt-2">Total annual cost for a typical $50,000 gold IRA: approximately $250–$450/year (0.5–0.9% of assets). Data sourced from provider disclosures, March 2026.</p>
        </div>

        {/* FAQ Section */}
        <h2 className="text-2xl font-bold text-[#0F172A] mb-4">Frequently Asked Questions</h2>
        <div className="space-y-4 mb-8">
          {faqSchema.mainEntity.map((item) => (
            <details key={item.name} className="group border border-slate-200 rounded-lg overflow-hidden">
              <summary className="flex items-center justify-between gap-4 p-5 cursor-pointer bg-white hover:bg-slate-50 transition-colors list-none">
                <span className="font-semibold text-[#0F172A] text-sm leading-snug">{item.name}</span>
                <span className="flex-shrink-0 w-5 h-5 text-[#D97706] transition-transform group-open:rotate-180">
                  <svg viewBox="0 0 20 20" fill="currentColor"><path fillRule="evenodd" d="M5.293 7.293a1 1 0 011.414 0L10 10.586l3.293-3.293a1 1 0 111.414 1.414l-4 4a1 1 0 01-1.414 0l-4-4a1 1 0 010-1.414z" clipRule="evenodd" /></svg>
                </span>
              </summary>
              <div className="px-5 pb-5 text-[#64748B] text-sm leading-relaxed bg-white">
                {item.acceptedAnswer.text}
              </div>
            </details>
          ))}
        </div>

        {/* Bottom CTA */}
        <div className="bg-amber-50 border border-amber-200 rounded-xl p-6 text-center mb-8">
          <h2 className="text-xl font-bold text-[#0F172A] mb-2">Ready to open your gold IRA?</h2>
          <p className="text-sm text-slate-600 mb-4">
            Compare our top-rated gold IRA providers, including fees, minimums, and independent scores.
          </p>
          <Link
            to="/precious-metals-ira/best-companies"
            className="inline-flex items-center justify-center px-6 py-3 bg-[#D97706] text-white font-semibold rounded-lg hover:bg-[#B45309] transition-colors"
          >
            See All Gold IRA Rankings →
          </Link>
        </div>

        {/* Related Links */}
        <div className="grid md:grid-cols-3 gap-4 text-sm">
          <Link to="/precious-metals-ira/401k-to-gold-ira-rollover" className="card hover:shadow-elevated transition-all">
            <div className="font-semibold text-[#0F172A] mb-1">401k to Gold IRA Rollover →</div>
            <div className="text-[#64748B]">Detailed rollover guide</div>
          </Link>
          <Link to="/precious-metals-ira/genesis-gold-group-review" className="card hover:shadow-elevated transition-all">
            <div className="font-semibold text-[#0F172A] mb-1">Genesis Gold Group Review →</div>
            <div className="text-[#64748B]">#1 rated gold IRA provider</div>
          </Link>
          <Link to="/precious-metals-ira/gold-ira-vs-silver-ira" className="card hover:shadow-elevated transition-all">
            <div className="font-semibold text-[#0F172A] mb-1">Gold IRA vs Silver IRA →</div>
            <div className="text-[#64748B]">Which metal is right for you?</div>
          </Link>
        </div>

      </section>
      {/* ── Newsletter Signup ─────────────────────────────────────────── */}
      <div className="container-site py-10 max-w-3xl">
        
        {/* Related Links */}

        <div className="mt-10 mb-6">

          <RelatedLinks variant="metals-guide" title="Related Guides &amp; Reviews" />

        </div>
<NewsletterSignup />
      </div>
    </>
  )
}
