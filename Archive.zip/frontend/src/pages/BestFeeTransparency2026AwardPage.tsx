import AwardDetailPage from './AwardDetailPage'

export default function BestFeeTransparency2026AwardPage() {
  return <AwardDetailPage awardSlug="best-fee-transparency-2026" />
}
