import StateGuideTemplate from '../components/StateGuideTemplate'

export default function BestCryptoIRANYPage() {
  return (
    <StateGuideTemplate
      stateName="New York"
      stateAbbr="NY"
      slug="new-york"
    />
  )
}
