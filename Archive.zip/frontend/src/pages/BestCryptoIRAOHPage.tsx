import StateGuideTemplate from '../components/StateGuideTemplate'

export default function BestCryptoIRAOHPage() {
  return (
    <StateGuideTemplate
      stateName="Ohio"
      stateAbbr="OH"
      slug="ohio"
    />
  )
}
