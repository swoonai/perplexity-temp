import { Link } from 'react-router-dom'
import { useRankedProviders, scoreColor } from '../hooks/useProviders'
import SEO from '../components/SEO'
import NewsletterSignup from '../components/NewsletterSignup';
import RelatedLinks from '../components/RelatedLinks';

const providerLinks = [
  {
    slug: 'blocktrust-ira',
    path: '/crypto-ira/blocktrust-ira-review',
    rank: '#1',
    badge: 'Top-Ranked',
    badgeColor: 'bg-sky-100 text-sky-700',
  },
  {
    slug: 'bitcoin-ira',
    path: '/crypto-ira/bitcoin-ira-review',
    rank: '#2',
    badge: 'Most Established',
    badgeColor: 'bg-slate-100 text-slate-700',
  },
  {
    slug: 'itrustcapital',
    path: '/crypto-ira/itrustcapital-review',
    rank: '#3',
    badge: 'Notable for Low Fees',
    badgeColor: 'bg-emerald-100 text-emerald-700',
  },
]

export default function CryptoIRAPage() {
  const { data: providers } = useRankedProviders('crypto', 10)

  return (
    <div className="section-padding">
      <SEO
        title="2026 Crypto IRA Provider Comparison & Independent Analysis"
        description="Independent, data-driven analysis of the top cryptocurrency IRA providers. Compare fees, security, asset selection, IRS compliance, and customer support to find the best crypto IRA for your retirement."
        canonical="/crypto-ira"
      />
      <div className="container-site">
        {/* Hero */}
        <div className="mb-10">
          <div className="badge-sky mb-4">Updated March 2026</div>
          <h1 className="text-4xl font-bold text-[#0F172A] mb-4">2026 Crypto IRA Provider Comparison & Independent Analysis</h1>
          <p className="text-lg text-[#64748B] max-w-2xl">
            Independent, data-driven analysis of the top cryptocurrency IRA providers. We evaluate 
            fees, security, asset selection, IRS compliance, and customer support to help you find 
            the right crypto IRA for your retirement goals.
          </p>
        </div>

        {/* Provider Cards */}
        <div className="space-y-4 mb-12">
          {providerLinks.map((pl) => {
            const provider = providers?.providers?.find((p) => p.slug === pl.slug)
            return (
              <Link
                key={pl.slug}
                to={pl.path}
                className="card hover:shadow-elevated transition-all flex flex-wrap md:flex-nowrap items-center gap-4 group"
              >
                <div className="flex-shrink-0 w-10 h-10 rounded-full bg-[#0F172A] text-white flex items-center justify-center font-bold text-sm">
                  {pl.rank}
                </div>
                <div className="flex-1 min-w-0">
                  <div className="flex flex-wrap items-center gap-2 mb-1">
                    <h3 className="font-bold text-[#0F172A] group-hover:text-[#0EA5E9] transition-colors">
                      {provider?.name ?? pl.slug}
                    </h3>
                    <span className={`inline-flex items-center px-2 py-0.5 rounded-full text-xs font-medium ${pl.badgeColor}`}>
                      {pl.badge}
                    </span>
                  </div>
                  <p className="text-sm text-[#64748B]">
                    {provider?.tagline ?? 'Full review with fees, security, and asset analysis'}
                  </p>
                  {provider && (
                    <div className="flex flex-wrap gap-4 mt-2 text-xs text-[#64748B]">
                      <span>Min: {provider.min_investment}</span>
                      <span>Annual: {provider.annual_fee}</span>
                      <span>Tx: {provider.transaction_fee}</span>
                      <span>{provider.asset_count}+ assets</span>
                    </div>
                  )}
                </div>
                {provider && (
                  <div className="flex-shrink-0 text-right">
                    <div className={`text-2xl font-bold ${scoreColor(provider.score_overall)}`}>
                      {provider.score_overall?.toFixed(1)}
                    </div>
                    <div className="text-xs text-[#64748B]">/ 10</div>
                  </div>
                )}
                <div className="flex-shrink-0 text-[#0EA5E9] font-medium text-sm">
                  Read Review →
                </div>
              </Link>
            )
          })}
        </div>

        {/* Hub Links */}
        <div className="grid md:grid-cols-2 gap-6 max-w-3xl">
          <Link to="/crypto-ira/best-companies" className="card hover:shadow-elevated transition-all bg-[#0F172A] text-white">
            <h3 className="font-bold mb-2">Full Comparison Table</h3>
            <p className="text-slate-300 text-sm">Side-by-side comparison of all crypto IRA providers ranked by our methodology.</p>
          </Link>
          <Link to="/methodology" className="card hover:shadow-elevated transition-all">
            <h3 className="font-bold text-[#0F172A] mb-2">Our Methodology</h3>
            <p className="text-[#64748B] text-sm">How we score and rank crypto IRA providers — fully transparent criteria.</p>
          </Link>
        </div>
      </div>
      {/* ── Newsletter Signup ─────────────────────────────────────────── */}
      <div className="container-site py-10 max-w-3xl">
                {/* Related Links */}
        <div className="mt-10 mb-6">
          <RelatedLinks variant="crypto-guide" title="Related Guides &amp; Reviews" />
        </div>
        <NewsletterSignup />
      </div>
    </div>
  )
}
