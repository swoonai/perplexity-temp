import StateGuideTemplate from '../components/StateGuideTemplate'

export default function BestCryptoIRANMPage() {
  return (
    <StateGuideTemplate
      stateName="New Mexico"
      stateAbbr="NM"
      slug="new-mexico"
    />
  )
}
