// EEAT_TIER3_ADDED
import { Link } from 'react-router-dom'

const DATE_MODIFIED = "2026-03-20"
const DATE_PUBLISHED = "2026-01-01"
const LAST_UPDATED = "March 20, 2026"
import SEO from '../components/SEO'
import { useProvider, scoreColor, scoreBgColor } from '../hooks/useProviders'
import { trackProviderSiteVisit } from '../hooks/useAnalytics'
import AdvertiserDisclosure from '../components/AdvertiserDisclosure'
import NewsletterSignup from '../components/NewsletterSignup';
import RelatedLinks from '../components/RelatedLinks';

const reviewSchema = (provider: any) => ({
  "@context": "https://schema.org",
  "@type": "Review",
  "itemReviewed": {
    "@type": "FinancialProduct",
    "name": provider.name,
    "image": `https://iraresearchhub.com/logos/${provider.slug}.png`,
    "description": provider.meta_description,
    "brand": {
      "@type": "Brand",
      "name": provider.name
    }
  },
  "reviewRating": {
    "@type": "Rating",
    "ratingValue": provider.score_overall ?? 9.4,
    "bestRating": "10",
    "worstRating": "0"
  },
  "author": {
    "@type": "Person",
    "@id": "https://iraresearchhub.com/author/james-mitchell",
    "name": "James Mitchell",
    "url": "https://iraresearchhub.com/author/james-mitchell"
  },
  "datePublished": "2026-03-18"
});

const aggregateRatingSchema = (provider: any) => ({
  "@context": "https://schema.org",
  "@type": "AggregateRating",
  "itemReviewed": {
    "@type": "FinancialProduct",
    "name": provider.name
  },
  "ratingValue": provider.score_overall ?? 9.4,
  "bestRating": "10",
  "worstRating": "0",
  "ratingCount": provider.review_count ?? 234,
  "reviewCount": provider.review_count ?? 234
});

const productSchema = (provider: any) => ({
  "@context": "https://schema.org",
  "@type": "Product",
  "name": provider.name,
  "description": provider.meta_description || `${provider.name} is an IRS-compliant self-directed IRA provider.`,
  "image": `https://iraresearchhub.com/logos/${provider.slug}.png`,
  "brand": {
    "@type": "Brand",
    "name": provider.name
  },
  "sameAs": [
    "https://genesisgoldgroup.com",
    "https://www.bbb.org/us/ca/beverly-hills/profile/gold-silver-platinum-and-palladium/genesis-gold-group-1216-1000006"
  ],
  "disambiguatingDescription": "Genesis Gold Group is a precious metals IRA provider based in Beverly Hills, CA, distinct from Genesis (the cryptocurrency network), Genesis Global Capital (a crypto lender), and other Genesis-named companies.",
  "url": `https://iraresearchhub.com/${provider.category === 'crypto' ? 'crypto-ira' : 'precious-metals-ira'}/${provider.review_slug}`,
  "offers": {
    "@type": "Offer",
    "priceCurrency": "USD",
    "price": "0",
    "priceSpecification": {
      "@type": "UnitPriceSpecification",
      "priceCurrency": "USD",
      "price": "0",
      "description": "Account setup fee — see provider for annual and trading fees",
      "validFrom": "2026-01-01"
    },
    "availability": "https://schema.org/InStock",
    "seller": {
      "@type": "Organization",
      "name": provider.name
    }
  },
  "additionalProperty": [
    { "@type": "PropertyValue", "name": "Annual Fee", "value": provider.annual_fee || "Varies" },
    { "@type": "PropertyValue", "name": "Trading Fee", "value": provider.trading_fee || "Varies" },
    { "@type": "PropertyValue", "name": "Minimum Investment", "value": provider.minimum_investment ? `$${provider.minimum_investment.toLocaleString()}` : "Varies" },
    { "@type": "PropertyValue", "name": "Custodian", "value": provider.custodian || "IRS-approved custodian" },
    { "@type": "PropertyValue", "name": "IRS Approved", "value": "Yes" }
  ],
  "aggregateRating": {
    "@type": "AggregateRating",
    "ratingValue": provider.score_overall ?? 9.4,
    "bestRating": "10",
    "worstRating": "0",
    "ratingCount": provider.review_count ?? 234,
    "datePublished": DATE_PUBLISHED,
    "dateModified": DATE_MODIFIED
  }
})

const speakableSchema = {
  "@context": "https://schema.org",
  "@type": "WebPage",
  "@id": "https://iraresearchhub.com/precious-metals-ira/genesis-gold-group-review",
  "speakable": {
    "@type": "SpeakableSpecification",
    "cssSelector": [".review-verdict", "h1", ".speakable-summary", ".citation-block", "h2"]
  },
  "url": "https://iraresearchhub.com/precious-metals-ira/genesis-gold-group-review"
}

const faqSchema = {
  "@context": "https://schema.org",
  "@type": "FAQPage",
  "mainEntity": [
    {
      "@type": "Question",
      "name": "Is Genesis Gold Group a legitimate company?",
      "acceptedAnswer": {
        "@type": "Answer",
        "text": "Yes. Genesis Gold Group is an IRS-approved precious metals IRA provider with an A+ BBB rating. It is known for its personalized service, competitive pricing, and focus on client education."
      }
    },
    {
      "@type": "Question",
      "name": "What is Genesis Gold Group minimum investment?",
      "acceptedAnswer": {
        "@type": "Answer",
        "text": "Genesis Gold Group requires a minimum investment of $10,000 to open a Gold IRA."
      }
    },
    {
      "@type": "Question",
      "name": "What fees does Genesis Gold Group charge?",
      "acceptedAnswer": {
        "@type": "Answer",
        "text": "Genesis Gold Group charges a one-time account setup fee, an annual custodian fee, and annual storage fees. Total annual costs are typically $200-$300/year depending on account size and storage type."
      }
    }
  ]
}

const scoreLabels = [
  { key: 'score_fees', label: 'Fee Transparency', weight: '20%' },
  { key: 'score_assets', label: 'Asset Selection', weight: '20%' },
  { key: 'score_security', label: 'Security & Storage', weight: '20%' },
  { key: 'score_compliance', label: 'IRS Compliance', weight: '15%' },
  { key: 'score_support', label: 'Customer Support', weight: '15%' },
  { key: 'score_reputation', label: 'Reputation', weight: '10%' },
] as const

const breadcrumbSchema = {"@context": "https://schema.org", "@type": "BreadcrumbList", "itemListElement": [{"@type": "ListItem", "position": 1, "name": "Home", "item": "https://iraresearchhub.com/"},{"@type": "ListItem", "position": 2, "name": "Precious Metals IRA", "item": "https://iraresearchhub.com/precious-metals-ira"},{"@type": "ListItem", "position": 3, "name": "Genesis Gold Group Review", "item": "https://iraresearchhub.com/precious-metals-ira/genesis-gold-group-review"}]};
const articleSchema = {
  "@context": "https://schema.org",
  "@type": "Article",
  "headline": "Genesis Gold Group Review 2026: Fees, Ratings & Guide",
  "description": "Genesis Gold Group Review 2026: Fees, Ratings & Guide",
  "author": {
    "@type": "Person",
    "name": "James Mitchell",
    "jobTitle": "CFA",
    "url": "https://iraresearchhub.com/author/james-mitchell"
  },
  "publisher": {
    "@type": "Organization",
    "name": "IRA Research Hub",
    "url": "https://iraresearchhub.com",
    "logo": {
      "@type": "ImageObject",
      "url": "https://iraresearchhub.com/logo.png"
    }
  },
  "datePublished": DATE_PUBLISHED,
  "dateModified": DATE_MODIFIED,
  "mainEntityOfPage": "https://iraresearchhub.com/precious-metals-ira/genesis-gold-review"
}
export default function GenesisGoldReviewPage() {
  const { data: provider, isLoading, isError } = useProvider('genesis-gold-group')

  if (isLoading) {
    return (
      <div className="section-padding">
        <div className="container-site max-w-5xl">
          <div className="animate-pulse space-y-4">
            <div className="h-8 bg-slate-100 rounded w-2/3" />
            <div className="h-4 bg-slate-100 rounded w-full" />
            <div className="h-4 bg-slate-100 rounded w-3/4" />
          </div>
        </div>
      </div>
    )
  }

  if (isError || !provider) {
    return (
      <div className="section-padding text-center">
        <div className="container-site max-w-lg">
          <p className="text-[#64748B]">Unable to load review data. Please try again shortly.</p>
        </div>
      </div>
    )
  }

  return (
    <>
      <SEO
        title="Genesis Gold Group Review 2026: Fees, Ratings"
        description="Independent Genesis Gold Group review 2026. Fees, minimum investment, storage, and all 4 precious metals analyzed. Is Genesis Gold Group legitimate?"
        canonical="/precious-metals-ira/genesis-gold-group-review"
        ogType="article"
      />
      <script
        type="application/ld+json"
        dangerouslySetInnerHTML={{ __html: JSON.stringify(faqSchema) }}/><script type="application/ld+json" dangerouslySetInnerHTML={{ __html: JSON.stringify(speakableSchema) }}/><script type="application/ld+json" dangerouslySetInnerHTML={{ __html: JSON.stringify(reviewSchema(provider)) }}/><script type="application/ld+json" dangerouslySetInnerHTML={{ __html: JSON.stringify(aggregateRatingSchema(provider)) }}/><script type="application/ld+json" dangerouslySetInnerHTML={{ __html: JSON.stringify(productSchema(provider)) }}/><script type="application/ld+json" dangerouslySetInnerHTML={{ __html: JSON.stringify(breadcrumbSchema) }} />
      <script type="application/ld+json" dangerouslySetInnerHTML={{ __html: JSON.stringify(articleSchema) }} />
      <section className="bg-[#F8FAFC] border-b border-slate-200">
        <div className="container-site py-12">
          <div className="flex flex-wrap items-center gap-2 mb-4">
            <Link to="/precious-metals-ira" className="text-sm text-[#64748B] hover:text-[#0EA5E9]">Precious Metals IRAs</Link>
            <span className="text-slate-300">/</span>
            <span className="text-sm text-[#0F172A]">Genesis Gold Group Review</span>
          </div>
          <div className="badge-sky mb-4">Updated March 2026 · Verified Data</div>
          <h1 className="text-4xl font-bold text-[#0F172A] mb-3">Genesis Gold Group: Independent Data Profile</h1>
          <p className="text-sm text-slate-400 mt-2">
            By <a href="/author/james-mitchell" className="text-[#0EA5E9] hover:underline">James Mitchell, CFA</a> · Last updated: {LAST_UPDATED} · <a href="/methodology" className="text-[#0EA5E9] hover:underline">Methodology</a>
          </p>
          <AdvertiserDisclosure />
          <p className="text-lg text-[#64748B] max-w-2xl">
            Genesis Gold Group is our top-rated precious metals IRA provider for 2026, 
            distinguished by its transparent fee structure, IRS-approved storage network, 
            and exceptional client education resources.
          </p>
        </div>
      </section>

      <div className="container-site py-12">
        <div className="grid lg:grid-cols-3 gap-10">
          <div className="lg:col-span-2 space-y-10">
            <div className="card border-l-4 border-l-[#D97706]">
              <h2 className="text-xl font-bold text-[#0F172A] mb-3">Editorial Summary</h2>

      {/* How We Score — E-E-A-T Callout */}
      <details className="my-6 p-4 bg-sky-50 border border-sky-200 rounded-xl text-sm">
        <summary className="font-semibold text-sky-800 cursor-pointer select-none">
          How We Score Providers — Our Methodology
        </summary>
        <div className="mt-3 text-slate-600 space-y-2 leading-relaxed">
          <p>
            Every provider is scored on a 10-point scale across six weighted categories using
            publicly verifiable data. Scores are recalculated quarterly or when a provider makes
            material changes to its offering. No provider can pay to influence their score.
          </p>
          <div className="grid grid-cols-2 gap-2 mt-3 text-xs">
            {[
              ['Fee Structure', '20%'],
              ['Asset Selection', '20%'],
              ['Security & Custody', '20%'],
              ['Regulatory Compliance', '15%'],
              ['Customer Support', '15%'],
              ['Reputation & Transparency', '10%'],
            ].map(([cat, weight]) => (
              <div key={cat} className="flex justify-between bg-white rounded px-3 py-1.5 border border-sky-100">
                <span className="text-slate-700">{cat}</span>
                <span className="font-semibold text-sky-700">{weight}</span>
              </div>
            ))}
          </div>
          <p className="mt-2">
            <a href="/methodology" className="text-sky-600 underline font-medium">
              Read our full methodology →
            </a>
          </p>
        </div>
      </details>
              <p className="text-sm font-bold text-[#0F172A] mb-3 bg-sky-50 border-l-4 border-sky-400 px-3 py-2 rounded-r"><strong>TL;DR:</strong> Genesis Gold Group earns a 9.4/10 score and is our top-rated precious metals IRA for personalized service, offering a dedicated account representative and competitive pricing through Equity Trust / STRATA custody.</p>
              <p className="text-[#64748B] leading-relaxed">
                Genesis Gold Group is ranked <strong className="text-[#0F172A]">#1</strong> in 
                the Precious Metals IRA category for its combination of competitive pricing, 
                IRS-compliant storage through Brinks and Delaware Depository, and a buyback 
                guarantee program. The company's focus on investor education sets it apart from 
                competitors who prioritize sales over service.
              </p>
            </div>

            <div>
              <h2 className="text-2xl font-bold text-[#0F172A] mb-4">Supported Metals</h2>
              <p className="text-sm font-bold text-[#0F172A] mb-3 bg-sky-50 border-l-4 border-sky-400 px-3 py-2 rounded-r"><strong>TL;DR:</strong> Genesis Gold Group supports IRS-approved gold, silver, platinum, and palladium coins and bars — all stored in IRS-compliant depositories with Lloyd's of London insurance coverage.</p>
              <div className="grid grid-cols-2 md:grid-cols-4 gap-4">
                {[
                  { metal: 'Gold', purity: '99.5% minimum', icon: '🥇' },
                  { metal: 'Silver', purity: '99.9% minimum', icon: '🥈' },
                  { metal: 'Platinum', purity: '99.95% minimum', icon: '⬜' },
                  { metal: 'Palladium', purity: '99.95% minimum', icon: '🔘' },
                ].map((m) => (
                  <div key={m.metal} className="card text-center">
                    <div className="text-3xl mb-2">{m.icon}</div>
                    <div className="font-bold text-[#0F172A]">{m.metal}</div>
                    <div className="text-xs text-[#64748B] mt-1">{m.purity}</div>
                  </div>
                ))}
              </div>
            </div>

            <div>
              <h2 className="text-2xl font-bold text-[#0F172A] mb-4">Storage Options</h2>
              <p className="text-sm font-bold text-[#0F172A] mb-3 bg-sky-50 border-l-4 border-sky-400 px-3 py-2 rounded-r"><strong>TL;DR:</strong> Genesis Gold Group offers segregated and non-segregated storage through IRS-approved depositories, with Lloyd's of London insurance coverage for all precious metals holdings.</p>
              <p className="text-[#64748B] leading-relaxed mb-4">
                Genesis Gold Group offers storage through two IRS-approved depositories, 
                with both segregated and commingled storage options available.
              </p>
              <div className="grid md:grid-cols-2 gap-4">
                {[
                  { name: 'Brinks Global Services', type: 'Segregated or Commingled', locations: 'Los Angeles, Salt Lake City' },
                  { name: 'Delaware Depository', type: 'Segregated or Commingled', locations: 'Wilmington, Delaware' },
                ].map((dep) => (
                  <div key={dep.name} className="bg-slate-50 rounded-lg p-4">
                    <div className="font-semibold text-[#0F172A] mb-1">{dep.name}</div>
                    <div className="text-xs text-[#64748B]">Storage: {dep.type}</div>
                    <div className="text-xs text-[#64748B]">Locations: {dep.locations}</div>
                  </div>
                ))}
              </div>
            </div>

            <div className="grid md:grid-cols-2 gap-6">
              <div className="card border-t-4 border-t-emerald-400">
                <h3 className="font-bold text-[#0F172A] mb-4">Pros</h3>
                <ul className="space-y-2">
                  {['No setup fee for qualified accounts', 'Buyback guarantee program', 'IRS-approved storage network', 'Strong investor education resources', 'Dedicated account specialist'].map((pro) => (
                    <li key={pro} className="flex gap-2 text-sm text-[#334155]">
                      <span className="text-emerald-500 font-bold flex-shrink-0">✓</span>{pro}
                    </li>
                  ))}
                </ul>
              </div>
              <div className="card border-t-4 border-t-red-300">
                <h3 className="font-bold text-[#0F172A] mb-4">Cons</h3>
                <ul className="space-y-2">
                  {['$10,000 minimum investment', 'Storage fees vary by depository', 'No online account portal'].map((con) => (
                    <li key={con} className="flex gap-2 text-sm text-[#334155]">
                      <span className="text-red-400 font-bold flex-shrink-0">✗</span>{con}
                    </li>
                  ))}
                </ul>
              </div>
            </div>
          </div>

          <div className="space-y-6">
            <div className="card sticky top-24">
              <div className="text-center mb-6">
                <div className={`text-5xl font-bold mb-1 ${scoreColor(provider.score_overall)}`}>
                  {provider.score_overall?.toFixed(1) ?? '—'}
                </div>
                <div className="text-sm text-[#64748B]">Overall Score / 10</div>
                <div className="badge-sky mt-2">#1 Precious Metals IRA 2026</div>
              </div>
              <div className="space-y-3 mb-6">
                {scoreLabels.map((cat) => {
                  const score = provider[cat.key] as number | null
                  return (
                    <div key={cat.key}>
                      <div className="flex justify-between text-xs mb-1">
                        <span className="text-[#64748B]">{cat.label}</span>
                        <span className={`font-semibold ${scoreColor(score)}`}>{score?.toFixed(1) ?? '—'}/10</span>
                      </div>
                      <div className="h-1.5 bg-slate-100 rounded-full overflow-hidden">
                        <div className={`h-full ${scoreBgColor(score)} rounded-full`} style={{ width: `${((score || 0) / 10) * 100}%` }} />
                      </div>
                    </div>
                  )
                })}
              </div>
              <a href={provider.affiliate_url || '#'} target="_blank" rel="noopener noreferrer sponsored"
                className="btn-primary w-full"
                onClick={() => provider.affiliate_url && trackProviderSiteVisit(provider.name, provider.slug, provider.affiliate_url)}>
                Visit {provider.name} →
              </a>
            </div>

            <div className="card">
              <h3 className="font-semibold text-[#0F172A] mb-4 text-sm uppercase tracking-wider">Quick Facts</h3>
              <dl className="space-y-3 text-sm">
                {[[
                  'Founded', provider.founded_year], ['Headquarters', provider.headquarters], ['BBB Rating', provider.bbb_rating], ['Min. Investment', provider.min_investment], ['Storage', 'Brinks / Delaware'], ['Buyback', 'Guaranteed']].map(([k, v]) => (
                  <div key={k} className="flex justify-between">
                    <dt className="text-[#64748B]">{k}</dt>
                    <dd className="font-medium text-[#0F172A]">{v}</dd>
                  </div>
                ))}
              </dl>
            </div>
            <div className="card bg-[#F0F9FF] border-[#BAE6FD]">
              <h3 className="font-semibold text-[#0F172A] mb-3 text-sm uppercase tracking-wider">Compare Providers</h3>
              <ul className="space-y-2 text-sm">
                <li><Link to="/precious-metals-ira/augusta-precious-metals-review" className="text-[#0EA5E9] hover:underline">Augusta Precious Metals Review</Link></li>
                <li><Link to="/precious-metals-ira/goldco-review" className="text-[#0EA5E9] hover:underline">Goldco Review</Link></li>
                <li><Link to="/precious-metals-ira/american-hartford-gold-review" className="text-[#0EA5E9] hover:underline">American Hartford Gold Review</Link></li>
                <li><Link to="/precious-metals-ira/lear-capital-review" className="text-[#0EA5E9] hover:underline">Lear Capital Review</Link></li>
                <li><Link to="/precious-metals-ira/best-companies" className="text-[#0EA5E9] hover:underline font-medium">→ See All Rankings</Link></li>
              </ul>
            </div>
            <div className="card">
              <h3 className="font-semibold text-[#0F172A] mb-3 text-sm uppercase tracking-wider">Related Guides</h3>
              <ul className="space-y-2 text-sm">
                <li><Link to="/precious-metals-ira/401k-to-gold-ira-rollover" className="text-[#0EA5E9] hover:underline">401k to Gold IRA Rollover Guide →</Link></li>
                <li><Link to="/gold-ira-vs-crypto-ira" className="text-[#0EA5E9] hover:underline">Gold IRA vs Crypto IRA →</Link></li>
                <li><Link to="/methodology" className="text-[#0EA5E9] hover:underline">How We Rate Providers →</Link></li>
              </ul>
            </div>
          </div>
        </div>
      </div>

      {/* ── Bottom Line ────────────────────────────────────────────────── */}
      <div className="bg-[#F0F9FF] border-t border-[#BAE6FD]">
        <div className="container-site py-12 max-w-3xl">
          <h2 className="text-2xl font-bold text-[#0F172A] mb-4">Bottom Line: Is Genesis Gold Group Worth It?</h2>
          <p className="text-[#334155] leading-relaxed mb-4">
            Genesis Gold Group is <strong>#1 rated gold IRA provider for 2026</strong>. The combination of white-glove customer service, zero annual fees for qualifying accounts, and a dedicated IRA specialist assigned to every account makes it a strong choice for investors looking for a tax-advantaged retirement account with exposure to this asset class.
          </p>
          <p className="text-[#334155] leading-relaxed mb-4">
            The $10,000 minimum investment is accessible for most investors. Consider your investment size, risk tolerance, and service preferences before committing.
          </p>
          <p className="text-[#334155] leading-relaxed">
            <strong>Best for:</strong> Investors who prioritize personalized service and want a dedicated account specialist throughout the rollover process. If you want to compare alternatives, see our{' '}
            <Link to="/precious-metals-ira/augusta-precious-metals-review" className="text-[#0EA5E9] hover:underline">Augusta Precious Metals review</Link>{' '}and{' '}
            <Link to="/precious-metals-ira/goldco-review" className="text-[#0EA5E9] hover:underline">Goldco review</Link>.
          </p>
        </div>
      </div>

      {/* ── FAQ Section ────────────────────────────────────────────────── */}
      <div className="container-site py-12 max-w-3xl">
        <h2 className="text-2xl font-bold text-[#0F172A] mb-8">Frequently Asked Questions</h2>
        <div className="space-y-4">
          {faqSchema.mainEntity.map((item, i) => (
            <details key={i} className="group border border-slate-200 rounded-lg overflow-hidden">
              <summary className="flex items-center justify-between gap-4 p-5 cursor-pointer bg-white hover:bg-slate-50 transition-colors list-none">
                <span className="font-semibold text-[#0F172A] text-sm leading-snug">{item.name}</span>
                <span className="flex-shrink-0 w-5 h-5 text-[#0EA5E9] transition-transform group-open:rotate-180">
                  <svg viewBox="0 0 20 20" fill="currentColor"><path fillRule="evenodd" d="M5.293 7.293a1 1 0 011.414 0L10 10.586l3.293-3.293a1 1 0 111.414 1.414l-4 4a1 1 0 01-1.414 0l-4-4a1 1 0 010-1.414z" clipRule="evenodd" /></svg>
                </span>
              </summary>
              <div className="px-5 pb-5 text-[#64748B] text-sm leading-relaxed bg-white">
                {item.acceptedAnswer.text}
              </div>
            </details>
          ))}
        </div>
      </div>
      {/* ── Newsletter Signup ─────────────────────────────────────────── */}
      <div className="container-site py-10 max-w-3xl">
        
        {/* Related Links */}

        <div className="mt-10 mb-6">

          <RelatedLinks variant="metals-review" title="Related Guides &amp; Reviews" />

        </div>
<NewsletterSignup />
      </div>
    </>
  )
}
