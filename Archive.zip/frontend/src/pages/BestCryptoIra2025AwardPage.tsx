import AwardDetailPage from './AwardDetailPage'

export default function BestCryptoIra2025AwardPage() {
  return <AwardDetailPage awardSlug="best-crypto-ira-2025" />
}
