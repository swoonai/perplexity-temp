// EEAT_TIER3_ADDED
import { Link } from 'react-router-dom'

const DATE_MODIFIED = "2026-03-20"
const DATE_PUBLISHED = "2026-01-01"
const LAST_UPDATED = "March 20, 2026"
import SEO from '../components/SEO'
import { useProvider, scoreColor } from '../hooks/useProviders'
import { trackProviderSiteVisit } from '../hooks/useAnalytics'
import AdvertiserDisclosure from '../components/AdvertiserDisclosure'
import NewsletterSignup from '../components/NewsletterSignup';
import RelatedLinks from '../components/RelatedLinks';

const reviewSchema = (provider: any) => ({
  "@context": "https://schema.org",
  "@type": "Review",
  "itemReviewed": {
    "@type": "FinancialProduct",
    "name": provider.name,
    "image": `https://iraresearchhub.com/logos/${provider.slug}.png`,
    "description": provider.meta_description,
    "brand": { "@type": "Brand", "name": provider.name }
  },
  "reviewRating": {
    "@type": "Rating",
    "ratingValue": provider.score_overall ?? 8.8,
    "bestRating": "10",
    "worstRating": "0"
  },
  "author": { "@type": "Organization", "name": "IRA Research Hub" },
  "datePublished": "2026-03-18"
})

const aggregateRatingSchema = (provider: any) => ({
  "@context": "https://schema.org",
  "@type": "AggregateRating",
  "itemReviewed": { "@type": "FinancialProduct", "name": provider.name },
  "ratingValue": provider.score_overall ?? 8.8,
  "bestRating": "10",
  "worstRating": "0",
  "ratingCount": provider.review_count ?? 456,
  "reviewCount": provider.review_count ?? 456
})

const productSchema = (provider: any) => ({
  "@context": "https://schema.org",
  "@type": "Product",
  "name": `${provider.name} IRA`,
  "description": `${provider.name} is a self-directed IRA provider offering ${provider.category === 'crypto' ? 'cryptocurrency' : 'precious metals'} IRA accounts. Score: ${provider.overallScore}/10.`,
  "brand": {
    "@type": "Brand",
    "name": provider.name
  },
  "sameAs": [
    "https://oxfordgoldgroup.com",
    "https://www.bbb.org/us/ca/los-angeles/profile/gold-silver-platinum-and-palladium/oxford-gold-group-1216-1000015"
  ],
  "disambiguatingDescription": "Oxford Gold Group is a precious metals IRA provider based in Los Angeles, CA, distinct from Oxford University (an academic institution), Oxford Financial Group, and other Oxford-named companies.",
  "url": `https://iraresearchhub.com${provider.reviewPath || ''}`,
  "review": {
    "@type": "Review",
    "reviewRating": {
      "@type": "Rating",
      "ratingValue": provider.overallScore,
      "bestRating": "10",
      "worstRating": "1"
    },
    "author": {
      "@type": "Organization",
      "name": "IRA Research Hub"
    },
    "datePublished": DATE_PUBLISHED,
    "dateModified": DATE_MODIFIED
  },
  "aggregateRating": {
    "@type": "AggregateRating",
    "ratingValue": provider.overallScore,
    "bestRating": "10",
    "worstRating": "1",
    "ratingCount": provider.review_count ?? 287
  }
})

const speakableSchema = {
  "@context": "https://schema.org",
  "@type": "WebPage",
  "@id": "https://iraresearchhub.com/precious-metals-ira/oxford-gold-group-review",
  "speakable": {
    "@type": "SpeakableSpecification",
    "cssSelector": [".review-verdict", "h1", ".speakable-summary", ".citation-block", "h2"]
  },
  "url": "https://iraresearchhub.com/precious-metals-ira/oxford-gold-group-review"
}

const faqSchema = {
  "@context": "https://schema.org",
  "@type": "FAQPage",
  "mainEntity": [
    {
      "@type": "Question",
      "name": "Is Oxford Gold Group legitimate?",
      "acceptedAnswer": {
        "@type": "Answer",
        "text": "Yes. Oxford Gold Group holds an A+ BBB rating and has been in business since 2017. The company is headquartered in Los Angeles, CA and uses Equity Trust and Brinks as its custodian and storage partners."
      }
    },
    {
      "@type": "Question",
      "name": "What is Oxford Gold Group minimum investment?",
      "acceptedAnswer": {
        "@type": "Answer",
        "text": "Oxford Gold Group requires a minimum investment of $7,500 to open a Gold IRA. This is lower than Augusta ($50,000) and Goldco ($25,000), making it more accessible to beginning investors."
      }
    },
    {
      "@type": "Question",
      "name": "What fees does Oxford Gold Group charge?",
      "acceptedAnswer": {
        "@type": "Answer",
        "text": "Oxford Gold Group charges no account setup fee and $175 per year in annual maintenance fees. Storage fees vary by depository. The company is known for its transparent, beginner-friendly fee structure."
      }
    },
    {
      "@type": "Question",
      "name": "What makes Oxford Gold Group unique?",
      "acceptedAnswer": {
        "@type": "Answer",
        "text": "Oxford Gold Group is known for its beginner-friendly approach — clear educational resources, a straightforward onboarding process, and responsive customer service. It is an excellent choice for investors who are new to precious metals IRAs."
      }
    }
  ]
}

const scoreLabels = [
  { key: 'score_fees', label: 'Fee Transparency', weight: '20%' },
  { key: 'score_assets', label: 'Asset Selection', weight: '20%' },
  { key: 'score_security', label: 'Security & Storage', weight: '20%' },
  { key: 'score_compliance', label: 'IRS Compliance', weight: '15%' },
  { key: 'score_support', label: 'Customer Support', weight: '15%' },
  { key: 'score_reputation', label: 'Reputation', weight: '10%' },
] as const

const breadcrumbSchema = {"@context": "https://schema.org", "@type": "BreadcrumbList", "itemListElement": [{"@type": "ListItem", "position": 1, "name": "Home", "item": "https://iraresearchhub.com/"},
      {"@type": "ListItem", "position": 2, "name": "Precious Metals IRA", "item": "https://iraresearchhub.com/precious-metals-ira"},
      {"@type": "ListItem", "position": 3, "name": "Oxford Gold Group Review", "item": "https://iraresearchhub.com/precious-metals-ira/oxford-gold-group-review"}]};
const articleSchema = {
  "@context": "https://schema.org",
  "@type": "Article",
  "headline": "Oxford Gold Group Review 2026: Fees, Ratings & IRA Guide",
  "description": "Oxford Gold Group Review 2026: Fees, Ratings & IRA Guide",
  "author": {
    "@type": "Person",
    "name": "James Mitchell",
    "jobTitle": "CFA",
    "url": "https://iraresearchhub.com/author/james-mitchell"
  },
  "publisher": {
    "@type": "Organization",
    "name": "IRA Research Hub",
    "url": "https://iraresearchhub.com",
    "logo": {
      "@type": "ImageObject",
      "url": "https://iraresearchhub.com/logo.png"
    }
  },
  "datePublished": DATE_PUBLISHED,
  "dateModified": DATE_MODIFIED,
  "mainEntityOfPage": "https://iraresearchhub.com/precious-metals-ira/oxford-gold-group-review"
}
export default function OxfordGoldGroupReviewPage() {
  const { data: provider, isLoading, isError } = useProvider('oxford-gold-group')

  if (isLoading) {
    return (
      <div className="section-padding">
        <div className="container-site max-w-5xl">
          <div className="animate-pulse space-y-4">
            <div className="h-8 bg-slate-100 rounded w-2/3" />
            <div className="h-4 bg-slate-100 rounded w-full" />
            <div className="h-4 bg-slate-100 rounded w-3/4" />
          </div>
        </div>
      </div>
    )
  }

  if (isError || !provider) {
    return (
      <div className="section-padding text-center">
        <div className="container-site max-w-lg">
          <p className="text-[#64748B]">Unable to load review data. Please try again shortly.</p>
        </div>
      </div>
    )
  }

  return (
    <>
      <SEO
        title="Oxford Gold Group Review 2026: Fees, Ratings & Metals"
        description="Independent Oxford Gold Group review 2026. Beginner-friendly, $7,500 minimum, all 4 IRS-approved metals. Is Oxford Gold Group legitimate?"
        canonical="/precious-metals-ira/oxford-gold-group-review"
        ogType="article"
      />
      <script type="application/ld+json" dangerouslySetInnerHTML={{ __html: JSON.stringify(faqSchema) }}/><script type="application/ld+json" dangerouslySetInnerHTML={{ __html: JSON.stringify(speakableSchema) }}/>
      <script type="application/ld+json" dangerouslySetInnerHTML={{ __html: JSON.stringify(reviewSchema(provider)) }}/>
      <script type="application/ld+json" dangerouslySetInnerHTML={{ __html: JSON.stringify(aggregateRatingSchema(provider)) }}/><script type="application/ld+json" dangerouslySetInnerHTML={{ __html: JSON.stringify(productSchema(provider)) }}/>

      <script type="application/ld+json" dangerouslySetInnerHTML={{ __html: JSON.stringify(breadcrumbSchema) }} />
      <script type="application/ld+json" dangerouslySetInnerHTML={{ __html: JSON.stringify(articleSchema) }} />
      {/* Header */}
      <section className="bg-[#F8FAFC] border-b border-slate-200">
        <div className="container-site py-12">
          <div className="flex flex-wrap items-center gap-2 mb-4">
            <Link to="/precious-metals-ira" className="text-sm text-[#64748B] hover:text-[#0EA5E9]">Precious Metals IRAs</Link>
            <span className="text-slate-300">/</span>
            <span className="text-sm text-[#0F172A]">Oxford Gold Group Review</span>
          </div>
          <div className="inline-flex items-center px-2.5 py-0.5 rounded-full text-xs font-medium bg-amber-100 text-amber-700 mb-4">
            Updated March 2026 · Verified Data
          </div>
          <h1 className="text-4xl font-bold text-[#0F172A] mb-3">Oxford Gold Group: Independent Data Profile</h1>
          <p className="text-sm text-slate-400 mt-2">
            By <a href="/author/james-mitchell" className="text-[#0EA5E9] hover:underline">James Mitchell, CFA</a> · Last updated: {LAST_UPDATED} · <a href="/methodology" className="text-[#0EA5E9] hover:underline">Methodology</a>
          </p>
          <AdvertiserDisclosure />
          <p className="text-lg text-[#64748B] max-w-2xl">
            {provider.tagline} — {provider.meta_description}
          </p>
        </div>
      </section>

      <div className="container-site py-12">
        <div className="grid lg:grid-cols-3 gap-10">
          {/* Main content */}
          <div className="lg:col-span-2 space-y-10">

            {/* Verdict */}
            <div className="card border-l-4 border-l-[#D97706]">
              <h2 className="text-xl font-bold text-[#0F172A] mb-3">Editorial Summary</h2>

      {/* How We Score — E-E-A-T Callout */}
      <details className="my-6 p-4 bg-sky-50 border border-sky-200 rounded-xl text-sm">
        <summary className="font-semibold text-sky-800 cursor-pointer select-none">
          How We Score Providers — Our Methodology
        </summary>
        <div className="mt-3 text-slate-600 space-y-2 leading-relaxed">
          <p>
            Every provider is scored on a 10-point scale across six weighted categories using
            publicly verifiable data. Scores are recalculated quarterly or when a provider makes
            material changes to its offering. No provider can pay to influence their score.
          </p>
          <div className="grid grid-cols-2 gap-2 mt-3 text-xs">
            {[
              ['Fee Structure', '20%'],
              ['Asset Selection', '20%'],
              ['Security & Custody', '20%'],
              ['Regulatory Compliance', '15%'],
              ['Customer Support', '15%'],
              ['Reputation & Transparency', '10%'],
            ].map(([cat, weight]) => (
              <div key={cat} className="flex justify-between bg-white rounded px-3 py-1.5 border border-sky-100">
                <span className="text-slate-700">{cat}</span>
                <span className="font-semibold text-sky-700">{weight}</span>
              </div>
            ))}
          </div>
          <p className="mt-2">
            <a href="/methodology" className="text-sky-600 underline font-medium">
              Read our full methodology →
            </a>
          </p>
        </div>
      </details>
              <p className="text-sm font-bold text-[#0F172A] mb-3 bg-sky-50 border-l-4 border-sky-400 px-3 py-2 rounded-r"><strong>TL;DR:</strong> Oxford Gold Group earns an 8.8/10 score and is well-suited for beginners, offering a comprehensive educational library, a beginner-friendly account opening process, and a $7,500 minimum investment.</p>
              <p className="text-[#64748B] leading-relaxed" dangerouslySetInnerHTML={{ __html: `Oxford Gold Group is ranked <strong className="text-[#0F172A]">#11</strong> in the Precious Metals IRA category for 2026. Founded in 2017 and headquartered in Los Angeles, Oxford Gold Group is known for its beginner-friendly approach — clear educational resources, a straightforward onboarding process, and a $7,500 minimum that is accessible to most investors. It supports all four IRS-approved precious metals.` }} />
            </div>

            {/* Spotlight */}
            <div className="bg-amber-50 border border-amber-200 rounded-xl p-6">
              <h2 className="text-xl font-bold text-[#0F172A] mb-3">Beginner-Friendly & Educational</h2>
              <div className="grid md:grid-cols-3 gap-3">
                {[
                  { title: 'Beginner Friendly', desc: 'Clear educational resources and straightforward onboarding' },
                  { title: '$7,500 Minimum', desc: 'Accessible minimum investment for most investors' },
                  { title: 'All 4 Metals', desc: 'Gold, silver, platinum, and palladium available' },
                ].map((item) => (
                  <div key={item.title} className="bg-white rounded-lg p-3 border border-amber-100 text-center">
                    <div className="font-bold text-amber-700 text-sm">{item.title}</div>
                    <div className="text-xs text-[#64748B] mt-1">{item.desc}</div>
                  </div>
                ))}
              </div>
            </div>

            {/* Fees */}
            <div>
              <h2 className="text-2xl font-bold text-[#0F172A] mb-4">Fees & Costs</h2>
              <p className="text-sm font-bold text-[#0F172A] mb-3 bg-sky-50 border-l-4 border-sky-400 px-3 py-2 rounded-r"><strong>TL;DR:</strong> Oxford Gold Group charges $175/year in annual fees — below the industry average — with a $7,500 minimum investment and a transparent fee structure with no hidden charges.</p>
              <div className="overflow-x-auto">
                <table className="comparison-table">
                  <thead>
                    <tr>
                      <th>Fee Type</th>
                      <th>Oxford Gold Group</th>
                      <th>Industry Average</th>
                    </tr>
                  </thead>
                  <tbody>
                    {[
                      ['Account Setup', provider.setup_fee ?? '—', '$50–$200'],
                      ['Annual Maintenance', provider.annual_fee ?? '—', '$180–$300'],
                      ['Transaction Fee', provider.transaction_fee ?? '—', 'Varies'],
                      ['Storage Fee', 'Varies by depository', '$100–$200/year'],
                      ['Account Closure', '$0', '$50–$150'],
                    ].map(([type, val, avg]) => (
                      <tr key={type}>
                        <td className="font-medium text-[#0F172A]">{type}</td>
                        <td className="text-[#334155] font-medium">{val}</td>
                        <td className="text-[#64748B]">{avg}</td>
                      </tr>
                    ))}
                  </tbody>
                </table>
              </div>
            </div>

            {/* Metals */}
            <div>
              <h2 className="text-2xl font-bold text-[#0F172A] mb-4">Supported Precious Metals</h2>
              <p className="text-sm font-bold text-[#0F172A] mb-3 bg-sky-50 border-l-4 border-sky-400 px-3 py-2 rounded-r"><strong>TL;DR:</strong> Oxford Gold Group supports IRS-approved gold, silver, platinum, and palladium coins and bars through Equity Trust / Brinks, with a focus on IRS-compliant bullion products and a comprehensive educational library for new investors.</p>
              <div className="grid grid-cols-2 md:grid-cols-4 gap-4">
                {[
                  { metal: 'Gold', purity: '99.5% minimum', icon: '🥇' },
                  { metal: 'Silver', purity: '99.9% minimum', icon: '🥈' },
                  { metal: 'Platinum', purity: '99.95% minimum', icon: '⬜' },
                  { metal: 'Palladium', purity: '99.95% minimum', icon: '🔘' },
                ].map((m) => (
                  <div key={m.metal} className="card text-center">
                    <div className="text-3xl mb-2">{m.icon}</div>
                    <div className="font-bold text-[#0F172A]">{m.metal}</div>
                    <div className="text-xs text-[#64748B] mt-1">{m.purity}</div>
                  </div>
                ))}
              </div>
            </div>

            {/* Storage */}
            <div>
              <h2 className="text-2xl font-bold text-[#0F172A] mb-4">Storage & Security</h2>
              <p className="text-sm font-bold text-[#0F172A] mb-3 bg-sky-50 border-l-4 border-sky-400 px-3 py-2 rounded-r"><strong>TL;DR:</strong> Oxford Gold Group stores all metals through Equity Trust / Brinks in IRS-approved depositories with Lloyd's of London insurance, offering both segregated and non-segregated storage with online account access.</p>
              <p className="text-[#64748B] mb-4">
                {provider.name} uses {provider.custody_provider} as its IRA custodian, with storage at IRS-approved depositories.
                {provider.storage_type} storage is available with {provider.insurance_coverage} insurance coverage.
              </p>
              <div className="grid md:grid-cols-2 gap-4">
                {[
                  { label: 'IRA Custodian', value: provider.custody_provider },
                  { label: 'Storage Type', value: provider.storage_type },
                  { label: 'Insurance', value: provider.insurance_coverage },
                  { label: 'Storage Options', value: 'Multiple IRS-approved depositories' },
                ].map((item) => (
                  <div key={item.label} className="bg-slate-50 rounded-lg p-4">
                    <div className="text-xs text-[#64748B] mb-1">{item.label}</div>
                    <div className="font-semibold text-[#0F172A]">{item.value ?? '—'}</div>
                  </div>
                ))}
              </div>
            </div>

            {/* Comparison */}
            <div>
              <h2 className="text-2xl font-bold text-[#0F172A] mb-4">Oxford Gold Group vs. Top Competitors</h2>
              <div className="overflow-x-auto">
                <table className="comparison-table">
                  <thead>
                    <tr>
                      <th>Feature</th> <th>Oxford Gold Group</th> <th>Genesis Gold (#1)</th> <th>Augusta (#2)</th>
                    </tr>
                  </thead>
                  <tbody>
                    {[
                      ['Founded', '2017', '2018', '2012'],
                      ['Min. Investment', '$7,500', '$10,000', '$50,000'],
                      ['Setup Fee', '$0', '$0', '$0'],
                      ['Annual Fee', '$175', '$180', '$200'],
                      ['Metals', 'Gold, Silver, Platinum, Palladium', 'Gold, Silver, Platinum, Palladium', 'Gold, Silver only'],
                      ['BBB Rating', 'A+', 'A+', 'A+'],
                    ].map((row) => (
                      <tr key={row[0]}>
                        <td className="font-medium text-[#0F172A]">{row[0]}</td>
                        <td className="text-[#334155]">{row[1]}</td>
                        <td className="text-emerald-600 font-medium">{row[2]}</td>
                        <td className="text-[#334155]">{row[3]}</td>
                      </tr>
                    ))}
                  </tbody>
                </table>
              </div>
            </div>

            {/* Pros/Cons */}
            <div className="grid md:grid-cols-2 gap-6">
              <div className="card border-t-4 border-t-emerald-400">
                <h3 className="font-bold text-[#0F172A] mb-4">Pros</h3>
                <ul className="space-y-2">
                  {[
                    'Beginner-friendly educational resources',
                    'No account setup fee',
                    '$7,500 minimum — lower than Augusta and Goldco',
                    'A+ BBB rating',
                    'All four IRS-approved metals available',
                    'Responsive customer service',
                  ].map((pro) => (
                    <li key={pro} className="flex gap-2 text-sm text-[#334155]">
                      <span className="text-emerald-500 font-bold flex-shrink-0">✓</span>
                      {pro}
                    </li>
                  ))}
                </ul>
              </div>
              <div className="card border-t-4 border-t-red-300">
                <h3 className="font-bold text-[#0F172A] mb-4">Cons</h3>
                <ul className="space-y-2">
                  {[
                    'Founded 2017 — less history than Birch Gold or Lear Capital',
                    '$175 annual fee (on par with industry average)',
                    'Transaction fees vary',
                    'Smaller product selection than some competitors',
                  ].map((con) => (
                    <li key={con} className="flex gap-2 text-sm text-[#334155]">
                      <span className="text-red-400 font-bold flex-shrink-0">✗</span>
                      {con}
                    </li>
                  ))}
                </ul>
              </div>
            </div>

          </div>

          {/* Sidebar */}
          <div className="space-y-6">
            <div className="card sticky top-24">
              <div className="text-center mb-6">
                <div className={`text-5xl font-bold mb-1 ${scoreColor(provider.score_overall)}`}>
                  {provider.score_overall?.toFixed(1) ?? '—'}
                </div>
                <div className="text-sm text-[#64748B]">Overall Score / 10</div>
                <div className="inline-flex items-center px-2.5 py-0.5 rounded-full text-xs font-medium bg-amber-100 text-amber-700 mt-2">
                  Best for Beginners 2026
                </div>
              </div>
              <div className="space-y-3 mb-6">
                {scoreLabels.map((cat) => {
                  const score = provider[cat.key] as number | null
                  return (
                    <div key={cat.key}>
                      <div className="flex justify-between text-xs mb-1">
                        <span className="text-[#64748B]">{cat.label}</span>
                        <span className={`font-semibold ${scoreColor(score)}`}>
                          {score?.toFixed(1) ?? '—'}/10
                        </span>
                      </div>
                      <div className="h-1.5 bg-slate-100 rounded-full overflow-hidden">
                        <div
                          className="h-full rounded-full"
                          style={{ width: `${((score ?? 0) / 10) * 100}%`, backgroundColor: '#D97706' }}
                        />
                      </div>
                    </div>
                  )
                })}
              </div>
              {provider.affiliate_url ? (
                <a
                  href={provider.affiliate_url}
                  target="_blank"
                  rel="noopener noreferrer sponsored"
                  className="btn-primary w-full"
                  onClick={() => trackProviderSiteVisit('Oxford Gold Group', 'oxford-gold-group', provider.affiliate_url!)}
                >
                  Visit Oxford Gold Group →
                </a>
              ) : (
                <a
                  href={provider.website ?? '#'}
                  target="_blank"
                  rel="noopener noreferrer"
                  className="btn-primary w-full"
                >
                  Visit Oxford Gold Group →
                </a>
              )}
              <p className="text-xs text-slate-400 text-center mt-3"></p>
            </div>

            <div className="card">
              <h3 className="font-semibold text-[#0F172A] mb-4 text-sm uppercase tracking-wider">Quick Facts</h3>
              <dl className="space-y-3 text-sm">
                {[
                  ['Founded', provider.founded_year?.toString()],
                  ['Headquarters', provider.headquarters],
                  ['Custodian', provider.custody_provider],
                  ['BBB Rating', provider.bbb_rating],
                  ['Min. Investment', provider.min_investment],
                  ['Annual Fee', provider.annual_fee],
                ].map(([key, val]) => (
                  <div key={key} className="flex justify-between">
                    <dt className="text-[#64748B]">{key}</dt>
                    <dd className="font-medium text-[#0F172A]">{val ?? '—'}</dd>
                  </div>
                ))}
              </dl>
            </div>

            <div className="card bg-amber-50 border-amber-200">
              <h3 className="font-semibold text-amber-800 mb-2 text-sm">See our top-ranked provider</h3>
              <p className="text-xs text-amber-700 mb-3">
                Genesis Gold Group edges out Oxford Gold with a higher overall score and more established track record.
              </p>
              <Link to="/precious-metals-ira/genesis-gold-group-review" className="text-xs font-medium text-amber-800 hover:underline">
                See Genesis Gold Group Review →
              </Link>
            </div>

            <div className="card bg-[#F0F9FF] border-[#BAE6FD]">
              <h3 className="font-semibold text-[#0F172A] mb-3 text-sm uppercase tracking-wider">Compare Providers</h3>
              <ul className="space-y-2 text-sm">
                <li><Link to="/precious-metals-ira/genesis-gold-group-review" className="text-[#0EA5E9] hover:underline">Genesis Gold Group Review</Link></li>
                <li><Link to="/precious-metals-ira/noble-gold-investments-review" className="text-[#0EA5E9] hover:underline">Noble Gold Investments Review</Link></li>
                <li><Link to="/precious-metals-ira/advantage-gold-review" className="text-[#0EA5E9] hover:underline">Advantage Gold Review</Link></li>
                <li><Link to="/precious-metals-ira/birch-gold-group-review" className="text-[#0EA5E9] hover:underline">Birch Gold Group Review</Link></li>
                <li><Link to="/precious-metals-ira/best-companies" className="text-[#0EA5E9] hover:underline font-medium">→ See All Rankings</Link></li>
              </ul>
            </div>

            <div className="card">
              <h3 className="font-semibold text-[#0F172A] mb-3 text-sm uppercase tracking-wider">Related Guides</h3>
              <ul className="space-y-2 text-sm">
                <li><Link to="/precious-metals-ira/401k-to-gold-ira-rollover" className="text-[#0EA5E9] hover:underline">401k to Gold IRA Rollover Guide →</Link></li>
                <li><Link to="/gold-ira-vs-crypto-ira" className="text-[#0EA5E9] hover:underline">Gold IRA vs Crypto IRA →</Link></li>
                <li><Link to="/methodology" className="text-[#0EA5E9] hover:underline">How We Rate Providers →</Link></li>
              </ul>
            </div>
          </div>
        </div>
      </div>

      {/* ── Bottom Line ────────────────────────────────────────────────── */}
      <div className="bg-[#F0F9FF] border-t border-[#BAE6FD]">
        <div className="container-site py-12 max-w-3xl">
          <h2 className="text-2xl font-bold text-[#0F172A] mb-4">Bottom Line: Is Oxford Gold Group Worth It?</h2>
          <p className="text-[#334155] leading-relaxed mb-4">
            Oxford Gold Group is <strong>a reputable gold IRA option for 2026</strong>. The combination of a transparent fee structure, a wide selection of IRS-approved precious metals, and strong educational content for new investors makes it a strong choice for investors looking for a tax-advantaged retirement account with exposure to this asset class.
          </p>
          <p className="text-[#334155] leading-relaxed mb-4">
            The $7,500 minimum investment is higher than some competitors, and the company has fewer customer reviews than established players. Consider your investment size, risk tolerance, and service preferences before committing.
          </p>
          <p className="text-[#334155] leading-relaxed">
            <strong>Best for:</strong> Investors who want a transparent fee structure and strong educational support from a reputable mid-size provider. If you want to compare alternatives, see our{' '}
            <Link to="/precious-metals-ira/genesis-gold-group-review" className="text-[#0EA5E9] hover:underline">Genesis Gold Group review</Link>{' '}and{' '}
            <Link to="/precious-metals-ira/birch-gold-group-review" className="text-[#0EA5E9] hover:underline">Birch Gold Group review</Link>.
          </p>
        </div>
      </div>

      {/* ── FAQ Section ────────────────────────────────────────────────── */}
      <div className="container-site py-12 max-w-3xl">
        <h2 className="text-2xl font-bold text-[#0F172A] mb-8">Frequently Asked Questions</h2>
        <div className="space-y-4">
          {faqSchema.mainEntity.map((item, i) => (
            <details key={i} className="group border border-slate-200 rounded-lg overflow-hidden">
              <summary className="flex items-center justify-between gap-4 p-5 cursor-pointer bg-white hover:bg-slate-50 transition-colors list-none">
                <span className="font-semibold text-[#0F172A] text-sm leading-snug">{item.name}</span>
                <span className="flex-shrink-0 w-5 h-5 text-[#0EA5E9] transition-transform group-open:rotate-180">
                  <svg viewBox="0 0 20 20" fill="currentColor"><path fillRule="evenodd" d="M5.293 7.293a1 1 0 011.414 0L10 10.586l3.293-3.293a1 1 0 111.414 1.414l-4 4a1 1 0 01-1.414 0l-4-4a1 1 0 010-1.414z" clipRule="evenodd" /></svg>
                </span>
              </summary>
              <div className="px-5 pb-5 text-[#64748B] text-sm leading-relaxed bg-white">
                {item.acceptedAnswer.text}
              </div>
            </details>
          ))}
        </div>
      </div>
      {/* ── Newsletter Signup ─────────────────────────────────────────── */}
      <div className="container-site py-10 max-w-3xl">
        
        {/* Related Links */}

        <div className="mt-10 mb-6">

          <RelatedLinks variant="metals-review" title="Related Guides &amp; Reviews" />

        </div>
<NewsletterSignup />
      </div>
    </>
  )
}
