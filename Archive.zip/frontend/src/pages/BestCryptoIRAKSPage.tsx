import StateGuideTemplate from '../components/StateGuideTemplate'

export default function BestCryptoIRAKSPage() {
  return (
    <StateGuideTemplate
      stateName="Kansas"
      stateAbbr="KS"
      slug="kansas"
    />
  )
}
