import { Link } from 'react-router-dom'
import SEO from '../components/SEO'
import NewsletterSignup from '../components/NewsletterSignup';

const GUIDES = [
  {
    category: 'Self-Directed IRA Fundamentals',
    items: [
      {
        title: 'What Is a Self-Directed IRA? Complete Beginner\'s Guide (2026)',
        description: 'IRS rules, eligible asset classes, prohibited transactions, custodian roles, and how to evaluate providers independently.',
        href: '/guides/what-is-self-directed-ira',
        badge: 'Foundational',
        readTime: '18 min read',
      },
      {
        title: 'How to Research SDIRA Providers: An Independent Framework',
        description: 'A step-by-step methodology for evaluating custodians using fee transparency, regulatory history, and operational track record.',
        href: '/guides/how-to-research-sdira-providers',
        badge: 'Due Diligence',
        readTime: '14 min read',
      },
      {
        title: 'IRA Rollover Rules: What the IRS Actually Says (2026)',
        description: 'The 60-day rule, one-rollover-per-year limit, direct vs. indirect transfers, and tax withholding requirements explained.',
        href: '/guides/ira-rollover-rules',
        badge: 'IRS Rules',
        readTime: '12 min read',
      },
      {
        title: 'IRA Contribution Limits & Eligibility Rules (2026)',
        description: 'COLA-adjusted contribution caps, income phase-outs for Roth IRAs, catch-up contributions, and spousal IRA rules.',
        href: '/guides/ira-contribution-limits-2026',
        badge: '2026 Update',
        readTime: '10 min read',
      },
      {
        title: 'Required Minimum Distributions: Rules & Strategies (2026)',
        description: 'SECURE 2.0 changes, RMD age thresholds, calculation methods, Roth IRA exemptions, and penalty avoidance strategies.',
        href: '/guides/required-minimum-distributions-2026',
        badge: '2026 Update',
        readTime: '13 min read',
      },
      {
        title: 'IRA Tax Strategies for High-Income Earners',
        description: 'Backdoor Roth conversions, mega backdoor Roth, tax-loss harvesting inside IRAs, and UBIT considerations for alternative assets.',
        href: '/guides/ira-tax-strategies-high-income',
        badge: 'Tax Strategy',
        readTime: '16 min read',
      },
    ],
  },
  {
    category: 'Cryptocurrency in IRAs',
    items: [
      {
        title: 'Crypto in Retirement Accounts: Rules, Risks & Tax Implications',
        description: 'How cryptocurrency is treated inside IRAs, IRS Notice 2014-21, UBIT exposure, and the structural risks unique to crypto custodians.',
        href: '/guides/crypto-in-retirement',
        badge: 'Crypto',
        readTime: '15 min read',
      },
      {
        title: 'Crypto IRA vs. Buying Crypto Directly: A Structural Comparison',
        description: 'Tax treatment, custody models, fee structures, and liquidity differences between holding crypto in an IRA versus a personal wallet.',
        href: '/guides/crypto-ira-vs-buying-directly',
        badge: 'Comparison',
        readTime: '11 min read',
      },
    ],
  },
  {
    category: 'Precious Metals in IRAs',
    items: [
      {
        title: 'Precious Metals in IRAs: Gold, Silver & Diversification',
        description: 'IRS fineness requirements, approved depositories, storage rules, prohibited collectibles, and the real cost structure of precious metals IRAs.',
        href: '/guides/precious-metals-in-ira',
        badge: 'Gold & Silver',
        readTime: '14 min read',
      },
      {
        title: 'Gold IRA vs. Gold ETF: Structural Differences Explained',
        description: 'Ownership structure, counterparty risk, expense ratios, liquidity, and tax treatment compared across physical gold IRAs and ETF alternatives.',
        href: '/guides/gold-ira-vs-gold-etf',
        badge: 'Comparison',
        readTime: '12 min read',
      },
    ],
  },
]

const BADGE_COLORS: Record<string, string> = {
  Foundational: 'bg-indigo-100 text-indigo-700',
  'Due Diligence': 'bg-violet-100 text-violet-700',
  'IRS Rules': 'bg-amber-100 text-amber-700',
  '2026 Update': 'bg-emerald-100 text-emerald-700',
  'Tax Strategy': 'bg-sky-100 text-sky-700',
  Crypto: 'bg-blue-100 text-blue-700',
  Comparison: 'bg-slate-100 text-slate-600',
  'Gold & Silver': 'bg-yellow-100 text-yellow-700',
}

export default function GuidesIndexPage() {
  return (
    <>
      <SEO
        title="Educational Guides — IRA Research Hub"
        description="Independent, IRS-cited educational guides on self-directed IRAs, crypto in retirement accounts, precious metals IRA rules, rollover regulations, and tax strategies. Not financial advice."
        canonical="/guides"
        ogType="website"
      />

      {/* Hero */}
      <div className="bg-[#F8FAFC] border-b border-slate-200 py-10">
        <div className="container-site max-w-5xl">
          <p className="text-xs font-semibold text-slate-400 uppercase tracking-wider mb-3">IRA Research Hub</p>
          <h1 className="text-4xl font-bold text-[#0F172A] mb-4 leading-tight">
            Educational Guides
          </h1>
          <p className="text-lg text-[#64748B] max-w-3xl">
            Independent, IRS-cited guides on self-directed IRAs, alternative asset rules, rollover regulations, and tax strategy. All content is for educational purposes only and does not constitute financial or legal advice.
          </p>
        </div>
      </div>

      {/* Guide categories */}
      <div className="container-site max-w-5xl py-12 space-y-14">
        {GUIDES.map((section) => (
          <section key={section.category}>
            <h2 className="text-xl font-bold text-[#0F172A] mb-6 pb-3 border-b border-slate-200">
              {section.category}
            </h2>
            <div className="grid gap-5 sm:grid-cols-2">
              {section.items.map((guide) => (
                <Link
                  key={guide.href}
                  to={guide.href}
                  className="group block bg-white border border-slate-200 rounded-xl p-5 hover:border-sky-400 hover:shadow-md transition-all duration-150"
                >
                  <div className="flex items-start justify-between gap-3 mb-3">
                    <span
                      className={`inline-flex items-center px-2.5 py-0.5 rounded-full text-xs font-medium ${BADGE_COLORS[guide.badge] ?? 'bg-slate-100 text-slate-600'}`}
                    >
                      {guide.badge}
                    </span>
                    <span className="text-xs text-slate-400 whitespace-nowrap">{guide.readTime}</span>
                  </div>
                  <h3 className="text-base font-semibold text-[#0F172A] mb-2 group-hover:text-sky-700 transition-colors leading-snug">
                    {guide.title}
                  </h3>
                  <p className="text-sm text-slate-500 leading-relaxed">
                    {guide.description}
                  </p>
                </Link>
              ))}
            </div>
          </section>
        ))}

        {/* Disclaimer */}
        <div className="bg-amber-50 border border-amber-200 rounded-xl p-5 text-sm text-amber-800">
          <strong>Educational Content Disclaimer:</strong> All guides on this page are provided for informational purposes only. Nothing on IRA Research Hub constitutes financial, tax, or legal advice. Consult a qualified professional before making investment decisions. Alternative assets in IRAs carry significant risks including illiquidity, potential loss of principal, and complex IRS compliance requirements.
        </div>
      </div>
      {/* ── Newsletter Signup ─────────────────────────────────────────── */}
      <div className="container-site py-10 max-w-3xl">
        <NewsletterSignup />
      </div>
    </>
  )
}
