import StateGuideTemplate from '../components/StateGuideTemplate'

export default function BestCryptoIRAMAPage() {
  return (
    <StateGuideTemplate
      stateName="Massachusetts"
      stateAbbr="MA"
      slug="massachusetts"
    />
  )
}
