import StateGuideTemplate from '../components/StateGuideTemplate'

export default function BestCryptoIRASDPage() {
  return (
    <StateGuideTemplate
      stateName="South Dakota"
      stateAbbr="SD"
      slug="south-dakota"
    />
  )
}
