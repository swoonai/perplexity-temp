import StateGuideTemplate from '../components/StateGuideTemplate'

export default function BestCryptoIRARIPage() {
  return (
    <StateGuideTemplate
      stateName="Rhode Island"
      stateAbbr="RI"
      slug="rhode-island"
    />
  )
}
