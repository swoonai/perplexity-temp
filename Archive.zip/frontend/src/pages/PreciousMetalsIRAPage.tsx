import { Link } from 'react-router-dom'
import { useRankedProviders, scoreColor } from '../hooks/useProviders'
import SEO from '../components/SEO'
import NewsletterSignup from '../components/NewsletterSignup';
import RelatedLinks from '../components/RelatedLinks';

const providerLinks = [
  {
    slug: 'genesis-gold-group',
    path: '/precious-metals-ira/genesis-gold-group-review',
    rank: '#1',
    badge: 'Top-Ranked',
    badgeColor: 'bg-amber-100 text-amber-700',
  },
  {
    slug: 'augusta-precious-metals',
    path: '/precious-metals-ira/augusta-precious-metals-review',
    rank: '#2',
    badge: 'Best Customer Education',
    badgeColor: 'bg-slate-100 text-slate-700',
  },
  {
    slug: 'birch-gold-group',
    path: '/precious-metals-ira/birch-gold-group-review',
    rank: '#3',
    badge: 'Notable for Diversified Metals',
    badgeColor: 'bg-emerald-100 text-emerald-700',
  },
]

export default function PreciousMetalsIRAPage() {
  const { data: providers } = useRankedProviders('precious_metals', 10)

  return (
    <div className="section-padding">
      <SEO
        title="Best Precious Metals IRA 2026"
        description="Independent, data-driven analysis of the top gold and silver IRA providers. Compare fees, storage options, buyback programs, and custodian quality to find the best precious metals IRA."
        canonical="/precious-metals-ira"
      />
      <div className="container-site">
        {/* Hero */}
        <div className="mb-10">
          <div className="inline-flex items-center px-2.5 py-0.5 rounded-full text-xs font-medium bg-amber-100 text-amber-700 mb-4">
            Updated March 2026
          </div>
          <h1 className="text-4xl font-bold text-[#0F172A] mb-4">2026 Precious Metals IRA Provider Comparison & Independent Analysis</h1>
          <p className="text-lg text-[#64748B] max-w-2xl">
            Independent, data-driven analysis of the top gold, silver, platinum, and palladium IRA 
            providers. We evaluate fees, storage options, IRS compliance, and customer service to 
            help you protect your retirement with physical precious metals.
          </p>
        </div>

        {/* What is a Precious Metals IRA */}
        <div className="bg-amber-50 border border-amber-200 rounded-xl p-6 mb-10">
          <h2 className="text-lg font-bold text-[#0F172A] mb-3">What is a Precious Metals IRA?</h2>
          <p className="text-[#64748B] text-sm leading-relaxed">
            A Precious Metals IRA (also called a Gold IRA or Self-Directed IRA) allows you to hold 
            IRS-approved physical gold, silver, platinum, and palladium within a tax-advantaged 
            retirement account. The metals must meet IRS purity standards and be stored in an 
            approved depository — you cannot take personal possession while the account is active.
          </p>
          <div className="grid md:grid-cols-4 gap-3 mt-4">
            {[
              { metal: 'Gold', purity: '99.5%+ pure', icon: '🥇' },
              { metal: 'Silver', purity: '99.9%+ pure', icon: '🥈' },
              { metal: 'Platinum', purity: '99.95%+ pure', icon: '⬜' },
              { metal: 'Palladium', purity: '99.95%+ pure', icon: '🔘' },
            ].map((m) => (
              <div key={m.metal} className="bg-white rounded-lg p-3 text-center border border-amber-100">
                <div className="text-2xl mb-1">{m.icon}</div>
                <div className="font-bold text-[#0F172A] text-sm">{m.metal}</div>
                <div className="text-xs text-[#64748B]">{m.purity}</div>
              </div>
            ))}
          </div>
        </div>

        {/* Provider Cards */}
        <div className="space-y-4 mb-12">
          {providerLinks.map((pl) => {
            const provider = providers?.providers?.find((p) => p.slug === pl.slug)
            return (
              <Link
                key={pl.slug}
                to={pl.path}
                className="card hover:shadow-elevated transition-all flex flex-wrap md:flex-nowrap items-center gap-4 group"
              >
                <div className="flex-shrink-0 w-10 h-10 rounded-full bg-[#D97706] text-white flex items-center justify-center font-bold text-sm">
                  {pl.rank}
                </div>
                <div className="flex-1 min-w-0">
                  <div className="flex flex-wrap items-center gap-2 mb-1">
                    <h3 className="font-bold text-[#0F172A] group-hover:text-[#D97706] transition-colors">
                      {provider?.name ?? pl.slug}
                    </h3>
                    <span className={`inline-flex items-center px-2 py-0.5 rounded-full text-xs font-medium ${pl.badgeColor}`}>
                      {pl.badge}
                    </span>
                  </div>
                  <p className="text-sm text-[#64748B]">
                    {provider?.tagline ?? 'Full review with fees, storage, and metals analysis'}
                  </p>
                  {provider && (
                    <div className="flex flex-wrap gap-4 mt-2 text-xs text-[#64748B]">
                      <span>Min: {provider.min_investment}</span>
                      <span>Annual: {provider.annual_fee}</span>
                      <span>Founded: {provider.founded_year}</span>
                      <span>BBB: {provider.bbb_rating}</span>
                    </div>
                  )}
                </div>
                {provider && (
                  <div className="flex-shrink-0 text-right">
                    <div className={`text-2xl font-bold ${scoreColor(provider.score_overall)}`}>
                      {provider.score_overall?.toFixed(1)}
                    </div>
                    <div className="text-xs text-[#64748B]">/ 10</div>
                  </div>
                )}
                <div className="flex-shrink-0 text-[#D97706] font-medium text-sm">
                  Read Review →
                </div>
              </Link>
            )
          })}
        </div>

        {/* How to Choose */}
        <div className="mb-12">
          <h2 className="text-2xl font-bold text-[#0F172A] mb-6">How to Choose a Precious Metals IRA</h2>
          <div className="grid md:grid-cols-3 gap-6">
            {[
              {
                title: 'Minimum Investment',
                desc: 'Most providers require $10,000–$50,000 to open an account. Augusta Precious Metals requires $50,000 — the highest in the industry.',
                icon: '💰',
              },
              {
                title: 'Storage Options',
                desc: 'Look for IRS-approved depositories with both segregated (your metals stored separately) and commingled options. Segregated storage costs more but offers greater security.',
                icon: '🏦',
              },
              {
                title: 'Metals Selection',
                desc: 'If you want all four IRS-approved metals (gold, silver, platinum, palladium), confirm the provider offers them. Augusta only offers gold and silver.',
                icon: '🥇',
              },
              {
                title: 'Fee Structure',
                desc: 'Watch for setup fees, annual maintenance fees, storage fees, and transaction fees. These can add up significantly over a long investment horizon.',
                icon: '📊',
              },
              {
                title: 'Custodian Quality',
                desc: 'Your IRA custodian holds legal title to your metals. Look for established custodians like Equity Trust or STRATA with strong regulatory track records.',
                icon: '🔒',
              },
              {
                title: 'Buyback Program',
                desc: 'A buyback guarantee means the company will repurchase your metals when you want to liquidate. Genesis Gold Group offers this — not all providers do.',
                icon: '🔄',
              },
            ].map((item) => (
              <div key={item.title} className="card">
                <div className="text-2xl mb-3">{item.icon}</div>
                <h3 className="font-bold text-[#0F172A] mb-2">{item.title}</h3>
                <p className="text-sm text-[#64748B] leading-relaxed">{item.desc}</p>
              </div>
            ))}
          </div>
        </div>

        {/* Hub Links */}
        <div className="grid md:grid-cols-2 gap-6 max-w-3xl">
          <Link to="/methodology" className="card hover:shadow-elevated transition-all">
            <h3 className="font-bold text-[#0F172A] mb-2">Our Methodology</h3>
            <p className="text-[#64748B] text-sm">How we score and rank precious metals IRA providers — fully transparent criteria.</p>
          </Link>
          <Link to="/crypto-ira" className="card hover:shadow-elevated transition-all">
            <h3 className="font-bold text-[#0F172A] mb-2">Also Considering Crypto IRAs?</h3>
            <p className="text-[#64748B] text-sm">Compare the top cryptocurrency IRA providers for Bitcoin and Ethereum exposure.</p>
          </Link>
        </div>
      </div>
      {/* ── Newsletter Signup ─────────────────────────────────────────── */}
      <div className="container-site py-10 max-w-3xl">
                {/* Related Links */}
        <div className="mt-10 mb-6">
          <RelatedLinks variant="metals-guide" title="Related Guides &amp; Reviews" />
        </div>
        <NewsletterSignup />
      </div>
    </div>
  )
}
