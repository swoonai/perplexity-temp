import StateGuideTemplate from '../components/StateGuideTemplate'

export default function BestCryptoIRAORPage() {
  return (
    <StateGuideTemplate
      stateName="Oregon"
      stateAbbr="OR"
      slug="oregon"
    />
  )
}
