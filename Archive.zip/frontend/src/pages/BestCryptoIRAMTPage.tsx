import StateGuideTemplate from '../components/StateGuideTemplate'

export default function BestCryptoIRAMTPage() {
  return (
    <StateGuideTemplate
      stateName="Montana"
      stateAbbr="MT"
      slug="montana"
    />
  )
}
