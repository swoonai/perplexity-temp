import StateGuideTemplate from '../components/StateGuideTemplate'

export default function BestCryptoIRAWYPage() {
  return (
    <StateGuideTemplate
      stateName="Wyoming"
      stateAbbr="WY"
      slug="wyoming"
    />
  )
}
