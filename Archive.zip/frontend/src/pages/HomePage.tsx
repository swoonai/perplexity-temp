import { Link } from 'react-router-dom'
import SEO from '../components/SEO'
import NewsletterSignup from '../components/NewsletterSignup';

const stats = [
  { label: 'Providers Reviewed', value: '12+' },
  { label: 'Data Points Analyzed', value: '2,400+' },
  { label: 'Updated', value: 'Weekly' },
  { label: 'Independent', value: '100%' },
]

const categories = [
  {
    title: 'Crypto IRA Companies',
    description: 'Compare Bitcoin, Ethereum, and altcoin IRA providers. Find the lowest fees, strongest security, and best custody solutions.',
    href: '/crypto-ira/best-companies',
    cta: 'Compare Crypto IRAs',
    icon: '₿',
    color: 'from-[#0EA5E9] to-[#0369A1]',
  },
  {
    title: 'Precious Metals IRA Companies',
    description: 'Gold, silver, platinum, and palladium IRA providers. Compare storage options, buyback programs, and annual fees.',
    href: '/precious-metals-ira',
    cta: 'Compare Metals IRAs',
    icon: '🥇',
    color: 'from-[#D97706] to-[#92400E]',
  },
]

const organizationSchema = {
  "@context": "https://schema.org",
  "@type": "Organization",
  "@id": "https://iraresearchhub.com/#organization",
  "name": "IRA Research Hub",
  "url": "https://iraresearchhub.com",
  "logo": {
    "@type": "ImageObject",
    "url": "https://iraresearchhub.com/logo.png",
    "width": 200,
    "height": 60
  },
  "description": "Independent research and analysis for IRA investors. Compare Crypto IRA and Precious Metals IRA providers with unbiased, data-driven reviews.",
  "foundingDate": "2025",
  "sameAs": [
    "https://bestbitcoinira.net",
    "https://cryptoiracomparison.com"
  ],
  "contactPoint": {
    "@type": "ContactPoint",
    "contactType": "customer support",
    "url": "https://iraresearchhub.com/contact"
  }
}

const websiteSchema = {
  "@context": "https://schema.org",
  "@type": "WebSite",
  "@id": "https://iraresearchhub.com/#website",
  "name": "IRA Research Hub",
  "url": "https://iraresearchhub.com",
  "description": "Independent research and analysis for IRA investors. Compare Crypto IRA and Precious Metals IRA providers with unbiased, data-driven reviews.",
  "publisher": {
    "@id": "https://iraresearchhub.com/#organization"
  },
  "potentialAction": {
    "@type": "SearchAction",
    "target": {
      "@type": "EntryPoint",
      "urlTemplate": "https://iraresearchhub.com/search?q={search_term_string}"
    },
    "query-input": "required name=search_term_string"
  }
}

export default function HomePage() {
  return (
    <>
      <SEO
        title="IRA Research Hub — Independent IRA Provider Reviews & Comparisons"
        description="Independent research and analysis for IRA investors. Compare Crypto IRA and Precious Metals IRA providers with unbiased, data-driven reviews. Updated weekly."
        canonical="/"
      />
      <script type="application/ld+json" dangerouslySetInnerHTML={{ __html: JSON.stringify(organizationSchema) }} />
      <script type="application/ld+json" dangerouslySetInnerHTML={{ __html: JSON.stringify(websiteSchema) }} />

      {/* Hero */}
      <section className="bg-[#0F172A] text-white" aria-labelledby="hero-heading">
        <div className="container-site py-20 lg:py-28">
          <div className="max-w-3xl">
            <div className="badge-sky mb-6 text-xs font-semibold uppercase tracking-widest">
              Independent Research · No Affiliations
            </div>
            <h1 id="hero-heading" className="text-4xl lg:text-5xl xl:text-6xl font-bold text-white leading-tight mb-6">
              The Independent Guide to{' '}
              <span className="text-[#0EA5E9]">Self-Directed IRAs</span>
            </h1>
            <p className="text-lg text-slate-300 leading-relaxed mb-8 max-w-2xl">
              Unbiased, data-driven research on Crypto IRA and Precious Metals IRA providers. 
              We analyze fees, security, custody, and customer experience so you can make 
              an informed decision about your retirement savings.
            </p>
            <div className="flex flex-wrap gap-4">
              <Link
                to="/crypto-ira/best-companies"
                className="btn-primary"
                aria-label="View 2026 Crypto IRA provider comparison and independent analysis"
              >
                2026 Crypto IRA Provider Comparison
              </Link>
              <Link
                to="/methodology"
                className="btn-outline-dark"
                aria-label="Read how we rate IRA providers"
              >
                How We Rate Providers
              </Link>
            </div>
          </div>
        </div>
      </section>

      {/* Stats bar */}
      <section className="bg-[#0EA5E9]" aria-label="Research statistics">
        <div className="container-site py-5">
          <dl className="grid grid-cols-2 md:grid-cols-4 gap-6">
            {stats.map((stat) => (
              <div key={stat.label} className="text-center">
                <dd className="text-2xl font-bold text-white">{stat.value}</dd>
                <dt className="text-sm text-sky-100">{stat.label}</dt>
              </div>
            ))}
          </dl>
        </div>
      </section>

      {/* Category cards */}
      <section className="section-padding bg-[#F8FAFC]" aria-labelledby="categories-heading">
        <div className="container-site">
          <div className="text-center mb-12">
            <h2 id="categories-heading" className="text-3xl font-bold text-[#0F172A] mb-4">Research by IRA Type</h2>
            <p className="text-[#64748B] max-w-xl mx-auto">
              Select your area of interest. Each section contains in-depth provider reviews, 
              fee comparisons, and expert analysis.
            </p>
          </div>
          <div className="grid md:grid-cols-2 gap-8 max-w-4xl mx-auto">
            {categories.map((cat) => (
              <article key={cat.href} className="card hover:shadow-elevated transition-all duration-200" aria-label={cat.title}>
                <div className={`w-12 h-12 rounded-xl bg-gradient-to-br ${cat.color} flex items-center justify-center text-2xl mb-5`} aria-hidden="true">
                  {cat.icon}
                </div>
                <h3 className="text-xl font-bold text-[#0F172A] mb-3">{cat.title}</h3>
                <p className="text-[#64748B] text-sm leading-relaxed mb-6">{cat.description}</p>
                <Link to={cat.href} className="btn-primary text-sm py-2.5" aria-label={`${cat.cta} — ${cat.title}`}>
                  {cat.cta}
                </Link>
              </article>
            ))}
          </div>
        </div>
      </section>

      {/* Trust signals */}
      <section className="section-padding bg-white" aria-labelledby="methodology-heading">
        <div className="container-site">
          <div className="max-w-3xl mx-auto text-center">
            <h2 id="methodology-heading" className="text-3xl font-bold text-[#0F172A] mb-4">How We Rate IRA Providers</h2>
            <p className="text-[#64748B] leading-relaxed mb-10">
              Our ratings are based on objective, verifiable criteria. We do not accept payment 
              for favorable reviews. Our editorial team independently evaluates each provider 
              across six key dimensions.
            </p>
            <ul className="grid grid-cols-2 md:grid-cols-3 gap-6 text-left" role="list" aria-label="Rating criteria">
              {[
                { label: 'Fee Transparency', desc: 'Setup, annual, and transaction fees' },
                { label: 'Asset Selection', desc: 'Range of supported cryptocurrencies or metals' },
                { label: 'Security & Custody', desc: 'Cold storage, insurance, and audit practices' },
                { label: 'IRS Compliance', desc: 'Proper IRA structure and custodian relationships' },
                { label: 'Customer Support', desc: 'Responsiveness and educational resources' },
                { label: 'Reputation', desc: 'BBB rating, user reviews, and track record' },
              ].map((item) => (
                <li key={item.label} className="flex gap-3">
                  <div className="w-5 h-5 rounded-full bg-[#0EA5E9] flex-shrink-0 mt-0.5 flex items-center justify-center" aria-hidden="true">
                    <svg className="w-3 h-3 text-white" fill="none" viewBox="0 0 24 24" stroke="currentColor" aria-hidden="true">
                      <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={3} d="M5 13l4 4L19 7" />
                    </svg>
                  </div>
                  <div>
                    <div className="font-semibold text-[#0F172A] text-sm">{item.label}</div>
                    <div className="text-[#64748B] text-xs mt-0.5">{item.desc}</div>
                  </div>
                </li>
              ))}
            </ul>
            <div className="mt-8">
              <Link
                to="/methodology"
                className="text-[#0EA5E9] font-medium text-sm hover:underline focus:outline-none focus:underline"
                aria-label="Read our full provider rating methodology"
              >
                Read our full methodology
              </Link>
            </div>
          </div>
        </div>
      </section>
      {/* ── Newsletter Signup ─────────────────────────────────────────── */}
      <div className="container-site py-10 max-w-3xl">
        <NewsletterSignup />
      </div>
    </>
  )
}
