import StateGuideTemplate from '../components/StateGuideTemplate'

export default function BestCryptoIRACOPage() {
  return (
    <StateGuideTemplate
      stateName="Colorado"
      stateAbbr="CO"
      slug="colorado"
    />
  )
}
