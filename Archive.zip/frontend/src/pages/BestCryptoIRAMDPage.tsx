import StateGuideTemplate from '../components/StateGuideTemplate'

export default function BestCryptoIRAMDPage() {
  return (
    <StateGuideTemplate
      stateName="Maryland"
      stateAbbr="MD"
      slug="maryland"
    />
  )
}
