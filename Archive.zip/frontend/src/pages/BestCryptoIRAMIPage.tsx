import StateGuideTemplate from '../components/StateGuideTemplate'

export default function BestCryptoIRAMIPage() {
  return (
    <StateGuideTemplate
      stateName="Michigan"
      stateAbbr="MI"
      slug="michigan"
    />
  )
}
