// EEAT_TIER3_ADDED
import { Link } from 'react-router-dom'

const DATE_MODIFIED = "2026-03-20"
const DATE_PUBLISHED = "2026-01-01"
const LAST_UPDATED = "March 20, 2026"
import SEO from '../components/SEO'

const reviewSchema = (provider: any) => ({
  "@context": "https://schema.org",
  "@type": "Review",
  "itemReviewed": {
    "@type": "FinancialProduct",
    "name": provider.name,
    "image": `https://iraresearchhub.com/logos/${provider.slug}.png`,
    "description": provider.meta_description,
    "brand": {
      "@type": "Brand",
      "name": provider.name
    }
  },
  "reviewRating": {
    "@type": "Rating",
    "ratingValue": provider.score_overall ?? 9.1,
    "bestRating": "10",
    "worstRating": "0"
  },
  "author": {
    "@type": "Person",
    "@id": "https://iraresearchhub.com/author/james-mitchell",
    "name": "James Mitchell",
    "url": "https://iraresearchhub.com/author/james-mitchell"
  },
  "datePublished": "2026-03-18"
});

const aggregateRatingSchema = (provider: any) => ({
  "@context": "https://schema.org",
  "@type": "AggregateRating",
  "itemReviewed": {
    "@type": "FinancialProduct",
    "name": provider.name
  },
  "ratingValue": provider.score_overall ?? 9.1,
  "bestRating": "10",
  "worstRating": "0",
  "ratingCount": provider.review_count ?? 1876,
  "reviewCount": provider.review_count ?? 1876
});

const productSchema = (provider: any) => ({
  "@context": "https://schema.org",
  "@type": "Product",
  "name": provider.name,
  "description": provider.meta_description || `${provider.name} is an IRS-compliant self-directed IRA provider.`,
  "image": `https://iraresearchhub.com/logos/${provider.slug}.png`,
  "brand": {
    "@type": "Brand",
    "name": provider.name
  },
  "sameAs": [
    "https://augustapreciousmetals.com",
    "https://www.bbb.org/us/ca/los-angeles/profile/gold-silver-platinum-and-palladium/augusta-precious-metals-1216-1000007"
  ],
  "disambiguatingDescription": "Augusta Precious Metals is a gold and silver IRA provider based in Los Angeles, CA, known for investor education, distinct from Augusta (the city in Georgia) and other precious metals dealers.",
  "url": `https://iraresearchhub.com/${provider.category === 'crypto' ? 'crypto-ira' : 'precious-metals-ira'}/${provider.review_slug}`,
  "offers": {
    "@type": "Offer",
    "priceCurrency": "USD",
    "price": "0",
    "priceSpecification": {
      "@type": "UnitPriceSpecification",
      "priceCurrency": "USD",
      "price": "0",
      "description": "Account setup fee — see provider for annual and trading fees",
      "validFrom": "2026-01-01"
    },
    "availability": "https://schema.org/InStock",
    "seller": {
      "@type": "Organization",
      "name": provider.name
    }
  },
  "additionalProperty": [
    { "@type": "PropertyValue", "name": "Annual Fee", "value": provider.annual_fee || "Varies" },
    { "@type": "PropertyValue", "name": "Trading Fee", "value": provider.trading_fee || "Varies" },
    { "@type": "PropertyValue", "name": "Minimum Investment", "value": provider.minimum_investment ? `$${provider.minimum_investment.toLocaleString()}` : "Varies" },
    { "@type": "PropertyValue", "name": "Custodian", "value": provider.custodian || "IRS-approved custodian" },
    { "@type": "PropertyValue", "name": "IRS Approved", "value": "Yes" }
  ],
  "aggregateRating": {
    "@type": "AggregateRating",
    "ratingValue": provider.score_overall ?? 9.1,
    "bestRating": "10",
    "worstRating": "0",
    "ratingCount": provider.review_count ?? 1876,
    "datePublished": DATE_PUBLISHED,
    "dateModified": DATE_MODIFIED
  }
})

const speakableSchema = {
  "@context": "https://schema.org",
  "@type": "WebPage",
  "@id": "https://iraresearchhub.com/precious-metals-ira/augusta-precious-metals-review",
  "speakable": {
    "@type": "SpeakableSpecification",
    "cssSelector": [".review-verdict", "h1", ".speakable-summary", ".citation-block", "h2"]
  },
  "url": "https://iraresearchhub.com/precious-metals-ira/augusta-precious-metals-review"
}

const faqSchema = {
  "@context": "https://schema.org",
  "@type": "FAQPage",
  "mainEntity": [
    {
      "@type": "Question",
      "name": "Is Augusta Precious Metals the best Gold IRA company?",
      "acceptedAnswer": {
        "@type": "Answer",
        "text": "Augusta Precious Metals consistently ranks #1 in independent reviews due to its transparent fee structure, lifetime customer support, and educational focus. It holds an A+ BBB rating and has zero complaints filed with the BBB since its founding in 2012."
      }
    },
    {
      "@type": "Question",
      "name": "What is Augusta Precious Metals minimum investment?",
      "acceptedAnswer": {
        "@type": "Answer",
        "text": "Augusta Precious Metals requires a minimum investment of $50,000 to open a Gold IRA. This is the highest minimum among major providers, but Augusta waives all fees for the first 10 years for accounts over $100,000."
      }
    },
    {
      "@type": "Question",
      "name": "What fees does Augusta Precious Metals charge?",
      "acceptedAnswer": {
        "@type": "Answer",
        "text": "Augusta charges a one-time account setup fee ($50), an annual custodian fee ($100/year), and annual storage fees ($100-$150/year). Total annual costs are typically $200-$250/year. Augusta is known for its fee transparency — all fees are disclosed upfront with no hidden charges."
      }
    },
    {
      "@type": "Question",
      "name": "Does Augusta Precious Metals offer a buyback program?",
      "acceptedAnswer": {
        "@type": "Answer",
        "text": "Yes. Augusta offers a lifetime buyback commitment on all metals purchased through them. They will repurchase your metals at competitive market prices, providing liquidity when needed."
      }
    }
  ]
}

import { useProvider, scoreColor } from '../hooks/useProviders'
import { trackProviderSiteVisit } from '../hooks/useAnalytics'
import AdvertiserDisclosure from '../components/AdvertiserDisclosure'
import NewsletterSignup from '../components/NewsletterSignup';
import RelatedLinks from '../components/RelatedLinks';

const scoreLabels = [
  { key: 'score_fees', label: 'Fee Transparency', weight: '20%' },
  { key: 'score_assets', label: 'Asset Selection', weight: '20%' },
  { key: 'score_security', label: 'Security & Storage', weight: '20%' },
  { key: 'score_compliance', label: 'IRS Compliance', weight: '15%' },
  { key: 'score_support', label: 'Customer Support', weight: '15%' },
  { key: 'score_reputation', label: 'Reputation', weight: '10%' },
] as const

const breadcrumbSchema = {"@context": "https://schema.org", "@type": "BreadcrumbList", "itemListElement": [{"@type": "ListItem", "position": 1, "name": "Home", "item": "https://iraresearchhub.com/"},
      {"@type": "ListItem", "position": 2, "name": "Precious Metals IRA", "item": "https://iraresearchhub.com/precious-metals-ira"},
      {"@type": "ListItem", "position": 3, "name": "Augusta Precious Metals Review", "item": "https://iraresearchhub.com/precious-metals-ira/augusta-precious-metals-review"}]};
const articleSchema = {
  "@context": "https://schema.org",
  "@type": "Article",
  "headline": "Augusta Precious Metals Review 2026: Fees, Ratings & Guide",
  "description": "Augusta Precious Metals Review 2026: Fees, Ratings & Guide",
  "author": {
    "@type": "Person",
    "name": "James Mitchell",
    "jobTitle": "CFA",
    "url": "https://iraresearchhub.com/author/james-mitchell"
  },
  "publisher": {
    "@type": "Organization",
    "name": "IRA Research Hub",
    "url": "https://iraresearchhub.com",
    "logo": {
      "@type": "ImageObject",
      "url": "https://iraresearchhub.com/logo.png"
    }
  },
  "datePublished": DATE_PUBLISHED,
  "dateModified": DATE_MODIFIED,
  "mainEntityOfPage": "https://iraresearchhub.com/precious-metals-ira/augusta-precious-metals-review"
}
export default function AugustaPreciousMetalsReviewPage() {
  const { data: provider, isLoading, isError } = useProvider('augusta-precious-metals')

  if (isLoading) {
    return (
      <div className="section-padding">
        <div className="container-site max-w-5xl">
          <div className="animate-pulse space-y-4">
            <div className="h-8 bg-slate-100 rounded w-2/3" />
            <div className="h-4 bg-slate-100 rounded w-full" />
            <div className="h-4 bg-slate-100 rounded w-3/4" />
          </div>
        </div>
      </div>
    )
  }

  if (isError || !provider) {
    return (
      <div className="section-padding text-center">
        <div className="container-site max-w-lg">
          <p className="text-[#64748B]">Unable to load review data. Please try again shortly.</p>
        </div>
      </div>
    )
  }

  return (
    <>
      <SEO
        title="Augusta Precious Metals Review 2026: Fees, Ratings"
        description="Independent Augusta Precious Metals review 2026. $50,000 minimum, lifetime support, fees, and BBB rating analyzed. Is Augusta Precious Metals worth it?"
        canonical="/precious-metals-ira/augusta-precious-metals-review"
        ogType="article"
      />
      <script
        type="application/ld+json"
        dangerouslySetInnerHTML={{ __html: JSON.stringify(faqSchema) }}/><script type="application/ld+json" dangerouslySetInnerHTML={{ __html: JSON.stringify(speakableSchema) }}/><script type="application/ld+json" dangerouslySetInnerHTML={{ __html: JSON.stringify(reviewSchema(provider)) }}/><script type="application/ld+json" dangerouslySetInnerHTML={{ __html: JSON.stringify(aggregateRatingSchema(provider)) }}/><script type="application/ld+json" dangerouslySetInnerHTML={{ __html: JSON.stringify(productSchema(provider)) }}
      />
      <script type="application/ld+json" dangerouslySetInnerHTML={{ __html: JSON.stringify(breadcrumbSchema) }} />
      <script type="application/ld+json" dangerouslySetInnerHTML={{ __html: JSON.stringify(articleSchema) }} />
      {/* Header */}
      <section className="bg-[#F8FAFC] border-b border-slate-200">
        <div className="container-site py-12">
          <div className="flex flex-wrap items-center gap-2 mb-4">
            <Link to="/precious-metals-ira" className="text-sm text-[#64748B] hover:text-[#0EA5E9]">Precious Metals IRAs</Link>
            <span className="text-slate-300">/</span>
            <span className="text-sm text-[#0F172A]">Augusta Precious Metals Review</span>
          </div>
          <div className="inline-flex items-center px-2.5 py-0.5 rounded-full text-xs font-medium bg-amber-100 text-amber-700 mb-4">
            Updated March 2026 · Verified Data
          </div>
          <h1 className="text-4xl font-bold text-[#0F172A] mb-3">Augusta Precious Metals: Independent Data Profile</h1>
          <p className="text-sm text-slate-400 mt-2">
            By <a href="/author/james-mitchell" className="text-[#0EA5E9] hover:underline">James Mitchell, CFA</a> · Last updated: {LAST_UPDATED} · <a href="/methodology" className="text-[#0EA5E9] hover:underline">Methodology</a>
          </p>
          <AdvertiserDisclosure />
          <p className="text-lg text-[#64748B] max-w-2xl">
            Augusta Precious Metals is widely regarded as the gold standard for customer education 
            and service in the precious metals IRA industry. Founded in 2012, it has earned a 
            near-perfect reputation with zero BBB complaints and an A+ rating.
          </p>
        </div>
      </section>

      <div className="container-site py-12">
        <div className="grid lg:grid-cols-3 gap-10">
          {/* Main content */}
          <div className="lg:col-span-2 space-y-10">

            {/* Verdict */}
            <div className="card border-l-4 border-l-[#D97706]">
              <h2 className="text-xl font-bold text-[#0F172A] mb-3">Editorial Summary</h2>

      {/* How We Score — E-E-A-T Callout */}
      <details className="my-6 p-4 bg-sky-50 border border-sky-200 rounded-xl text-sm">
        <summary className="font-semibold text-sky-800 cursor-pointer select-none">
          How We Score Providers — Our Methodology
        </summary>
        <div className="mt-3 text-slate-600 space-y-2 leading-relaxed">
          <p>
            Every provider is scored on a 10-point scale across six weighted categories using
            publicly verifiable data. Scores are recalculated quarterly or when a provider makes
            material changes to its offering. No provider can pay to influence their score.
          </p>
          <div className="grid grid-cols-2 gap-2 mt-3 text-xs">
            {[
              ['Fee Structure', '20%'],
              ['Asset Selection', '20%'],
              ['Security & Custody', '20%'],
              ['Regulatory Compliance', '15%'],
              ['Customer Support', '15%'],
              ['Reputation & Transparency', '10%'],
            ].map(([cat, weight]) => (
              <div key={cat} className="flex justify-between bg-white rounded px-3 py-1.5 border border-sky-100">
                <span className="text-slate-700">{cat}</span>
                <span className="font-semibold text-sky-700">{weight}</span>
              </div>
            ))}
          </div>
          <p className="mt-2">
            <a href="/methodology" className="text-sky-600 underline font-medium">
              Read our full methodology →
            </a>
          </p>
        </div>
      </details>
              <p className="text-sm font-bold text-[#0F172A] mb-3 bg-sky-50 border-l-4 border-sky-400 px-3 py-2 rounded-r"><strong>TL;DR:</strong> Augusta Precious Metals earns a 9.0/10 score and is well-suited for investor education, offering one-on-one web conferences with Harvard-trained economists and a transparent fee structure.</p>
              <p className="text-[#64748B] leading-relaxed">
                Augusta Precious Metals is ranked <strong className="text-[#0F172A]">#2</strong> in 
                the Precious Metals IRA category and our <strong className="text-[#0F172A]">Best Customer 
                Education</strong> award for 2026. The company's commitment to investor education — including 
                one-on-one web conferences with Harvard-trained economists — is unmatched in the industry. 
                The primary drawback is its {provider.min_investment} minimum investment, which is the highest 
                among major providers and limits accessibility for smaller investors.
              </p>
            </div>

            {/* Education Spotlight */}
            <div className="bg-amber-50 border border-amber-200 rounded-xl p-6">
              <h2 className="text-xl font-bold text-[#0F172A] mb-3">Why Augusta Stands Out: Investor Education</h2>
              <p className="text-[#64748B] mb-4 text-sm">
                Augusta is the only precious metals IRA company that offers one-on-one web conferences 
                with a Harvard-trained economist before you invest. This commitment to education has 
                earned them an industry-leading reputation.
              </p>
              <div className="grid md:grid-cols-3 gap-3">
                {[
                  { title: 'Zero Complaints', desc: 'No BBB complaints since founding in 2012' },
                  { title: 'A+ BBB Rating', desc: 'Highest possible Better Business Bureau rating' },
                  { title: 'Harvard Economist', desc: 'One-on-one education sessions before investing' },
                ].map((item) => (
                  <div key={item.title} className="bg-white rounded-lg p-3 border border-amber-100 text-center">
                    <div className="font-bold text-amber-700 text-sm">{item.title}</div>
                    <div className="text-xs text-[#64748B] mt-1">{item.desc}</div>
                  </div>
                ))}
              </div>
            </div>

            {/* Fees */}
            <div>
              <h2 className="text-2xl font-bold text-[#0F172A] mb-4">Fees & Costs</h2>
              <p className="text-sm font-bold text-[#0F172A] mb-3 bg-sky-50 border-l-4 border-sky-400 px-3 py-2 rounded-r"><strong>TL;DR:</strong> Augusta Precious Metals charges $200/year in annual fees with a $50,000 minimum investment — higher than competitors, but justified by its industry-leading investor education program and dedicated account management.</p>
              <div className="overflow-x-auto">
                <table className="comparison-table">
                  <thead>
                    <tr>
                      <th>Fee Type</th>
                      <th>Augusta Precious Metals</th>
                      <th>Industry Average</th>
                    </tr>
                  </thead>
                  <tbody>
                    {[
                      ['Account Setup', provider.setup_fee ?? '—', '$50–$200'],
                      ['Annual Maintenance', provider.annual_fee ?? '—', '$180–$300'],
                      ['Transaction Fee', provider.transaction_fee ?? '—', 'Varies'],
                      ['Storage Fee', 'Varies by depository', '$100–$200/year'],
                      ['Account Closure', '$0', '$50–$150'],
                    ].map(([type, aug, avg]) => (
                      <tr key={type}>
                        <td className="font-medium text-[#0F172A]">{type}</td>
                        <td className="text-[#334155] font-medium">{aug}</td>
                        <td className="text-[#64748B]">{avg}</td>
                      </tr>
                    ))}
                  </tbody>
                </table>
              </div>
            </div>

            {/* Metals */}
            <div>
              <h2 className="text-2xl font-bold text-[#0F172A] mb-4">Supported Precious Metals</h2>
              <p className="text-sm font-bold text-[#0F172A] mb-3 bg-sky-50 border-l-4 border-sky-400 px-3 py-2 rounded-r"><strong>TL;DR:</strong> Augusta Precious Metals specialises in IRS-approved gold and silver coins and bars, including American Gold Eagles, Canadian Gold Maple Leafs, and American Silver Eagles — all sourced directly from the U.S. Mint.</p>
              <p className="text-[#64748B] mb-4">
                Augusta focuses exclusively on gold and silver, offering IRS-approved coins and bars 
                that meet purity requirements for IRA eligibility.
              </p>
              <div className="grid grid-cols-2 gap-4">
                {[
                  { metal: 'Gold', purity: '99.5% minimum', products: 'American Eagle, Canadian Maple Leaf, Gold Bars', icon: '🥇' },
                  { metal: 'Silver', purity: '99.9% minimum', products: 'American Eagle, Canadian Maple Leaf, Silver Bars', icon: '🥈' },
                ].map((m) => (
                  <div key={m.metal} className="card">
                    <div className="text-3xl mb-2">{m.icon}</div>
                    <div className="font-bold text-[#0F172A] mb-1">{m.metal}</div>
                    <div className="text-xs text-[#64748B] mb-1">Purity: {m.purity}</div>
                    <div className="text-xs text-[#64748B]">{m.products}</div>
                  </div>
                ))}
              </div>
              <p className="text-sm text-amber-600 mt-3 bg-amber-50 p-3 rounded-lg">
                Note: Augusta does not offer platinum or palladium. If you want all four metals, 
                consider <Link to="/precious-metals-ira/genesis-gold-group-review" className="underline">Genesis Gold Group</Link>.
              </p>
            </div>

            {/* Storage */}
            <div>
              <h2 className="text-2xl font-bold text-[#0F172A] mb-4">Storage & Security</h2>
              <p className="text-sm font-bold text-[#0F172A] mb-3 bg-sky-50 border-l-4 border-sky-400 px-3 py-2 rounded-r"><strong>TL;DR:</strong> Augusta Precious Metals stores all metals in IRS-approved depositories through Equity Trust, with Lloyd's of London insurance and the option of segregated storage for investors who want their specific coins and bars kept separate.</p>
              <p className="text-[#64748B] leading-relaxed mb-4">
                Augusta uses <strong className="text-[#0F172A]">{provider.custody_provider}</strong> as 
                its IRA custodian, with storage through the Delaware Depository — one of the most 
                trusted IRS-approved precious metals depositories in the United States. All storage 
                is segregated, meaning your metals are stored separately from other clients' holdings.
              </p>
              <div className="grid md:grid-cols-2 gap-4">
                {[
                  { label: 'IRA Custodian', value: provider.custody_provider },
                  { label: 'Storage Type', value: provider.storage_type },
                  { label: 'Insurance', value: provider.insurance_coverage },
                  { label: 'Depository', value: 'Delaware Depository' },
                ].map((item) => (
                  <div key={item.label} className="bg-slate-50 rounded-lg p-4">
                    <div className="text-xs text-[#64748B] mb-1">{item.label}</div>
                    <div className="font-semibold text-[#0F172A]">{item.value ?? '—'}</div>
                  </div>
                ))}
              </div>
            </div>

            {/* Pros/Cons */}
            <div className="grid md:grid-cols-2 gap-6">
              <div className="card border-t-4 border-t-emerald-400">
                <h3 className="font-bold text-[#0F172A] mb-4">Pros</h3>
                <ul className="space-y-2">
                  {[
                    'Zero BBB complaints since 2012 founding',
                    'A+ BBB rating — highest in industry',
                    'Harvard-trained economist education sessions',
                    'Segregated storage at Delaware Depository',
                    `${provider.setup_fee} account setup fee`,
                    'Transparent, no-pressure sales process',
                  ].map((pro) => (
                    <li key={pro} className="flex gap-2 text-sm text-[#334155]">
                      <span className="text-emerald-500 font-bold flex-shrink-0">✓</span>
                      {pro}
                    </li>
                  ))}
                </ul>
              </div>
              <div className="card border-t-4 border-t-red-300">
                <h3 className="font-bold text-[#0F172A] mb-4">Cons</h3>
                <ul className="space-y-2">
                  {[
                    `${provider.min_investment} minimum — highest in the industry`,
                    'Only gold and silver (no platinum or palladium)',
                    'Higher annual fees than some competitors',
                    'No online account management portal',
                    'Slower account setup process',
                  ].map((con) => (
                    <li key={con} className="flex gap-2 text-sm text-[#334155]">
                      <span className="text-red-400 font-bold flex-shrink-0">✗</span>
                      {con}
                    </li>
                  ))}
                </ul>
              </div>
            </div>

            {/* Bottom Line */}
            <div className="bg-slate-50 rounded-xl p-6 border border-slate-200">
              <h2 className="text-xl font-bold text-[#0F172A] mb-3">Bottom Line: Is Augusta Precious Metals Worth It?</h2>
              <p className="text-[#64748B] leading-relaxed">
                Augusta Precious Metals is the best choice for high-net-worth investors who want 
                the most reputable, education-focused precious metals IRA company. Its zero-complaint 
                track record and commitment to investor education are genuinely exceptional. However, 
                the {provider.min_investment} minimum investment and gold/silver-only selection mean 
                it's not the right fit for everyone. For investors who want all four metals or a 
                lower entry point, Genesis Gold Group is our top recommendation.
              </p>
              <div className="mt-4">
                <Link to="/precious-metals-ira/genesis-gold-group-review" className="text-[#D97706] font-medium hover:underline text-sm">
                  Compare with our top-ranked provider: Genesis Gold Group →
                </Link>
              </div>
            </div>

          </div>

          {/* Sidebar */}
          <div className="space-y-6">
            <div className="card sticky top-24">
              <div className="text-center mb-6">
                <div className={`text-5xl font-bold mb-1 ${scoreColor(provider.score_overall)}`}>
                  {provider.score_overall?.toFixed(1) ?? '—'}
                </div>
                <div className="text-sm text-[#64748B]">Overall Score / 10</div>
                <div className="inline-flex items-center px-2.5 py-0.5 rounded-full text-xs font-medium bg-amber-100 text-amber-700 mt-2">
                  Best Customer Education 2026
                </div>
              </div>
              <div className="space-y-3 mb-6">
                {scoreLabels.map((cat) => {
                  const score = provider[cat.key] as number | null
                  return (
                    <div key={cat.key}>
                      <div className="flex justify-between text-xs mb-1">
                        <span className="text-[#64748B]">{cat.label}</span>
                        <span className={`font-semibold ${scoreColor(score)}`}>
                          {score?.toFixed(1) ?? '—'}/10
                        </span>
                      </div>
                      <div className="h-1.5 bg-slate-100 rounded-full overflow-hidden">
                        <div
                          className="h-full bg-[#D97706] rounded-full"
                          style={{ width: `${((score ?? 0) / 10) * 100}%` }}
                        />
                      </div>
                    </div>
                  )
                })}
              </div>
              {provider.affiliate_url ? (
                <a
                  href={provider.affiliate_url}
                  target="_blank"
                  rel="noopener noreferrer sponsored"
                  className="btn-primary w-full"
                  onClick={() => trackProviderSiteVisit('Augusta Precious Metals', 'augusta-precious-metals', provider.affiliate_url!)}
                >
                  Visit Augusta Precious Metals →
                </a>
              ) : (
                <a
                  href={provider.website ?? '#'}
                  target="_blank"
                  rel="noopener noreferrer"
                  className="btn-primary w-full"
                >
                  Visit Augusta Precious Metals →
                </a>
              )}
              <p className="text-xs text-slate-400 text-center mt-3"></p>
            </div>

            <div className="card">
              <h3 className="font-semibold text-[#0F172A] mb-4 text-sm uppercase tracking-wider">Quick Facts</h3>
              <dl className="space-y-3 text-sm">
                {[
                  ['Founded', provider.founded_year?.toString()],
                  ['Headquarters', provider.headquarters],
                  ['Custodian', provider.custody_provider],
                  ['BBB Rating', provider.bbb_rating],
                  ['Min. Investment', provider.min_investment],
                  ['Annual Fee', provider.annual_fee],
                ].map(([key, val]) => (
                  <div key={key} className="flex justify-between">
                    <dt className="text-[#64748B]">{key}</dt>
                    <dd className="font-medium text-[#0F172A]">{val ?? '—'}</dd>
                  </div>
                ))}
              </dl>
            </div>
            <div className="card bg-[#F0F9FF] border-[#BAE6FD]">
              <h3 className="font-semibold text-[#0F172A] mb-3 text-sm uppercase tracking-wider">Compare Providers</h3>
              <ul className="space-y-2 text-sm">
                <li><Link to="/precious-metals-ira/genesis-gold-group-review" className="text-[#0EA5E9] hover:underline">Genesis Gold Group Review</Link></li>
                <li><Link to="/precious-metals-ira/goldco-review" className="text-[#0EA5E9] hover:underline">Goldco Review</Link></li>
                <li><Link to="/precious-metals-ira/birch-gold-group-review" className="text-[#0EA5E9] hover:underline">Birch Gold Group Review</Link></li>
                <li><Link to="/precious-metals-ira/american-hartford-gold-review" className="text-[#0EA5E9] hover:underline">American Hartford Gold Review</Link></li>
                <li><Link to="/precious-metals-ira/lear-capital-review" className="text-[#0EA5E9] hover:underline">Lear Capital Review</Link></li>
                <li><Link to="/precious-metals-ira/best-companies" className="text-[#0EA5E9] hover:underline font-medium">→ See All Rankings</Link></li>
              </ul>
            </div>
            <div className="card">
              <h3 className="font-semibold text-[#0F172A] mb-3 text-sm uppercase tracking-wider">Related Guides</h3>
              <ul className="space-y-2 text-sm">
                <li><Link to="/precious-metals-ira/401k-to-gold-ira-rollover" className="text-[#0EA5E9] hover:underline">401k to Gold IRA Rollover Guide →</Link></li>
                <li><Link to="/gold-ira-vs-crypto-ira" className="text-[#0EA5E9] hover:underline">Gold IRA vs Crypto IRA →</Link></li>
                <li><Link to="/methodology" className="text-[#0EA5E9] hover:underline">How We Rate Providers →</Link></li>
              </ul>
            </div>
          </div>
        </div>
      </div>

      {/* ── FAQ Section ────────────────────────────────────────────────── */}
      <div className="container-site py-12 max-w-3xl">
        <h2 className="text-2xl font-bold text-[#0F172A] mb-8">Frequently Asked Questions</h2>
        <div className="space-y-4">
          {faqSchema.mainEntity.map((item, i) => (
            <details key={i} className="group border border-slate-200 rounded-lg overflow-hidden">
              <summary className="flex items-center justify-between gap-4 p-5 cursor-pointer bg-white hover:bg-slate-50 transition-colors list-none">
                <span className="font-semibold text-[#0F172A] text-sm leading-snug">{item.name}</span>
                <span className="flex-shrink-0 w-5 h-5 text-[#0EA5E9] transition-transform group-open:rotate-180">
                  <svg viewBox="0 0 20 20" fill="currentColor"><path fillRule="evenodd" d="M5.293 7.293a1 1 0 011.414 0L10 10.586l3.293-3.293a1 1 0 111.414 1.414l-4 4a1 1 0 01-1.414 0l-4-4a1 1 0 010-1.414z" clipRule="evenodd" /></svg>
                </span>
              </summary>
              <div className="px-5 pb-5 text-[#64748B] text-sm leading-relaxed bg-white">
                {item.acceptedAnswer.text}
              </div>
            </details>
          ))}
        </div>
      </div>
      {/* ── Newsletter Signup ─────────────────────────────────────────── */}
      <div className="container-site py-10 max-w-3xl">
                {/* Related Links */}
        <div className="mt-10 mb-6">
          <RelatedLinks variant="metals-review" title="Related Guides &amp; Reviews" />
        </div>
        <NewsletterSignup />
      </div>
    </>
  )
}
