import StateGuideTemplate from '../components/StateGuideTemplate'

export default function BestCryptoIRAPAPage() {
  return (
    <StateGuideTemplate
      stateName="Pennsylvania"
      stateAbbr="PA"
      slug="pennsylvania"
    />
  )
}
