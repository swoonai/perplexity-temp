import StateGuideTemplate from '../components/StateGuideTemplate'

export default function BestCryptoIRACTPage() {
  return (
    <StateGuideTemplate
      stateName="Connecticut"
      stateAbbr="CT"
      slug="connecticut"
    />
  )
}
