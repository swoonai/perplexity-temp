import { Link } from 'react-router-dom'
import SEO from '../components/SEO'
import AdvertiserDisclosure from '../components/AdvertiserDisclosure'
import NewsletterSignup from '../components/NewsletterSignup';
import RelatedLinks from '../components/RelatedLinks';

const DATE_MODIFIED = "2026-03-20"
const DATE_PUBLISHED = "2026-01-15"
const LAST_UPDATED = "March 20, 2026"

// W2.F — HowTo schema for agentic AI and voice assistants
const howToSchema = {
  "@context": "https://schema.org",
  "@type": "HowTo",
  "name": "How to Roll Over a 401k to a Gold IRA",
  "description": "A step-by-step guide to rolling over a 401(k) to a Gold IRA (Precious Metals IRA) tax-free and penalty-free under IRS rules.",
  "totalTime": "PT4W",
  "estimatedCost": {
    "@type": "MonetaryAmount",
    "currency": "USD",
    "value": "0",
    "description": "Direct rollovers are tax-free and penalty-free. Annual custodian and storage fees apply after account opening."
  },
  "step": [
    { "@type": "HowToStep", "position": 1, "name": "Choose a Gold IRA Provider", "text": "Select an IRS-compliant Gold IRA provider. Compare fees, approved metals, storage options, and minimum investment requirements. Top options include Genesis Gold Group, Augusta Precious Metals, and Goldco.", "url": "https://iraresearchhub.com/precious-metals-ira/best-companies" },
    { "@type": "HowToStep", "position": 2, "name": "Open Your Self-Directed IRA Account", "text": "Complete the provider's account application. Choose Traditional or Roth IRA type. Provide your SSN, employment information, and beneficiary details. Account opening typically takes 1-3 business days." },
    { "@type": "HowToStep", "position": 3, "name": "Request a Direct Rollover from Your 401k Plan", "text": "Contact your 401k plan administrator and request a direct rollover (trustee-to-trustee transfer). Funds go directly to your Gold IRA custodian. This avoids the 20% mandatory withholding that applies to indirect rollovers." },
    { "@type": "HowToStep", "position": 4, "name": "Fund Your Gold IRA", "text": "Once rollover funds arrive (typically 2-4 weeks), they appear as cash in your Gold IRA account. You can then purchase IRS-approved precious metals through your provider." },
    { "@type": "HowToStep", "position": 5, "name": "Select and Purchase IRS-Approved Metals", "text": "Choose from IRS-approved gold, silver, platinum, or palladium coins and bars. Gold must be 99.5% pure (exception: American Gold Eagle coins). Your metals are stored in an IRS-approved depository under your name." }
  ]
}

// W2.DD — Agent-ready action layer
const agentActionSchema = {
  "@context": "https://schema.org",
  "@type": "WebPage",
  "@id": "https://iraresearchhub.com/precious-metals-ira/401k-to-gold-ira-rollover",
  "name": "401k to Gold IRA Rollover Guide 2026",
  "datePublished": DATE_PUBLISHED,
  "dateModified": DATE_MODIFIED,
  "potentialAction": [
    { "@type": "ReadAction", "target": "https://iraresearchhub.com/precious-metals-ira/401k-to-gold-ira-rollover" },
    { "@type": "SearchAction", "target": "https://iraresearchhub.com/precious-metals-ira/best-companies", "description": "Compare Gold IRA providers" }
  ]
}

const faqSchema = {
  "@context": "https://schema.org",
  "@type": "FAQPage",
  "mainEntity": [
    {
      "@type": "Question",
      "name": "Can I roll over my 401k to a Gold IRA without penalty?",
      "acceptedAnswer": {
        "@type": "Answer",
        "text": "Yes. A direct rollover from a 401k to a Gold IRA is tax-free and penalty-free under IRS rules, as long as the funds go directly from your 401k custodian to your Gold IRA custodian (you never touch the money). You have 60 days to complete an indirect rollover, but a direct rollover is recommended to avoid withholding complications."
      }
    },
    {
      "@type": "Question",
      "name": "How long does a 401k to Gold IRA rollover take?",
      "acceptedAnswer": {
        "@type": "Answer",
        "text": "A direct rollover typically takes 2–4 weeks from start to finish. This includes: opening your Gold IRA account (1–3 business days), submitting the rollover request to your 401k plan administrator (5–10 business days for processing), and the custodian receiving and investing the funds (2–5 business days). Some providers offer expedited processing."
      }
    },
    {
      "@type": "Question",
      "name": "What types of gold can I hold in a Gold IRA?",
      "acceptedAnswer": {
        "@type": "Answer",
        "text": "The IRS requires gold held in an IRA to meet a minimum fineness of 0.995 (99.5% pure). Approved gold products include: American Gold Eagle coins (the only exception to the fineness rule, allowed at 91.67%), American Gold Buffalo coins, Canadian Gold Maple Leaf coins, Austrian Gold Philharmonic coins, and gold bars/rounds from approved refiners like PAMP Suisse, Credit Suisse, and Johnson Matthey."
      }
    },
    {
      "@type": "Question",
      "name": "What is the minimum investment for a Gold IRA?",
      "acceptedAnswer": {
        "@type": "Answer",
        "text": "Minimum investments vary by provider. Augusta Precious Metals requires $50,000. Goldco requires $25,000. Birch Gold Group requires $10,000. American Hartford Gold requires $10,000. Genesis Gold Group requires $10,000. Most financial advisors recommend at least $25,000–$50,000 to make the annual fees cost-effective."
      }
    },
    {
      "@type": "Question",
      "name": "Can I roll over a Roth 401k to a Gold IRA?",
      "acceptedAnswer": {
        "@type": "Answer",
        "text": "Yes, but you must roll a Roth 401k into a Roth Gold IRA (not a traditional Gold IRA) to preserve the tax-free treatment of your contributions. The rollover process is the same, but you must specify a Roth IRA account type when opening your Gold IRA."
      }
    },
    {
      "@type": "Question",
      "name": "What are the annual fees for a Gold IRA?",
      "acceptedAnswer": {
        "@type": "Answer",
        "text": "Gold IRA annual fees typically include: custodian fees ($75–$300/year), storage fees ($100–$300/year for segregated storage), and sometimes an administration fee. Total annual costs typically range from $175–$600/year depending on the provider and account size. Some providers like Augusta Precious Metals offer fee waivers for larger accounts."
      }
    }
  ]
}

const speakableSchema = {
  "@context": "https://schema.org",
  "@type": "WebPage",
  "speakable": {
    "@type": "SpeakableSpecification",
    "cssSelector": [".speakable-summary", "h1", ".citation-block"]
  },
  "url": "https://iraresearchhub.com/precious-metals-ira/401k-to-gold-ira-rollover"
}

const breadcrumbSchema = {"@context": "https://schema.org", "@type": "BreadcrumbList", "itemListElement": [{"@type": "ListItem", "position": 1, "name": "Precious Metals IRA", "item": "https://iraresearchhub.com/precious-metals-ira"},
      {"@type": "ListItem", "position": 2, "name": "401(k) to Gold IRA Rollover", "item": "https://iraresearchhub.com/precious-metals-ira/401k-to-gold-ira-rollover"}]};
export default function GoldIRARolloverGuidePage() {
  return (
    <>
      <SEO
        title="How to Roll Over a 401k to a Gold IRA (2026 Step-by-Step Guide)"
        description="Complete step-by-step guide to rolling over your 401k to a Gold IRA in 2026. Tax rules, timelines, approved metals, fees, and provider recommendations."
        canonical="/precious-metals-ira/401k-to-gold-ira-rollover"
        ogType="article"
        ogImage="/og/401k-to-gold-ira-rollover.jpg"
      />
      <script type="application/ld+json" dangerouslySetInnerHTML={{ __html: JSON.stringify(faqSchema) }} />
      <script type="application/ld+json" dangerouslySetInnerHTML={{ __html: JSON.stringify(howToSchema) }} />
      <script type="application/ld+json" dangerouslySetInnerHTML={{ __html: JSON.stringify(agentActionSchema) }} />
      <script type="application/ld+json" dangerouslySetInnerHTML={{ __html: JSON.stringify(speakableSchema) }} />

      <script type="application/ld+json" dangerouslySetInnerHTML={{ __html: JSON.stringify(breadcrumbSchema) }} />
      {/* Header */}
      <section className="bg-[#F8FAFC] border-b border-slate-200">
        <div className="container-site py-12">
          <div className="flex flex-wrap items-center gap-2 mb-4">
            <Link to="/precious-metals-ira" className="text-sm text-[#64748B] hover:text-[#0EA5E9]">Precious Metals IRA</Link>
            <span className="text-slate-300">/</span>
            <span className="text-sm text-[#0F172A]">401k to Gold IRA Rollover Guide</span>
          </div>
          <div className="badge-sky mb-4">By <a href="/author/james-mitchell" className="text-[#0EA5E9] hover:underline">James Mitchell, CFA</a> · Updated {LAST_UPDATED} · IRS-Verified</div>
          <h1 className="text-4xl font-bold text-[#0F172A] mb-4">
            How to Roll Over a 401k to a Gold IRA (2026)
          </h1>
              <AdvertiserDisclosure />

          <p className="text-lg text-[#64748B] max-w-2xl leading-relaxed">
            A complete, step-by-step guide to moving your 401k into a Gold IRA — tax-free and
            penalty-free. Includes IRS rules, approved metals, fee comparisons, and our top
            provider recommendations.
          </p>
        </div>
      </section>

      <div className="container-site py-12">
        <div className="grid lg:grid-cols-3 gap-10">
          {/* Main content */}
          <div className="lg:col-span-2 space-y-10">

            {/* Quick summary */}
            <div className="card border-l-4 border-l-amber-400">
              <h2 className="text-lg font-bold text-[#0F172A] mb-3">Key Takeaways</h2>
              <ul className="space-y-2 text-sm text-[#334155]">
                {[
                  'A direct 401k rollover to a Gold IRA is tax-free and penalty-free under IRS rules',
                  'The process takes 2–4 weeks from start to finish',
                  'Gold must meet IRS purity standards (0.995 fineness minimum)',
                  'Annual costs typically run $175–$600/year (custodian + storage)',
                  'Most providers require a $10,000–$50,000 minimum investment',
                  'You must use an IRS-approved custodian — you cannot store gold at home',
                ].map((point) => (
                  <li key={point} className="flex gap-2">
                    <span className="text-amber-500 font-bold flex-shrink-0">✓</span>
                    {point}
                  </li>
                ))}
              </ul>
            </div>

            {/* What is a Gold IRA */}
            <div>
              <h2 className="text-2xl font-bold text-[#0F172A] mb-4">What Is a Gold IRA?</h2>
              <p className="text-[#64748B] leading-relaxed mb-4">
                A Gold IRA (also called a Precious Metals IRA or Self-Directed IRA) is a retirement
                account that holds physical gold, silver, platinum, or palladium instead of — or in
                addition to — stocks and bonds. It operates under the same IRS rules as a traditional
                IRA, including the same contribution limits, RMD rules, and tax treatment.
              </p>
              <p className="text-[#64748B] leading-relaxed">
                The key difference: instead of a brokerage holding paper assets, a specialized
                custodian holds your physical metals in an IRS-approved depository. You own the
                physical metal — it's allocated to your account specifically.
              </p>
            </div>

            {/* Why roll over */}
            <div>
              <h2 className="text-2xl font-bold text-[#0F172A] mb-4">Why Roll Over to a Gold IRA?</h2>
              <div className="grid md:grid-cols-2 gap-4">
                {[
                  {
                    title: 'Inflation Hedge',
                    desc: 'Gold has historically maintained purchasing power during inflationary periods. Since 2000, gold has outperformed the S&P 500 on a risk-adjusted basis.',
                  },
                  {
                    title: 'Portfolio Diversification',
                    desc: 'Gold has a low or negative correlation with stocks and bonds, reducing overall portfolio volatility during market downturns.',
                  },
                  {
                    title: 'Currency Devaluation Protection',
                    desc: 'Physical gold is a tangible asset that holds value independent of any government\'s monetary policy or currency strength.',
                  },
                  {
                    title: 'Geopolitical Risk Hedge',
                    desc: 'Gold tends to rise during periods of geopolitical uncertainty, providing a counterbalance to equity market losses.',
                  },
                ].map((item) => (
                  <div key={item.title} className="bg-slate-50 rounded-lg p-4">
                    <h3 className="font-semibold text-[#0F172A] mb-2">{item.title}</h3>
                    <p className="text-sm text-[#64748B]">{item.desc}</p>
                  </div>
                ))}
              </div>
            </div>

            {/* Direct vs Indirect Rollover */}
            <div>
              <h2 className="text-2xl font-bold text-[#0F172A] mb-4">Direct vs. Indirect Rollovers</h2>
              <p className="text-[#64748B] leading-relaxed mb-4">
                When moving funds from a 401(k) to a Gold IRA, you have two options: a direct rollover or an indirect rollover. Understanding the difference is critical to avoid taxes and penalties.
              </p>
              <div className="grid md:grid-cols-2 gap-6">
                <div className="card bg-slate-50">
                  <h3 className="font-semibold text-[#0F172A] mb-2">Direct Rollover (Recommended)</h3>
                  <p className="text-sm text-[#64748B] mb-3">
                    Funds move directly from your 401(k) custodian to your new Gold IRA custodian. You never touch the money. This is the simplest and safest method.
                  </p>
                  <ul className="space-y-2 text-sm">
                    <li className="flex gap-2"><span className="text-emerald-500 font-bold">✓</span> No taxes or penalties</li>
                    <li className="flex gap-2"><span className="text-emerald-500 font-bold">✓</span> No 60-day deadline to worry about</li>
                    <li className="flex gap-2"><span className="text-emerald-500 font-bold">✓</span> No limit on the number of rollovers</li>
                  </ul>
                </div>
                <div className="card bg-slate-50">
                  <h3 className="font-semibold text-[#0F172A] mb-2">Indirect Rollover</h3>
                  <p className="text-sm text-[#64748B] mb-3">
                    Your 401(k) administrator sends you a check. You have 60 days to deposit the funds into your new Gold IRA. This method is more complex and carries risks.
                  </p>
                  <ul className="space-y-2 text-sm">
                    <li className="flex gap-2"><span className="text-red-500 font-bold">✗</span> 20% of funds are automatically withheld for taxes</li>
                    <li className="flex gap-2"><span className="text-red-500 font-bold">✗</span> If you miss the 60-day deadline, the entire amount is taxed as income + 10% penalty</li>
                    <li className="flex gap-2"><span className="text-red-500 font-bold">✗</span> You can only do one indirect rollover per year</li>
                  </ul>
                </div>
              </div>
            </div>

            {/* Common Rollover Mistakes */}
            <div>
              <h2 className="text-2xl font-bold text-[#0F172A] mb-4">Common Rollover Mistakes to Avoid</h2>
              <div className="space-y-4">
                <div className="card">
                  <h3 className="font-semibold text-[#0F172A] mb-2">1. Missing the 60-Day Deadline (Indirect Rollovers)</h3>
                  <p className="text-sm text-[#64748B]">
                    If you choose an indirect rollover, you have exactly 60 days to deposit the funds. Missing this deadline by even one day results in the entire amount being treated as a taxable distribution, plus a 10% early withdrawal penalty if you are under 59½. For this reason, most financial advisors strongly recommend a direct rollover.
                  </p>
                </div>
                <div className="card">
                  <h3 className="font-semibold text-[#0F172A] mb-2">2. Not Accounting for the 20% Withholding (Indirect Rollovers)</h3>
                  <p className="text-sm text-[#64748B]">
                    With an indirect rollover, your old 401(k) administrator is required to withhold 20% for federal income tax. To complete a full rollover, you must deposit the entire original amount (including the 20% that was withheld) into your new IRA. This means you must come up with the 20% from other funds. You can then claim the withheld amount back on your next tax return.
                  </p>
                </div>
                <div className="card">
                  <h3 className="font-semibold text-[#0F172A] mb-2">3. The "One Rollover Per Year" Rule</h3>
                  <p className="text-sm text-[#64748B]">
                    The IRS only allows one indirect rollover across all of your IRAs in any 12-month period. This rule does not apply to direct, trustee-to-trustee transfers. Another reason to always choose a direct rollover.
                  </p>
                </div>
                <div className="card">
                  <h3 className="font-semibold text-[#0F172A] mb-2">4. Rolling Over Ineligible Funds</h3>
                  <p className="text-sm text-[#64748B]">
                    You cannot roll over Required Minimum Distributions (RMDs). If you are over 72, you must take your RMD for the year before you can roll over any remaining funds.
                  </p>
                </div>
              </div>
            </div>

            {/* Step-by-step */}
            <div>
              <h2 className="text-2xl font-bold text-[#0F172A] mb-6">Step-by-Step Rollover Process</h2>
              <div className="space-y-6">
                {[
                  {
                    step: '1',
                    title: 'Choose a Gold IRA Custodian',
                    time: '1–3 business days',
                    desc: 'Select an IRS-approved custodian that specializes in precious metals IRAs. Key factors: fee transparency, storage options, customer service, and BBB rating. Our top-rated options are Augusta Precious Metals, Goldco, and Birch Gold Group.',
                    action: 'Compare our top-rated providers',
                    link: '/precious-metals-ira/best-companies',
                  },
                  {
                    step: '2',
                    title: 'Open Your Gold IRA Account',
                    time: '1–3 business days',
                    desc: 'Complete the custodian\'s account application (usually online). You\'ll need: government-issued ID, Social Security number, and your current 401k account information. Specify whether you want a Traditional or Roth Gold IRA.',
                    action: null,
                    link: null,
                  },
                  {
                    step: '3',
                    title: 'Initiate the Rollover Request',
                    time: '5–10 business days',
                    desc: 'Contact your current 401k plan administrator and request a direct rollover (also called a "trustee-to-trustee transfer"). Provide your new Gold IRA custodian\'s information. For a direct rollover, the funds go straight from your 401k to your Gold IRA — you never receive a check.',
                    action: null,
                    link: null,
                  },
                  {
                    step: '4',
                    title: 'Fund Your Account',
                    time: '2–5 business days',
                    desc: 'Your Gold IRA custodian receives the funds from your 401k. The money sits in a cash/money market position until you select your metals. This is not taxable — it\'s a transfer between retirement accounts.',
                    action: null,
                    link: null,
                  },
                  {
                    step: '5',
                    title: 'Select Your Metals',
                    time: '1–2 business days',
                    desc: 'Work with your custodian\'s precious metals specialist to select IRS-approved gold, silver, platinum, or palladium products. Most investors start with American Gold Eagle or Gold Buffalo coins, or PAMP Suisse gold bars.',
                    action: null,
                    link: null,
                  },
                  {
                    step: '6',
                    title: 'Metals Purchased & Stored',
                    time: '3–7 business days',
                    desc: 'Your custodian purchases the metals on your behalf and arranges delivery to an IRS-approved depository (Delaware Depository, Brink\'s, etc.). You receive a confirmation showing the specific metals allocated to your account.',
                    action: null,
                    link: null,
                  },
                ].map((item) => (
                  <div key={item.step} className="flex gap-4">
                    <div className="flex-shrink-0 w-10 h-10 rounded-full bg-[#0EA5E9] text-white font-bold flex items-center justify-center text-sm">
                      {item.step}
                    </div>
                    <div className="flex-1">
                      <div className="flex items-center gap-3 mb-2">
                        <h3 className="font-bold text-[#0F172A]">{item.title}</h3>
                        <span className="text-xs text-[#64748B] bg-slate-100 px-2 py-0.5 rounded-full">{item.time}</span>
                      </div>
                      <p className="text-[#64748B] text-sm leading-relaxed">{item.desc}</p>
                      {item.action && item.link && (
                        <Link to={item.link} className="text-[#0EA5E9] text-sm hover:underline mt-2 inline-block">
                          {item.action} →
                        </Link>
                      )}
                    </div>
                  </div>
                ))}
              </div>
            </div>

            {/* BlockTrust Cross-Promo Banner */}
            <div className="rounded-xl border border-amber-200 bg-gradient-to-r from-amber-50 to-orange-50 p-5 my-2">
              <div className="flex flex-col sm:flex-row items-start sm:items-center gap-4">
                <div className="flex-1">
                  <div className="flex items-center gap-2 mb-1">
                    <span className="inline-flex items-center px-2 py-0.5 rounded text-xs font-semibold bg-amber-100 text-amber-800">★ Editor’s Choice 2026</span>
                    <span className="text-xs text-slate-500">Crypto IRA</span>
                  </div>
                  <p className="font-bold text-[#0F172A] text-base leading-snug">Also considering a Crypto IRA? BlockTrust IRA is our #1 pick.</p>
                  <p className="text-sm text-slate-600 mt-1">Considering alternatives to Gold? Bitcoin IRAs have outperformed gold 3 years running.</p>
                </div>
                <Link to="/crypto-ira/blocktrust-ira-review" className="flex-shrink-0 inline-flex items-center gap-1.5 px-4 py-2.5 rounded-lg bg-amber-500 hover:bg-amber-600 text-white font-semibold text-sm transition-colors whitespace-nowrap">See BlockTrust Review →</Link>
              </div>
            </div>

            {/* IRS Rules */}
            <div>
              <h2 className="text-2xl font-bold text-[#0F172A] mb-4">IRS Rules for Gold IRAs</h2>
              <div className="overflow-x-auto">
                <table className="comparison-table">
                  <thead>
                    <tr>
                      <th>Rule</th>
                      <th>Details</th>
                    </tr>
                  </thead>
                  <tbody>
                    {[
                      ['Contribution Limits', '$7,000/year ($8,000 if age 50+) for 2026'],
                      ['Gold Purity Minimum', '0.995 fineness (99.5% pure) — exception for American Gold Eagles'],
                      ['Approved Custodians', 'Must use an IRS-approved non-bank trustee or bank'],
                      ['Storage Requirement', 'Must be stored in an IRS-approved depository — not at home'],
                      ['RMD Rules', 'Same as traditional IRA — begin at age 73'],
                      ['Early Withdrawal', '10% penalty + income tax if withdrawn before age 59½'],
                      ['Rollover Limit', 'One IRA-to-IRA rollover per 12-month period (direct transfers unlimited)'],
                      ['60-Day Rule', 'Indirect rollovers must be completed within 60 days to avoid taxes/penalties'],
                    ].map(([rule, detail]) => (
                      <tr key={rule}>
                        <td className="font-medium text-[#0F172A]">{rule}</td>
                        <td className="text-[#64748B]">{detail}</td>
                      </tr>
                    ))}
                  </tbody>
                </table>
              </div>
            </div>

            {/* Fee comparison */}
            <div>
              <h2 className="text-2xl font-bold text-[#0F172A] mb-4">Gold IRA Fee Comparison</h2>
              <div className="overflow-x-auto">
                <table className="comparison-table">
                  <thead>
                    <tr>
                      <th>Provider</th>
                      <th>Min. Investment</th>
                      <th>Setup Fee</th>
                      <th>Annual Fee</th>
                      <th>Storage</th>
                    </tr>
                  </thead>
                  <tbody>
                    {[
                      ['Augusta Precious Metals', '$50,000', '$0', '$0 (yr 1)', 'Included'],
                      ['Goldco', '$25,000', '$0', '$175–$225', '$150/yr'],
                      ['Birch Gold Group', '$10,000', '$0', '$80', '$100–$150/yr'],
                      ['American Hartford Gold', '$10,000', '$0', '$75–$180', '$120–$150/yr'],
                      ['Genesis Gold Group', '$10,000', '$0', '$180', '$150/yr'],
                      ['Lear Capital', '$7,500', '$0', '$280', '$200/yr'],
                    ].map(([name, min, setup, annual, storage]) => (
                      <tr key={name}>
                        <td className="font-medium text-[#0F172A]">{name}</td>
                        <td>{min}</td>
                        <td className="text-emerald-600">{setup}</td>
                        <td>{annual}</td>
                        <td>{storage}</td>
                      </tr>
                    ))}
                  </tbody>
                </table>
              </div>
              <p className="text-xs text-[#64748B] mt-2">
                Fees are approximate and subject to change. Verify current fees directly with each provider.
              </p>
            </div>

            {/* Approved metals */}
            <div>
              <h2 className="text-2xl font-bold text-[#0F172A] mb-4">IRS-Approved Precious Metals</h2>
              <div className="grid md:grid-cols-2 gap-6">
                {[
                  {
                    metal: 'Gold',
                    purity: '0.995 (99.5%)',
                    approved: [
                      'American Gold Eagle (exception: 91.67%)',
                      'American Gold Buffalo',
                      'Canadian Gold Maple Leaf',
                      'Austrian Gold Philharmonic',
                      'PAMP Suisse Gold Bars',
                      'Credit Suisse Gold Bars',
                    ],
                  },
                  {
                    metal: 'Silver',
                    purity: '0.999 (99.9%)',
                    approved: [
                      'American Silver Eagle',
                      'Canadian Silver Maple Leaf',
                      'Austrian Silver Philharmonic',
                      'Australian Silver Kookaburra',
                      'Silver bars (0.999+ fineness)',
                    ],
                  },
                  {
                    metal: 'Platinum',
                    purity: '0.9995 (99.95%)',
                    approved: [
                      'American Platinum Eagle',
                      'Canadian Platinum Maple Leaf',
                      'Isle of Man Noble',
                      'Platinum bars (0.9995+ fineness)',
                    ],
                  },
                  {
                    metal: 'Palladium',
                    purity: '0.9995 (99.95%)',
                    approved: [
                      'Canadian Palladium Maple Leaf',
                      'Palladium bars (0.9995+ fineness)',
                    ],
                  },
                ].map((item) => (
                  <div key={item.metal} className="card">
                    <div className="flex items-center justify-between mb-3">
                      <h3 className="font-bold text-[#0F172A]">{item.metal}</h3>
                      <span className="text-xs bg-amber-50 text-amber-700 px-2 py-1 rounded-full font-medium">
                        Min. {item.purity}
                      </span>
                    </div>
                    <ul className="space-y-1">
                      {item.approved.map((product) => (
                        <li key={product} className="text-sm text-[#64748B] flex gap-2">
                          <span className="text-amber-500 flex-shrink-0">✓</span>
                          {product}
                        </li>
                      ))}
                    </ul>
                  </div>
                ))}
              </div>
            </div>

            {/* FAQ */}
            <div>
              <h2 className="text-2xl font-bold text-[#0F172A] mb-6">Frequently Asked Questions</h2>
              <div className="space-y-4">
                {faqSchema.mainEntity.map((faq) => (
                  <div key={faq.name} className="border border-slate-200 rounded-xl p-5">
                    <h3 className="font-semibold text-[#0F172A] mb-2">{faq.name}</h3>
                    <p className="text-sm text-[#64748B] leading-relaxed">{faq.acceptedAnswer.text}</p>
                  </div>
                ))}
              </div>
            </div>

            {/* CTA */}
            <div className="card bg-gradient-to-br from-amber-50 to-orange-50 border-amber-200">
              <h2 className="text-xl font-bold text-[#0F172A] mb-3">Ready to Start Your Rollover?</h2>
              <p className="text-[#64748B] mb-5">
                Compare our top-rated Gold IRA providers and get started with a free consultation.
                Most providers can complete your rollover in 2–4 weeks.
              </p>
              <div className="flex flex-wrap gap-3">
                <Link to="/precious-metals-ira/best-companies" className="btn-primary">
                  Compare Top Providers →
                </Link>
                <Link to="/precious-metals-ira/genesis-gold-group-review" className="btn-outline">
                  #1 Rated: Genesis Gold Group
                </Link>
              </div>
            </div>

          </div>

          {/* Sidebar */}
          <div className="space-y-6">
            <div className="card sticky top-24">
              <h3 className="font-semibold text-[#0F172A] mb-4 text-sm uppercase tracking-wider">In This Guide</h3>
              <nav className="space-y-2 text-sm">
                {[
                  ['What Is a Gold IRA?', '#'],
                  ['Why Roll Over?', '#'],
                  ['Step-by-Step Process', '#'],
                  ['IRS Rules', '#'],
                  ['Fee Comparison', '#'],
                  ['Approved Metals', '#'],
                  ['FAQ', '#'],
                ].map(([label, href]) => (
                  <a key={label} href={href} className="block text-[#64748B] hover:text-[#0EA5E9] py-1 border-b border-slate-100 last:border-0">
                    {label}
                  </a>
                ))}
              </nav>
            </div>

            <div className="card">
              <h3 className="font-semibold text-[#0F172A] mb-4 text-sm uppercase tracking-wider">Top Providers</h3>
              <div className="space-y-3">
                {[
                  { name: 'Augusta Precious Metals', rank: '#1', slug: 'augusta-precious-metals-review' },
                  { name: 'Goldco', rank: '#2', slug: 'goldco-review' },
                  { name: 'Birch Gold Group', rank: '#3', slug: 'birch-gold-group-review' },
                  { name: 'American Hartford Gold', rank: '#4', slug: 'american-hartford-gold-review' },
                ].map((p) => (
                  <Link
                    key={p.name}
                    to={`/precious-metals-ira/${p.slug}`}
                    className="flex items-center justify-between text-sm hover:text-[#0EA5E9] py-1 border-b border-slate-100 last:border-0"
                  >
                    <span className="text-[#64748B]">{p.name}</span>
                    <span className="text-xs font-semibold text-amber-600">{p.rank}</span>
                  </Link>
                ))}
              </div>
            </div>

            <div className="card border border-amber-200 bg-gradient-to-b from-amber-50 to-white">
              <div className="flex items-center gap-1.5 mb-3">
                <span className="inline-flex items-center px-2 py-0.5 rounded text-xs font-semibold bg-amber-100 text-amber-800">★ Editor’s Choice 2026</span>
              </div>
              <h3 className="font-bold text-[#0F172A] text-sm mb-1">Our #1 Rated Crypto IRA</h3>
              <p className="text-xs text-slate-600 mb-1 font-semibold">BlockTrust IRA</p>
              <p className="text-xs text-slate-500 mb-3">Considering alternatives to Gold? Bitcoin IRAs have outperformed gold 3 years running.</p>
              <Link to="/crypto-ira/blocktrust-ira-review" className="block w-full text-center px-3 py-2.5 rounded-lg bg-amber-500 hover:bg-amber-600 text-white font-semibold text-sm transition-colors">See Full Review →</Link>
            </div>

            <div className="card">
              <h3 className="font-semibold text-[#0F172A] mb-3 text-sm uppercase tracking-wider">Related Guides</h3>
              <div className="space-y-2 text-sm">
                <Link to="/crypto-ira/401k-to-crypto-ira-rollover" className="block text-[#0EA5E9] hover:underline">
                  401k to Crypto IRA Rollover Guide →
                </Link>
                <Link to="/gold-ira-vs-crypto-ira" className="block text-[#0EA5E9] hover:underline">
                  Gold IRA vs Crypto IRA Comparison →
                </Link>
                <Link to="/methodology" className="block text-[#0EA5E9] hover:underline">
                  How We Rate Providers →
                </Link>
              </div>
            </div>
          </div>
        </div>
      </div>
      {/* ── Newsletter Signup ─────────────────────────────────────────── */}
      <div className="container-site py-10 max-w-3xl">
        
        {/* Related Links */}

        <div className="mt-10 mb-6">

          <RelatedLinks variant="metals-guide" title="Related Guides &amp; Reviews" />

        </div>
<NewsletterSignup />
      </div>
    </>
  )
}
