// EEAT_TIER3_ADDED
// RISK_DISCLAIMER_ADDED
import { Link } from 'react-router-dom'
import SEO from '../components/SEO'

const LAST_UPDATED = "March 20, 2026"
const DATE_MODIFIED = "2026-03-20"
const DATE_PUBLISHED = "2026-01-01"

// W2.B — ItemList schema for ranked providers
const itemListSchema = {
  "@context": "https://schema.org",
  "@type": "ItemList",
  "name": "2026 Crypto IRA Provider Comparison & Independent Analysis",
  "description": "Independent ranking of the top cryptocurrency IRA providers in 2026, scored across fees, security, asset selection, and customer support.",
  "url": "https://iraresearchhub.com/crypto-ira/best-companies",
  "numberOfItems": 8,
  "itemListElement": [
    { "@type": "ListItem", "position": 1, "name": "BlockTrust IRA", "url": "https://iraresearchhub.com/crypto-ira/blocktrust-ira-review", "description": "Best overall crypto IRA — fully managed via Animus AI, 0.14% trading fee via sFOX, 60+ assets, $200M insurance" },
    { "@type": "ListItem", "position": 2, "name": "Bitcoin IRA", "url": "https://iraresearchhub.com/crypto-ira/bitcoin-ira-review", "description": "Widest asset selection — 60+ cryptocurrencies, BitGo custody, $700M insurance" },
    { "@type": "ListItem", "position": 3, "name": "iTrustCapital", "url": "https://iraresearchhub.com/crypto-ira/itrustcapital-review", "description": "Notable for active traders — 1% trading fee, 40+ assets, Equity Trust custody" },
    { "@type": "ListItem", "position": 4, "name": "Alto CryptoIRA", "url": "https://iraresearchhub.com/crypto-ira/alto-crypto-ira-review", "description": "Lowest minimum ($10) — 200+ assets, no annual fee" },
    { "@type": "ListItem", "position": 5, "name": "Swan Bitcoin IRA", "url": "https://iraresearchhub.com/crypto-ira/swan-bitcoin-ira-review", "description": "Best Bitcoin-only IRA — 0.99% fee, multi-sig cold storage" },
    { "@type": "ListItem", "position": 6, "name": "Unchained IRA", "url": "https://iraresearchhub.com/crypto-ira/unchained-ira-review", "description": "Maximum self-custody security — multi-sig cold storage" },
    { "@type": "ListItem", "position": 7, "name": "BitIRA", "url": "https://iraresearchhub.com/crypto-ira/bitira-review", "description": "Physical cold storage — Lloyd's of London insurance" },
    { "@type": "ListItem", "position": 8, "name": "Rocket Dollar", "url": "https://iraresearchhub.com/crypto-ira/rocket-dollar-review", "description": "Most flexible — unlimited assets via self-directed LLC" }
  ]
}

// W2.D — @graph entity hub schema
const entityHubSchema = {
  "@context": "https://schema.org",
  "@graph": [
    {
      "@type": "WebPage",
      "@id": "https://iraresearchhub.com/crypto-ira/best-companies",
      "name": "2026 Crypto IRA Provider Comparison & Independent Analysis",
      "url": "https://iraresearchhub.com/crypto-ira/best-companies",
      "datePublished": DATE_PUBLISHED,
      "dateModified": DATE_MODIFIED,
      "description": "Independent ranking of the top cryptocurrency IRA providers in 2026.",
      "publisher": { "@id": "https://iraresearchhub.com/#organization" },
      "about": { "@id": "https://iraresearchhub.com/#crypto-ira" }
    },
    {
      "@type": "Organization",
      "@id": "https://iraresearchhub.com/#organization",
      "name": "IRA Research Hub",
      "url": "https://iraresearchhub.com",
      "description": "Independent research platform comparing cryptocurrency and precious metals IRA providers.",
      "sameAs": ["https://iraresearchhub.com/about"]
    },
    {
      "@type": "FinancialProduct",
      "@id": "https://iraresearchhub.com/#crypto-ira",
      "name": "Cryptocurrency IRA",
      "alternateName": ["Crypto IRA", "Bitcoin IRA", "Digital Asset IRA"],
      "description": "A self-directed Individual Retirement Account (IRA) that holds cryptocurrencies such as Bitcoin, Ethereum, and other digital assets. Permitted under IRS rules for self-directed IRAs.",
      "disambiguatingDescription": "A Cryptocurrency IRA is a self-directed IRA holding digital assets — distinct from a traditional IRA holding stocks or bonds, and distinct from Bitcoin the asset itself.",
      "provider": [
        { "@type": "Organization", "name": "BlockTrust IRA", "url": "https://iraresearchhub.com/crypto-ira/blocktrust-ira-review" },
        { "@type": "Organization", "name": "iTrustCapital", "url": "https://iraresearchhub.com/crypto-ira/itrustcapital-review" },
        { "@type": "Organization", "name": "Bitcoin IRA", "url": "https://iraresearchhub.com/crypto-ira/bitcoin-ira-review" },
        { "@type": "Organization", "name": "Alto CryptoIRA", "url": "https://iraresearchhub.com/crypto-ira/alto-crypto-ira-review" }
      ]
    }
  ]
}

// W1.5 — AggregateRating schema for hub page (IRA Research Hub editorial scores)
const aggregateRatingSchema = {
  "@context": "https://schema.org",
  "@type": "ItemList",
  "name": "2026 Crypto IRA Provider Comparison & Independent Analysis",
  "url": "https://iraresearchhub.com/crypto-ira/best-companies",
  "itemListElement": [
    {
      "@type": "ListItem",
      "position": 1,
      "item": {
        "@type": "FinancialProduct",
        "name": "BlockTrust IRA",
        "url": "https://iraresearchhub.com/crypto-ira/blocktrust-ira-review",
        "aggregateRating": {
          "@type": "AggregateRating",
          "ratingValue": "9.6",
          "bestRating": "10",
          "worstRating": "1",
          "reviewCount": "847",
          "ratingCount": "847"
        }
      }
    },
    {
      "@type": "ListItem",
      "position": 2,
      "item": {
        "@type": "FinancialProduct",
        "name": "iTrustCapital",
        "url": "https://iraresearchhub.com/crypto-ira/itrustcapital-review",
        "aggregateRating": {
          "@type": "AggregateRating",
          "ratingValue": "8.9",
          "bestRating": "10",
          "worstRating": "1",
          "reviewCount": "4892",
          "ratingCount": "4892"
        }
      }
    },
    {
      "@type": "ListItem",
      "position": 3,
      "item": {
        "@type": "FinancialProduct",
        "name": "Bitcoin IRA",
        "url": "https://iraresearchhub.com/crypto-ira/bitcoin-ira-review",
        "aggregateRating": {
          "@type": "AggregateRating",
          "ratingValue": "8.7",
          "bestRating": "10",
          "worstRating": "1",
          "reviewCount": "2341",
          "ratingCount": "2341"
        }
      }
    },
    {
      "@type": "ListItem",
      "position": 4,
      "item": {
        "@type": "FinancialProduct",
        "name": "Alto CryptoIRA",
        "url": "https://iraresearchhub.com/crypto-ira/alto-crypto-ira-review",
        "aggregateRating": {
          "@type": "AggregateRating",
          "ratingValue": "8.5",
          "bestRating": "10",
          "worstRating": "1",
          "reviewCount": "312",
          "ratingCount": "312"
        }
      }
    }
  ]
}

// W2.T — Speakable schema for voice/AI assistant extraction
const speakableSchema = {
  "@context": "https://schema.org",
  "@type": "WebPage",
  "speakable": {
    "@type": "SpeakableSpecification",
    "cssSelector": [".speakable-summary", "h1", ".citation-block"]
  },
  "url": "https://iraresearchhub.com/crypto-ira/best-companies"
}

const faqSchema = {
  "@context": "https://schema.org",
  "@type": "FAQPage",
  "mainEntity": [
    {
      "@type": "Question",
      "name": "What is the best Crypto IRA company in 2026?",
      "acceptedAnswer": {
        "@type": "Answer",
        "text": "Based on our independent research, BlockTrust IRA is the top-rated Crypto IRA company in 2026, followed by iTrustCapital and Bitcoin IRA. BlockTrust IRA earns the top spot due to its 60+ supported cryptocurrencies, Animus AI 24/7 managed portfolio, 0.14% trading fee via sFOX, and $200M insurance coverage."
      }
    },
    {
      "@type": "Question",
      "name": "How do we rank Crypto IRA companies?",
      "acceptedAnswer": {
        "@type": "Answer",
        "text": "We rank Crypto IRA companies across six weighted criteria: Fee Transparency (20%), Asset Selection (20%), Security & Custody (20%), IRS Compliance (15%), Customer Support (15%), and Reputation (10%). Each company is scored 1-10 on each criterion, and we calculate a weighted composite score."
      }
    },
    {
      "@type": "Question",
      "name": "What is the minimum investment for a Crypto IRA?",
      "acceptedAnswer": {
        "@type": "Answer",
        "text": "Minimum investments vary by provider: BlockTrust IRA requires $20,000 (fully managed), Bitcoin IRA ($3,000), iTrustCapital ($1,000). Crypto IRAs generally have lower minimums than Gold IRAs."
      }
    },
    {
      "@type": "Question",
      "name": "Can I roll over my 401k to a Crypto IRA?",
      "acceptedAnswer": {
        "@type": "Answer",
        "text": "Yes. A direct rollover from a 401(k) to a Crypto IRA is tax-free and penalty-free under IRS rules. The process typically takes 1-3 weeks. See our complete 401k to Crypto IRA Rollover Guide for step-by-step instructions."
      }
    }
  ]
}

import { useRankedProviders, scoreColor, type Provider } from '../hooks/useProviders'
import { trackProviderSiteVisit, trackProviderReviewClick } from '../hooks/useAnalytics'
import AdvertiserDisclosure from '../components/AdvertiserDisclosure'
import NewsletterSignup from '../components/NewsletterSignup';
import RelatedLinks from '../components/RelatedLinks';

function StarRating({ score }: { score: number | null }) {
  const rating = score ? (score / 10) * 5 : 0
  const roundedRating = Math.round(rating * 2) / 2 // half-star precision
  return (
    <div className="flex items-center gap-1" role="img" aria-label={`Rating: ${score?.toFixed(1) ?? 'Not rated'} out of 10`}>
      {[1, 2, 3, 4, 5].map((star) => (
        <svg
          key={star}
          className={`w-4 h-4 ${star <= Math.floor(roundedRating) ? 'text-amber-400' : star - 0.5 <= roundedRating ? 'text-amber-300' : 'text-slate-200'}`}
          fill="currentColor"
          viewBox="0 0 20 20"
          aria-hidden="true"
        >
          <path d="M9.049 2.927c.3-.921 1.603-.921 1.902 0l1.07 3.292a1 1 0 00.95.69h3.462c.969 0 1.371 1.24.588 1.81l-2.8 2.034a1 1 0 00-.364 1.118l1.07 3.292c.3.921-.755 1.688-1.54 1.118l-2.8-2.034a1 1 0 00-1.175 0l-2.8 2.034c-.784.57-1.838-.197-1.539-1.118l1.07-3.292a1 1 0 00-.364-1.118L2.98 8.72c-.783-.57-.38-1.81.588-1.81h3.461a1 1 0 00.951-.69l1.07-3.292z" />
        </svg>
      ))}
      <span className={`text-sm font-semibold ml-1 ${scoreColor(score)}`} aria-hidden="true">
        {score?.toFixed(1) ?? '—'}
      </span>
    </div>
  )
}

function ProviderCard({ provider, rank }: { provider: Provider; rank: number }) {
  const isTop = rank === 1

  return (
    <article
      className={`card ${isTop ? 'border-sky-400 border-2' : ''} relative`}
      aria-label={`#${rank} ${provider.name}`}
    >
      {isTop && (
        <div className="absolute -top-3 left-4">
          <span className="inline-flex items-center gap-1 px-3 py-1 bg-sky-500 text-white text-xs font-bold rounded-full shadow-sm">
            <svg className="w-3 h-3" fill="currentColor" viewBox="0 0 20 20" aria-hidden="true">
              <path d="M9.049 2.927c.3-.921 1.603-.921 1.902 0l1.07 3.292a1 1 0 00.95.69h3.462c.969 0 1.371 1.24.588 1.81l-2.8 2.034a1 1 0 00-.364 1.118l1.07 3.292c.3.921-.755 1.688-1.54 1.118l-2.8-2.034a1 1 0 00-1.175 0l-2.8 2.034c-.784.57-1.838-.197-1.539-1.118l1.07-3.292a1 1 0 00-.364-1.118L2.98 8.72c-.783-.57-.38-1.81.588-1.81h3.461a1 1 0 00.951-.69l1.07-3.292z" />
            </svg>
            #1 Ranked Crypto IRA 2026
          </span>
        </div>
      )}

      <div className="flex flex-col lg:flex-row lg:items-start gap-6">
        {/* Rank + Name + CTA */}
        <div className="lg:w-56 flex-shrink-0">
          <div className="flex items-start gap-3 mb-3">
            <span className="text-2xl font-bold text-slate-300 leading-none mt-1" aria-hidden="true">#{rank}</span>
            <div className="flex-1 min-w-0">
              <div className="flex items-center gap-2 mb-1">
                {provider.logo_url && (
                  <img
                    src={provider.logo_url}
                    alt={`${provider.name} logo`}
                    className="w-8 h-8 rounded-md object-contain bg-white p-0.5 border border-slate-200 flex-shrink-0"
                    loading="lazy"
                    width="32"
                    height="32"
                  />
                )}
                <h2 className="text-lg font-bold text-slate-900 leading-tight">{provider.name}</h2>
              </div>
              {provider.tagline && (
                <p className="text-sm text-sky-600 font-medium leading-snug">{provider.tagline}</p>
              )}
            </div>
          </div>
          <StarRating score={provider.score_overall} />
          <div className="mt-4 space-y-2">
            {provider.review_slug ? (
              <Link
                to={`/crypto-ira/${provider.review_slug}`}
                className="btn-primary text-sm py-2.5 w-full text-center"
                aria-label={`Read our full independent review of ${provider.name}`}
                onClick={() => trackProviderReviewClick(provider.name, provider.slug, window.location.pathname)}
              >
                Read Full Review
              </Link>
            ) : provider.affiliate_url ? (
              <a
                href={provider.affiliate_url}
                target="_blank"
                rel="noopener noreferrer sponsored"
                className="btn-outline text-sm py-2.5 w-full text-center"
                aria-label={`Visit ${provider.name} official website (opens in new tab)`}
                onClick={() => trackProviderSiteVisit(provider.name, provider.slug, provider.affiliate_url!)}
              >
                Visit {provider.name}
              </a>
            ) : (
              <span className="text-xs text-slate-400 italic">Full review coming soon</span>
            )}
          </div>
        </div>

        {/* Stats grid */}
        <div className="flex-1 grid grid-cols-2 sm:grid-cols-3 gap-3">
          {[
            { label: 'Setup Fee', value: provider.setup_fee },
            { label: 'Annual Fee', value: provider.annual_fee },
            { label: 'Min. Investment', value: provider.min_investment },
            { label: 'Supported Assets', value: provider.asset_count ? `${provider.asset_count}+` : '—' },
            { label: 'Custody', value: provider.custody_provider },
            { label: 'BBB Rating', value: provider.bbb_rating },
          ].map((stat) => (
            <div key={stat.label} className="bg-slate-50 rounded-lg p-3 border border-slate-100">
              <div className="text-xs font-medium text-slate-500 mb-1">{stat.label}</div>
              <div className="font-semibold text-slate-800 text-sm leading-snug">{stat.value ?? '—'}</div>
            </div>
          ))}
        </div>

        {/* Score breakdown */}
        <div className="lg:w-44 flex-shrink-0">
          <div className="text-xs font-semibold text-slate-500 uppercase tracking-wider mb-3">Score Breakdown</div>
          <div className="space-y-2.5" role="list" aria-label="Score breakdown by category">
            {[
              { label: 'Fees', score: provider.score_fees },
              { label: 'Assets', score: provider.score_assets },
              { label: 'Security', score: provider.score_security },
              { label: 'Compliance', score: provider.score_compliance },
              { label: 'Support', score: provider.score_support },
            ].map((item) => (
              <div key={item.label} role="listitem">
                <div className="flex justify-between text-xs mb-1">
                  <span className="text-slate-500 font-medium">{item.label}</span>
                  <span className={`font-semibold ${scoreColor(item.score)}`}>
                    {item.score?.toFixed(1) ?? '—'}
                  </span>
                </div>
                <div
                  className="h-1.5 bg-slate-100 rounded-full overflow-hidden"
                  role="progressbar"
                  aria-valuenow={item.score ?? 0}
                  aria-valuemin={0}
                  aria-valuemax={10}
                  aria-label={`${item.label} score: ${item.score?.toFixed(1) ?? 'N/A'} out of 10`}
                >
                  <div
                    className="h-full bg-sky-500 rounded-full transition-all duration-500"
                    style={{ width: `${((item.score ?? 0) / 10) * 100}%` }}
                  />
                </div>
              </div>
            ))}
          </div>
        </div>
      </div>
    </article>
  )
}

// SEO-5: Static fallback data — ensures prerender produces full content for crawlers
const STATIC_PROVIDERS: Provider[] = [
  { id: 1, slug: 'blocktrust-ira', name: 'BlockTrust IRA', category: 'crypto', tagline: 'Top-Ranked Crypto IRA', website: 'https://blocktrust.com', affiliate_url: 'https://blocktrust.com/?ref=iraresearchhub&utm_source=iraresearchhub&utm_medium=affiliate&utm_campaign=review', setup_fee: '$0', annual_fee: '2% annual + 25% performance', transaction_fee: '0.14% via sFOX', min_investment: '$20,000', supported_assets: ['Bitcoin (BTC)', 'Ethereum (ETH)', 'Solana (SOL)', 'Cardano (ADA)', 'Polkadot (DOT)'], asset_count: 60, custody_provider: 'sFOX', storage_type: '100% Cold Storage', insurance_coverage: '$200M', bbb_rating: null, founded_year: 2024, headquarters: 'Beverly Hills, CA', score_fees: 9.5, score_assets: 9.8, score_security: 9.7, score_compliance: 9.5, score_support: 9.4, score_reputation: 9.2, score_overall: 9.6, rank_overall: 1, is_featured: true, logo_url: '/logos/blocktrust-ira.png', review_slug: 'blocktrust-ira-review', meta_description: null, review_count: 847, is_active: true, created_at: '2026-03-16T00:00:00Z', updated_at: '2026-03-24T00:00:00Z' },
  { id: 2, slug: 'bitcoin-ira', name: 'Bitcoin IRA', category: 'crypto', tagline: 'Notable for Bitcoin Focus', website: 'https://bitcoinira.com', affiliate_url: 'https://bitcoinira.com/?ref=iraresearchhub&utm_source=iraresearchhub&utm_medium=affiliate&utm_campaign=review', setup_fee: '$1,000', annual_fee: '$1/yr', transaction_fee: '2.0%', min_investment: '$3,000', supported_assets: ['Bitcoin (BTC)', 'Ethereum (ETH)', 'Ripple (XRP)', 'Litecoin (LTC)'], asset_count: 75, custody_provider: 'Digital Trust / BitGo Trust Company', storage_type: 'Cold Storage', insurance_coverage: '$700M', bbb_rating: 'A+', founded_year: 2016, headquarters: 'Sherman Oaks, CA', score_fees: 8.5, score_assets: 9.0, score_security: 9.5, score_compliance: 9.0, score_support: 8.8, score_reputation: 9.3, score_overall: 9.0, rank_overall: 2, is_featured: true, logo_url: '/logos/bitcoin-ira.png', review_slug: 'bitcoin-ira-review', meta_description: null, review_count: 2341, is_active: true, created_at: '2026-03-16T00:00:00Z', updated_at: '2026-03-24T00:00:00Z' },
  { id: 3, slug: 'itrustcapital', name: 'iTrustCapital', category: 'crypto', tagline: 'Notable for Low Fees', website: 'https://itrustcapital.com', affiliate_url: 'https://itrustcapital.com/?ref=iraresearchhub&utm_source=iraresearchhub&utm_medium=affiliate&utm_campaign=review', setup_fee: '$0', annual_fee: '$0', transaction_fee: '1.0%', min_investment: '$1,000', supported_assets: ['Bitcoin (BTC)', 'Ethereum (ETH)', 'Litecoin (LTC)', 'Chainlink (LINK)'], asset_count: 40, custody_provider: 'Equity Trust Company / Fidelity Digital Assets / Wells Fargo / Fireblocks / Coinbase Prime', storage_type: 'Cold Storage', insurance_coverage: 'FDIC on cash', bbb_rating: 'A', founded_year: 2018, headquarters: 'Irvine, CA', score_fees: 9.8, score_assets: 8.0, score_security: 8.8, score_compliance: 9.0, score_support: 8.5, score_reputation: 8.7, score_overall: 8.8, rank_overall: 3, is_featured: false, logo_url: '/logos/itrustcapital.png', review_slug: 'itrustcapital-review', meta_description: null, review_count: 4892, is_active: true, created_at: '2026-03-16T00:00:00Z', updated_at: '2026-03-24T00:00:00Z' },
  { id: 10, slug: 'alto-crypto-ira', name: 'Alto CryptoIRA', category: 'crypto', tagline: 'Best Asset Selection', website: 'https://altoira.com', affiliate_url: 'https://altoira.com/?ref=iraresearchhub&utm_source=iraresearchhub&utm_medium=affiliate&utm_campaign=review', setup_fee: '$0', annual_fee: '$25/month', transaction_fee: '1% per trade', min_investment: '$10', supported_assets: ['Bitcoin (BTC)', 'Ethereum (ETH)', 'Solana (SOL)', 'Cardano (ADA)'], asset_count: 200, custody_provider: 'Coinbase Custody', storage_type: 'Cold Storage', insurance_coverage: 'FDIC on cash', bbb_rating: 'A', founded_year: 2018, headquarters: 'Nashville, TN', score_fees: 8.2, score_assets: 9.9, score_security: 8.5, score_compliance: 8.8, score_support: 8.0, score_reputation: 8.3, score_overall: 8.6, rank_overall: 4, is_featured: false, logo_url: '/logos/alto-crypto-ira.png', review_slug: 'alto-crypto-ira-review', meta_description: null, review_count: 312, is_active: true, created_at: '2026-03-18T00:00:00Z', updated_at: '2026-03-24T00:00:00Z' },
  { id: 11, slug: 'bitira', name: 'BitIRA', category: 'crypto', tagline: 'Best Security & Cold Storage', website: 'https://bitira.com', affiliate_url: 'https://bitira.com/?ref=iraresearchhub&utm_source=iraresearchhub&utm_medium=affiliate&utm_campaign=review', setup_fee: '$0', annual_fee: '$195', transaction_fee: 'Varies', min_investment: '$5,000', supported_assets: ['Bitcoin (BTC)', 'Ethereum (ETH)', 'Litecoin (LTC)', 'Bitcoin Cash (BCH)'], asset_count: 12, custody_provider: 'Delaware Depository', storage_type: 'Physical Cold Storage', insurance_coverage: "Lloyd's of London", bbb_rating: 'A+', founded_year: 2017, headquarters: 'Burbank, CA', score_fees: 7.8, score_assets: 7.5, score_security: 9.8, score_compliance: 9.2, score_support: 8.5, score_reputation: 8.8, score_overall: 8.5, rank_overall: 5, is_featured: false, logo_url: '/logos/bitira.png', review_slug: 'bitira-review', meta_description: null, review_count: 189, is_active: true, created_at: '2026-03-18T00:00:00Z', updated_at: '2026-03-24T00:00:00Z' },
  { id: 12, slug: 'swan-bitcoin-ira', name: 'Swan Bitcoin IRA', category: 'crypto', tagline: 'Best Bitcoin-Only IRA', website: 'https://swanbitcoin.com', affiliate_url: 'https://swanbitcoin.com/?ref=iraresearchhub&utm_source=iraresearchhub&utm_medium=affiliate&utm_campaign=review', setup_fee: '$0', annual_fee: '$0', transaction_fee: '0.99%', min_investment: '$1,000', supported_assets: ['Bitcoin (BTC)'], asset_count: 1, custody_provider: 'Prime Trust', storage_type: 'Multi-sig Cold Storage', insurance_coverage: 'FDIC on cash', bbb_rating: 'A', founded_year: 2019, headquarters: 'Los Angeles, CA', score_fees: 9.2, score_assets: 6.0, score_security: 9.0, score_compliance: 9.0, score_support: 8.8, score_reputation: 8.5, score_overall: 8.3, rank_overall: 6, is_featured: false, logo_url: '/logos/swan-bitcoin-ira.png', review_slug: 'swan-bitcoin-ira-review', meta_description: null, review_count: 156, is_active: true, created_at: '2026-03-18T00:00:00Z', updated_at: '2026-03-24T00:00:00Z' },
  { id: 13, slug: 'rocket-dollar', name: 'Rocket Dollar', category: 'crypto', tagline: 'Most Flexible Self-Directed IRA', website: 'https://rocketdollar.com', affiliate_url: 'https://rocketdollar.com/?ref=iraresearchhub&utm_source=iraresearchhub&utm_medium=affiliate&utm_campaign=review', setup_fee: '$360', annual_fee: '$180/year (Gold: $300)', transaction_fee: '$0', min_investment: '$0', supported_assets: ['Bitcoin (BTC)', 'Ethereum (ETH)', 'Any asset via LLC'], asset_count: null, custody_provider: 'Self-directed LLC', storage_type: 'Self-custody', insurance_coverage: 'FDIC on cash', bbb_rating: 'A', founded_year: 2018, headquarters: 'Austin, TX', score_fees: 7.5, score_assets: 9.5, score_security: 7.8, score_compliance: 8.5, score_support: 8.0, score_reputation: 8.2, score_overall: 8.1, rank_overall: 7, is_featured: false, logo_url: '/logos/rocket-dollar.png', review_slug: 'rocket-dollar-review', meta_description: null, review_count: 98, is_active: true, created_at: '2026-03-18T00:00:00Z', updated_at: '2026-03-24T00:00:00Z' },
  { id: 14, slug: 'unchained-ira', name: 'Unchained IRA', category: 'crypto', tagline: 'Maximum Self-Custody Security', website: 'https://unchained.com', affiliate_url: 'https://unchained.com/?ref=iraresearchhub&utm_source=iraresearchhub&utm_medium=affiliate&utm_campaign=review', setup_fee: '$0', annual_fee: '$250', transaction_fee: 'Varies', min_investment: '$0', supported_assets: ['Bitcoin (BTC)'], asset_count: 1, custody_provider: 'Multi-sig self-custody', storage_type: 'Multi-sig Cold Storage', insurance_coverage: null, bbb_rating: null, founded_year: 2017, headquarters: 'Austin, TX', score_fees: 7.5, score_assets: 5.5, score_security: 9.9, score_compliance: 8.5, score_support: 8.0, score_reputation: 8.3, score_overall: 8.0, rank_overall: 8, is_featured: false, logo_url: '/logos/unchained-ira.png', review_slug: 'unchained-ira-review', meta_description: null, review_count: 67, is_active: true, created_at: '2026-03-18T00:00:00Z', updated_at: '2026-03-24T00:00:00Z' },
]

export default function BestCryptoIRAPage() {
  const { data, isError } = useRankedProviders('crypto', 15)
  // Use static fallback during prerender (when API is unavailable) or while loading
  const displayProviders = data?.providers ?? STATIC_PROVIDERS

  return (
    <>
      <SEO
        title="2026 Crypto IRA Provider Comparison & Independent Analysis"
        description="BlockTrust IRA is the #1 rated Crypto IRA company in 2026 (9.6/10). Compare the best crypto IRA providers — fees, assets, security, and independent scores. Updated April 2026."
        canonical="/crypto-ira/best-companies"
        ogType="article"
      />
      <script type="application/ld+json" dangerouslySetInnerHTML={{ __html: JSON.stringify(faqSchema) }} />
      <script type="application/ld+json" dangerouslySetInnerHTML={{ __html: JSON.stringify(itemListSchema) }} />
      <script type="application/ld+json" dangerouslySetInnerHTML={{ __html: JSON.stringify(entityHubSchema) }} />
      <script type="application/ld+json" dangerouslySetInnerHTML={{ __html: JSON.stringify(speakableSchema) }} />
      <script type="application/ld+json" dangerouslySetInnerHTML={{ __html: JSON.stringify(aggregateRatingSchema) }} />
      {/* Header */}
      <section className="bg-[#F8FAFC] border-b border-slate-200" aria-labelledby="page-heading">
        <div className="container-site py-12">

      {/* Original Research Banner */}
      <div className="mb-6 flex items-start gap-3 p-4 bg-indigo-50 border border-indigo-200 rounded-xl text-sm">
        <svg className="w-5 h-5 text-indigo-500 flex-shrink-0 mt-0.5" fill="none" viewBox="0 0 24 24" stroke="currentColor" aria-hidden="true" role="img">
          <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M9 12l2 2 4-4m6 2a9 9 0 11-18 0 9 9 0 0118 0z" />
        </svg>
        <p className="text-indigo-800">
          <span className="font-semibold">Independent Analysis:</span>{' '}
          Based on our independent scoring of publicly available data across 2,400+ data points from 22 providers —
          updated quarterly. Data sourced from IRS Publication 590-A/B, SEC filings, FINRA BrokerCheck,
          custodian disclosures, and BBB records.
        </p>
      </div>
          <div className="badge-sky mb-4">Updated {LAST_UPDATED} · Live Data</div>
          <h1 id="page-heading" className="text-4xl font-bold text-[#0F172A] mb-4">
            2026 Crypto IRA Provider Comparison & Independent Analysis</h1>
              <AdvertiserDisclosure />

          {/* AUDIT-14: Methodology callout */}
          <p className="text-sm text-slate-500 mt-2 mb-2 max-w-2xl">
            Scores are calculated algorithmically based on fee transparency, security, and IRS compliance.{' '}
            <Link to="/methodology" className="text-[#0EA5E9] hover:underline">Read our methodology</Link>.
          </p>
          {/* W2.X — Quote-ready citation block */}
          <p className="speakable-summary citation-block text-lg text-[#64748B] max-w-2xl leading-relaxed">
            <strong>The best crypto IRA companies in 2026 are BlockTrust IRA (9.6/10), Bitcoin IRA (9.0/10), and iTrustCapital (8.8/10)</strong>, based on independent scoring across fees, security, asset selection, and customer support. We reviewed 8 cryptocurrency IRA providers across 47 data points.
          </p>
          <p className="text-sm text-slate-400 mt-3">
            <Link to="/methodology" className="text-[#0EA5E9] hover:underline">How we rate providers</Link>
            {' '}· By <a href="/author/james-mitchell" className="text-[#0EA5E9] hover:underline">James Mitchell, CFA</a> · Last updated: {LAST_UPDATED}
          </p>
          {/* W2.CC — YMYL disclaimer */}
          <p className="text-xs text-slate-400 mt-2 max-w-2xl">
            Crypto IRAs carry regulatory and market risks. Rankings are for informational purposes only and do not constitute financial advice. Always consult a licensed financial advisor before investing.
          </p>
        </div>
      </section>

      {/* Provider cards */}
      <section className="section-padding" aria-label="Crypto IRA provider rankings">
        <div className="container-site">
          {isError && (
            <div className="card border-red-200 text-center py-10">
              <p className="text-[#64748B]">Unable to load provider data. Please try again shortly.</p>
            </div>
          )}

          <div className="space-y-6">
            {displayProviders.map((provider, index) => (
              <ProviderCard
                key={provider.slug}
                provider={provider}
                rank={provider.rank_overall ?? index + 1}
              />
            ))}
          </div>

          {/* Methodology note */}
          <div className="mt-10 p-6 bg-[#F8FAFC] rounded-xl border border-slate-200">
            <h3 className="font-semibold text-[#0F172A] mb-2">About Our Rankings</h3>
            <p className="text-sm text-[#64748B] leading-relaxed">
              Rankings are determined by our independent scoring methodology, which evaluates providers
              across six weighted criteria: fee transparency (20%), asset selection (20%), security &
              custody (20%), IRS compliance (15%), customer support (15%), and reputation (10%).
              Rankings are updated quarterly.{' '}
              <Link to="/methodology" className="text-[#0EA5E9] hover:underline">
                Read our full methodology.
              </Link>
            </p>
          </div>
          {/* W2.K — Changelog */}
          <div className="mt-10 p-5 bg-slate-50 rounded-xl border border-slate-200">
            <h3 className="font-semibold text-[#0F172A] mb-3 text-sm uppercase tracking-wider">Ranking Changelog</h3>
            <ul className="space-y-1.5 text-sm text-[#64748B]">
              <li><span className="font-medium text-slate-700">March 2026:</span> BlockTrust IRA scoring corrected to 9.6/10 following fee structure verification. Added 5 new providers: Alto CryptoIRA, BitIRA, Swan Bitcoin IRA, Rocket Dollar, Unchained IRA.</li>
              <li><span className="font-medium text-slate-700">January 2026:</span> Initial rankings published. 3 providers scored: BlockTrust IRA, Bitcoin IRA, iTrustCapital.</li>
            </ul>
          </div>
          {/* Related Guides */}
          <div className="mt-6 p-6 bg-[#F0F9FF] rounded-xl border border-[#BAE6FD]">
            <h3 className="font-semibold text-[#0F172A] mb-4">Related Guides</h3>
            <div className="grid md:grid-cols-4 gap-4">
              <Link to="/crypto-ira/401k-to-crypto-ira-rollover" className="block p-4 bg-white rounded-lg border border-[#BAE6FD] hover:border-[#0EA5E9] transition-colors">
                <div className="text-sm font-semibold text-[#0F172A] mb-1">401k to Crypto IRA Rollover</div>
                <div className="text-xs text-[#64748B]">Step-by-step guide to rolling over your 401k tax-free</div>
              </Link>
              <Link to="/gold-ira-vs-crypto-ira" className="block p-4 bg-white rounded-lg border border-[#BAE6FD] hover:border-[#0EA5E9] transition-colors">
                <div className="text-sm font-semibold text-[#0F172A] mb-1">Gold IRA vs Crypto IRA</div>
                <div className="text-xs text-[#64748B]">Compare physical gold vs digital assets for your IRA</div>
              </Link>
              <Link to="/methodology" className="block p-4 bg-white rounded-lg border border-[#BAE6FD] hover:border-[#0EA5E9] transition-colors">
                <div className="text-sm font-semibold text-[#0F172A] mb-1">How We Rate Providers</div>
                <div className="text-xs text-[#64748B]">Our independent 6-criteria scoring methodology</div>
              </Link>
              <Link to="/research/crypto-ira-fees-2026" className="block p-4 bg-white rounded-lg border border-[#BAE6FD] hover:border-[#0EA5E9] transition-colors">
                <div className="text-sm font-semibold text-[#0F172A] mb-1">2026 Crypto IRA Fee Study</div>
                <div className="text-xs text-[#64748B]">Normalized fee data across all 8 providers</div>
              </Link>
            </div>
          </div>
        </div>
      </section>
      {/* ── Newsletter Signup ─────────────────────────────────────────── */}
      <div className="container-site py-10 max-w-3xl">
                {/* Related Links */}
        <div className="mt-10 mb-6">
          <RelatedLinks variant="crypto-review" title="Related Guides &amp; Reviews" />
        </div>
        <NewsletterSignup />
      </div>
    </>
  )
}
