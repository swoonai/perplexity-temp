import StateGuideTemplate from '../components/StateGuideTemplate'

export default function BestCryptoIRATNPage() {
  return (
    <StateGuideTemplate
      stateName="Tennessee"
      stateAbbr="TN"
      slug="tennessee"
    />
  )
}
