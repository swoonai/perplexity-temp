import StateGuideTemplate from '../components/StateGuideTemplate'

export default function BestCryptoIRANHPage() {
  return (
    <StateGuideTemplate
      stateName="New Hampshire"
      stateAbbr="NH"
      slug="new-hampshire"
    />
  )
}
