import AwardDetailPage from './AwardDetailPage'

export default function BestCryptoIra2026AwardPage() {
  return <AwardDetailPage awardSlug="best-crypto-ira-2026" />
}
