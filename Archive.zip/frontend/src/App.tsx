import { lazy, Suspense } from 'react'
import ScrollToTop from './components/ScrollToTop'
import { BrowserRouter as Router, Routes, Route, Navigate } from 'react-router-dom'
import { QueryClient, QueryClientProvider } from '@tanstack/react-query'
import Layout from './components/Layout'

// Eagerly load only the most critical page (homepage)
import HomePage from './pages/HomePage'

// Lazy-load all other pages — each becomes its own JS chunk
const AboutPage = lazy(() => import('./pages/AboutPage'))
const MethodologyPage = lazy(() => import('./pages/MethodologyPage'))
const PrivacyPage = lazy(() => import('./pages/PrivacyPage'))
const TermsPage = lazy(() => import('./pages/TermsPage'))
const EditorialPolicyPage = lazy(() => import('./pages/EditorialPolicyPage'))
const AuthorPage = lazy(() => import('./pages/AuthorPage'))

// Crypto IRA hub pages
const CryptoIRAPage = lazy(() => import('./pages/CryptoIRAPage'))
const BestCryptoIRAPage = lazy(() => import('./pages/BestCryptoIRAPage'))
const BestBitcoinIRAPage = lazy(() => import('./pages/BestBitcoinIRAPage'))
const BestGoldIRAPage = lazy(() => import('./pages/BestGoldIRAPage'))
const SwanVsBlockTrustPage = lazy(() => import('./pages/SwanVsBlockTrustPage'))
const AltoVsITrustCapitalPage = lazy(() => import('./pages/AltoVsITrustCapitalPage'))
const BitIRAVsBitcoinIRAPage = lazy(() => import('./pages/BitIRAVsBitcoinIRAPage'))
const WhatIsCryptoIRAPage = lazy(() => import('./pages/WhatIsCryptoIRAPage'))
const WhatIsGoldIRAPage = lazy(() => import('./pages/WhatIsGoldIRAPage'))
const CryptoIRAVsStockIRAPage = lazy(() => import('./pages/CryptoIRAVsStockIRAPage'))
const HowToOpenCryptoIRAPage = lazy(() => import('./pages/HowToOpenCryptoIRAPage'))

// Crypto IRA review pages
const BlockTrustReviewPage = lazy(() => import('./pages/BlockTrustReviewPage'))
const BitcoinIRAReviewPage = lazy(() => import('./pages/BitcoinIRAReviewPage'))
const ITrustCapitalReviewPage = lazy(() => import('./pages/ITrustCapitalReviewPage'))
const AltoCryptoIRAReviewPage = lazy(() => import('./pages/AltoCryptoIRAReviewPage'))
const BitIRAReviewPage = lazy(() => import('./pages/BitIRAReviewPage'))
const SwanBitcoinIRAReviewPage = lazy(() => import('./pages/SwanBitcoinIRAReviewPage'))
const RocketDollarReviewPage = lazy(() => import('./pages/RocketDollarReviewPage'))
const UnchainedIRAReviewPage = lazy(() => import('./pages/UnchainedIRAReviewPage'))

// Precious Metals IRA hub pages
const PreciousMetalsIRAPage = lazy(() => import('./pages/PreciousMetalsIRAPage'))
const BestPreciousMetalsIRAPage = lazy(() => import('./pages/BestPreciousMetalsIRAPage'))

// Precious Metals IRA review pages
const GenesisGoldReviewPage = lazy(() => import('./pages/GenesisGoldReviewPage'))
const AugustaPreciousMetalsReviewPage = lazy(() => import('./pages/AugustaPreciousMetalsReviewPage'))
const BirchGoldGroupReviewPage = lazy(() => import('./pages/BirchGoldGroupReviewPage'))
const GoldcoReviewPage = lazy(() => import('./pages/GoldcoReviewPage'))
const AmericanHartfordGoldReviewPage = lazy(() => import('./pages/AmericanHartfordGoldReviewPage'))
const LearCapitalReviewPage = lazy(() => import('./pages/LearCapitalReviewPage'))
const NobleGoldInvestmentsReviewPage = lazy(() => import('./pages/NobleGoldInvestmentsReviewPage'))
const AdvantageGoldReviewPage = lazy(() => import('./pages/AdvantageGoldReviewPage'))
const GoldenCrestMetalsReviewPage = lazy(() => import('./pages/GoldenCrestMetalsReviewPage'))
const PatriotGoldGroupReviewPage = lazy(() => import('./pages/PatriotGoldGroupReviewPage'))
const OxfordGoldGroupReviewPage = lazy(() => import('./pages/OxfordGoldGroupReviewPage'))
const PreserveGoldReviewPage = lazy(() => import('./pages/PreserveGoldReviewPage'))
const RoslandCapitalReviewPage = lazy(() => import('./pages/RoslandCapitalReviewPage'))
const AllegianceGoldReviewPage = lazy(() => import('./pages/AllegianceGoldReviewPage'))

// Rollover guides
const GoldIRARolloverGuidePage = lazy(() => import('./pages/GoldIRARolloverGuidePage'))
const CryptoIRARolloverGuidePage = lazy(() => import('./pages/CryptoIRARolloverGuidePage'))

// Comparison pages
const BlockTrustVsBitcoinIRAPage = lazy(() => import('./pages/BlockTrustVsBitcoinIRAPage'))
const BlockTrustVsITrustCapitalPage = lazy(() => import('./pages/BlockTrustVsITrustCapitalPage'))
const BitcoinIRAVsITrustCapitalPage = lazy(() => import('./pages/BitcoinIRAVsITrustCapitalPage'))

// Research pages
const CryptoIRAFees2026Page = lazy(() => import('./pages/CryptoIRAFees2026Page'))
const GoldIRAFees2026Page = lazy(() => import('./pages/GoldIRAFees2026Page'))
const PreciousMetalsIRAFeesPage = lazy(() => import('./pages/PreciousMetalsIRAFeesPage'))
const GoldVsCryptoIRAPage = lazy(() => import('./pages/GoldVsCryptoIRAPage'))

// Comparison pages
const AugustaVsGoldcoPage = lazy(() => import('./pages/AugustaVsGoldcoPage'))
const BirchGoldVsAugustaPage = lazy(() => import('./pages/BirchGoldVsAugustaPage'))
const GoldIRAVsSilverIRAPage = lazy(() => import('./pages/GoldIRAVsSilverIRAPage'))

// How-to guides
const HowToOpenGoldIRAPage = lazy(() => import('./pages/HowToOpenGoldIRAPage'))
const HowToBuyGoldInIRAPage = lazy(() => import('./pages/HowToBuyGoldInIRAPage'))

// Fidelity Crypto IRA review
const FidelityCryptoIRAReviewPage = lazy(() => import('./pages/FidelityCryptoIRAReviewPage'))

// Coin-specific IRA guides
const XRPRippleIRAPage = lazy(() => import('./pages/XRPRippleIRAPage'))
const LitecoinIRAPage = lazy(() => import('./pages/LitecoinIRAPage'))
const SolanaIRAPage = lazy(() => import('./pages/SolanaIRAPage'))
const DogecoinIRAPage = lazy(() => import('./pages/DogecoinIRAPage'))
const EthereumIRAPage = lazy(() => import('./pages/EthereumIRAPage'))

// Education pages (Google Ads compliance — no affiliate links)
// Educational Guide pages (Tier 2 content strategy)
const GuidesIndexPage = lazy(() => import('./pages/GuidesIndexPage'))
const WhatIsSDIRAPage = lazy(() => import('./pages/WhatIsSDIRAPage'))
const CryptoInRetirementPage = lazy(() => import('./pages/CryptoInRetirementPage'))
const PreciousMetalsInIRAGuidePage = lazy(() => import('./pages/PreciousMetalsInIRAGuidePage'))
const IRARolloverRulesPage = lazy(() => import('./pages/IRARolloverRulesPage'))
const HowToResearchSDIRAProvidersPage = lazy(() => import('./pages/HowToResearchSDIRAProvidersPage'))
const IRAContributionLimitsPage = lazy(() => import('./pages/IRAContributionLimitsPage'))
const RMDGuide2026Page = lazy(() => import('./pages/RMDGuide2026Page'))
const CryptoIRAVsDirectPage = lazy(() => import('./pages/CryptoIRAVsDirectPage'))
const GoldIRAVsGoldETFPage = lazy(() => import('./pages/GoldIRAVsGoldETFPage'))
const IRATaxStrategiesPage = lazy(() => import('./pages/IRATaxStrategiesPage'))
const IrsRulesDigitalAssetIrasPage = lazy(() => import('./pages/IrsRulesDigitalAssetIrasPage'))
const GoldIRAGuidePage = lazy(() => import('./pages/GoldIRAGuidePage'))
const CryptoIRAGuidePage = lazy(() => import('./pages/CryptoIRAGuidePage'))
const BestCryptoIRA2026Page = lazy(() => import('./pages/BestCryptoIRA2026Page'))
const DigitalAssetRetirementPage = lazy(() => import('./pages/DigitalAssetRetirementPage'))

// Admin tools
const DomainMonitorPage = lazy(() => import('./pages/DomainMonitorPage'))
const CitationDashboardPage = lazy(() => import('./pages/CitationDashboardPage'))
const SEODashboardPage = lazy(() => import('./pages/SEODashboardPage'))

// Content Gap Pages
const CryptoIRAFeeCalculatorPage = lazy(() => import('./pages/CryptoIRAFeeCalculatorPage'))
const CryptoIRARolloverEligibilityPage = lazy(() => import('./pages/CryptoIRARolloverEligibilityPage'))
const BlockTrustVsSwanBitcoinIRAPage = lazy(() => import('./pages/BlockTrustVsSwanBitcoinIRAPage'))
const CryptoIRAIndustryReport2026Page = lazy(() => import('./pages/CryptoIRAIndustryReport2026Page'))
const BestCryptoIRAHighNetWorthPage = lazy(() => import('./pages/BestCryptoIRAHighNetWorthPage'))
const BestCryptoIRASelfEmployedPage = lazy(() => import('./pages/BestCryptoIRASelfEmployedPage'))
const BestCryptoIRABitcoinOnlyPage = lazy(() => import('./pages/BestCryptoIRABitcoinOnlyPage'))
const BestCryptoIRARetireesPage = lazy(() => import('./pages/BestCryptoIRARetireesPage'))
const BestCryptoIRAActiveTradersPage = lazy(() => import('./pages/BestCryptoIRAActiveTradersPage'))
const BestCryptoIRAAltcoinsPage = lazy(() => import('./pages/BestCryptoIRAAltcoinsPage'))
const BestCryptoIRARolloverPage = lazy(() => import('./pages/BestCryptoIRARolloverPage'))
const BestCryptoIRABeginnersPage = lazy(() => import('./pages/BestCryptoIRABeginnersPage'))
const CryptoIRATaxGuide2026Page = lazy(() => import('./pages/CryptoIRATaxGuide2026Page'))
const BestCryptoIRAMNPage = lazy(() => import('./pages/BestCryptoIRAMNPage'))
const BestCryptoIRAWIPage = lazy(() => import('./pages/BestCryptoIRAWIPage'))
const BestCryptoIRAINPage = lazy(() => import('./pages/BestCryptoIRAINPage'))
const BestCryptoIRAMOPage = lazy(() => import('./pages/BestCryptoIRAMOPage'))
const BestCryptoIRASCPage = lazy(() => import('./pages/BestCryptoIRASCPage'))
const BestCryptoIRACTPage = lazy(() => import('./pages/BestCryptoIRACTPage'))
const BestCryptoIRALAPage = lazy(() => import('./pages/BestCryptoIRALAPage'))
const BestCryptoIRAKSPage = lazy(() => import('./pages/BestCryptoIRAKSPage'))
const BestCryptoIRAKYPage = lazy(() => import('./pages/BestCryptoIRAKYPage'))
const BestCryptoIRAOKPage = lazy(() => import('./pages/BestCryptoIRAOKPage'))
const BestCryptoIRAALPage = lazy(() => import('./pages/BestCryptoIRAALPage'))
const BestCryptoIRAIAPage = lazy(() => import('./pages/BestCryptoIRAIAPage'))
const BestCryptoIRAIDPage = lazy(() => import('./pages/BestCryptoIRAIDPage'))
const BestCryptoIRANEPage = lazy(() => import('./pages/BestCryptoIRANEPage'))
const BestCryptoIRANMPage = lazy(() => import('./pages/BestCryptoIRANMPage'))
const BestCryptoIRANHPage = lazy(() => import('./pages/BestCryptoIRANHPage'))
const BestCryptoIRAHIPage = lazy(() => import('./pages/BestCryptoIRAHIPage'))
const BestCryptoIRAARPage = lazy(() => import('./pages/BestCryptoIRAARPage'))
const BestCryptoIRAWYPage = lazy(() => import('./pages/BestCryptoIRAWYPage'))
const BestCryptoIRAWVPage = lazy(() => import('./pages/BestCryptoIRAWVPage'))
const BestCryptoIRASDPage = lazy(() => import('./pages/BestCryptoIRASDPage'))
const BestCryptoIRAAKPage = lazy(() => import('./pages/BestCryptoIRAAKPage'))
const BestCryptoIRADEPage = lazy(() => import('./pages/BestCryptoIRADEPage'))
const BestCryptoIRAMSPage = lazy(() => import('./pages/BestCryptoIRAMSPage'))
const BestCryptoIRAMEPage = lazy(() => import('./pages/BestCryptoIRAMEPage'))
const BestCryptoIRARIPage = lazy(() => import('./pages/BestCryptoIRARIPage'))
const BestCryptoIRAMTPage = lazy(() => import('./pages/BestCryptoIRAMTPage'))
const BestCryptoIRAVTPage = lazy(() => import('./pages/BestCryptoIRAVTPage'))
const BestCryptoIRANDPage = lazy(() => import('./pages/BestCryptoIRANDPage'))
const BestCryptoIRAILPage = lazy(() => import('./pages/BestCryptoIRAILPage'))
const BestCryptoIRAPAPage = lazy(() => import('./pages/BestCryptoIRAPAPage'))
const BestCryptoIRAGAPage = lazy(() => import('./pages/BestCryptoIRAGAPage'))
const BestCryptoIRACOPage = lazy(() => import('./pages/BestCryptoIRACOPage'))
const BestCryptoIRAWAPage = lazy(() => import('./pages/BestCryptoIRAWAPage'))
const BestCryptoIRANCPage = lazy(() => import('./pages/BestCryptoIRANCPage'))
const BestCryptoIRAOHPage = lazy(() => import('./pages/BestCryptoIRAOHPage'))
const BestCryptoIRANJPage = lazy(() => import('./pages/BestCryptoIRANJPage'))
const BestCryptoIRAAZPage = lazy(() => import('./pages/BestCryptoIRAAZPage'))
const BestCryptoIRAMIPage = lazy(() => import('./pages/BestCryptoIRAMIPage'))
const BestCryptoIRAVAPage = lazy(() => import('./pages/BestCryptoIRAVAPage'))
const BestCryptoIRANVPage = lazy(() => import('./pages/BestCryptoIRANVPage'))
const BestCryptoIRAMAPage = lazy(() => import('./pages/BestCryptoIRAMAPage'))
const BestCryptoIRAMDPage = lazy(() => import('./pages/BestCryptoIRAMDPage'))
const BestCryptoIRATNPage = lazy(() => import('./pages/BestCryptoIRATNPage'))
const BestCryptoIRAUTPage = lazy(() => import('./pages/BestCryptoIRAUTPage'))
const BestCryptoIRAORPage = lazy(() => import('./pages/BestCryptoIRAORPage'))
const BestCryptoIRANYPage = lazy(() => import('./pages/BestCryptoIRANYPage'))
const BestCryptoIRAFLPage = lazy(() => import('./pages/BestCryptoIRAFLPage'))
const BestCryptoIRATXPage = lazy(() => import('./pages/BestCryptoIRATXPage'))
const BestCryptoIRACAPage = lazy(() => import('./pages/BestCryptoIRACAPage'))

// Quiz / email capture
const IRAFitQuizPage = lazy(() => import('./pages/IRAFitQuizPage'))

// Awards pages
const AwardsHubPage = lazy(() => import('./pages/AwardsHubPage'))
const BestCryptoIra2026AwardPage = lazy(() => import('./pages/BestCryptoIra2026AwardPage'))
const BestGoldIra2026AwardPage = lazy(() => import('./pages/BestGoldIra2026AwardPage'))
const BestFeeTransparency2026AwardPage = lazy(() => import('./pages/BestFeeTransparency2026AwardPage'))
const BestCustomerService2026AwardPage = lazy(() => import('./pages/BestCustomerService2026AwardPage'))
const BestCryptoIra2025AwardPage = lazy(() => import('./pages/BestCryptoIra2025AwardPage'))
const BestGoldIra2025AwardPage = lazy(() => import('./pages/BestGoldIra2025AwardPage'))

// 404
const NotFoundPage = lazy(() => import('./pages/NotFoundPage'))

// Loading fallback — minimal spinner that matches the site's dark theme
function PageLoader() {
  return (
    <div className="flex items-center justify-center min-h-[400px]">
      <div className="text-slate-400 text-sm">Loading…</div>
    </div>
  )
}

const queryClient = new QueryClient({
  defaultOptions: {
    queries: {
      staleTime: 1000 * 60 * 5,
      retry: 1,
    },
  },
})

function App() {
  return (
    <QueryClientProvider client={queryClient}>
      <Router>
        <ScrollToTop />
        <Suspense fallback={<PageLoader />}>
          <Routes>
            <Route path="/" element={<Layout />}>
              <Route index element={<HomePage />} />
              <Route path="about" element={<AboutPage />} />
              <Route path="methodology" element={<MethodologyPage />} />
              <Route path="privacy" element={<PrivacyPage />} />
              <Route path="terms" element={<TermsPage />} />
              <Route path="editorial-policy" element={<EditorialPolicyPage />} />

              {/* Author pages */}
              <Route path="author/james-mitchell" element={<AuthorPage />} />

              {/* Crypto IRA routes */}
              <Route path="crypto-ira" element={<CryptoIRAPage />} />
              <Route path="crypto-ira/best-companies" element={<BestCryptoIRAPage />} />
              <Route path="crypto-ira/best-bitcoin-ira" element={<BestBitcoinIRAPage />} />
              <Route path="precious-metals-ira/best-gold-ira" element={<BestGoldIRAPage />} />
              <Route path="crypto-ira/swan-bitcoin-ira-vs-blocktrust-ira" element={<SwanVsBlockTrustPage />} />
              <Route path="crypto-ira/alto-crypto-ira-vs-itrustcapital" element={<AltoVsITrustCapitalPage />} />
              <Route path="crypto-ira/bitira-vs-bitcoin-ira" element={<BitIRAVsBitcoinIRAPage />} />
              <Route path="crypto-ira/what-is-a-crypto-ira" element={<WhatIsCryptoIRAPage />} />
              <Route path="crypto-ira/best-crypto-ira-2026" element={<BestCryptoIRA2026Page />} />
              <Route path="precious-metals-ira/what-is-a-gold-ira" element={<WhatIsGoldIRAPage />} />
              {/* Redirect legacy /precious-metals/ URLs to correct /precious-metals-ira/ paths */}
              <Route path="precious-metals/what-is-a-gold-ira" element={<Navigate to="/precious-metals-ira/what-is-a-gold-ira" replace />} />
              <Route path="precious-metals/best-gold-ira" element={<Navigate to="/precious-metals-ira/best-gold-ira" replace />} />
              <Route path="precious-metals/best-companies" element={<Navigate to="/precious-metals-ira/best-companies" replace />} />
              <Route path="crypto-ira-vs-stock-ira" element={<CryptoIRAVsStockIRAPage />} />
              <Route path="crypto-ira/how-to-open-a-crypto-ira" element={<HowToOpenCryptoIRAPage />} />
              <Route path="crypto-ira/blocktrust-ira-review" element={<BlockTrustReviewPage />} />
              <Route path="crypto-ira/bitcoin-ira-review" element={<BitcoinIRAReviewPage />} />
              <Route path="crypto-ira/itrustcapital-review" element={<ITrustCapitalReviewPage />} />
              <Route path="crypto-ira/alto-crypto-ira-review" element={<AltoCryptoIRAReviewPage />} />
              <Route path="crypto-ira/bitira-review" element={<BitIRAReviewPage />} />
              <Route path="crypto-ira/swan-bitcoin-ira-review" element={<SwanBitcoinIRAReviewPage />} />
              <Route path="crypto-ira/rocket-dollar-review" element={<RocketDollarReviewPage />} />
              <Route path="crypto-ira/unchained-ira-review" element={<UnchainedIRAReviewPage />} />

              {/* Precious Metals IRA routes */}
              <Route path="precious-metals-ira" element={<PreciousMetalsIRAPage />} />
              <Route path="precious-metals-ira/best-companies" element={<BestPreciousMetalsIRAPage />} />
              <Route path="precious-metals-ira/genesis-gold-group-review" element={<GenesisGoldReviewPage />} />
              <Route path="precious-metals-ira/augusta-precious-metals-review" element={<AugustaPreciousMetalsReviewPage />} />
              <Route path="precious-metals-ira/birch-gold-group-review" element={<BirchGoldGroupReviewPage />} />
              <Route path="precious-metals-ira/goldco-review" element={<GoldcoReviewPage />} />
              <Route path="precious-metals-ira/american-hartford-gold-review" element={<AmericanHartfordGoldReviewPage />} />
              <Route path="precious-metals-ira/lear-capital-review" element={<LearCapitalReviewPage />} />
              <Route path="precious-metals-ira/noble-gold-investments-review" element={<NobleGoldInvestmentsReviewPage />} />
              <Route path="precious-metals-ira/advantage-gold-review" element={<AdvantageGoldReviewPage />} />
              <Route path="precious-metals-ira/goldencrest-metals-review" element={<GoldenCrestMetalsReviewPage />} />
              <Route path="precious-metals-ira/patriot-gold-group-review" element={<PatriotGoldGroupReviewPage />} />
              <Route path="precious-metals-ira/oxford-gold-group-review" element={<OxfordGoldGroupReviewPage />} />
              <Route path="precious-metals-ira/preserve-gold-review" element={<PreserveGoldReviewPage />} />
              <Route path="precious-metals-ira/rosland-capital-review" element={<RoslandCapitalReviewPage />} />
              <Route path="precious-metals-ira/allegiance-gold-review" element={<AllegianceGoldReviewPage />} />

              {/* Rollover guides */}
              <Route path="precious-metals-ira/401k-to-gold-ira-rollover" element={<GoldIRARolloverGuidePage />} />
              <Route path="crypto-ira/401k-to-crypto-ira-rollover" element={<CryptoIRARolloverGuidePage />} />

              {/* Comparison pages */}
              <Route path="gold-ira-vs-crypto-ira" element={<GoldVsCryptoIRAPage />} />
              <Route path="crypto-ira/blocktrust-ira-vs-bitcoin-ira" element={<BlockTrustVsBitcoinIRAPage />} />
              <Route path="crypto-ira/blocktrust-ira-vs-itrustcapital" element={<BlockTrustVsITrustCapitalPage />} />
              <Route path="crypto-ira/bitcoin-ira-vs-itrustcapital" element={<BitcoinIRAVsITrustCapitalPage />} />
              <Route path="precious-metals-ira/augusta-vs-goldco" element={<AugustaVsGoldcoPage />} />
              <Route path="precious-metals-ira/birch-gold-vs-augusta" element={<BirchGoldVsAugustaPage />} />
              <Route path="precious-metals-ira/gold-ira-vs-silver-ira" element={<GoldIRAVsSilverIRAPage />} />
              <Route path="precious-metals-ira/how-to-open-gold-ira" element={<HowToOpenGoldIRAPage />} />
              <Route path="precious-metals-ira/how-to-buy-gold-in-ira" element={<HowToBuyGoldInIRAPage />} />

              <Route path="crypto-ira/fidelity-crypto-ira-review" element={<FidelityCryptoIRAReviewPage />} />

              {/* Coin-specific IRA guides */}
              <Route path="crypto-ira/xrp-ripple-ira" element={<XRPRippleIRAPage />} />
              <Route path="crypto-ira/litecoin-ira" element={<LitecoinIRAPage />} />
              <Route path="crypto-ira/solana-ira" element={<SolanaIRAPage />} />
              <Route path="crypto-ira/dogecoin-ira" element={<DogecoinIRAPage />} />
              <Route path="crypto-ira/ethereum-ira" element={<EthereumIRAPage />} />

              {/* Research / Proprietary Data pages */}
              <Route path="research/crypto-ira-fees-2026" element={<CryptoIRAFees2026Page />} />
              <Route path="research/gold-ira-fees-2026" element={<GoldIRAFees2026Page />} />
              <Route path="research/precious-metals-ira-fees-2026" element={<PreciousMetalsIRAFeesPage />} />
              <Route path="research/gold-ira-vs-crypto-ira-2026" element={<GoldVsCryptoIRAPage />} />

                            {/* Educational Guide pages — /guides/* */}
              <Route path="guides" element={<GuidesIndexPage />} />
              <Route path="guides/what-is-self-directed-ira" element={<WhatIsSDIRAPage />} />
              <Route path="guides/crypto-in-retirement" element={<CryptoInRetirementPage />} />
              <Route path="guides/precious-metals-in-ira" element={<PreciousMetalsInIRAGuidePage />} />
              <Route path="guides/ira-rollover-rules" element={<IRARolloverRulesPage />} />
              <Route path="guides/how-to-research-sdira-providers" element={<HowToResearchSDIRAProvidersPage />} />
              <Route path="guides/ira-contribution-limits-2026" element={<IRAContributionLimitsPage />} />
              <Route path="guides/required-minimum-distributions-2026" element={<RMDGuide2026Page />} />
              <Route path="guides/crypto-ira-vs-buying-directly" element={<CryptoIRAVsDirectPage />} />
              <Route path="guides/gold-ira-vs-gold-etf" element={<GoldIRAVsGoldETFPage />} />
              <Route path="guides/ira-tax-strategies-high-income" element={<IRATaxStrategiesPage />} />
              {/* Redirect routes for Google Ads landing pages — /education/* → /guides/* */}
              <Route path="education/what-is-a-self-directed-ira" element={<Navigate to="/guides/what-is-self-directed-ira" replace />} />
              <Route path="education/how-to-research-sdira-providers" element={<Navigate to="/guides/how-to-research-sdira-providers" replace />} />
              <Route path="education/required-minimum-distributions" element={<Navigate to="/guides/required-minimum-distributions-2026" replace />} />
              <Route path="education/ira-tax-strategies-high-income" element={<Navigate to="/guides/ira-tax-strategies-high-income" replace />} />
              {/* Education pages — no affiliate links (Google Ads compliance) */}
              <Route path="education/irs-rules-digital-asset-iras" element={<IrsRulesDigitalAssetIrasPage />} />
              <Route path="education/gold-ira-guide" element={<GoldIRAGuidePage />} />
              <Route path="education/crypto-ira-guide" element={<CryptoIRAGuidePage />} />
              <Route path="education/digital-asset-retirement-planning" element={<DigitalAssetRetirementPage />} />

              {/* Admin tools */}
              <Route path="admin/domain-monitor" element={<DomainMonitorPage />} />
              <Route path="admin/citation-monitor" element={<CitationDashboardPage />} />
              <Route path="admin/seo-dashboard" element={<SEODashboardPage />} />

              {/* Content Gap Routes */}
              <Route path="tools/crypto-ira-fee-calculator" element={<CryptoIRAFeeCalculatorPage />} />
              <Route path="tools/crypto-ira-rollover-eligibility" element={<CryptoIRARolloverEligibilityPage />} />
              <Route path="crypto-ira/blocktrust-ira-vs-swan-bitcoin-ira" element={<BlockTrustVsSwanBitcoinIRAPage />} />
              <Route path="research/crypto-ira-industry-report-2026" element={<CryptoIRAIndustryReport2026Page />} />
              <Route path="investor/best-crypto-ira-high-net-worth" element={<BestCryptoIRAHighNetWorthPage />} />
              <Route path="investor/best-crypto-ira-self-employed" element={<BestCryptoIRASelfEmployedPage />} />
              <Route path="investor/best-crypto-ira-bitcoin-only" element={<BestCryptoIRABitcoinOnlyPage />} />
              <Route path="investor/best-crypto-ira-retirees" element={<BestCryptoIRARetireesPage />} />
              <Route path="investor/best-crypto-ira-active-traders" element={<BestCryptoIRAActiveTradersPage />} />
              <Route path="investor/best-crypto-ira-altcoins" element={<BestCryptoIRAAltcoinsPage />} />
              <Route path="investor/best-crypto-ira-rollover" element={<BestCryptoIRARolloverPage />} />
              <Route path="investor/best-crypto-ira-beginners" element={<BestCryptoIRABeginnersPage />} />
              <Route path="education/crypto-ira-tax-guide-2026" element={<CryptoIRATaxGuide2026Page />} />
              <Route path="local/best-crypto-ira-minnesota" element={<BestCryptoIRAMNPage />} />
              <Route path="local/best-crypto-ira-wisconsin" element={<BestCryptoIRAWIPage />} />
              <Route path="local/best-crypto-ira-indiana" element={<BestCryptoIRAINPage />} />
              <Route path="local/best-crypto-ira-missouri" element={<BestCryptoIRAMOPage />} />
              <Route path="local/best-crypto-ira-south-carolina" element={<BestCryptoIRASCPage />} />
              <Route path="local/best-crypto-ira-connecticut" element={<BestCryptoIRACTPage />} />
              <Route path="local/best-crypto-ira-louisiana" element={<BestCryptoIRALAPage />} />
              <Route path="local/best-crypto-ira-kansas" element={<BestCryptoIRAKSPage />} />
              <Route path="local/best-crypto-ira-kentucky" element={<BestCryptoIRAKYPage />} />
              <Route path="local/best-crypto-ira-oklahoma" element={<BestCryptoIRAOKPage />} />
              <Route path="local/best-crypto-ira-alabama" element={<BestCryptoIRAALPage />} />
              <Route path="local/best-crypto-ira-iowa" element={<BestCryptoIRAIAPage />} />
              <Route path="local/best-crypto-ira-idaho" element={<BestCryptoIRAIDPage />} />
              <Route path="local/best-crypto-ira-nebraska" element={<BestCryptoIRANEPage />} />
              <Route path="local/best-crypto-ira-new-mexico" element={<BestCryptoIRANMPage />} />
              <Route path="local/best-crypto-ira-new-hampshire" element={<BestCryptoIRANHPage />} />
              <Route path="local/best-crypto-ira-hawaii" element={<BestCryptoIRAHIPage />} />
              <Route path="local/best-crypto-ira-arkansas" element={<BestCryptoIRAARPage />} />
              <Route path="local/best-crypto-ira-wyoming" element={<BestCryptoIRAWYPage />} />
              <Route path="local/best-crypto-ira-west-virginia" element={<BestCryptoIRAWVPage />} />
              <Route path="local/best-crypto-ira-south-dakota" element={<BestCryptoIRASDPage />} />
              <Route path="local/best-crypto-ira-alaska" element={<BestCryptoIRAAKPage />} />
              <Route path="local/best-crypto-ira-delaware" element={<BestCryptoIRADEPage />} />
              <Route path="local/best-crypto-ira-mississippi" element={<BestCryptoIRAMSPage />} />
              <Route path="local/best-crypto-ira-maine" element={<BestCryptoIRAMEPage />} />
              <Route path="local/best-crypto-ira-rhode-island" element={<BestCryptoIRARIPage />} />
              <Route path="local/best-crypto-ira-montana" element={<BestCryptoIRAMTPage />} />
              <Route path="local/best-crypto-ira-vermont" element={<BestCryptoIRAVTPage />} />
              <Route path="local/best-crypto-ira-north-dakota" element={<BestCryptoIRANDPage />} />
              <Route path="local/best-crypto-ira-illinois" element={<BestCryptoIRAILPage />} />
              <Route path="local/best-crypto-ira-pennsylvania" element={<BestCryptoIRAPAPage />} />
              <Route path="local/best-crypto-ira-georgia" element={<BestCryptoIRAGAPage />} />
              <Route path="local/best-crypto-ira-colorado" element={<BestCryptoIRACOPage />} />
              <Route path="local/best-crypto-ira-washington" element={<BestCryptoIRAWAPage />} />
              <Route path="local/best-crypto-ira-north-carolina" element={<BestCryptoIRANCPage />} />
              <Route path="local/best-crypto-ira-ohio" element={<BestCryptoIRAOHPage />} />
              <Route path="local/best-crypto-ira-new-jersey" element={<BestCryptoIRANJPage />} />
              <Route path="local/best-crypto-ira-arizona" element={<BestCryptoIRAAZPage />} />
              <Route path="local/best-crypto-ira-michigan" element={<BestCryptoIRAMIPage />} />
              <Route path="local/best-crypto-ira-virginia" element={<BestCryptoIRAVAPage />} />
              <Route path="local/best-crypto-ira-nevada" element={<BestCryptoIRANVPage />} />
              <Route path="local/best-crypto-ira-massachusetts" element={<BestCryptoIRAMAPage />} />
              <Route path="local/best-crypto-ira-maryland" element={<BestCryptoIRAMDPage />} />
              <Route path="local/best-crypto-ira-tennessee" element={<BestCryptoIRATNPage />} />
              <Route path="local/best-crypto-ira-utah" element={<BestCryptoIRAUTPage />} />
              <Route path="local/best-crypto-ira-oregon" element={<BestCryptoIRAORPage />} />
              <Route path="local/best-crypto-ira-new-york" element={<BestCryptoIRANYPage />} />
              <Route path="local/best-crypto-ira-florida" element={<BestCryptoIRAFLPage />} />
              <Route path="local/best-crypto-ira-texas" element={<BestCryptoIRATXPage />} />
              <Route path="local/best-crypto-ira-california" element={<BestCryptoIRACAPage />} />

              <Route path="quiz" element={<IRAFitQuizPage />} />

              <Route path="awards" element={<AwardsHubPage />} />
              <Route path="awards/best-crypto-ira-2026" element={<BestCryptoIra2026AwardPage />} />
              <Route path="awards/best-gold-ira-2026" element={<BestGoldIra2026AwardPage />} />
              <Route path="awards/best-fee-transparency-2026" element={<BestFeeTransparency2026AwardPage />} />
              <Route path="awards/best-customer-service-2026" element={<BestCustomerService2026AwardPage />} />
              <Route path="awards/best-crypto-ira-2025" element={<BestCryptoIra2025AwardPage />} />
              <Route path="awards/best-gold-ira-2025" element={<BestGoldIra2025AwardPage />} />
              <Route path="*" element={<NotFoundPage />} />
            </Route>
          </Routes>
        </Suspense>
      </Router>
    </QueryClientProvider>
  )
}

export default App
