import axios from 'axios'

// In production, API calls go to the same origin via Nginx proxy.
// In development, Vite dev server proxies /api → localhost:8000.
const BASE_URL = '/api/v1'

const apiClient = axios.create({
  baseURL: BASE_URL,
  timeout: 10000,
  headers: { 'Content-Type': 'application/json' },
})

export interface Provider {
  id: number
  slug: string
  name: string
  category: string
  tagline: string | null
  website: string | null
  affiliate_url: string | null
  setup_fee: string | null
  annual_fee: string | null
  transaction_fee: string | null
  min_investment: string | null
  supported_assets: string[] | null
  asset_count: number | null
  custody_provider: string | null
  storage_type: string | null
  insurance_coverage: string | null
  bbb_rating: string | null
  founded_year: number | null
  headquarters: string | null
  score_fees: number | null
  score_assets: number | null
  score_security: number | null
  score_compliance: number | null
  score_support: number | null
  score_reputation: number | null
  score_overall: number | null
  rank_overall: number | null
  is_featured: boolean
  logo_url: string | null
  review_slug: string | null
  meta_description: string | null
  review_count: number | null
  is_active: boolean
  created_at: string
  updated_at: string
}

export interface ProviderListResponse {
  providers: Provider[]
  total: number
  category: string | null
}

export const providersApi = {
  getRanked: async (category: 'crypto' | 'precious_metals', limit = 10): Promise<ProviderListResponse> => {
    const { data } = await apiClient.get<ProviderListResponse>('/providers/ranked', {
      params: { category, limit },
    })
    return data
  },

  getAll: async (category?: 'crypto' | 'precious_metals'): Promise<ProviderListResponse> => {
    const { data } = await apiClient.get<ProviderListResponse>('/providers/', {
      params: category ? { category } : {},
    })
    return data
  },

  getBySlug: async (slug: string): Promise<Provider> => {
    const { data } = await apiClient.get<Provider>(`/providers/${slug}`)
    return data
  },
}
