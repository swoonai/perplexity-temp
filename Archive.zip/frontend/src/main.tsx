import { StrictMode } from 'react'
import { createRoot } from 'react-dom/client'
import { QueryClient, QueryClientProvider } from '@tanstack/react-query'
import { HelmetProvider } from 'react-helmet-async'
import './index.css'
import App from './App.tsx'

const queryClient = new QueryClient({
  defaultOptions: {
    queries: {
      retry: 2,
      refetchOnWindowFocus: false,
    },
  },
})

// Seed React Query cache from prerender-injected provider data.
// During prerender, prerender.cjs fetches all providers from the live API and
// injects window.__PROVIDER_CACHE__ into the page <head> before Puppeteer renders.
// This ensures useProvider() resolves immediately (isLoading: false) during
// prerender so the full page content is captured in static HTML for crawlers.
declare global {
  interface Window {
    // eslint-disable-next-line @typescript-eslint/no-explicit-any
    __PROVIDER_CACHE__?: Record<string, any>
  }
}
if (typeof window !== 'undefined' && window.__PROVIDER_CACHE__) {
  const cache = window.__PROVIDER_CACHE__
  // Seed individual provider queries: ['providers', 'detail', slug]
  if (cache.bySlug && typeof cache.bySlug === 'object') {
    for (const [slug, data] of Object.entries(cache.bySlug)) {
      queryClient.setQueryData(['providers', 'detail', slug], data)
    }
  }
  // Seed ranked provider queries: ['providers', 'ranked', category, limit]
  if (cache.ranked && typeof cache.ranked === 'object') {
    for (const [key, data] of Object.entries(cache.ranked)) {
      const parts = key.split(':')
      const category = parts[0]
      const limit = Number(parts[1])
      queryClient.setQueryData(['providers', 'ranked', category, limit], data)
    }
  }
  // Seed all-providers queries: ['providers', 'all', category?]
  if (cache.all) {
    queryClient.setQueryData(['providers', 'all', undefined], cache.all)
  }
  if (cache.allCrypto) {
    queryClient.setQueryData(['providers', 'all', 'crypto'], cache.allCrypto)
  }
  if (cache.allMetals) {
    queryClient.setQueryData(['providers', 'all', 'precious_metals'], cache.allMetals)
  }
}

createRoot(document.getElementById('root')!).render(
  <StrictMode>
    <HelmetProvider>
      <QueryClientProvider client={queryClient}>
        <App />
      </QueryClientProvider>
    </HelmetProvider>
  </StrictMode>,
)
