/**
 * prerender.cjs — Post-build static pre-rendering for iraresearchhub.com
 *
 * Runs AFTER `vite build` to generate static HTML for every route.
 * This makes the site visible to AI crawlers (GPTBot, ClaudeBot, PerplexityBot)
 * which cannot execute JavaScript.
 *
 * Usage: node prerender.cjs
 * Called from: npm run build (via package.json "build" script)
 *
 * Provider data strategy:
 *   During prerender, the React app makes API calls to /api/v1/providers/...
 *   which resolve to localhost:PORT — the local static server, not the real backend.
 *   This causes useProvider() to stay in isLoading:true and the page renders as a
 *   loading skeleton with no data (dashes for scores, fees, custody, etc.).
 *
 *   Fix: Before rendering, we fetch all provider data from the live API
 *   (iraresearchhub.com), then inject it as a <script> tag into dist/index.html
 *   that sets window.__PROVIDER_CACHE__ before React mounts. main.tsx reads this
 *   cache and seeds React Query so useProvider() resolves immediately with full data.
 *   After all routes are rendered, we restore the original index.html.
 */

const puppeteer = require('puppeteer')
const http = require('http')
const https = require('https')
const fs = require('fs')
const path = require('path')

const DIST_DIR = path.join(__dirname, 'dist')
// Use a random port in range 7700-7799 to avoid conflicts with concurrent runs
const PORT = 7700 + Math.floor(Math.random() * 100)
const BASE_URL = `http://localhost:${PORT}`
const RENDER_TIMEOUT = 5000 // ms to wait for React to render after networkidle0
const LIVE_API = 'https://iraresearchhub.com/api/v1'

// All routes to pre-render
const ROUTES = [
  '/',
  '/about',
  '/methodology',
  '/privacy',
  '/terms',
  '/editorial-policy',
  '/author/james-mitchell',
  // Crypto IRA
  '/crypto-ira',
  '/crypto-ira/best-companies',
  '/crypto-ira/blocktrust-ira-review',
  '/crypto-ira/bitcoin-ira-review',
  '/crypto-ira/itrustcapital-review',
  '/crypto-ira/alto-crypto-ira-review',
  '/crypto-ira/bitira-review',
  '/crypto-ira/swan-bitcoin-ira-review',
  '/crypto-ira/rocket-dollar-review',
  '/crypto-ira/unchained-ira-review',
  '/crypto-ira/401k-to-crypto-ira-rollover',
  '/crypto-ira/what-is-a-crypto-ira',
  // Precious Metals IRA
  '/precious-metals-ira',
  '/precious-metals-ira/best-companies',
  '/precious-metals-ira/genesis-gold-group-review',
  '/precious-metals-ira/augusta-precious-metals-review',
  '/precious-metals-ira/birch-gold-group-review',
  '/precious-metals-ira/goldco-review',
  '/precious-metals-ira/american-hartford-gold-review',
  '/precious-metals-ira/lear-capital-review',
  '/precious-metals-ira/noble-gold-investments-review',
  '/precious-metals-ira/advantage-gold-review',
  '/precious-metals-ira/goldencrest-metals-review',
  '/precious-metals-ira/patriot-gold-group-review',
  '/precious-metals-ira/oxford-gold-group-review',
  '/precious-metals-ira/preserve-gold-review',
  '/precious-metals-ira/rosland-capital-review',
  '/precious-metals-ira/allegiance-gold-review',
  '/precious-metals-ira/401k-to-gold-ira-rollover',
  // Comparison & Research
  '/gold-ira-vs-crypto-ira',
  '/crypto-ira/blocktrust-ira-vs-bitcoin-ira',
  '/crypto-ira/blocktrust-ira-vs-itrustcapital',
  '/crypto-ira/bitcoin-ira-vs-itrustcapital',
  '/precious-metals-ira/augusta-vs-goldco',
  '/precious-metals-ira/birch-gold-vs-augusta',
  '/precious-metals-ira/gold-ira-vs-silver-ira',
  '/precious-metals-ira/how-to-open-gold-ira',
  '/precious-metals-ira/how-to-buy-gold-in-ira',
  '/research/crypto-ira-fees-2026',
  '/research/gold-ira-fees-2026',
  // Coin-specific IRA guides
  '/crypto-ira/xrp-ripple-ira',
  '/crypto-ira/litecoin-ira',
  '/crypto-ira/solana-ira',
  '/crypto-ira/dogecoin-ira',
  '/crypto-ira/ethereum-ira',
  // Educational Guide pages
  '/guides/what-is-self-directed-ira',
  '/guides/crypto-in-retirement',
  '/guides/precious-metals-in-ira',
  '/guides/ira-rollover-rules',
  '/guides/how-to-research-sdira-providers',
  '/guides/ira-contribution-limits-2026',
  '/guides/required-minimum-distributions-2026',
  '/guides/crypto-ira-vs-buying-directly',
  '/guides/gold-ira-vs-gold-etf',
  '/guides/ira-tax-strategies-high-income',
  // Competitor reviews
  '/crypto-ira/fidelity-crypto-ira-review',
]

// ─── Fetch helpers ────────────────────────────────────────────────────────────

/**
 * Fetch JSON from a URL using Node's built-in https module.
 * Returns parsed JSON or null on error.
 */
function fetchJson(url) {
  return new Promise((resolve) => {
    const req = https.get(url, { timeout: 15000 }, (res) => {
      let body = ''
      res.on('data', chunk => { body += chunk })
      res.on('end', () => {
        try {
          resolve(JSON.parse(body))
        } catch {
          resolve(null)
        }
      })
    })
    req.on('error', () => resolve(null))
    req.on('timeout', () => { req.destroy(); resolve(null) })
  })
}

/**
 * Fetch all provider data from the live API and build the cache object
 * that will be injected as window.__PROVIDER_CACHE__.
 */
async function fetchProviderCache() {
  console.log('[prerender] Fetching provider data from live API...')

  const allData = await fetchJson(`${LIVE_API}/providers/?limit=100`)
  if (!allData || !allData.providers) {
    console.warn('[prerender] WARNING: Could not fetch provider list from live API. Pages will render without provider data.')
    return null
  }

  const providers = allData.providers
  console.log(`[prerender] Fetched ${providers.length} providers from live API`)

  // Build bySlug map
  const bySlug = {}
  for (const p of providers) {
    bySlug[p.slug] = p
  }

  // Build ranked maps
  const cryptoProviders = providers
    .filter(p => p.category === 'crypto')
    .sort((a, b) => (a.rank_overall || 99) - (b.rank_overall || 99))
  const metalsProviders = providers
    .filter(p => p.category === 'precious_metals')
    .sort((a, b) => (a.rank_overall || 99) - (b.rank_overall || 99))

  const ranked = {
    'crypto:10': { providers: cryptoProviders.slice(0, 10), total: cryptoProviders.length, category: 'crypto' },
    'precious_metals:10': { providers: metalsProviders.slice(0, 10), total: metalsProviders.length, category: 'precious_metals' },
    'crypto:5': { providers: cryptoProviders.slice(0, 5), total: cryptoProviders.length, category: 'crypto' },
    'precious_metals:5': { providers: metalsProviders.slice(0, 5), total: metalsProviders.length, category: 'precious_metals' },
  }

  return {
    bySlug,
    ranked,
    all: { providers, total: providers.length, category: null },
    allCrypto: { providers: cryptoProviders, total: cryptoProviders.length, category: 'crypto' },
    allMetals: { providers: metalsProviders, total: metalsProviders.length, category: 'precious_metals' },
  }
}

/**
 * Inject window.__PROVIDER_CACHE__ into dist/index.html as a <script> tag.
 * Returns the original HTML so it can be restored after prerender.
 */
function injectCacheIntoIndexHtml(providerCache) {
  const indexPath = path.join(DIST_DIR, 'index.html')
  const original = fs.readFileSync(indexPath, 'utf-8')

  const cacheScript = `<script>window.__PROVIDER_CACHE__=${JSON.stringify(providerCache)};</script>`

  // Inject immediately before the <script type="module"> tag (the React bundle)
  // so window.__PROVIDER_CACHE__ is set before React mounts and useProvider() runs.
  const moduleScriptMatch = original.match(/<script type="module"[^>]*>/)
  if (moduleScriptMatch) {
    const injected = original.replace(moduleScriptMatch[0], `${cacheScript}\n${moduleScriptMatch[0]}`)
    fs.writeFileSync(indexPath, injected, 'utf-8')
    console.log(`[prerender] Provider cache injected before module bundle (${Math.round(cacheScript.length / 1024)}kB)`)
    return original
  }

  // Fallback: inject before </head>
  const injected = original.replace('</head>', `${cacheScript}\n</head>`)
  if (injected === original) {
    console.warn('[prerender] WARNING: Could not find injection point in index.html')
    return original
  }

  fs.writeFileSync(indexPath, injected, 'utf-8')
  console.log(`[prerender] Provider cache injected into index.html (${Math.round(cacheScript.length / 1024)}kB script tag)`)
  return original
}

// ─── HTML cleaning ──────────────────────────────────────────────────────────────

/**
 * Strip tracking pixel script tags from the captured HTML.
 * GTM and other scripts inject additional <script> tags into the DOM during
 * Puppeteer rendering. These get baked into the static HTML and cause:
 * 1. Bing UET firing with localhost:PORT as the page URL
 * 2. Unnecessary third-party scripts loading for crawlers
 * We remove all known tracking/analytics script tags from the captured HTML.
 */
function cleanHtml(html) {
  // First pass: remove comment-delimited tracking blocks.
  // These are inline <script> blocks where the tracking domain appears inside
  // the JS code body (not in a src= attribute), so src-based regexes don't match.
  html = html
    .replace(/<!--\s*Microsoft UET Tag[\s\S]*?<!--\s*End Microsoft UET Tag\s*-->/gi, '')
    .replace(/<!--\s*Taboola Pixel[^-]*-->[\s\S]*?<!--\s*End Taboola Pixel\s*-->/gi, '')
    .replace(/<!--\s*Reddit Pixel\s*-->\s*<script>[\s\S]*?<\/script>/gi, '')
    .replace(/<!--\s*Clicky analytics\s*-->\s*<script>[\s\S]*?<\/script>/gi, '')
    .replace(/<!--\s*Lemlist[^-]*-->[\s\S]*?<\/script>/gi, '')

  // Second pass: remove script tags for known tracking/analytics domains
  // Uses a regex that matches the full <script ...>...</script> or self-closing tags
  const trackingPatterns = [
    /<!--\s*Google Tag Manager[\s\S]*?<!--\s*End Google Tag Manager[\s\S]*?-->/gi,
    /<script[^>]*bat\.bing\.com[^>]*>[\s\S]*?<\/script>/gi,
    /<script[^>]*bat\.bing\.com[^>]*\/>/gi,
    /<script[^>]*bat\.bing\.com[^>]*><\/script>/gi,
    /<script[^>]*redditstatic\.com[^>]*>[\s\S]*?<\/script>/gi,
    /<script[^>]*redditstatic\.com[^>]*><\/script>/gi,
    /<script[^>]*taboola\.com[^>]*>[\s\S]*?<\/script>/gi,
    /<script[^>]*taboola\.com[^>]*><\/script>/gi,
    /<script[^>]*tfa\.js[^>]*>[\s\S]*?<\/script>/gi,
    /<script[^>]*tfa\.js[^>]*><\/script>/gi,
    /<script[^>]*googletagmanager\.com[^>]*>[\s\S]*?<\/script>/gi,
    /<script[^>]*googletagmanager\.com[^>]*><\/script>/gi,
    /<script[^>]*google-analytics\.com[^>]*>[\s\S]*?<\/script>/gi,
    /<script[^>]*lemlist\.com[^>]*>[\s\S]*?<\/script>/gi,
    /<script[^>]*lemlist\.com[^>]*><\/script>/gi,
    /<script[^>]*connect\.facebook\.net[^>]*>[\s\S]*?<\/script>/gi,
    /<script[^>]*connect\.facebook\.net[^>]*><\/script>/gi,
    /<noscript[^>]*>[\s\S]*?googletagmanager[\s\S]*?<\/noscript>/gi,
    /<noscript[^>]*>[\s\S]*?bat\.bing[\s\S]*?<\/noscript>/gi,
    // Inline GTM dataLayer scripts
    /<script>[\s\S]*?window\.dataLayer[\s\S]*?<\/script>/gi,
    // Bing UET inline config
    /<script>[\s\S]*?window\.uetq[\s\S]*?<\/script>/gi,
  ]

  let cleaned = html
  for (const pattern of trackingPatterns) {
    cleaned = cleaned.replace(pattern, '')
  }
  return cleaned
}

// ─── Static file server ───────────────────────────────────────────────────────

function createServer() {
  return new Promise((resolve) => {
    const server = http.createServer((req, res) => {
      let filePath = req.url.split('?')[0]

      // Map routes to index.html for SPA routing
      if (!filePath.includes('.')) {
        filePath = '/index.html'
      }

      const fullPath = path.join(DIST_DIR, filePath)

      if (fs.existsSync(fullPath) && fs.statSync(fullPath).isFile()) {
        const ext = path.extname(fullPath)
        const contentTypes = {
          '.html': 'text/html',
          '.js': 'application/javascript',
          '.css': 'text/css',
          '.png': 'image/png',
          '.svg': 'image/svg+xml',
          '.json': 'application/json',
        }
        res.writeHead(200, { 'Content-Type': contentTypes[ext] || 'text/plain' })
        fs.createReadStream(fullPath).pipe(res)
      } else {
        // Fallback to index.html for SPA
        res.writeHead(200, { 'Content-Type': 'text/html' })
        fs.createReadStream(path.join(DIST_DIR, 'index.html')).pipe(res)
      }
    })

    server.listen(PORT, () => {
      console.log(`[prerender] Static server running on port ${PORT}`)
      resolve(server)
    })
  })
}

// ─── Route rendering ──────────────────────────────────────────────────────────

async function prerenderRoute(page, route) {
  const url = `${BASE_URL}${route}`

  try {
    await page.goto(url, { waitUntil: 'networkidle0', timeout: 30000 })
    // Wait additional time for React to fully render
    await new Promise(r => setTimeout(r, RENDER_TIMEOUT))

    const rawHtml = await page.content()

    // Verify the page actually rendered (not just the empty shell)
    const rootContent = await page.$eval('#root', el => el.innerHTML.length)
    if (rootContent < 100) {
      console.warn(`[prerender] WARNING: Route ${route} may not have rendered fully (root innerHTML: ${rootContent} chars)`)
    }

    // Strip tracking pixels injected by GTM during rendering
    const html = cleanHtml(rawHtml)
    return html
  } catch (err) {
    console.error(`[prerender] ERROR rendering ${route}: ${err.message}`)
    return null
  }
}

function writeRouteFile(route, html) {
  let outputPath
  if (route === '/') {
    outputPath = path.join(DIST_DIR, 'index.html')
  } else {
    // Create directory structure: /crypto-ira/blocktrust-ira-review → dist/crypto-ira/blocktrust-ira-review/index.html
    const routeDir = path.join(DIST_DIR, route.slice(1))
    fs.mkdirSync(routeDir, { recursive: true })
    outputPath = path.join(routeDir, 'index.html')
  }

  fs.writeFileSync(outputPath, html, 'utf-8')
  const size = Math.round(html.length / 1024)
  console.log(`[prerender] ✓ ${route} → ${outputPath} (${size}kB)`)
}

// ─── Main ─────────────────────────────────────────────────────────────────────

async function main() {
  console.log('[prerender] Starting pre-rendering for', ROUTES.length, 'routes...')

  // Check dist exists
  if (!fs.existsSync(DIST_DIR)) {
    console.error('[prerender] ERROR: dist/ directory not found. Run vite build first.')
    process.exit(1)
  }

  // Step 1: Fetch provider data from live API and inject into index.html
  // This seeds window.__PROVIDER_CACHE__ so React Query is pre-populated
  // and useProvider() resolves immediately without an API call during prerender.
  const providerCache = await fetchProviderCache()
  let originalIndexHtml = null
  if (providerCache) {
    originalIndexHtml = injectCacheIntoIndexHtml(providerCache)
  }

  const server = await createServer()

  const browser = await puppeteer.launch({
    headless: true,
    args: [
      '--no-sandbox',
      '--disable-setuid-sandbox',
      '--disable-dev-shm-usage',
      '--disable-gpu',
    ],
  })

  const page = await browser.newPage()

  // Block unnecessary requests to speed up rendering
  // IMPORTANT: Block all analytics/pixel/tracking scripts — they fire during prerender
  // and capture window.location = localhost:PORT, baking that into the static HTML.
  // This was causing Bing UET to record all conversions as localhost:7777 instead of
  // iraresearchhub.com. All tracking still fires correctly for real users in the browser.
  await page.setRequestInterception(true)
  page.on('request', (req) => {
    const type = req.resourceType()
    const url = req.url()
    // Block external analytics, tracking pixels, fonts, and images
    if (
      type === 'image' ||
      // Google
      url.includes('googletagmanager') ||
      url.includes('google-analytics') ||
      url.includes('fonts.googleapis') ||
      // Microsoft Bing UET
      url.includes('bat.bing.com') ||
      url.includes('bing.com/bat') ||
      url.includes('bing.com/p/action') ||
      // Taboola
      url.includes('taboola.com') ||
      url.includes('tfa.js') ||
      // Reddit
      url.includes('redditstatic.com') ||
      url.includes('rdt.js') ||
      // Lemlist
      url.includes('lemlist.com') ||
      // Meta/Facebook
      url.includes('connect.facebook.net') ||
      // Generic tracking
      url.includes('/pixel') ||
      url.includes('/beacon') ||
      url.includes('/track')
    ) {
      req.abort()
    } else {
      req.continue()
    }
  })

  let successCount = 0
  let errorCount = 0

  for (const route of ROUTES) {
    const html = await prerenderRoute(page, route)
    if (html) {
      writeRouteFile(route, html)
      successCount++
    } else {
      errorCount++
    }
  }

  await browser.close()
  server.close()

  // Step 2: Restore the original index.html (without the injected cache script).
  // The rendered route files already have the provider data baked in via Puppeteer.
  // The index.html served to real users should NOT have the cache script — it would
  // be stale and real users should always get fresh data from the API.
  if (originalIndexHtml) {
    fs.writeFileSync(path.join(DIST_DIR, 'index.html'), originalIndexHtml, 'utf-8')
    console.log('[prerender] Restored original index.html (cache script removed)')
  }

  console.log(`\n[prerender] Complete: ${successCount} routes rendered, ${errorCount} errors`)

  if (errorCount > 0) {
    console.warn('[prerender] Some routes failed to render. Check errors above.')
    // Don't exit with error code — build should still succeed
  }
}

main().catch((err) => {
  // If Chromium is not available (e.g. CI without system deps), warn but don't fail the build
  const isChromiumError = err.message && (
    err.message.includes('Could not find Chrome') ||
    err.message.includes('Failed to launch') ||
    err.message.includes('spawn') ||
    err.message.includes('ENOENT')
  )
  if (isChromiumError) {
    console.warn('[prerender] WARNING: Chromium not available, skipping pre-rendering.')
    console.warn('[prerender] Install Chromium system deps or run with Puppeteer bundled Chromium.')
    console.warn('[prerender] Error:', err.message)
    process.exit(0) // Don't fail the build
  } else {
    console.error('[prerender] Fatal error:', err)
    process.exit(1)
  }
})
